// U19 -- one drag, one write.
//
// Reordering a day PATCHed every row in it, sequentially, awaiting each. Eight
// items on a day meant eight round trips one after another with "Saving order…"
// on screen throughout, and a failure at row five left the day half-renumbered
// with nothing to put it back. It is now a single batch, which D1 runs as one
// transaction: all of it lands or none of it does.
//
// Verified live against the dev API on two throwaway trips:
//   reorder 4 activities        -> {ok, asked:4, updated:4}, order D1 C2 B3 A4
//   column vs blob              -> sort_order and json_extract($.sort_order)
//                                  agree on every row (1/1, 2/2, 3/3, 4/4)
//   another trip's item         -> updated:0, and the foreign row stayed at 0
//   kind "expense"              -> "Cannot reorder expense."
//   kind "constructor"          -> "Cannot reorder constructor."
//   the same row twice          -> "The same item appears twice."
//   an empty list               -> "Nothing to reorder."
//   sort_order -1, and 1.5      -> "Bad item in reorder."
//   after every refusal         -> the existing order was untouched
//   a row deleted mid-drag      -> {asked:4, updated:3}, survivors keep theirs
//
// And driven through the real UI with a synthesized HTML5 drag, counting every
// non-GET fetch from the page: dragging the last of four rows onto the first
// produced exactly ONE write, POST /v1/trip/{id}/reorder, where the old code
// issued four sequential PATCHes. The row moved to the front and the other
// three kept their relative order.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");
const core = fs.readFileSync("functions/api/_core.js", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

const fn = core.slice(core.indexOf("async function reorderItems"), core.indexOf("async function patchRow"));
const client = app.slice(app.indexOf("async function reorderWithin"), app.indexOf("// ---- trip health check ----"));

console.log("\nthe day goes in one request");
t("there is a batch endpoint", /async function reorderItems\(db, tripId, body\)/.test(core), true);
t("routed at /v1/trip/{id}/reorder",
  /if \(what === "reorder" && method === "POST"\) return reorderItems\(db, tripId, await readBody\(request\)\);/.test(core), true);
// The whole point: one statement per row, handed to D1 together.
t("statements are collected, not awaited one by one", /stmts\.push\(db\.prepare\(/.test(fn), true);
t("and run as one batch", /const res = await db\.batch\(stmts\);/.test(fn), true);
// Extract the loop BODY by brace matching. A regex of the form
// /for \(...\) \{[\s\S]*?await/ looks right and is not: it is lazy but
// unbounded, so it happily runs past the loop's closing brace and matches the
// `await db.batch` that follows -- reporting a problem in code that is correct.
const loopBody = (() => {
  const at = fn.indexOf("for (const it of items)");
  let depth = 0, i = fn.indexOf("{", at);
  const from = i;
  for (; i < fn.length; i++) {
    if (fn[i] === "{") depth++;
    else if (fn[i] === "}") { depth--; if (!depth) break; }
  }
  return fn.slice(from, i + 1);
})();
t("the loop body is found", loopBody.length > 400, true);
t("and contains no await at all", /await/.test(loopBody), false);

console.log("\nit cannot be pointed at another trip");
// trip_id in the WHERE, not merely in the URL. Without it the body could name
// any row in the database and this would renumber someone else's itinerary.
// Live: sending a foreign id returned updated:0 and left that row at 0.
t("every statement is bound to this trip", /WHERE id=\? AND trip_id=\? AND deleted_at IS NULL/.test(fn), true);
t("with the trip id bound after the row id", /\.bind\(order, ts, order, ts, id, tripId\)/.test(fn), true);
t("and deleted rows are excluded", /deleted_at IS NULL/.test(fn), true);

console.log("\nonly the three kinds that carry an order");
t("resolved through the null-prototype map", /const info = BY_SINGULAR\[kind\];/.test(fn), true);
// Expenses have a sort_order column and are not draggable; accepting one would
// let a client write an order that nothing reads.
t("and checked against ORDERED_TABLES", /if \(!info \|\| !ORDERED_TABLES\.has\(info\.table\)\)/.test(fn), true);
t("a non-string kind cannot reach the lookup", /typeof it\.kind === "string"/.test(fn), true);

console.log("\nbad input is refused before anything is written");
t("an empty list", /if \(!items \|\| !items\.length\) return err\("Nothing to reorder\.", 400\);/.test(fn), true);
// A day with more rows than this is not something a person dragged.
t("an implausible number of items", /if \(items\.length > 200\)/.test(fn), true);
t("a non-array body", /Array\.isArray\(body\.items\)/.test(fn), true);
t("a non-integer or negative position", /!Number\.isInteger\(order\) \|\| order < 0/.test(fn), true);
t("an unparseable id", /!Number\.isFinite\(id\)/.test(fn), true);
// The same row twice would make the outcome depend on statement order.
t("the same row named twice", /if \(seen\.has\(key\)\) return err\("The same item appears twice\.", 400\);/.test(fn), true);
t("keyed by table and id, not id alone", /const key = info\.table \+ ":" \+ id;/.test(fn), true);
// Every refusal returns before db.batch, so a rejected request writes nothing.
t("all validation precedes the write", fn.indexOf("return err(\"Bad item in reorder.\", 400)") < fn.indexOf("await db.batch"), true);

console.log("\nthe column and the blob move together");
// The blob is the copy compare-and-set reads. Letting them disagree would make
// a later if_match on sort_order check a value that is no longer stored.
// reflowDays already pairs them this way; this follows it.
t("json_set writes the blob", /data=json_set\(data,'\$\.sort_order',\?,'\$\.updated_at',\?\)/.test(fn), true);
t("alongside the column", /SET sort_order=\?, updated_at=\?,/.test(fn), true);
t("with one timestamp for the whole batch", /const ts = nowIso\(\);/.test(fn), true);

console.log("\nwhat actually changed is reported back");
t("the count is summed from the batch results", /r\.meta && r\.meta\.changes/.test(fn), true);
t("and both numbers are returned", /json\(\{ ok: true, asked: stmts\.length, updated: changed \}\)/.test(fn), true);

console.log("\nthe client sends the day, once");
t("it builds one list of positions", /var order = block\.map\(function \(n, i\) \{/.test(client), true);
t("numbered from one", /sort_order: i \+ 1/.test(client), true);
t("posted to the batch endpoint",
  /await api\("\/v1\/trip\/" \+ trip\.id \+ "\/reorder",\s*\n\s*\{ method: "POST", body: JSON\.stringify\(\{ items: order \}\) \}\);/.test(client), true);
// The old shape: a PATCH per row inside a loop.
t("no per-row PATCH survives", /method: "PATCH", body: JSON\.stringify\(\{ sort_order: i \+ 1 \}\)/.test(app), false);
t("and no loop of awaited writes", /for \(var i = 0; i < block\.length; i\+\+\) \{[\s\S]*?await api/.test(app), false);

console.log("\na row that vanished mid-drag is said out loud");
// Live: asked 4, updated 3 after deleting one between the drag and the drop.
// The reorder that landed is still correct, so this reports rather than fails.
t("a short count is noticed", /res\.updated != null && res\.updated < order\.length/.test(client), true);
t("and named in the toast", /" item" \+ \(order\.length - res\.updated === 1 \? " was" : "s were"\) \+ " no longer there\."/.test(client), true);
t("a full count just says saved", /toast\("Order saved"\);/.test(client), true);
t("and a failure still reports itself", /toast\("Couldn't save order: " \+ e\.message\);/.test(client), true);
// The redraw is what reconciles the screen with whatever is really there.
t("the trip is redrawn either way", /openTrip\(trip\);/.test(client), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
