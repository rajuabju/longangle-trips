// The expense report.
//
// A trip's costs in one CSV, for filing a claim. Two things make it either
// useful or actively misleading:
//
// BOTH sources have to be in it. A business trip's real cost is the flight and
// the hotel far more than the taxis, and a report listing only the standalone
// expenses would understate it by an order of magnitude while looking complete.
//
// And the escaping has to be right. Hotel names carry commas constantly
// ("Hyatt Place, Tempe"), and a CSV that breaks on one silently shifts every
// column after it — which is the kind of error that reaches an accounts
// department before anyone notices.
//
// Fixtures are invented.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");

function grab(name) {
  const i = src.indexOf("  function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}

globalThis.dayKey = (u) => (u ? String(u).slice(0, 10) : null);
// Read from the source, not restated: this copy was already stale the day
// "Credit" was added, and a hand-kept list agrees with itself forever.
globalThis.BUDGET_CATS = eval(src.slice(src.indexOf("  var BUDGET_CATS = ") + 19,
  src.indexOf(";", src.indexOf("  var BUDGET_CATS = "))));
// Same rule as BUDGET_CATS above: read it from the source. This was the last
// hand-kept copy of a shared constant in the suites.
globalThis.KIND_CAT = eval("(" + src.slice(src.indexOf("var KIND_CAT = {") + 15,
  src.indexOf(";", src.indexOf("var KIND_CAT = {"))) + ")");
globalThis.state = { me: { default_currency: "USD" } };
globalThis.DOC_PARENT = { transport: "transportation", hosting: "hosting", activity: "activity", expense: "expense" };
// Receipts are looked up per line; the fixture decides what is attached.
let RECEIPTS = {};
globalThis.docsFor = (o, kind) => RECEIPTS[kind + ":" + (o && o.id)] || [];

const CREDIT_LINE = src.slice(src.indexOf("  var CREDIT_CAT = "),
  src.indexOf(";", src.indexOf("  var CREDIT_CAT = ")) + 1);
const DINING_LINES = src.slice(src.indexOf("  var DINING_CAT = "),
  src.indexOf(";", src.indexOf("  var DINING_TYPES = ")) + 1);
eval(CREDIT_LINE + String.fromCharCode(10) + DINING_LINES + String.fromCharCode(10) +
  ["linkedItem", "priceCurrency", "signedAmount", "linkCategory", "budgetLines",
  "budgetCategories", "bookingDate", "csvCell", "csvLine",
  "expenseRows", "expenseCsv"].map(grab).join(String.fromCharCode(10)) +
  ";Object.assign(globalThis,{CREDIT_CAT,priceCurrency,signedAmount,bookingDate," +
  "csvCell,csvLine,expenseRows,expenseCsv});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

const TRIP = { name: "Phoenix", starts_at: "2026-08-21" };
const DATA = {
  transports: [{ id: 1, company: "Southwest", transport_number: "WN22", price: 318.4,
    currency: "USD", departure_at: "2026-08-21T15:00:00Z", provider_reservation_code: "ABC123" }],
  hostings: [{ id: 10, name: "Hyatt Place, Tempe", price: 412, currency: "USD",
    starts_at: "2026-08-21T22:00:00Z" }],
  activities: [{ id: 20, name: "Client dinner", price: 0, currency: "USD" }],
  expenses: [
    { id: 30, title: "Taxi to the office", price: 41.5, currency: "USD", date: "2026-08-22", category: "Transport" },
    { id: 31, title: "Baggage", price: 35, currency: "USD", date: "2026-08-21",
      linked_kind: "transport", linked_id: 1 },
  ],
};

// ---- what is in the report --------------------------------------------------
const rows = expenseRows(TRIP, DATA);
t("bookings and expenses both appear", rows.length, 4);
t("a flight is in it", rows.some((r) => r.description === "Southwest WN22"), true);
t("so is the hotel", rows.some((r) => r.description === "Hyatt Place, Tempe"), true);
t("bookings are marked as such",
  rows.filter((r) => r.kind === "Booking").length, 2);
t("and expenses as expenses", rows.filter((r) => r.kind === "Expense").length, 2);
// A zero-price activity is not a cost; it would pad a claim with empty lines.
t("a free activity is not a line", rows.some((r) => r.description === "Client dinner"), false);
t("a linked expense says what it belongs to",
  rows.filter((r) => r.description === "Baggage")[0].partOf, "Southwest WN22");
t("a confirmation rides along for the flight",
  rows.filter((r) => r.description === "Southwest WN22")[0].confirmation, "ABC123");

// ---- order ------------------------------------------------------------------
// Chronological, because that is the order a claim is read and the order of the
// card statement it will be checked against.
t("chronological", rows.map((r) => r.date),
  ["2026-08-21", "2026-08-21", "2026-08-21", "2026-08-22"]);
// Undated lines go last: those are the ones needing a date typed in.
const undated = expenseRows(TRIP, { expenses: [
  { id: 1, title: "Something", price: 10, currency: "USD" },
  { id: 2, title: "Dated", price: 10, currency: "USD", date: "2026-08-21" }] });
t("undated lines sort last", undated.map((r) => r.description), ["Dated", "Something"]);

// ---- receipts ---------------------------------------------------------------
RECEIPTS = { "expense:30": [{ title: "Taxi receipt" }] };
const withR = expenseRows(TRIP, DATA);
t("an expense with a receipt says so",
  withR.filter((r) => r.description === "Taxi to the office")[0].receipts, ["Taxi receipt"]);
t("one without says nothing",
  withR.filter((r) => r.description === "Baggage")[0].receipts, []);
// A hotel folio attaches to the hosting, not to a separate expense, and still
// counts as that line's evidence.
RECEIPTS = { "hosting:10": [{ title: "Folio" }] };
t("a booking's own paperwork counts as its receipt",
  expenseRows(TRIP, DATA).filter((r) => r.description === "Hyatt Place, Tempe")[0].receipts, ["Folio"]);
RECEIPTS = {};

// ---- the CSV itself ---------------------------------------------------------
const csv = expenseCsv(TRIP, DATA);
const lines = csv.split("\r\n").filter(Boolean);
t("CRLF line endings, as the format says", /\r\n/.test(csv), true);
t("a header, every row, and a total", lines.length, 1 + 4 + 1);
t("the header names every column", lines[0],
  "Date,Category,Description,Type,Part of,Amount,Currency,Confirmation,Receipt,Receipt files");
t("amounts carry two decimals", /,318\.40,/.test(csv), true);
t("a total per currency", /TOTAL USD,,,806\.90,USD/.test(csv), true);

// The escaping, which is where a CSV goes quietly wrong.
t("a comma in a name is quoted", csvCell("Hyatt Place, Tempe"), '"Hyatt Place, Tempe"');
t("a quote is doubled inside quotes", csvCell('Taxi to "the office"'), '"Taxi to ""the office"""');
t("a newline forces quoting", csvCell("two\nlines"), '"two\nlines"');
t("a plain value is left alone", csvCell("Southwest WN22"), "Southwest WN22");
t("nothing becomes empty, not the word null", csvCell(null), "");
t("zero is not nothing", csvCell(0), "0");
t("the hotel's comma survives into the file",
  csv.indexOf('"Hyatt Place, Tempe"') > 0, true);
// A quoted field must not break the column count for the rows after it.
t("every row has ten columns",
  lines.every((l) => (l.match(/,(?=(?:[^"]*"[^"]*")*[^"]*$)/g) || []).length === 9), true);

// ---- an empty trip ----------------------------------------------------------
t("nothing costed is no rows", expenseRows(TRIP, {}).length, 0);
t("and the file is just a header", expenseCsv(TRIP, {}).split("\r\n").filter(Boolean).length, 1);

// ---- the wiring -------------------------------------------------------------
// Two entries now: the styled .xlsx people read, and the plain .csv systems
// ingest. CSV cannot carry bold or column widths, whatever writes it.
t("the styled report is offered under Export", /Expense Report \(\.xlsx\)/.test(src), true);
t("and the plain CSV stays for imports", /Expense Report \(\.csv, plain\)/.test(src), true);
t("Excel gets a BOM, or accents arrive mangled", /uFEFF/.test(src), true);
t("the file is named after the trip and its date", /"expenses-" \+ \(slug/.test(src), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
