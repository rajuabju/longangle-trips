// Wayfarer — inbox Worker.
//
// Cloudflare Email Routing hands a forwarded booking confirmation here. This
// stores it and stops. It does not parse: the importer has the model and the
// field rules, and it runs twice a day with everything else it needs. Capture
// and comprehension are separate jobs, and a Worker is only good at the first.
//
// Why this exists at all, given the importer already reads Gmail and Outlook
// directly: it covers the two cases a scheduled scan cannot. A confirmation
// that lands at an address nobody is watching, and one you want captured the
// moment it arrives rather than at the next run.
//
// Pages Functions cannot receive email — only a Worker with an email() handler
// can — which is why this is a separate deployable rather than another route in
// functions/api. It shares the same D1 and the same R2 bucket.

// Who may send here. Without this the address is a public spam sink: anybody
// who learns it could fill the table and the bucket. Email Routing already
// drops most rubbish, but the address is the only credential this endpoint has,
// so it should not be the only check.
const ALLOWED = [
  "alex.wayfarer@gmail.com",
  "you@example.com",
  "partner@example.com",
];

const MAX_BYTES = 20 * 1024 * 1024;

function headerOf(message, name) {
  try { return message.headers.get(name) || null; } catch (e) { return null; }
}

export default {
  async email(message, env, ctx) {
    const from = String(message.from || "").toLowerCase();
    if (!ALLOWED.includes(from)) {
      // Reject rather than silently drop, so a legitimate sender who is not on
      // the list gets a bounce telling them, instead of wondering why nothing
      // ever appeared.
      message.setReject("Not an address permitted to file bookings here.");
      return;
    }
    if (message.rawSize > MAX_BYTES) {
      message.setReject("That message is too large to file.");
      return;
    }

    const now = new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
    const messageId = headerOf(message, "message-id");

    // Deduplicate on Message-ID before spending anything on storage. Forwarding
    // the same confirmation twice is a normal thing to do when you are not sure
    // the first one worked.
    if (messageId) {
      const seen = await env.DB.prepare("SELECT id FROM inbox WHERE message_id = ?")
        .bind(messageId).first();
      if (seen) return;
    }

    // The id comes from the same sequence everything else uses, so an inbox row
    // can never collide with a trip or a document.
    const seq = await env.DB.prepare(
      "UPDATE id_seq SET next = next + 1 WHERE name = 'global' RETURNING next"
    ).first();
    if (!seq || seq.next == null) throw new Error("id_seq has no 'global' row");
    const id = Number(seq.next) - 1;

    const key = `inbox/${id}.eml`;
    const raw = new Response(message.raw);
    await env.DOCS.put(key, await raw.arrayBuffer(), {
      httpMetadata: { contentType: "message/rfc822" },
    });

    try {
      await env.DB.prepare(
        `INSERT INTO inbox (id, received_at, from_addr, to_addr, subject, message_id, size, r2_key, status)
         VALUES (?,?,?,?,?,?,?,?,'pending')`
      ).bind(
        id, now, from, String(message.to || ""),
        headerOf(message, "subject"), messageId, message.rawSize, key
      ).run();
    } catch (e) {
      // Never leave bytes in the bucket that no row points at.
      try { await env.DOCS.delete(key); } catch (_) { /* ignore */ }
      throw e;
    }
  },
};
