// Proxy for the free external services the dashboard uses. Everything here
// is keyless and free; the proxy exists to (a) avoid CORS surprises, (b) send the
// descriptive User-Agent that Nominatim's usage policy requires — browsers won't
// let us set that header — and (c) cache aggressively so we stay well inside the
// providers' fair-use limits.
//
//   /api/ext/geocode?q=Carbone New York       -> OpenStreetMap Nominatim
//   /api/ext/weather?lat=&lon=&start=&end=    -> Open-Meteo
//   /api/ext/fx?base=USD                      -> Frankfurter (ECB rates)
//   /api/ext/photos?q=Kyoto                  -> Wikimedia Commons
// Nominatim's usage policy requires a descriptive User-Agent with a reachable
// contact URL. This pointed at tripsy.example-org.com, which no longer
// resolves — a dead contact is exactly what gets an app blocked.
const UA = "wayfarer/1.0 (https://trips.example.com)";

// An average of five past years and a country border do not move day to day,
// so these sit far above the forecast's hour.
const TTL = { geocode: 86400, weather: 3600, fx: 43200, typical: 2592000, country: 2592000, holidays: 604800 };

// Google encodes a route as a signed-varint polyline rather than GeoJSON.
// Returned as [lat, lon] pairs to match what OSRM's branch produces, so every
// caller sees one shape whichever router answered.
function decodePolyline(str) {
  const out = [];
  let i = 0, lat = 0, lon = 0;
  while (i < str.length) {
    let shift = 0, result = 0, b;
    do { b = str.charCodeAt(i++) - 63; result |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
    lat += (result & 1) ? ~(result >> 1) : (result >> 1);
    shift = 0; result = 0;
    do { b = str.charCodeAt(i++) - 63; result |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
    lon += (result & 1) ? ~(result >> 1) : (result >> 1);
    out.push([lat / 1e5, lon / 1e5]);
  }
  return out;
}

// Marks a body as "this is an upstream failure, do not cache it". Every handler
// below answers a failed upstream with HTTP 200 and an `error` key, because the
// callers treat a non-200 as fatal and a missing map pin should not break the
// page. But a 200 is exactly what cached() used to store — so one rate-limited
// Nominatim reply poisoned that query for a full 24 hours, and a transient
// Open-Meteo blip cost an hour of weather. The status stays 200 for the client;
// this header is how cached() tells the two apart.
const UPSTREAM_FAILED = "x-upstream-failed";

// The coordinate and date parameters end up in TWO places that both punish
// junk quietly: cache keys, where an unnormalised value multiplies entries or
// collides them, and upstream URLs, where a "#" truncates the request at the
// fragment. Normalise once, reject early.
function numParam(v, lo, hi) {
  const n = Number(v);
  return Number.isFinite(n) && n >= lo && n <= hi ? n : null;
}
function dateParam(v) {
  return /^\d{4}-\d{2}-\d{2}$/.test(String(v || "")) ? String(v) : null;
}

function json(obj, status, ttl) {
  var headers = {
    "content-type": "application/json",
    "cache-control": ttl ? "public, max-age=" + ttl : "no-store",
  };
  // No ttl on a body carrying an `error` means: served, but never stored.
  if (obj && obj.error && !ttl) headers[UPSTREAM_FAILED] = "1";
  return new Response(JSON.stringify(obj), { status: status || 200, headers: headers });
}

async function cached(context, key, ttl, work) {
  var cache = caches.default;
  var cacheKey = new Request(new URL(key, context.request.url).toString(), { method: "GET" });
  var hit = await cache.match(cacheKey);
  if (hit) return hit;
  var res = await work();
  if (res.status === 200 && !res.headers.get(UPSTREAM_FAILED)) {
    var copy = new Response(res.body, res);
    copy.headers.set("cache-control", "public, max-age=" + ttl);
    context.waitUntil(cache.put(cacheKey, copy.clone()));
    return copy;
  }
  return res;
}

export async function onRequest(context) {
  const { request, params, env } = context;
  const url = new URL(request.url);
  const path = Array.isArray(params.path) ? params.path.join("/") : params.path || "";

  try {
    if (path === "geocode") {
      const q = (url.searchParams.get("q") || "").trim();
      if (q.length < 3) return json({ results: [] });

      // ---- optional: search inside a box ----
      //
      // "Bath Bomb Workshop" is unfindable on its own and dangerous to guess at
      // -- a bare name is how Blackberry Farm ended up in south London. But the
      // trip it belongs to already knows where it is, because its other items
      // have coordinates. Passing that bounding box turns an unanswerable
      // question into an easy one, WITHOUT stuffing town names into the query
      // string and hoping the geocoder parses them the way we meant.
      //
      // bounded=1 makes the box a hard filter rather than a preference. A wrong
      // answer inside the right valley is recoverable; a confident answer on
      // another continent is the failure this exists to prevent.
      const vb = (url.searchParams.get("viewbox") || "").trim();
      const boxOk = /^-?\d{1,3}(\.\d+)?(,-?\d{1,3}(\.\d+)?){3}$/.test(vb);
      const boxPart = boxOk ? "&viewbox=" + encodeURIComponent(vb) + "&bounded=1" : "";

      // The box is part of what was asked, so it is part of the cache key.
      // Without it the same name inside two different trips would collide.
      const key = "/cache/geocode?q=" + encodeURIComponent(q.toLowerCase()) +
        (boxOk ? "&vb=" + encodeURIComponent(vb) : "");
      return cached(context, key, TTL.geocode, async function () {
        const u = "https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&limit=6" +
          boxPart + "&q=" + encodeURIComponent(q);
        const r = await fetch(u, { headers: { "User-Agent": UA, Accept: "application/json" } });
        if (!r.ok) return json({ results: [], error: "geocoder " + r.status }, 200);
        const list = await r.json();
        const results = (list || []).map(function (p) {
          return {
            name: (p.name && p.name.trim()) || (p.display_name || "").split(",")[0],
            label: p.display_name,
            lat: Number(p.lat),
            lon: Number(p.lon),
            type: p.type,
          };
        });
        return json({ results: results, attribution: "© OpenStreetMap contributors" }, 200, TTL.geocode);
      });
    }

    if (path === "weather") {
      const lat = numParam(url.searchParams.get("lat"), -90, 90);
      const lon = numParam(url.searchParams.get("lon"), -180, 180);
      if (lat == null || lon == null) return json({ error: "lat and lon required" }, 400);
      const start = dateParam(url.searchParams.get("start")), end = dateParam(url.searchParams.get("end"));
      let u = "https://api.open-meteo.com/v1/forecast?latitude=" + encodeURIComponent(lat) +
        "&longitude=" + encodeURIComponent(lon) +
        // sunrise, sunset and daylight_duration cost nothing here: same call,
        // same vendor, same free tier, no extra request and no new failure mode.
        "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
        ",sunrise,sunset,daylight_duration" +
        "&timezone=auto" + (url.searchParams.get("u") === "metric" ? "" : "&temperature_unit=fahrenheit");
      // Open-Meteo only forecasts ~16 days out; callers pass the trip window.
      u += start && end ? "&start_date=" + start + "&end_date=" + end : "&forecast_days=7";
      // The unit is part of the cache key, or switching °F/°C would serve a
      // cached response still in the previous unit.
      var unitKey = url.searchParams.get("u") === "metric" ? "c" : "f";
      return cached(context, "/cache/weather?" + lat + "," + lon + "," + (start || "") + (end || "") + "," + unitKey, TTL.weather, async function () {
        const r = await fetch(u);
        if (!r.ok) return json({ error: "weather " + r.status }, 200);
        return json(await r.json(), 200, TTL.weather);
      });
    }

    // ---- what the weather is USUALLY like -------------------------------
    //
    // The forecast reaches about 16 days. On 2026-08-25 every upcoming trip was
    // 32, 51, 114, 149 and 240 days out, so the weather feature was dark on all
    // five -- it only ever appears in the fortnight before you go, which is
    // after the packing decisions are made.
    //
    // This fills that gap with the same vendor's archive: the same calendar
    // window over the last five years, averaged. It is deliberately NOT a
    // forecast and the client must never present it as one -- see the "usually"
    // wording there.
    //
    // Five separate requests, because the archive API takes one contiguous
    // range and these are five windows a year apart. Cached for a month, since
    // an average of five years does not move day to day.
    if (path === "typical") {
      const lat = numParam(url.searchParams.get("lat"), -90, 90);
      const lon = numParam(url.searchParams.get("lon"), -180, 180);
      const start = dateParam(url.searchParams.get("start")), end = dateParam(url.searchParams.get("end"));
      if (lat == null || lon == null || !start || !end) return json({ error: "lat, lon, start and end required" }, 400);
      const metric = url.searchParams.get("u") === "metric";
      const YEARS = 5;
      return cached(context, "/cache/typical?" + lat + "," + lon + "," + start + "," + end + "," + (metric ? "c" : "f"),
        TTL.typical, async function () {
          // Keyed by month-day, so the same date across years lines up even
          // when a leap day shifts the count.
          const acc = Object.create(null);
          const thisYear = Number(start.slice(0, 4));
          let answered = 0;
          for (let i = 1; i <= YEARS; i++) {
            const y = thisYear - i;
            // MONTH-DAY comparison, not full dates. A trip 28 Dec - 3 Jan has
            // end > start as full strings (the year digits dominate), so the
            // +1 never applied and every archive request was an inverted
            // range: from December of one year to January of the SAME year.
            // Typical weather was silently dark on every year-crossing trip.
            const crosses = end.slice(5) < start.slice(5);
            const from = y + start.slice(4), to = (y + (crosses ? 1 : 0)) + end.slice(4);
            const u = "https://archive-api.open-meteo.com/v1/archive?latitude=" + encodeURIComponent(lat) +
              "&longitude=" + encodeURIComponent(lon) +
              "&start_date=" + from + "&end_date=" + to +
              "&daily=temperature_2m_max,temperature_2m_min,precipitation_sum&timezone=auto" +
              (metric ? "" : "&temperature_unit=fahrenheit");
            let d = null;
            try {
              const r = await fetch(u);
              if (!r.ok) continue;
              d = await r.json();
            } catch (e) { continue; }
            const day = d && d.daily;
            if (!day || !day.time) continue;
            answered++;
            day.time.forEach(function (iso, k) {
              const md = String(iso).slice(5);
              const hi = day.temperature_2m_max ? day.temperature_2m_max[k] : null;
              const lo = day.temperature_2m_min ? day.temperature_2m_min[k] : null;
              const wet = day.precipitation_sum ? day.precipitation_sum[k] : null;
              if (hi == null || lo == null) return;
              const a = acc[md] || (acc[md] = { hi: 0, lo: 0, n: 0, wet: 0 });
              a.hi += hi; a.lo += lo; a.n++;
              // A "wet day" rather than a millimetre total, which nobody reads.
              if (wet != null && wet >= 1) a.wet++;
            });
          }
          // ZERO years answering is an outage, not an answer -- and the old
          // code cached that empty for a month. No ttl marks it UPSTREAM_FAILED
          // so cached() refuses to store it; a genuinely gap-ridden archive
          // still answers with a time axis, so the two stay distinguishable.
          if (!answered) return json({ days: [], error: "archive unreachable" }, 200);
          const days = Object.keys(acc).sort().map(function (md) {
            const a = acc[md];
            return { md: md, hi: Math.round(a.hi / a.n), lo: Math.round(a.lo / a.n), wet: a.wet, years: a.n };
          });
          // An empty DAYS list under an answering archive is a real answer --
          // gaps exist at some coordinates -- and the client shows nothing
          // rather than a zero.
          return json({ days: days, years: YEARS }, 200, TTL.typical);
        });
    }

    // ---- which country a coordinate is in --------------------------------
    //
    // Two features need it and neither is worth a stored column: public
    // holidays and the practicalities table. Nominatim already answers this and
    // is already the geocoder here, so no new vendor. zoom=5 asks for the
    // country level rather than a full address.
    //
    // Cached for a month: borders do not move, and this keeps a per-trip lookup
    // from becoming a per-render one.
    if (path === "country") {
      const lat = numParam(url.searchParams.get("lat"), -90, 90);
      const lon = numParam(url.searchParams.get("lon"), -180, 180);
      if (lat == null || lon == null) return json({ error: "lat and lon required" }, 400);
      // Rounded to ~1km before it becomes a cache key, so two hotels in the
      // same city do not each cost a lookup. The UPSTREAM CALL uses the same
      // rounded point: keying on one point and asking about another let the
      // first hotel in a border-straddling cell answer for the whole cell.
      // At zoom=5 (country level) a kilometre of rounding changes nothing
      // except exactly at a land border, where agreement matters most.
      const rlat = lat.toFixed(2), rlon = lon.toFixed(2);
      const key = rlat + "," + rlon;
      return cached(context, "/cache/country?" + key, TTL.country, async function () {
        const u = "https://nominatim.openstreetmap.org/reverse?format=json&zoom=5&lat=" +
          rlat + "&lon=" + rlon;
        const r = await fetch(u, { headers: { "User-Agent": UA, "Accept-Language": "en" } });
        if (!r.ok) return json({ error: "country " + r.status }, 200);
        const d = await r.json();
        const cc = d && d.address && d.address.country_code;
        return json({ cc: cc ? String(cc).toUpperCase() : null, name: (d && d.address && d.address.country) || null },
          200, TTL.country);
      });
    }

    // ---- public holidays where you are going -----------------------------
    //
    // Nager.Date, free and keyless. NATIONAL ONLY: `global` separates the two,
    // and for Spain that is 10 holidays of 32 -- the rest are regional (Día de
    // Andalucía, Dia de les Illes Balears) and would fire for a Madrid trip
    // that they do not affect.
    //
    // Even filtered this is a heads-up and not an authority: coverage varies by
    // country and religious observances that close things are often absent. The
    // client wording says so.
    if (path === "holidays") {
      const cc = String(url.searchParams.get("cc") || "").toUpperCase();
      const year = String(url.searchParams.get("year") || "");
      if (!/^[A-Z]{2}$/.test(cc) || !/^\d{4}$/.test(year)) return json({ error: "cc and year required" }, 400);
      return cached(context, "/cache/holidays?" + cc + "," + year, TTL.holidays, async function () {
        const r = await fetch("https://date.nager.at/api/v3/PublicHolidays/" + year + "/" + cc);
        // 404 means Nager does not cover the country, which is a fact worth
        // returning plainly rather than as an error the client has to guess at.
        if (r.status === 404) return json({ results: [], covered: false }, 200, TTL.holidays);
        if (!r.ok) return json({ error: "holidays " + r.status }, 200);
        const d = await r.json();
        const out = (Array.isArray(d) ? d : []).filter(function (h) { return h && h.global; })
          .map(function (h) { return { date: h.date, name: h.localName || h.name, english: h.name }; });
        return json({ results: out, covered: true }, 200, TTL.holidays);
      });
    }

    if (path === "fx") {
      const base = (url.searchParams.get("base") || "USD").toUpperCase();
      return cached(context, "/cache/fx?" + base, TTL.fx, async function () {
        const r = await fetch("https://api.frankfurter.dev/v1/latest?base=" + encodeURIComponent(base));
        if (!r.ok) return json({ error: "fx " + r.status }, 200);
        const d = await r.json();
        return json({ base: d.base, date: d.date, rates: d.rates || {} }, 200, TTL.fx);
      });
    }

    // Driving route between two points, for trips taken by car.
    //
    // OSRM's public instances are keyless and free. Volume here is a handful of
    // requests against the same few destinations — Pinecrest, San Diego, Mammoth,
    // Las Vegas — so the 24h cache means the upstream sees almost nothing.
    if (path === "route") {
      const from = (url.searchParams.get("from") || "").trim();
      const to = (url.searchParams.get("to") || "").trim();
      const pair = /^-?\d{1,3}(\.\d+)?,-?\d{1,3}(\.\d+)?$/;
      if (!pair.test(from) || !pair.test(to)) return json({ error: "from and to must be lat,lon" }, 400);
      const [aLat, aLon] = from.split(",").map(Number);
      const [bLat, bLon] = to.split(",").map(Number);
      if (![aLat, aLon, bLat, bLon].every(isFinite)) return json({ error: "bad coordinates" }, 400);

      const key = "/cache/route?" + aLat.toFixed(3) + "," + aLon.toFixed(3) + ";" + bLat.toFixed(3) + "," + bLon.toFixed(3);
      return cached(context, key, TTL.geocode, async function () {
        // ---- Google Routes first, when there is a key ----
        //
        // Traffic-aware, and far better roads coverage than the public OSRM
        // demo servers, which are best-effort and do fall over.
        //
        // The 24-hour cache above is what makes this ALLOWED: Google's terms
        // permit caching a route's coordinates for at most 30 consecutive days.
        // That is also why geocoding stayed on OpenStreetMap -- those results
        // are stored on records permanently, and only ODbL permits that. A
        // route is computed, shown, and forgotten, so it fits inside the rule.
        // MAPS_SERVER_KEY, not the browser one. A Maps JavaScript key has to
        // be locked to HTTP referrers because it is public in the page, and a
        // Worker fetch sends no referrer at all -- so the browser key would be
        // rejected here every single time. Two keys, restricted two different
        // ways: this one to the Routes API and nothing else.
        if (env.MAPS_SERVER_KEY) {
          try {
            const r = await fetch("https://routes.googleapis.com/directions/v2:computeRoutes", {
              method: "POST",
              headers: {
                "content-type": "application/json",
                "X-Goog-Api-Key": env.MAPS_SERVER_KEY,
                // Routes bills by what you ask for, so ask for exactly the three
                // fields that get used and nothing else.
                "X-Goog-FieldMask": "routes.distanceMeters,routes.duration,routes.polyline.encodedPolyline",
              },
              body: JSON.stringify({
                origin: { location: { latLng: { latitude: aLat, longitude: aLon } } },
                destination: { location: { latLng: { latitude: bLat, longitude: bLon } } },
                travelMode: "DRIVE",
                polylineQuality: "OVERVIEW",
              }),
            });
            if (r.ok) {
              const d = await r.json();
              const route = d && d.routes && d.routes[0];
              if (route && route.polyline && route.polyline.encodedPolyline) {
                return json({
                  distance_m: route.distanceMeters,
                  // "1234s" -> 1234. Routes returns a protobuf duration string.
                  duration_s: Number(String(route.duration || "").replace(/[^0-9.]/g, "")) || 0,
                  line: decodePolyline(route.polyline.encodedPolyline),
                  attribution: "Routing by Google",
                }, 200, TTL.geocode);
              }
            }
          } catch (e) { /* fall through to OSRM rather than lose the road line */ }
        }

        // ---- OSRM, kept deliberately ----
        //
        // Not dead code and not a hedge. Google answers first and answers
        // better -- traffic-aware, and far wider road coverage than these
        // public demo servers, which are best-effort and do fall over.
        //
        // This runs when Google cannot: no MAPS_SERVER_KEY, a request that
        // times out, Google having a bad hour, or the daily quota cap being
        // reached. That last one is not an accident -- ComputeRoutes is capped
        // at 300/day, deliberately BELOW the free allowance, so that a runaway
        // loop is refused rather than billed. The refusal is the safety
        // mechanism working, and this is what keeps a road on the map while it
        // does.
        //
        // Deleting it would trade a real outage for two hosts in an array. The
        // drive times are the only reason half these trips show a road at all,
        // and losing them silently is worse than losing traffic awareness. Same
        // reasoning as the lazy-loaded Leaflet fallback in app.js; if one of the
        // two is ever removed, remove both and say why.
        //
        // OSRM wants lon,lat. Getting this backwards routes you into the sea.
        const coords = `${aLon},${aLat};${bLon},${bLat}`;
        const hosts = [
          "https://routing.openstreetmap.de/routed-car/route/v1/driving/",
          "https://router.project-osrm.org/route/v1/driving/",
        ];
        for (const host of hosts) {
          try {
            const r = await fetch(host + coords + "?overview=simplified&geometries=geojson", {
              headers: { "User-Agent": UA, Accept: "application/json" },
            });
            if (!r.ok) continue;
            const d = await r.json();
            const route = d && d.routes && d.routes[0];
            if (!route) continue;
            return json({
              distance_m: route.distance,
              duration_s: route.duration,
              // GeoJSON is [lon,lat]; Leaflet wants [lat,lon]. Flip once, here,
              // so no caller has to remember.
              line: (route.geometry.coordinates || []).map(([lo, la]) => [la, lo]),
              attribution: "© OpenStreetMap contributors, routing by OSRM",
            }, 200, TTL.geocode);
          } catch (e) { /* try the next host */ }
        }
        // The map still draws without this; it just shows no road line.
        return json({ error: "No routing host responded" }, 200);
      });
    }

    if (path === "photos") {
      // Cover-photo search. Wikimedia Commons is keyless, has no rate limit worth
      // worrying about, and — the reason it beats every other free image API here —
      // serves its files from upload.wikimedia.org, a permanent public CDN. The
      // Tripsy iOS app has to be able to fetch whatever we store in
      // cover_image_url, so a URL behind an API key or a signed expiry is useless.
      const q = (url.searchParams.get("q") || "").trim();
      if (q.length < 2) return json({ photos: [] });
      return cached(context, "/cache/photos?q=" + encodeURIComponent(q.toLowerCase()), TTL.geocode, async function () {
        const u = "https://commons.wikimedia.org/w/api.php?action=query&format=json&formatversion=2" +
          "&generator=search&gsrnamespace=6&gsrlimit=24&gsrsearch=" + encodeURIComponent(q + " filetype:bitmap") +
          "&prop=imageinfo&iiprop=url|extmetadata|size&iiurlwidth=1600";
        const r = await fetch(u, { headers: { "User-Agent": UA, Accept: "application/json" } });
        if (!r.ok) return json({ photos: [], error: "commons " + r.status }, 200);
        const d = await r.json();
        const pages = (d.query && d.query.pages) || [];
        const photos = pages.map(function (p) {
          const ii = (p.imageinfo || [])[0] || {};
          const meta = ii.extmetadata || {};
          const strip = function (s) { return s ? String(s).replace(/<[^>]*>/g, "").trim() : ""; };
          return {
            title: (p.title || "").replace(/^File:/, "").replace(/\.[a-z]+$/i, ""),
            // thumburl is a resized derivative — a fraction of the original's
            // bytes, which routinely run to 20 MB for a Commons photo.
            url: ii.thumburl || ii.url,
            thumb: (ii.thumburl || ii.url || "").replace(/\/1600px-/, "/320px-"),
            width: ii.thumbwidth || ii.width,
            height: ii.thumbheight || ii.height,
            credit: strip(meta.Artist && meta.Artist.value),
            license: strip(meta.LicenseShortName && meta.LicenseShortName.value),
          };
        }).filter(function (p) { return p.url && /^https:\/\/upload\.wikimedia\.org\//.test(p.url); });
        return json({ photos: photos, attribution: "Wikimedia Commons" }, 200, TTL.geocode);
      });
    }

    return json({ error: "Unknown endpoint" }, 404);
  } catch (e) {
    return json({ error: String((e && e.message) || e) }, 502);
  }
}