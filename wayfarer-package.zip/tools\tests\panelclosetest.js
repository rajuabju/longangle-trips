// Closing a panel gives its address back.
//
// Reported as "trip ideas keeps popping up if i dont actually press the Done
// chip". The Done chip turned out to make no difference -- all three ways of
// closing are back.remove() -- so the panel came back whichever was used.
//
// What happened: panelRoute pushes a history entry when a panel opens. The two
// panels that render into an overlay() -- #ideas and #history -- closed by
// removing the backdrop and nothing else, leaving both the hash and the entry
// in place. The panel looked shut and was not. Open a trip, close it, and
// closeDetail's history.back() lands on #ideas, where handleHash duly re-opens
// a panel nobody asked for.
//
// Reproduced before the fix, at every step:
//   open Trip Ideas            -> hash #ideas, one overlay
//   click away                 -> overlay gone, hash STILL #ideas
//   open a trip                -> hash #trip/1141877
//   close the trip             -> hash #ideas, Trip Ideas open again, two
//                                 overlays, and the trip still open underneath
// and identically for Escape and for the Done chip.
//
// The three panels that render into #detail-overlay never had this: they close
// through closeDetail, which already released the address. Confirmed by
// measurement -- #check, #changes and #calendar all cleared the hash; only
// #history and #ideas left it behind.
//
// Verified after the fix: all five panels open at their address, close, and
// clear it; the reported sequence resurfaces nothing by any of the three close
// paths; and a deep link straight to #ideas closes without navigating out of
// the app (history.length unchanged, dashboard still there).
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

function lift(decl) {
  const at = app.indexOf(decl);
  if (at < 0) throw new Error("not found: " + decl);
  let depth = 0, i = app.indexOf("{", at);
  for (; i < app.length; i++) {
    if (app[i] === "{") depth++;
    else if (app[i] === "}") { depth--; if (!depth) break; }
  }
  return app.slice(at, i + 1);
}

// Run the real function against a stub history, because the branch that matters
// -- back() versus replaceState() -- is the difference between closing a panel
// and navigating the user out of the app.
function harness({ hash, pushed, shown }) {
  const calls = [];
  const location = { hash, pathname: "/", search: "" };
  const history = {
    back: () => { calls.push("back"); },
    replaceState: (a, b, url) => { calls.push("replaceState:" + url); location.hash = ""; },
  };
  const src = "var shownPanel = shown, pushedDetail = pushed;\n" +
    lift("function closePanelRoute(hash)") +
    "\nreturn { close: closePanelRoute, state: function () { return { shownPanel: shownPanel, pushedDetail: pushedDetail }; } };";
  const api = new Function("location", "history", "pushed", "shown", src)(location, history, pushed, shown);
  return { ...api, calls, location };
}

console.log("\nthe panel that pushed an entry gives it back");
{
  // The ordinary case: opened from the toolbar, so panelRoute pushed.
  const h = harness({ hash: "#ideas", pushed: true, shown: "#ideas" });
  h.close("#ideas");
  t("it goes back rather than rewriting", h.calls, ["back"]);
  t("and stops claiming a panel is showing", h.state().shownPanel, null);
  // Or the next close would try to go back a second time for the same panel.
  t("the pushed flag is cleared", h.state().pushedDetail, false);
}

console.log("\na deep link has nothing behind it");
{
  // Arriving on #ideas directly: panelRoute saw the hash was already right and
  // pushed nothing. history.back() here leaves the app entirely.
  const h = harness({ hash: "#ideas", pushed: false, shown: "#ideas" });
  h.close("#ideas");
  t("it replaces instead of going back", h.calls, ["replaceState:/"]);
  t("which drops the address", h.location.hash, "");
}

console.log("\nit never rewrites somebody else's address");
{
  // A trip opened from inside the panel owns the address now. Verified live:
  // the reported sequence reaches exactly this state.
  const h = harness({ hash: "#trip/1141877", pushed: true, shown: "#ideas" });
  h.close("#ideas");
  t("a different address is left alone", h.calls, []);
  t("and the hash is untouched", h.location.hash, "#trip/1141877");
  // shownPanel still belonged to this panel, so it is still cleared.
  t("but the panel stops being the shown one", h.state().shownPanel, null);
}
{
  const h = harness({ hash: "", pushed: true, shown: null });
  h.close("#ideas");
  t("no hash at all is a no-op", h.calls, []);
}
{
  // Closing #ideas must not clear a shownPanel belonging to #history.
  const h = harness({ hash: "#history", pushed: true, shown: "#history" });
  h.close("#ideas");
  t("another panel's shown state survives", h.state().shownPanel, "#history");
}

console.log("\nreleased on every way of closing, not one of them");
// Every close path ends in the backdrop leaving the document -- the backdrop
// click, Escape via closeTopLayer, and the Done chip's bare back.remove(). Only
// the removal watcher sees all three, so that is where it goes.
t("the removal watcher releases the route", /if \(back\.__route\) closePanelRoute\(back\.__route\);/.test(app), true);
// The focus block below it returns early when something else has taken focus.
// Behind that return, the route would leak again in exactly that case.
t("before the focus block, which can return early",
  app.indexOf("if (back.__route) closePanelRoute(back.__route);") <
  app.indexOf("if (now && now !== document.body && now !== document.documentElement) return;"), true);

console.log("\nboth routed overlays are tagged");
t("Trip Ideas", /o\.back\.__route = "#ideas";/.test(app), true);
t("History", /o\.back\.__route = "#history";/.test(app), true);
// And each sits with the panelRoute call it pairs with.
t("paired with panelRoute for ideas", /panelRoute\("#ideas"\);[\s\S]{0,200}?o\.back\.__route = "#ideas";/.test(app), true);
t("paired with panelRoute for history", /panelRoute\("#history"\);[\s\S]{0,200}?o\.back\.__route = "#history";/.test(app), true);
// The other three close through closeDetail, which already did this. Tagging
// them would double-release the address.
// Exactly two overlays carry a route, and these are they. Asserted as a count
// rather than as "the other three are not tagged": __route is new, so that
// negative could never have matched any version and would have guarded
// nothing. A third tag -- or a lost one -- fails this instead.
t("exactly two overlays carry a route", (app.match(/__route = "#/g) || []).length, 2);
t("and they are ideas and history",
  (app.match(/__route = "(#[a-z]+)"/g) || []).sort(), ['__route = "#history"', '__route = "#ideas"']);
t("and closeDetail still handles those", /if \(pushedDetail && location\.hash\) \{\s*\n\s*pushedDetail = false;\s*\n\s*history\.back\(\);/.test(app), true);

console.log("\nthe clean snapshot survives a panel that builds itself late");
// Second bug, found while verifying the first. __clean is taken one tick after
// the overlay is created, which is right for a dialog built synchronously and
// wrong for one that awaits a fetch: openBucketList snapshotted an EMPTY panel
// (measured length 0), so every later comparison differed and Escape asked
// "Discard your changes?" on a panel nobody had typed into -- then refused to
// close when the answer was no.
t("the snapshot is re-taken while the panel fills", /var settling = new MutationObserver\(function \(\) \{/.test(app), true);
t("watching the panel's whole subtree", /settling\.observe\(panel, \{ childList: true, subtree: true \}\);/.test(app), true);
t("and stopping once the user touches something", /touched = true;\s*\n\s*settling\.disconnect\(\);/.test(app), true);
// Capture, because the fields it must hear did not exist when this was wired.
t("input and change are heard in the capture phase",
  /back\.addEventListener\("input", markTouched, true\);\s*\n\s*back\.addEventListener\("change", markTouched, true\);/.test(app), true);
t("it never re-snapshots after a real edit", /if \(touched \|\| !back\.isConnected\) return;/.test(app), true);
t("and it is disconnected when the overlay goes", /if \(settling\) settling\.disconnect\(\);/.test(app), true);
// The guard itself must still be there -- this makes it accurate, not absent.
t("the unsaved-changes guard still exists", /if \(!confirm\("Discard your changes\?"\)\) return false;/.test(app), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
