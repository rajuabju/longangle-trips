// Cover focal point.
//
// coverPosition guards a value that is written straight into a style attribute,
// and the trip blob it comes from is writable through the API — patchRow merges
// arbitrary fields with no allowlist. So the guard is the only thing between a
// stored string and the DOM, and it is what this suite is really about.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");

function grab(name) {
  const i = src.indexOf("  function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
const list = src.slice(src.indexOf("  var COVER_POSITIONS = ["),
  src.indexOf("];", src.indexOf("  var COVER_POSITIONS = [")) + 2);

// gradientCss picks from the palette, which is not what this suite is about.
// Stubbed so the shape of the output can be asserted exactly.
globalThis.gradientCss = () => "linear-gradient(stub)";
eval(list + "\n" + ["coverPosition", "coverFallback", "coverStyle"].map(grab).join("\n") +
  ";Object.assign(globalThis,{COVER_POSITIONS,coverPosition,coverFallback,coverStyle});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const ok = got === want;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + JSON.stringify(want) + "\n        got  " + JSON.stringify(got));
};

// ---- the nine ------------------------------------------------------------
t("nine positions", COVER_POSITIONS.length, 9);
t("centre is among them", COVER_POSITIONS.indexOf("center center") >= 0, true);
COVER_POSITIONS.forEach((p) => t("accepted: " + p, coverPosition({ cover_position: p }), p));

// ---- the default ---------------------------------------------------------
// Every one of 183 trips predates this field, so absent must mean centre.
t("absent is centre", coverPosition({}), "center center");
t("null trip is centre", coverPosition(null), "center center");
t("empty string is centre", coverPosition({ cover_position: "" }), "center center");

// ---- the guard -----------------------------------------------------------
// Anything not on the list is discarded rather than sanitised. A value that
// closed the declaration could append rules of its own to the style attribute.
t("a stray keyword is refused", coverPosition({ cover_position: "top" }), "center center");
t("pixel offsets are refused", coverPosition({ cover_position: "10px 20px" }), "center center");
t("percentages are refused", coverPosition({ cover_position: "50% 50%" }), "center center");
t("a smuggled declaration is refused",
  coverPosition({ cover_position: "center center;background-image:url(http://evil/x)" }), "center center");
t("a closed quote is refused",
  coverPosition({ cover_position: "center center';x:y" }), "center center");
t("a number is refused", coverPosition({ cover_position: 5 }), "center center");
t("an object is refused", coverPosition({ cover_position: { x: 1 } }), "center center");

// ---- what ends up in the attribute ---------------------------------------
// Two layers now: the photo, and the trip's gradient beneath it. The gradient
// is what shows while the image is still on the wire, so a card on hotel wifi
// is a coloured tile rather than an empty box. Two background-images need two
// positions, or the second layer takes the first one's and the shorthand is
// invalid for it.
t("an image carries its position, over its gradient",
  coverStyle({ cover_image_url: "/api/v1/cover/1", cover_position: "right center", cover_gradient: 3 }),
  "background-image:url('/api/v1/cover/1'),linear-gradient(stub);background-position:right center,center");
t("an image with no position is centred",
  coverStyle({ cover_image_url: "/api/v1/cover/1", cover_gradient: 3 }),
  "background-image:url('/api/v1/cover/1'),linear-gradient(stub);background-position:center center,center");
// A trip with a photo and no gradient still gets the default one underneath,
// because the point is that SOMETHING is there while the photo loads.
t("no gradient set still gets one underneath",
  coverStyle({ cover_image_url: "/x" }).indexOf("linear-gradient(135deg,#4f7cff,#8a5bff)") >= 0, true);

// ---- the fallback on its own ---------------------------------------------
// It is used in two places -- under a photo, and as the whole background when
// there is no photo -- so it returns a bare gradient with no "background:".
t("returns a bare value, not a declaration",
  coverFallback({ cover_gradient: 3 }).indexOf(":") >= 0 &&
  coverFallback({ cover_gradient: 3 }).indexOf("background") >= 0, false);
t("an explicit colour list is honoured",
  coverFallback({ cover_gradient: { colors: ["#111", "#222"] } }), "linear-gradient(135deg,#111,#222)");
t("index zero is a gradient, not a missing one",
  coverFallback({ cover_gradient: 0 }), "linear-gradient(stub)");
t("nothing set falls back to the default pair",
  coverFallback({}), "linear-gradient(135deg,#4f7cff,#8a5bff)");
t("no trip at all does not throw",
  coverFallback(null), "linear-gradient(135deg,#4f7cff,#8a5bff)");
t("a hostile position never reaches the attribute",
  coverStyle({ cover_image_url: "/x", cover_position: "center;background:url(http://evil/y)" }).indexOf("evil") >= 0,
  false);
// A gradient has no subject, so it takes no position — and must not grow one.
t("a gradient carries no position",
  coverStyle({ cover_gradient: 3, cover_position: "right center" }).indexOf("background-position") >= 0,
  false);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
