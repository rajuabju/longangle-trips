// readPage turns a hotel's HTML into a bucket-list entry. Everything it does is
// a guess, so the guesses are the thing worth pinning down: which part of a
// page title is the hotel, which part is the chain, and where the address ends
// up. The fixtures below are hand-written HTML in the shapes real hotel pages
// use — no captured pages, and nothing from an actual booking.
const fs = require("fs");
const src = fs.readFileSync("functions/api/_core.js", "utf8");

// Pull the real functions out of the API rather than copying them, so a rename
// or a rewrite fails here instead of silently testing a stale duplicate.
function grab(name, kind) {
  const head = (kind || "function") + " " + name + "(";
  const i = src.indexOf("\n" + head);
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
// Emitted as `var`, not `const`: a function declaration inside a direct eval is
// hoisted out to this module's scope, but a const stays inside the eval's own
// scope — so the extracted functions would be left unable to see their tables.
const constOf = (name) => {
  const i = src.indexOf("const " + name + " =");
  if (i < 0) throw new Error("missing const " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    const c = src[j];
    if (c === "(" || c === "[" || c === "{") { d++; seen = true; }
    else if (c === ")" || c === "]" || c === "}") { d--; }
    else if (c === ";" && seen && d === 0) return "var " + src.slice(i + 6, j + 1);
  }
  throw new Error("unterminated const " + name);
};

eval(
  constOf("ENTITIES") + "\n" +
  constOf("PLACE_TYPES") + "\n" +
  constOf("escapeRe") + "\n" +
  constOf("TLD_ISH") + "\n" +
  constOf("ADDRESS_COUNTRY") + "\n" +
  ["decodeEntities", "metaOf", "jsonLdNodes", "addrText", "postalAddress", "geoOf",
    "trimTail", "hostWords", "brief", "readPage", "isPublicHost"]
    .map((n) => grab(n)).join("\n") + "\n" +
  "Object.assign(globalThis,{decodeEntities,metaOf,jsonLdNodes,addrText,trimTail,hostWords,brief,readPage,isPublicHost});"
);

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const ok = got === want;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + JSON.stringify(want) + "\n        got  " + JSON.stringify(got));
};
const U = (s) => new URL(s);

// ---- the SSRF guard --------------------------------------------------------
// This is the only check standing between a pasted address and Cloudflare's
// own network, so it gets tested first and hardest.
[
  ["localhost", false], ["app.localhost", false], ["printer.local", false],
  ["db.internal", false], ["127.0.0.1", false], ["127.1.1.1", false],
  ["10.0.0.5", false], ["172.16.4.1", false], ["172.31.255.254", false],
  ["192.168.1.1", false], ["169.254.169.254", false], ["100.64.0.1", false],
  ["0.0.0.0", false], ["224.0.0.1", false], ["::1", false], ["[::1]", false],
  ["fd00::1", false], ["", false],
  // The other side of the line: these are ordinary public hosts and must pass.
  ["belmond.com", true], ["www.hotelcaruso.com", true], ["8.8.8.8", true],
  ["172.15.0.1", true], ["172.32.0.1", true], ["192.169.1.1", true], ["11.0.0.1", true],
].forEach(([h, want]) => t("isPublicHost(" + JSON.stringify(h) + ")", isPublicHost(h), want));

// A four-octet shape with an out-of-range octet is not an address at all; it
// must not be waved through as though it were a hostname.
t("octet over 255 is refused", isPublicHost("10.0.0.999"), false);

// ---- metadata scraping -----------------------------------------------------
t("meta in property-then-content order",
  metaOf('<meta property="og:title" content="Hotel Caruso">', "property", "og:title"), "Hotel Caruso");
t("meta in content-then-property order",
  metaOf('<meta content="Hotel Caruso" property="og:title">', "property", "og:title"), "Hotel Caruso");
t("single-quoted attributes",
  metaOf("<meta property='og:site_name' content='Belmond'>", "property", "og:site_name"), "Belmond");
t("a missing tag is empty, not undefined",
  metaOf("<html></html>", "property", "og:title"), "");
// og:title must not be satisfied by og:title:alt or similar near-misses.
t("near-miss property names do not match",
  metaOf('<meta property="og:title:alt" content="X">', "property", "og:title"), "");

t("entities are decoded", decodeEntities("Caf&eacute; &amp; Bar &#8212; Ravello"), "Caf&eacute; & Bar — Ravello");
t("numeric entities are decoded", decodeEntities("Rock&#39;s End"), "Rock's End");
t("hex entities are decoded", decodeEntities("Rock&#x27;s End"), "Rock's End");

// ---- title cleaning --------------------------------------------------------
t("chain name stripped from the tail", trimTail("Hotel Caruso, Ravello | Belmond", ["Belmond"]), "Hotel Caruso, Ravello");
t("chain name stripped from the front", trimTail("Belmond — Hotel Caruso", ["Belmond"]), "Hotel Caruso");
t("en dash separator", trimTail("Hotel Caruso – Belmond", ["Belmond"]), "Hotel Caruso");
t("hyphen separator", trimTail("Hotel Caruso - Belmond", ["Belmond"]), "Hotel Caruso");
t("a tail that is not there changes nothing", trimTail("Hotel Caruso", ["Belmond"]), "Hotel Caruso");
// The place is called Belmond Villa Sant'Andrea; stripping every occurrence
// would leave "Villa Sant'Andrea" mid-title. Only the ends are trimmed.
t("only the ends are trimmed", trimTail("Belmond Villa Sant Andrea, Taormina", ["Belmond"]),
  "Belmond Villa Sant Andrea, Taormina");
// Trimming must never empty the field: a page whose whole title is the brand
// is better kept than blanked.
t("a title that is only the site name survives", trimTail("Belmond", ["Belmond"]), "Belmond");
t("a title that is site name plus separator survives", trimTail("Aman | Aman", ["Aman"]), "Aman");

// ---- the site's name guessed from the address ------------------------------
t("subdomain and TLD dropped", hostWords("en.wikipedia.org").join(","), "wikipedia");
t("www dropped", hostWords("www.belmond.com").join(","), "belmond");
t("two-part suffix dropped", hostWords("thened.co.uk").join(","), "thened");
t("a bare host keeps its one word", hostWords("fogoislandinn.ca").join(","), "fogoislandinn");

// ---- addresses -------------------------------------------------------------
t("PostalAddress becomes locality, region, country",
  addrText({ addressLocality: "Ravello", addressRegion: "Campania", addressCountry: "Italy" }),
  "Ravello, Campania, Italy");
t("street is deliberately left out of a title",
  addrText({ streetAddress: "Piazza San Giovanni 2", addressLocality: "Ravello", addressCountry: "Italy" }),
  "Ravello, Italy");
t("country as an object", addrText({ addressLocality: "Kyoto", addressCountry: { name: "Japan" } }), "Kyoto, Japan");
// schema.org country slots are as often a code as a name.
t("a country code is expanded", addrText({ addressLocality: "Ravello", addressCountry: "IT" }), "Ravello, Italy");
t("a country code in an object is expanded",
  addrText({ addressLocality: "Lisbon", addressCountry: { name: "PT" } }), "Lisbon, Portugal");
// NL here is Newfoundland. Expanding the region slot would turn a Canadian inn
// into a Dutch one, so only the country slot goes through the table.
t("the region slot is left alone",
  addrText({ addressLocality: "Joe Batt's Arm", addressRegion: "NL", addressCountry: "CA" }),
  "Joe Batt's Arm, NL, Canada");
t("an unknown country code is kept as-is",
  addrText({ addressLocality: "Reykjavik", addressCountry: "IS" }), "Reykjavik, IS");
t("a plain string address passes through", addrText("Ravello, Italy"), "Ravello, Italy");
t("repeated parts collapse", addrText({ addressLocality: "Singapore", addressCountry: "Singapore" }), "Singapore");
t("no address is empty, not 'undefined'", addrText(null), "");

// ---- note trimming ---------------------------------------------------------
t("a short note is untouched", brief("A cliffside hotel."), "A cliffside hotel.");
t("whitespace is collapsed", brief("A  cliffside\n hotel."), "A cliffside hotel.");
const longish = "A cliffside hotel in a former palace. The garden looks straight down the Amalfi coast and the pool appears to end in mid-air, which is the picture everybody has seen. Booking opens a year ahead and the good rooms go first.";
t("a long note is cut at a sentence", brief(longish).endsWith("."), true);
t("a long note stays within the cap", brief(longish).length <= 221, true);
t("a long unpunctuated note gets an ellipsis", brief("x".repeat(400)).endsWith("…"), true);

// ---- the whole page --------------------------------------------------------
// The best case: a hotel that publishes schema.org, which is where the name and
// the town come from directly rather than being guessed out of a title.
const jsonLd = `<html><head>
<title>Hotel Caruso, Ravello | Belmond</title>
<meta property="og:site_name" content="Belmond">
<meta property="og:description" content="Marketing copy nobody asked for.">
<script type="application/ld+json">
{"@context":"https://schema.org","@type":"Hotel","name":"Hotel Caruso",
 "description":"An eleventh-century palace above the Amalfi coast.",
 "address":{"@type":"PostalAddress","addressLocality":"Ravello","addressCountry":"Italy"}}
</script></head><body></body></html>`;
let r = readPage(jsonLd, U("https://www.belmond.com/hotels/caruso"));
t("schema name and town become the title", r.place, "Hotel Caruso, Ravello, Italy");
t("schema description wins over og:description", r.note, "An eleventh-century palace above the Amalfi coast.");
t("the site name is reported separately", r.site, "Belmond");
t("www is dropped from the host", r.host, "belmond.com");
t("a page with schema is not thin", r.thin, false);

// @graph is how most CMS plugins emit it, and the hotel node is rarely first.
const graph = `<html><head><title>Lodge</title>
<script type="application/ld+json">
{"@graph":[{"@type":"WebSite","name":"Some CMS"},
 {"@type":["LodgingBusiness","Organization"],"name":"Fogo Island Inn",
  "address":{"addressLocality":"Joe Batt's Arm","addressRegion":"Newfoundland","addressCountry":"Canada"}}]}
</script></head></html>`;
r = readPage(graph, U("https://fogoislandinn.ca/"));
t("the hotel is found inside @graph", r.place, "Fogo Island Inn, Joe Batt's Arm, Newfoundland, Canada");
// The WebSite node came first and must not have been mistaken for the place.
t("a non-place node is skipped", r.name, "Fogo Island Inn");

// No schema at all: fall back through open graph, and strip the chain name that
// the title carries. This is the common case.
const ogOnly = `<html><head>
<title>The Ned — London | Soho House</title>
<meta property="og:site_name" content="Soho House">
<meta property="og:title" content="The Ned — London">
<meta name="description" content="A 1920s bank turned hotel in the City.">
</head></html>`;
r = readPage(ogOnly, U("https://www.thened.com/london"));
t("og:title is used when there is no schema", r.place, "The Ned — London");
t("meta description becomes the note", r.note, "A 1920s bank turned hotel in the City.");

// A title that already names the town must not have it appended twice.
const dupe = `<html><head><title>Hotel Caruso, Ravello</title>
<script type="application/ld+json">
{"@type":"Hotel","name":"Hotel Caruso, Ravello",
 "address":{"addressLocality":"Ravello","addressCountry":"Italy"}}
</script></head></html>`;
r = readPage(dupe, U("https://example-hotel.com/"));
t("a town already in the name is not repeated", r.place, "Hotel Caruso, Ravello, Italy");

// The worst case: a page that says nothing. It must still produce something
// saveable and must admit that it is thin, so the client can say so.
r = readPage("<html><head></head><body>hi</body></html>", U("https://obscurelodge.example/"));
t("an empty page falls back to the host", r.place, "obscurelodge.example");
t("an empty page has no note", r.note, "");
t("an empty page is flagged thin", r.thin, true);

// Malformed JSON-LD is common and must not take the whole read down with it.
const broken = `<html><head><title>Somewhere Nice | Chain</title>
<script type="application/ld+json">{ this is not json }</script>
<meta property="og:site_name" content="Chain"></head></html>`;
r = readPage(broken, U("https://example.com/x"));
t("unparseable schema falls back to the title", r.place, "Somewhere Nice");

// The site names itself only in its address. This is the Wikipedia shape, and
// the reason hostWords exists at all.
const noSiteName = `<html><head><title>Belmond Hotel Caruso - Wikipedia</title>
<meta property="og:title" content="Belmond Hotel Caruso - Wikipedia"></head></html>`;
r = readPage(noSiteName, U("https://en.wikipedia.org/wiki/Hotel_Caruso"));
t("the site name is stripped using the host", r.place, "Belmond Hotel Caruso");
t("a page with a title but nothing else is thin", r.thin, true);

// The final URL is what gets saved, so a redirect must be reflected back.
t("the resolved address is returned", readPage("<html></html>", U("https://b.example/final")).url,
  "https://b.example/final");

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
