// Near-duplicate detection for activity ideas.
//
// A destination search sells the same day out several times over. The titles
// below are the real ones returned for Las Vegas and La Fortuna — the threshold
// was set against them, so they are what the suite protects. Nothing here is
// trip data: they are public product names from a search, not bookings.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");

function grab(name) {
  const i = src.indexOf("  function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
// TOUR_NOISE is built by a chained expression, so take it whole.
const noise = src.slice(src.indexOf("  var TOUR_NOISE = {};"),
  src.indexOf("function tourTokens"));
const same = src.slice(src.indexOf("  var TOUR_SAME"), src.indexOf(";", src.indexOf("  var TOUR_SAME")) + 1);
// dedupeIdeas reads this too. Miss it and the constant is undefined, every
// family comparison is false, and the family rule quietly stops existing —
// which the "same supplier, different departure" case below would catch, but
// only after looking like a threshold problem rather than a missing constant.
const floor = src.slice(src.indexOf("  var TOUR_FAMILY_FLOOR"), src.indexOf(";", src.indexOf("  var TOUR_FAMILY_FLOOR")) + 1);

eval(noise + "\n" + same + "\n" + floor + "\n" +
  ["tourTokens", "tourLikeness", "tourFamily", "dedupeIdeas"].map(grab).join("\n") +
  ";Object.assign(globalThis,{tourTokens,tourLikeness,tourFamily,dedupeIdeas,TOUR_SAME,TOUR_FAMILY_FLOOR});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const ok = got === want;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + JSON.stringify(want) + "\n        got  " + JSON.stringify(got));
};
const near = (label, got, want, tol) => t(label + " (" + got.toFixed(2) + ")", Math.abs(got - want) <= (tol || 0.06), true);

// ---- the case that motivated all of this ----------------------------------
const GC_A = "Grand Canyon West, Hoover Dam Stop,Wi-Fi,Optional Lunch & Skywalk";
const GC_B = "Grand Canyon West, Hoover Dam Stop, Breakfast, Lunch & Skywalk";
// 1.00, not merely close: once the meals, "optional" and the sub-three-letter
// fragments of "Wi-Fi" are gone, the two titles are word-for-word identical.
near("two operators, same coach, different meal", tourLikeness(GC_A, GC_B), 1.00);
t("…and it counts as the same", tourLikeness(GC_A, GC_B) >= TOUR_SAME, true);

// A self-drive audio guide over the same landmarks is NOT the same day out.
const GC_AUDIO = "Audio Driving Tour: Grand Canyon West, Hoover Dam Red Rock Canyon";
t("self-drive audio guide is a different product", tourLikeness(GC_A, GC_AUDIO) < TOUR_SAME, true);

// ---- the case that must survive -------------------------------------------
const CR_HOT = "La Fortuna Waterfall, Arenal Volcano, Hot Springs Full Day Tour";
const CR_BRIDGE = "La Fortuna Waterfall, Hanging Bridges, Arenal Volcano Combo Tour";
near("waterfall+springs vs waterfall+bridges", tourLikeness(CR_HOT, CR_BRIDGE), 0.50);
t("…and both are kept", tourLikeness(CR_HOT, CR_BRIDGE) < TOUR_SAME, true);

// ---- morning vs afternoon --------------------------------------------------
// Identical titles differing only by time of day: the noise list handles it.
t("morning vs afternoon of one tour",
  tourLikeness("Arenal Hanging Bridges Morning Guided Walk",
               "Arenal Hanging Bridges Afternoon Guided Walk") >= TOUR_SAME, true);
// And where the titles are genuinely identical, the product code catches it.
t("same supplier, different departure", tourFamily("132218P75"), "132218");
t("…matches its sibling", tourFamily("132218P76"), "132218");
t("different supplier", tourFamily("3431P5"), "3431");
t("a code with no P is no family", tourFamily("5383GOURMET"), null);
t("an absent code is no family", tourFamily(undefined), null);

// ---- tokenising ------------------------------------------------------------
t("noise words are dropped", tourTokens("Full Day Private Guided Tour").size, 0);
t("bare numbers are dropped", tourTokens("8 Days 7 Nights").size, 1); // "nights"
t("punctuation does not glue tokens", tourTokens("Wi-Fi").size, 0);
t("an empty title has no tokens", tourTokens("").size, 0);
t("nothing is similar to nothing", tourLikeness("Full Day Tour", "Private Tour"), 0);

// ---- the whole filter ------------------------------------------------------
const ranked = [
  { title: GC_A, code: "132218P75", rating: 4.9, reviews: 24399 },
  { title: GC_B, code: "3431P5", rating: 4.85, reviews: 13425 },
  { title: GC_AUDIO, code: "309754P2", rating: 4.6, reviews: 28 },
  { title: "DZRT Splendor Adventure: RED ROCK RIM UTV Tour", code: "352371P1", rating: 0, reviews: 0 },
];
const kept = dedupeIdeas(ranked, 6);
t("four results collapse to three", kept.length, 3);
t("the best-reviewed of the pair survives", kept[0].code, "132218P75");
t("the duplicate is the one dropped", kept.some(k => k.code === "3431P5"), false);
t("genuinely different tours are kept", kept.map(k => k.code).join(","), "132218P75,309754P2,352371P1");

// Same product family, identical titles — the morning/afternoon shape.
const fam = dedupeIdeas([
  { title: "Arenal Hanging Bridges", code: "15373P2", rating: 4.9 },
  { title: "Arenal Hanging Bridges", code: "15373P7", rating: 4.8 },
], 6);
t("two departures of one product collapse", fam.length, 1);
t("…keeping the better-rated", fam[0].code, "15373P2");

// ---- one supplier, two unrelated day trips ---------------------------------
// Transporte Baja out of Ensenada sells both of these under code 31612. They are
// a wine day and a blowhole-plus-handicrafts half day, and on the family rule
// alone the Bufadora trip was collapsed into the wine tour and disappeared. It
// was the only non-wine idea in a real Pinecrest set of ten, so the panel rendered
// as six near-identical wine tours and the footer described the casualty as a
// near-duplicate. Hence the title floor on the family rule.
const BAJA_WINE = "Guadalupe Valley Wine Route Tour in Baja California";
const BAJA_BLOWHOLE = "La Bufadora Tour in Baja California";
near("wine route vs blowhole, same supplier", tourLikeness(BAJA_WINE, BAJA_BLOWHOLE), 0.29);
t("…the shared words are only the region", tourLikeness(BAJA_WINE, BAJA_BLOWHOLE) < TOUR_FAMILY_FLOOR, true);
t("…so a shared family is not enough to collapse them", dedupeIdeas([
  { title: BAJA_WINE, code: "31612P1", rating: 4.97, reviews: 333 },
  { title: BAJA_BLOWHOLE, code: "31612P3", rating: 4.78, reviews: 218 },
], 6).length, 2);

// The floor must not undo the rule it guards: identical titles still collapse.
t("the floor leaves identical-title departures collapsing",
  tourLikeness("Arenal Hanging Bridges", "Arenal Hanging Bridges") >= TOUR_FAMILY_FLOOR, true);
// And the floor sits below TOUR_SAME, or the family rule could never fire on
// anything the title rule had not already caught.
t("the floor is below the title threshold", TOUR_FAMILY_FLOOR < TOUR_SAME, true);

t("the limit is honoured", dedupeIdeas([
  { title: "Alpha rafting", code: "1P1" }, { title: "Bravo cooking", code: "2P1" },
  { title: "Charlie diving", code: "3P1" }, { title: "Delta surfing", code: "4P1" },
], 2).length, 2);
t("an empty list is fine", dedupeIdeas([], 6).length, 0);
t("a missing list is fine", dedupeIdeas(undefined, 6).length, 0);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
