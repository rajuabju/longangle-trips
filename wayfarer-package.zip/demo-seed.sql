-- Demo data. Entirely invented — no real person, booking or confirmation code.
--
-- WHY THIS EXISTS. An empty install renders every screen blank, and a blank
-- screen cannot be told apart from a broken one. These four trips light up the
-- itinerary, the map, the budget, Trip Check, the packing list and the history
-- panel, so after loading them you know your deployment works before you trust
-- it with anything real.
--
--   npx wrangler d1 execute wayfarer-data --remote --file=demo-seed.sql
--
-- DELETE IT ALL when you are ready, in one statement:
--
--   DELETE FROM trips WHERE id BETWEEN 9000001 AND 9000099;
--
-- Child rows go with the trip: every table below is ON DELETE CASCADE.
--
-- The dates are deliberately RELATIVE-LOOKING but fixed, so the demo shows a
-- past trip, a current-year trip and two upcoming ones. If you load this long
-- after 2027 they will all read as past — harmless, and another reason to
-- delete them once your own trips are in.

-- ---------------------------------------------------------------- id_seq ----
-- nextId() increments this row and hands back the previous value. Without it
-- every write fails with a 500 that looks like a database problem. schema.sql
-- seeds it; this raises the floor above the demo ids so nothing collides.
INSERT INTO id_seq (name, next) VALUES ('global', 9100000)
  ON CONFLICT(name) DO UPDATE SET next = MAX(next, 9100000);

-- ------------------------------------------------------------------ trips ---
INSERT INTO trips (id, name, starts_at, ends_at, has_dates, timezone, description, hidden, cover_gradient, number_of_days, data, created_at, updated_at) VALUES
 (9000001,'Lisbon','2027-04-08','2027-04-14',1,'Europe/Lisbon','Demo trip — delete me.',0,3,7,'{"trip_type":"personal"}',datetime('now'),datetime('now')),
 (9000002,'Big Sur','2027-06-19','2027-06-21',1,'America/Los_Angeles','Demo trip — a drive, no flights.',0,1,3,'{"trip_type":"personal"}',datetime('now'),datetime('now')),
 (9000003,'Chicago','2026-11-04','2026-11-06',1,'America/Chicago','Demo trip — a past business trip.',0,5,3,'{"trip_type":"business"}',datetime('now'),datetime('now')),
 (9000004,'The Ranch','2027-08-13','2027-08-16',1,'America/Los_Angeles','Demo trip — a name and two dates, nothing else. This is what a repeat visit to a known place looks like.',0,2,4,'{"trip_type":"personal"}',datetime('now'),datetime('now'));

-- --------------------------------------------------------- transportations --
-- Lisbon: an outbound with a connection, so the itinerary shows a layover and
-- the destination logic has to skip it. Chicago: a plain round trip.
INSERT INTO transportations (id, trip_id, name, transportation_type, transport_number, company, departure_at, arrival_at, departure_timezone, arrival_timezone, provider_reservation_code, sort_order, data, created_at, updated_at) VALUES
 (9000010,9000001,'LAX → JFK','airplane','DL412','Delta','2027-04-08T15:30:00Z','2027-04-08T23:45:00Z','America/Los_Angeles','America/New_York','DEMO01',0,'{"departure_description":"Los Angeles International Airport (LAX)","arrival_description":"John F. Kennedy International Airport (JFK)","departure_latitude":33.9416,"departure_longitude":-118.4085,"arrival_latitude":40.6413,"arrival_longitude":-73.7781,"price":0,"seat_class":"economy"}',datetime('now'),datetime('now')),
 (9000011,9000001,'JFK → LIS','airplane','TP204','TAP Air Portugal','2027-04-09T01:30:00Z','2027-04-09T12:50:00Z','America/New_York','Europe/Lisbon','DEMO01',1,'{"departure_description":"John F. Kennedy International Airport (JFK)","arrival_description":"Humberto Delgado Airport (LIS)","departure_latitude":40.6413,"departure_longitude":-73.7781,"arrival_latitude":38.7742,"arrival_longitude":-9.1342,"price":0,"seat_class":"economy"}',datetime('now'),datetime('now')),
 (9000012,9000001,'LIS → LAX','airplane','TP205','TAP Air Portugal','2027-04-14T10:15:00Z','2027-04-14T22:40:00Z','Europe/Lisbon','America/Los_Angeles','DEMO01',2,'{"departure_description":"Humberto Delgado Airport (LIS)","arrival_description":"Los Angeles International Airport (LAX)","departure_latitude":38.7742,"departure_longitude":-9.1342,"arrival_latitude":33.9416,"arrival_longitude":-118.4085,"price":0}',datetime('now'),datetime('now')),
 (9000013,9000003,'LAX → ORD','airplane','AA318','American Airlines','2026-11-04T14:00:00Z','2026-11-04T20:05:00Z','America/Los_Angeles','America/Chicago','DEMO02',0,'{"departure_description":"Los Angeles International Airport (LAX)","arrival_description":"O''Hare International Airport (ORD)","departure_latitude":33.9416,"departure_longitude":-118.4085,"arrival_latitude":41.9742,"arrival_longitude":-87.9073,"price":0}',datetime('now'),datetime('now')),
 (9000014,9000003,'ORD → LAX','airplane','AA2251','American Airlines','2026-11-06T22:30:00Z','2026-11-07T01:10:00Z','America/Chicago','America/Los_Angeles','DEMO02',1,'{"departure_description":"O''Hare International Airport (ORD)","arrival_description":"Los Angeles International Airport (LAX)","departure_latitude":41.9742,"departure_longitude":-87.9073,"arrival_latitude":33.9416,"arrival_longitude":-118.4085,"price":0}',datetime('now'),datetime('now'));

-- ---------------------------------------------------------------- hostings ---
-- Big Sur has two rooms on the same nights, which is what a family booking
-- looks like and what the "second room, not a duplicate" rule exists for.
INSERT INTO hostings (id, trip_id, name, starts_at, ends_at, timezone, address, latitude, longitude, provider_reservation_code, sort_order, data, created_at, updated_at) VALUES
 (9000020,9000001,'Hotel do Chiado','2027-04-09T14:00:00Z','2027-04-14T09:00:00Z','Europe/Lisbon','Rua Nova do Almada 114, Lisbon, Portugal',38.7110,-9.1400,'DEMOH1',0,'{"refundable":true}',datetime('now'),datetime('now')),
 (9000021,9000002,'Big Sur Lodge','2027-06-19T16:00:00Z','2027-06-21T11:00:00Z','America/Los_Angeles','47225 CA-1, Big Sur, CA',36.2704,-121.7802,'DEMOH2',0,'{"refundable":false,"description":"Room 1"}',datetime('now'),datetime('now')),
 (9000022,9000002,'Big Sur Lodge','2027-06-19T16:00:00Z','2027-06-21T11:00:00Z','America/Los_Angeles','47225 CA-1, Big Sur, CA',36.2704,-121.7802,NULL,1,'{"description":"Room 2"}',datetime('now'),datetime('now')),
 (9000023,9000003,'The Blackstone','2026-11-04T21:00:00Z','2026-11-06T17:00:00Z','America/Chicago','636 S Michigan Ave, Chicago, IL',41.8724,-87.6244,'DEMOH3',0,'{"refundable":true}',datetime('now'),datetime('now'));

-- -------------------------------------------------------------- activities ---
INSERT INTO activities (id, trip_id, name, activity_type, starts_at, ends_at, timezone, address, latitude, longitude, sort_order, data, created_at, updated_at) VALUES
 (9000030,9000001,'Jerónimos Monastery','sightseeing','2027-04-10T09:30:00Z','2027-04-10T11:30:00Z','Europe/Lisbon','Praça do Império, Lisbon',38.6979,-9.2067,0,'{}',datetime('now'),datetime('now')),
 (9000031,9000001,'Dinner at Taberna Real','restaurant','2027-04-10T19:30:00Z','2027-04-10T21:30:00Z','Europe/Lisbon','Rua da Misericórdia, Lisbon',38.7118,-9.1436,1,'{}',datetime('now'),datetime('now')),
 (9000032,9000002,'McWay Falls walk','sightseeing','2027-06-20T10:00:00Z','2027-06-20T11:00:00Z','America/Los_Angeles','Julia Pfeiffer Burns State Park, CA',36.1577,-121.6720,0,'{}',datetime('now'),datetime('now')),
 (9000033,9000003,'Client meeting','meeting','2026-11-05T15:00:00Z','2026-11-05T17:00:00Z','America/Chicago','233 S Wacker Dr, Chicago, IL',41.8789,-87.6359,0,'{}',datetime('now'),datetime('now'));

-- ---------------------------------------------------------------- expenses ---
-- Costs live on expenses LINKED to the booking they pay for, never on the
-- booking itself — see SETUP.md. Lisbon is deliberately only partly costed, so
-- the Budget shows its "this total covers 2 of 4 bookings" line.
INSERT INTO expenses (id, trip_id, name, amount, currency, date, sort_order, data, created_at, updated_at) VALUES
 (9000040,9000001,'TAP LIS return, 2 pax (conf DEMO01)',1284.60,'USD','2027-01-14',0,'{"linked_kind":"transport","linked_id":9000011,"category":"Transport"}',datetime('now'),datetime('now')),
 (9000041,9000001,'Hotel do Chiado, 5 nights',1420.00,'EUR','2027-04-14',1,'{"linked_kind":"hosting","linked_id":9000020,"category":"Lodging"}',datetime('now'),datetime('now')),
 (9000042,9000001,'Dinner, Taberna Real',96.50,'EUR','2027-04-10',2,'{"category":"Dining"}',datetime('now'),datetime('now')),
 (9000043,9000002,'Big Sur Lodge, both rooms',742.00,'USD','2027-06-21',0,'{"linked_kind":"hosting","linked_id":9000021,"category":"Lodging"}',datetime('now'),datetime('now')),
 (9000044,9000003,'The Blackstone, 2 nights',518.44,'USD','2026-11-06',0,'{"linked_kind":"hosting","linked_id":9000023,"category":"Lodging"}',datetime('now'),datetime('now'));
