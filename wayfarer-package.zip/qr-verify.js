// Verifies public/qr.js by decoding what it encodes with jsQR, an independent
// implementation. Run with: node qr-verify.js
// jsqr is a dev-only dependency (npm install jsqr --no-save); this script is not
// part of the deployed bundle.
const fs = require("fs");
const path = require("path");
const jsQR = require("jsqr").default || require("jsqr");

// qr.js attaches itself to `window`; give it one.
const window = {};
global.window = window;
eval(fs.readFileSync(path.join(__dirname, "public", "qr.js"), "utf8"));
const QR = window.RiveraQR;

function rasterise(text, scale) {
  scale = scale || 4;
  const q = QR.build(text);
  const quiet = 4;
  const dim = (q.size + quiet * 2) * scale;
  // RGBA, white background.
  const data = new Uint8ClampedArray(dim * dim * 4).fill(255);
  for (let r = 0; r < q.size; r++) {
    for (let c = 0; c < q.size; c++) {
      if (!q.modules[r][c]) continue;
      for (let dy = 0; dy < scale; dy++) {
        for (let dx = 0; dx < scale; dx++) {
          const y = (r + quiet) * scale + dy, x = (c + quiet) * scale + dx;
          const i = (y * dim + x) * 4;
          data[i] = data[i + 1] = data[i + 2] = 0;
        }
      }
    }
  }
  return { data, dim, version: q.version };
}

const tests = [
  "TEST123",
  "27183094471-4",
  "ABC-123-XYZ",
  "https://tickets.example.com/t/9f3ac21b8e",
  "M1RIVERA/ALEX     EABC123 LAXSFODL 1715 270Y012A0028 100",
  "0123456789012345678901234567890123456789012345678901234567890123456789",
  "A".repeat(150),
  "A".repeat(300),
  "Café — naïve € ünïcode ✓",
];

// Exercise every version by filling each one close to capacity — the block
// splitting and interleaving differ per version, so v1 passing proves little
// about v11.
for (let v = 1; v <= 15; v++) {
  const cap = { 1: 14, 2: 26, 3: 42, 4: 62, 5: 84, 6: 106, 7: 122, 8: 152, 9: 180, 10: 213, 11: 251, 12: 287, 13: 331, 14: 362, 15: 412 }[v];
  tests.push("v" + v + "-" + "X".repeat(cap - String("v" + v + "-").length));
}

let pass = 0;
for (const t of tests) {
  const { data, dim, version } = rasterise(t);
  const res = jsQR(data, dim, dim);
  const ok = !!res && res.data === t;
  if (ok) pass++;
  console.log(
    (ok ? "PASS" : "FAIL") + "  v" + String(version).padStart(2) +
    "  len=" + String(t.length).padStart(3) +
    (ok ? "" : "  decoded=" + JSON.stringify(res ? res.data : null).slice(0, 60))
  );
}
console.log(pass + "/" + tests.length + " round-tripped");
process.exit(pass === tests.length ? 0 : 1);
