// The calendar feed's timestamps.
//
// A dinner reservation has a start and no end. So does an Uber, and most
// activities booked for a time rather than a span. The feed rendered every one
// of them with DTEND at the Unix epoch, which a calendar in any US timezone
// draws as 31 December 1969 — thirty-two events across the feed.
//
// The cause is one of JavaScript's genuinely nasty edges: new Date(null) is
// epoch 0, a perfectly valid Date, so an isNaN() guard waves it through.
// undefined and "" both give Invalid Date and were caught. null — which is
// exactly what a missing field reads as coming out of D1 — was not.
//
// Fixtures are invented.
const fs = require("fs");
const src = fs.readFileSync("functions/cal/[token].js", "utf8");

// The feed is an ES module for Pages Functions, so lift the helpers out rather
// than importing it.
function grabConst(name) {
  const i = src.indexOf("const " + name + " = ");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1) + ";"; }
  }
  throw new Error("unterminated " + name);
}
eval(grabConst("stampUtc") + "globalThis.stampUtc = stampUtc;");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

console.log("\nreal instants");
t("a stored timestamp", stampUtc("2027-01-22T16:57:00Z"), "20270122T165700Z");
t("milliseconds are dropped", stampUtc("2027-01-22T16:57:00.000Z"), "20270122T165700Z");
t("an offset is normalised to UTC", stampUtc("2027-01-22T08:57:00-08:00"), "20270122T165700Z");
// A date with no time is a real instant: midnight UTC.
t("a bare date", stampUtc("2027-01-22"), "20270122T000000Z");

console.log("\nabsent means absent, not 1970");
// THE bug. null is what D1 gives for a missing JSON field, and new Date(null)
// is epoch 0 rather than Invalid Date, so the old isNaN() guard passed it.
t("null", stampUtc(null), null);
t("undefined", stampUtc(undefined), null);
t("empty string", stampUtc(""), null);
// The specific value that was being emitted, so this test names the symptom.
t("null does not become the epoch stamp", stampUtc(null) === "19700101T000000Z", false);
t("nor any 1970 stamp at all", /^1970/.test(String(stampUtc(null))), false);

console.log("\nand junk is still refused");
t("not a date", stampUtc("not a date"), null);
t("a confirmation code", stampUtc("DZQKRT"), null);
t("an object", stampUtc({}), null);
t("NaN", stampUtc(NaN), null);
// 0 is a real instant if someone genuinely means it, but it is not what a
// missing field looks like -- and nothing in this database stores one.
t("the number zero is epoch, and says so", stampUtc(0), "19700101T000000Z");

console.log("\nwhat the feed does with a missing end");
// timed() falls back to the start when the end is absent, giving a
// point-in-time event -- which is what a dinner reservation actually is. That
// fallback could never fire while stampUtc returned a truthy epoch string.
t("the fallback exists", /const e = stampUtc\(endIso\) \|\| s;/.test(src), true);
// And an item with no START is skipped entirely rather than emitted at 1970.
t("a missing start skips the event", /const s = stampUtc\(startIso\);\s*\n\s*if \(!s\) return;/.test(src), true);
t("the guard is on the value, not just isNaN",
  /if \(iso == null \|\| iso === ""\) return null;/.test(src), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
