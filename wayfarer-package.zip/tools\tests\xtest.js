// Exercise crossTripFindings against real trip data plus planted faults.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");

// Pull the function out along with the small helpers it leans on.
function grab(name) {
  const i = src.indexOf("  function " + name + "(");
  if (i < 0) throw new Error("not found: " + name);
  let d = 0, started = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; started = true; }
    else if (src[j] === "}") { d--; if (started && d === 0) return src.slice(i, j + 1); }
  }
  throw new Error("unbalanced: " + name);
}

const stubs = `
  function dayKey(when, tz) { return String(when).slice(0, 10); }
  function dayLabel(k) { return k; }
  function fmtRange(t) { return t.starts_at + ".." + t.ends_at; }
  function transName(o) { return ((o.company || "") + " " + (o.transport_number || "")).trim() || "Flight"; }
`;
eval(stubs + grab("allItems") + grab("crossTripFindings") + ";globalThis.X = crossTripFindings;");

const T = (id, name, s, e) => ({ id, name, starts_at: s, ends_at: e, has_dates: true });
const F = (id, company, num, dep, code) => ({
  id, company, transport_number: num, departure_at: dep, provider_reservation_code: code,
});

const cases = [
  {
    label: "clean: two ordinary trips",
    loaded: [
      { trip: T(1, "Vegas", "2026-10-16", "2026-10-18"), data: { transports: [F(101, "Delta", "DL1", "2026-10-16T09:00:00Z", "ABC123")], hostings: [], activities: [] } },
      { trip: T(2, "Costa Rica", "2027-01-22", "2027-01-31"), data: { transports: [F(201, "Alaska", "AS1412", "2027-01-22T08:00:00Z", "XYZ789")], hostings: [], activities: [] } },
    ],
    expect: [],
  },
  {
    label: "one confirmation code on two trips (the live VPUI2K shape)",
    loaded: [
      { trip: T(1, "Europe", "2026-05-18", "2026-05-30"), data: { transports: [F(101, "Air France", "AF22", "2026-05-18T10:00:00Z", "VPUI2K")], hostings: [], activities: [] } },
      { trip: T(2, "Los Angeles", "2026-06-29", "2026-07-02"), data: { transports: [F(201, "Air France", "AF22", "2026-06-29T10:00:00Z", "VPUI2K")], hostings: [], activities: [] } },
    ],
    expect: ["code|VPUI2K"],
  },
  {
    label: "booking dated inside a different trip's window",
    loaded: [
      { trip: T(1, "Vegas", "2026-10-16", "2026-10-18"), data: { transports: [F(101, "Delta", "DL1", "2027-01-25T09:00:00Z", "ABC123")], hostings: [], activities: [] } },
      { trip: T(2, "Costa Rica", "2027-01-22", "2027-01-31"), data: { transports: [], hostings: [], activities: [] } },
    ],
    expect: ["misfiled|101"],
  },
  {
    label: "outside its own trip but matching NO other trip -> silent (per-trip check owns it)",
    loaded: [
      { trip: T(1, "Vegas", "2026-10-16", "2026-10-18"), data: { transports: [F(101, "Delta", "DL1", "2029-03-03T09:00:00Z", "ABC123")], hostings: [], activities: [] } },
      { trip: T(2, "Costa Rica", "2027-01-22", "2027-01-31"), data: { transports: [], hostings: [], activities: [] } },
    ],
    expect: [],
  },
  {
    label: "outside its own trip but matching TWO others -> silent (would be a guess)",
    loaded: [
      { trip: T(1, "Vegas", "2026-10-16", "2026-10-18"), data: { transports: [F(101, "Delta", "DL1", "2027-01-25T09:00:00Z", "ABC")], hostings: [], activities: [] } },
      { trip: T(2, "Costa Rica", "2027-01-22", "2027-01-31"), data: { transports: [], hostings: [], activities: [] } },
      { trip: T(3, "Overlapping", "2027-01-24", "2027-01-27"), data: { transports: [], hostings: [], activities: [] } },
    ],
    expect: [],
  },
  {
    label: "same leg on two trips with no confirmation codes",
    loaded: [
      { trip: T(1, "Trip A", "2026-10-16", "2026-10-18"), data: { transports: [F(101, "United", "UA555", "2026-10-16T13:00:00Z", null)], hostings: [], activities: [] } },
      { trip: T(2, "Trip B", "2026-10-16", "2026-10-19"), data: { transports: [F(201, "United", "UA555", "2026-10-16T13:00:00Z", null)], hostings: [], activities: [] } },
    ],
    expect: ["dupleg|united|ua555|2026-10-16T13:00:00Z"],
  },
  {
    label: "short codes are ignored (they collide by chance)",
    loaded: [
      { trip: T(1, "A", "2026-10-16", "2026-10-18"), data: { transports: [F(101, "Delta", "DL1", "2026-10-16T09:00:00Z", "AB1")], hostings: [], activities: [] } },
      { trip: T(2, "B", "2026-11-16", "2026-11-18"), data: { transports: [F(201, "Delta", "DL2", "2026-11-16T09:00:00Z", "AB1")], hostings: [], activities: [] } },
    ],
    expect: [],
  },
  {
    label: "same code twice within ONE trip is not a cross-trip finding",
    loaded: [
      { trip: T(1, "A", "2026-10-16", "2026-10-20"), data: { transports: [F(101, "Delta", "DL1", "2026-10-16T09:00:00Z", "SAME99"), F(102, "Delta", "DL2", "2026-10-20T09:00:00Z", "SAME99")], hostings: [], activities: [] } },
    ],
    expect: [],
  },
  {
    label: "a hosting filed under the wrong trip is caught too",
    loaded: [
      { trip: T(1, "Vegas", "2026-10-16", "2026-10-18"), data: { transports: [], hostings: [{ id: 301, name: "Nayara Tented Camp", starts_at: "2027-01-24T22:00:00Z", ends_at: "2027-01-27T18:00:00Z" }], activities: [] } },
      { trip: T(2, "Costa Rica", "2027-01-22", "2027-01-31"), data: { transports: [], hostings: [], activities: [] } },
    ],
    expect: ["misfiled|301"],
  },
];

let pass = 0, fail = 0;
for (const c of cases) {
  const got = X(c.loaded).map((f) => f.key.replace(/^x\|/, "")).sort();
  const want = c.expect.slice().sort();
  const ok = JSON.stringify(got) === JSON.stringify(want);
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + c.label);
  if (!ok) console.log("        want " + JSON.stringify(want) + "\n        got  " + JSON.stringify(got));
}
console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
