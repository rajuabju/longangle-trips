// U16 -- edit an idea, keep the list you already have.
//
// Every write in the Trip Ideas panel ended with reload(): a fresh GET of the
// whole list to find out about one changed row. The reply already contained it.
// Both handlers in _core.js read the row back after writing and return it
// hydrated, so the response IS the authoritative version.
//
// Confirmed against the dev API: PATCHing only {note} to an idea returns
//   place, note, target_from, airport, airport_auto, id, created_at,
//   updated_at, address, latitude, longitude, target_to, season_from,
//   season_to, sort_order
// with place and target_from intact and airport/airport_auto filled in by
// withAutoAirport server-side. That last part is the whole reason these apply
// the RESPONSE and never the request body: applying {note} locally would leave
// the row looking edited and missing everything the server added.
//
// The splices are run for real. A test that only matched the source would not
// notice the case that actually matters -- what happens when the row is not
// there any more.
// Verified live against the dev API, counting fetches from the page:
//   edit   -> PATCH  /v1/ideas/{id}, 0 GET /v1/ideas, row shows the new note
//   create -> POST   /v1/ideas,      0 GET /v1/ideas, list grows to 4
//   remove -> DELETE /v1/ideas/{id}, 0 GET /v1/ideas, list back to 3
// Each was two requests before this and is one now.
//
// The local seed database had no trip_ideas table at all, so none of this could
// be exercised until the table was created from schema.sql. Worth knowing
// before anyone tries to test this panel locally again.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

function lift(decl) {
  const start = app.indexOf(decl);
  if (start < 0) throw new Error("not found: " + decl);
  let depth = 0, i = app.indexOf("{", start);
  for (; i < app.length; i++) {
    if (app[i] === "{") depth++;
    else if (app[i] === "}") { depth--; if (!depth) break; }
  }
  return app.slice(start, i + 1);
}

// dropIdea REASSIGNS ideas, so the harness has to hand back a live view of the
// variable rather than a snapshot taken at build time.
function harness(seed) {
  const src = [
    "var ideas = seed.slice();",
    lift("function replaceIdea(fresh)"),
    lift("function addIdea(fresh)"),
    lift("function dropIdea(id)"),
    "return { replaceIdea: replaceIdea, addIdea: addIdea, dropIdea: dropIdea, list: function () { return ideas; } };",
  ].join("\n");
  return new Function("seed", src)(seed);
}

const SEED = () => [
  { id: 1, place: "Kyoto", note: "before", target_from: "2027-10" },
  { id: 2, place: "Lisbon", note: "b", target_from: "2028-04" },
  { id: 3, place: "Reykjavik", note: "c", target_from: null },
];

console.log("\nan edit lands on the row it belongs to");
{
  const h = harness(SEED());
  // What the server actually sends back: the whole row, not the patch.
  const ok = h.replaceIdea({ id: 2, place: "Lisbon", note: "after", target_from: "2028-04", airport: "LIS" });
  t("it reports success", ok, true);
  t("the row is replaced wholesale", h.list()[1], { id: 2, place: "Lisbon", note: "after", target_from: "2028-04", airport: "LIS" });
  t("the list does not grow", h.list().length, 3);
  t("its neighbours are untouched", [h.list()[0].note, h.list()[2].note], ["before", "c"]);
  // Order is not the server's to decide here -- paint() re-derives it through
  // sortIdeas -- so the splice keeps position and lets the sort do its job.
  t("and it stays where it was", h.list().map((x) => x.id), [1, 2, 3]);
}
{
  // Fields the client never sent must survive, because the server computes some
  // of them. This is the case that makes applying the request body wrong.
  const h = harness(SEED());
  h.replaceIdea({ id: 1, place: "Kyoto", note: "after", target_from: "2027-10", airport: "KIX", airport_auto: 1 });
  t("server-computed fields arrive with it", [h.list()[0].airport, h.list()[0].airport_auto], ["KIX", 1]);
}

console.log("\nwhen the splice cannot be trusted, it says so");
// The caller reloads on false. Silently doing nothing would leave the panel
// showing a row the user just edited, unchanged, with no error.
{
  const h = harness(SEED());
  t("a row that is not in the list", h.replaceIdea({ id: 99, place: "Oslo" }), false);
  t("nothing is added by the attempt", h.list().length, 3);
  t("a reply with no id", h.replaceIdea({ place: "Oslo" }), false);
  t("an id of null", h.replaceIdea({ id: null, place: "Oslo" }), false);
  t("an empty reply", h.replaceIdea(null), false);
  t("undefined", h.replaceIdea(undefined), false);
}
{
  // id 0 is falsy but a legitimate id. `== null` is deliberate here where a
  // plain `!fresh.id` would reject it.
  const h = harness([{ id: 0, place: "Zero" }]);
  t("id zero is a real id", h.replaceIdea({ id: 0, place: "Zero", note: "n" }), true);
  t("and it is applied", h.list()[0].note, "n");
}

console.log("\nadding puts one row on the end");
{
  const h = harness(SEED());
  t("it reports success", h.addIdea({ id: 4, place: "Porto" }), true);
  t("the list grows by one", h.list().length, 4);
  t("with the server's id", h.list()[3].id, 4);
}
{
  // The panel can sit open while another device writes. A second copy of the
  // same id would render twice and edit unpredictably.
  const h = harness(SEED());
  h.addIdea({ id: 2, place: "Lisbon", note: "from another tab" });
  t("an id already present updates rather than duplicates", h.list().length, 3);
  t("and takes the newer values", h.list()[1].note, "from another tab");
}
{
  const h = harness(SEED());
  t("a reply with no id is refused", h.addIdea({ place: "Nowhere" }), false);
  t("and nothing is added", h.list().length, 3);
  t("an empty reply too", h.addIdea(null), false);
}

console.log("\nremoving takes exactly one row out");
{
  const h = harness(SEED());
  t("it reports success", h.dropIdea(2), true);
  t("the list shrinks by one", h.list().length, 2);
  t("and it is the right one", h.list().map((x) => x.id), [1, 3]);
}
{
  const h = harness(SEED());
  t("an id not in the list", h.dropIdea(99), false);
  t("leaves it alone", h.list().length, 3);
  // The delete replies {ok:true} with no row, so this drops by id -- a string
  // "2" from a stray dataset read must not silently match the number 2 and
  // remove someone else's row, nor be treated as a success.
  t("a string id does not match a numeric one", h.dropIdea("2"), false);
  t("so nothing is removed", h.list().length, 3);
}

console.log("\nthe call sites use them, and fall back when they cannot");
const panel = app.slice(app.indexOf("async function openBucketList()"),
                        app.indexOf("async function openBucketList()") + 22000);
t("the edit applies the response", /var fresh = await api\("\/v1\/ideas\/" \+ item\.id, \{ method: "PATCH", body: JSON\.stringify\(patch\) \}\);/.test(panel), true);
t("and reloads only if it could not", /if \(!replaceIdea\(fresh\)\) await reload\(\);/.test(panel), true);
t("the create applies the response", /var fresh = await api\("\/v1\/ideas", \{ method: "POST", body: JSON\.stringify\(entry\) \}\);/.test(panel), true);
t("with the same fallback", /if \(!addIdea\(fresh\)\) await reload\(\);/.test(panel), true);
t("the remove drops by id", /if \(!dropIdea\(item\.id\)\) await reload\(\);/.test(panel), true);
// Each one still repaints -- the splice changes the data, not the screen.
t("all three repaint", (panel.match(/await reload\(\);\s*\n\s*paint\(\);/g) || []).length, 3);

// The bulk geocoder writes many rows at once and its reload is correct: there
// is no single response to splice. It must NOT be converted.
t("the bulk geocoder still re-reads the list",
  /openFindLocations\(placeless, async function \(\) \{ await reload\(\); paint\(\); \}\);/.test(app), true);
t("and it is the only wholesale reload left in the panel",
  (app.match(/await reload\(\); paint\(\);/g) || []).length, 1);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
