#!/usr/bin/env node
// Smoke test. Fast, no dependencies, and aimed squarely at the failures that
// have actually happened here rather than at coverage for its own sake.
//
// The calendar feed is the reason this exists. On 2026-08-12 a dead-code sweep
// removed nextDay(), whose only call sits inside a template literal, and every
// /cal/ request 500'd for a day. Nothing noticed until Outlook refused the
// subscription, because the feed had no test of any kind.
//
//   npm run smoke                        # against a local preview on 8788
//   npm run smoke -- --base=http://127.0.0.1:8790
//   npm run smoke -- --feed=https://trips.example.com/cal/<token>.ics
//
// --base creates a temporary feed through the API, tests it, and deletes it.
// --feed tests one URL you supply. Pass the production token that way rather
// than committing it: a feed URL is a bearer credential and this file is in git.
const fs = require("fs");
const path = require("path");

const args = process.argv.slice(2);
const arg = (n, d) => { const a = args.find((x) => x.startsWith("--" + n + "=")); return a ? a.slice(n.length + 3) : d; };
const BASE = arg("base", args.some((a) => a.startsWith("--feed=")) ? null : "http://127.0.0.1:8788");
const FEED = arg("feed", null);
const ROOT = path.resolve(__dirname, "..");

let pass = 0, fail = 0;
const results = [];
function check(name, ok, detail) {
  ok ? pass++ : fail++;
  results.push({ name, ok, detail: ok ? "" : String(detail == null ? "" : detail) });
}
const section = (t) => results.push({ section: t });

// ---------------------------------------------------------------- static ----
function staticChecks() {
  section("Static — the built client");
  const idx = fs.readFileSync(path.join(ROOT, "public/index.html"), "utf8");
  const refs = [...new Set((idx.match(/(app|styles|qr|feasibility)\.[a-f0-9]{10}\.(js|css)/g) || []))];
  check("index.html references hashed assets", refs.length >= 3, refs.length + " found");
  for (const r of refs) {
    check("asset exists on disk: " + r, fs.existsSync(path.join(ROOT, "public", r)));
  }
  const appName = refs.find((r) => r.startsWith("app."));
  if (appName) {
    const app = fs.readFileSync(path.join(ROOT, "public", appName), "utf8");
    let parsed = true, why = "";
    try { new Function(app); } catch (e) { parsed = false; why = e.message; }
    check("built app.js parses", parsed, why);
    check("build marker present", /__WAYFARER_BUILD\s*=\s*"v\d+\.\d+"/.test(app),
      (app.match(/__WAYFARER_BUILD[^;]*/) || [""])[0]);
  }
  // The service worker precaches by exact filename; a mismatch serves a stale
  // bundle to every installed PWA.
  const sw = fs.readFileSync(path.join(ROOT, "public/sw.js"), "utf8");
  const swRefs = [...new Set((sw.match(/(app|styles|qr|feasibility)\.[a-f0-9]{10}\.(js|css)/g) || []))];
  // Not plain equality any more. Every asset the PAGE requests must be
  // precached or the installed PWA breaks offline -- that half is unchanged.
  // But the service worker may legitimately hold MORE than index.html lists:
  // qr.js is loaded on demand by the ticket dialog and is precached so that
  // dialog still works on a plane. An extra is only allowed if something
  // actually references it, which for a lazily-loaded asset means app.js
  // carries its hashed name; that keeps a stale precache entry from hiding here.
  const appSrc = fs.readFileSync(path.join(ROOT, "public/app.js"), "utf8");
  const missing = refs.filter((r) => !swRefs.includes(r));
  const unreferenced = swRefs.filter((r) => !refs.includes(r) && appSrc.indexOf(r) < 0);
  check("service worker precaches everything the page loads",
    missing.length === 0, "not precached: " + (missing.join(",") || "none"));
  check("and precaches nothing stale",
    unreferenced.length === 0,
    "in sw but referenced nowhere: " + (unreferenced.join(",") || "none"));

  // Every Worker file must parse as an ES module. `node --check` on a .js reads
  // it as CommonJS and rejects `export`, so these are checked as text instead.
  section("Static — Worker sources");
  const workers = [
    "functions/api/_core.js",
    "functions/api/v1/[[path]].js",
    "functions/api/ingest/[[path]].js",
    "functions/api/ext/[[path]].js",
    "functions/cal/[token].js",
  ];
  for (const w of workers) {
    const p = path.join(ROOT, w);
    if (!fs.existsSync(p)) { check("exists: " + w, false); continue; }
    const src = fs.readFileSync(p, "utf8");
    let ok = true, why = "";
    try { new Function("return (async()=>{})"); new (require("vm").Script)(src, { filename: w }); }
    catch (e) { ok = /import|export/.test(e.message) ? true : false; why = e.message; }
    check("parses: " + w, ok, why);
  }
}

// ------------------------------------------------------------------ http ----
async function get(url, opts) {
  const r = await fetch(url, Object.assign({ cache: "no-store" }, opts));
  return { status: r.status, ct: r.headers.get("content-type") || "", text: await r.text() };
}

async function apiChecks() {
  if (!BASE) return;
  section("API — every route answers");
  const routes = ["/api/v1/me", "/api/v1/trips", "/api/v1/insights", "/api/v1/checkstate",
                  "/api/v1/calfeeds", "/api/v1/packing", "/api/v1/knownname?q=probe"];
  for (const r of routes) {
    try {
      const res = await get(BASE + r);
      check("GET " + r, res.status === 200, "status " + res.status);
    } catch (e) { check("GET " + r, false, e.message); }
  }
  // The guard that stops a doubly-encoded body scattering one character per column.
  try {
    const r = await fetch(BASE + "/api/v1/trip/1/hostings", {
      method: "POST", headers: { "content-type": "application/json" }, body: '"{\\"a\\":1}"',
    });
    check("doubly-encoded body rejected", r.status === 400, "status " + r.status);
  } catch (e) { check("doubly-encoded body rejected", false, e.message); }
}

// ------------------------------------------------------------------ feed ----
function feedChecks(body, status, ct) {
  section("Calendar feed — RFC 5545");
  check("HTTP 200", status === 200, "status " + status);
  check("content-type is text/calendar", /text\/calendar/i.test(ct), ct);
  if (status !== 200) return;

  check("starts BEGIN:VCALENDAR", /^BEGIN:VCALENDAR/.test(body), body.slice(0, 80));
  check("ends END:VCALENDAR", /END:VCALENDAR\r\n$/.test(body), JSON.stringify(body.slice(-30)));
  check("VERSION:2.0 present", /^VERSION:2\.0$/m.test(body));
  check("PRODID present", /^PRODID:/m.test(body));

  const begins = (body.match(/BEGIN:VEVENT/g) || []).length;
  const ends = (body.match(/END:VEVENT/g) || []).length;
  check("has at least one VEVENT", begins > 0, begins + " events");
  check("VEVENT BEGIN/END balanced", begins === ends, begins + "/" + ends);

  const uids = [...body.matchAll(/^UID:(.*)$/gm)].map((m) => m[1]);
  check("one UID per VEVENT", uids.length === begins, uids.length + " uids / " + begins + " events");
  check("UIDs unique", new Set(uids).size === uids.length,
    uids.length - new Set(uids).size + " duplicates");

  const lines = body.split("\r\n");
  check("CRLF line endings", (body.match(/(?<!\r)\n/g) || []).length === 0,
    (body.match(/(?<!\r)\n/g) || []).length + " bare LF");
  const over = lines.filter((l) => Buffer.byteLength(l, "utf8") > 75);
  check("no line exceeds 75 octets", over.length === 0,
    over.length + " long lines, first: " + (over[0] || "").slice(0, 40));

  // The nextDay regression, caught directly. An all-day DTEND must be strictly
  // after its DTSTART; if the helper is missing the value is absent or bogus.
  const events = body.split("BEGIN:VEVENT").slice(1).map((b) => b.split("END:VEVENT")[0]);
  const allDay = events.filter((e) => /DTSTART;VALUE=DATE:/.test(e));
  let badSpan = 0;
  for (const e of allDay) {
    const s = (e.match(/DTSTART;VALUE=DATE:(\d{8})/) || [])[1];
    const t = (e.match(/DTEND;VALUE=DATE:(\d{8})/) || [])[1];
    if (!s || !t || !(t > s)) badSpan++;
  }
  check("all-day events have an exclusive DTEND after DTSTART", badSpan === 0,
    badSpan + " of " + allDay.length + " malformed");

  // A missing helper or field usually leaks one of these into the output.
  for (const junk of ["undefined", "NaN", "[object Object]", "ReferenceError"]) {
    check('no literal "' + junk + '" in the feed', !body.includes(junk));
  }
}

async function feedViaBase() {
  const mk = await fetch(BASE + "/api/v1/calfeeds", {
    method: "POST", headers: { "content-type": "application/json" },
    body: JSON.stringify({ name: "smoke-test" }),
  });
  if (!mk.ok) { check("create temporary feed", false, "status " + mk.status); return; }
  const feed = await mk.json();
  try {
    const res = await get(BASE + "/cal/" + feed.token + ".ics");
    feedChecks(res.text, res.status, res.ct);
  } finally {
    // Always clean up, even when the assertions above threw.
    const list = await fetch(BASE + "/api/v1/calfeeds").then((r) => r.json()).catch(() => ({}));
    const mine = (list.results || []).find((f) => f.name === "smoke-test");
    if (mine) await fetch(BASE + "/api/v1/calfeeds/" + mine.id, { method: "DELETE" }).catch(() => {});
  }
}

(async () => {
  staticChecks();
  if (FEED) {
    const res = await get(FEED).catch((e) => ({ status: 0, ct: "", text: e.message }));
    feedChecks(res.text, res.status, res.ct);
  } else {
    try { await get(BASE + "/api/v1/me"); }
    catch { console.log("\n  No preview on " + BASE + " — start one with `npm run dev`, or pass --feed=<url>.\n"); process.exit(2); }
    await apiChecks();
    await feedViaBase();
  }

  for (const r of results) {
    if (r.section) { console.log("\n  " + r.section); continue; }
    console.log("    " + (r.ok ? "ok  " : "FAIL") + "  " + r.name + (r.detail ? "  — " + r.detail : ""));
  }
  console.log("\n  " + pass + " passed, " + fail + " failed\n");
  process.exit(fail ? 1 : 0);
})();
