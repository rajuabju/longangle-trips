// Connect a REAL bank through Plaid, pull real data, and work out what would
// actually count toward a spend threshold. No app changes; nothing written to
// the app's database.
//
// Uses Plaid's HOSTED LINK: Plaid hosts the authentication page and hands back
// a URL. Amex and Chase are OAuth institutions -- Link redirects you to the
// bank's own login -- and self-hosting that flow means registering redirect
// URIs in the Plaid dashboard first. Hosted Link skips all of it.
//
// Your bank credentials go to the bank. Not to this script, not to the app, not
// to the transcript. What comes back here is an opaque token.
//
//   node tools/plaid-connect.js start   chase     mint the sign-in URL
//   ...sign in at the bank in your browser...
//   node tools/plaid-connect.js finish  chase     exchange, save the token, analyse
//   node tools/plaid-connect.js analyse chase     re-run the analysis, no re-linking
//   node tools/plaid-connect.js update  amex      change WHICH accounts are shared
//
// The bank name is a LABEL, not a filter -- Plaid Link is where you pick the
// institution. It decides which .dev.vars key the token is saved under
// (PLAID_CHASE_ACCESS_TOKEN), and that is the same name card_items.token_env
// points at, so one word ties the whole chain together. Defaults to amex.
//
// THE FREE TIER COVERS TEN ACCOUNTS IN TOTAL, and a single Amex login already
// used four of them. Link lets you tick individual accounts; tick only the
// cards with a threshold worth tracking.
//
// HISTORY: the first version of this asked for Plaid's default window and got
// 90 days, which starts a "calendar year to date" total in May. days_requested
// is only honoured at LINK time, so a longer window means re-linking -- hence
// this asking for 730 up front.
const fs = require("fs");
const path = require("path");
const os = require("os");
// The one classifier, shared with plaid-spend.js and agreeing with the app.
// This file used to carry its own category-based copy -- the version that read
// $427,904 of Amex payments as refunds -- which would have reproduced that
// mistake against every new bank linked with it.
const RULES = require("./plaid-rules");

const MODE = (process.argv[2] || "").toLowerCase();
// Sanitised because it becomes both a filename and an environment key.
const BANK = (process.argv[3] || "amex").toLowerCase().replace(/[^a-z0-9]/g, "");
const TOKEN_KEY = "PLAID_" + BANK.toUpperCase() + "_ACCESS_TOKEN";
// Per bank, so a half-finished Chase link cannot be picked up by a later Citi
// one and exchanged under the wrong name.
const SESSION = path.join(os.tmpdir(), "wayfarer-plaid-session-" + BANK + ".json");
const ENV_FILE = path.join(process.cwd(), ".dev.vars");
const DAYS_REQUESTED = 730;

if (!fs.existsSync(ENV_FILE)) {
  console.error("\nNo .dev.vars found at " + ENV_FILE + "\n");
  process.exit(1);
}

function readEnv() {
  const out = {};
  for (const line of fs.readFileSync(ENV_FILE, "utf8").split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/.exec(line);
    if (m) out[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
  return out;
}

// Written back into .dev.vars, which is gitignored. This IS a credential -- it
// reads bank transactions -- so it lives beside the Plaid secret rather than
// anywhere the repo can see, and is never printed.
function saveEnv(key, value) {
  const lines = fs.existsSync(ENV_FILE) ? fs.readFileSync(ENV_FILE, "utf8").split(/\r?\n/) : [];
  const idx = lines.findIndex((l) => new RegExp("^\\s*" + key + "\\s*=").test(l));
  if (idx >= 0) lines[idx] = key + "=" + value;
  else {
    if (lines.length && lines[lines.length - 1].trim() !== "") lines.push("");
    lines.push(key + "=" + value);
  }
  fs.writeFileSync(ENV_FILE, lines.join("\n"));
}

const env = readEnv();
const CLIENT_ID = env.PLAID_CLIENT_ID, SECRET = env.PLAID_SECRET;
const PLAID_ENV = (env.PLAID_ENV || "production").toLowerCase();
const BASE = "https://" + PLAID_ENV + ".plaid.com";
if (!CLIENT_ID || !SECRET) { console.error("Missing PLAID_CLIENT_ID or PLAID_SECRET"); process.exit(1); }

const shape = (s) => (s ? s.length + " chars" : "(none)");
const money = (n) => (n < 0 ? "-" : "") + "$" + Math.abs(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

async function call(endpoint, body) {
  const res = await fetch(BASE + endpoint, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(Object.assign({ client_id: CLIENT_ID, secret: SECRET }, body)),
  });
  const text = await res.text();
  let data = null;
  try { data = JSON.parse(text); } catch (e) {}
  return { ok: res.ok, status: res.status, data, raw: text };
}

function explain(r) {
  if (r.data && r.data.error_code) {
    console.log("    " + r.data.error_code + " - " + (r.data.error_message || ""));
    if (r.data.error_type) console.log("    type: " + r.data.error_type);
  } else console.log("    HTTP " + r.status + "  " + r.raw.slice(0, 300));
}

async function start() {
  console.log("1. Asking Plaid for a hosted Link session, with " + DAYS_REQUESTED + " days of history...");
  const link = await call("/link/token/create", {
    client_name: "Wayfarer",
    country_codes: ["US"],
    language: "en",
    user: { client_user_id: "wayfarer-" + Date.now() },
    products: ["transactions"],
    // The whole reason for re-linking. Only honoured at link time.
    transactions: { days_requested: DAYS_REQUESTED },
    hosted_link: {},
  });
  if (!link.ok) { console.log("   refused:"); explain(link); process.exit(1); }
  const hostedUrl = link.data.hosted_link_url;
  if (!hostedUrl) { console.log("   no hosted_link_url; keys: " + Object.keys(link.data).join(", ")); process.exit(1); }

  fs.writeFileSync(SESSION, JSON.stringify({ link_token: link.data.link_token, at: Date.now() }));
  console.log("   ok - session created, expires " + link.data.expiration + "\n");
  console.log("2. Open this URL and sign in to your bank:\n");
  console.log("   " + hostedUrl + "\n");
  console.log("   Your credentials go to the bank. Nothing sensitive comes back here --");
  console.log("   what returns is an opaque token, saved to .dev.vars as " + TOKEN_KEY + ".");
  console.log("   Tick ONLY the cards worth tracking: the free tier covers ten accounts");
  console.log("   in total, and one Amex login already used four.\n");
}

async function finish() {
  if (!fs.existsSync(SESSION)) { console.error("   No session - run 'start' first.\n"); process.exit(1); }
  const linkToken = JSON.parse(fs.readFileSync(SESSION, "utf8")).link_token;

  console.log("3. Checking whether the session completed...");
  let publicToken = null;
  for (let i = 0; i < 20 && !publicToken; i++) {
    const got = await call("/link/token/get", { link_token: linkToken });
    if (!got.ok) { explain(got); break; }
    for (const s of (got.data && got.data.link_sessions) || []) {
      const item = ((s.results || {}).item_add_results || [])[0];
      if (item && item.public_token) { publicToken = item.public_token; break; }
      if (s.public_token) { publicToken = s.public_token; break; }
    }
    if (!publicToken) { if (!i) console.log("   not yet - polling..."); await new Promise((r) => setTimeout(r, 2000)); }
  }
  if (!publicToken) { console.log("\n   No completed session found.\n"); process.exit(1); }
  console.log("   ok - public_token received (" + shape(publicToken) + ")\n");

  console.log("4. Exchanging for an access_token...");
  const ex = await call("/item/public_token/exchange", { public_token: publicToken });
  if (!ex.ok) { explain(ex); process.exit(1); }
  saveEnv(TOKEN_KEY, ex.data.access_token);
  console.log("   ok - saved to .dev.vars as " + TOKEN_KEY + " (" + shape(ex.data.access_token) + ")");
  console.log("        gitignored, never printed. 'analyse' can now re-run without re-linking.\n");
  try { fs.unlinkSync(SESSION); } catch (e) {}
  await analyse(ex.data.access_token);
}

// Change which accounts an existing link shares, without re-linking.
//
// Account selection happens once, inside Link, and nothing on this side can
// revise it -- so dropping a card from a connection means sending the user back
// into Link in UPDATE MODE. The access token does not change and is not
// re-issued, which is why this mode takes no products and there is no public
// token to exchange afterwards.
//
// Worth doing: the free tier counts ACCOUNTS, not institutions, and one Amex
// login claimed four of ten. Cards with no threshold to track are pure cost.
//
// The transactions of a dropped account go with it. History for the accounts
// you KEEP is untouched -- but days_requested was set at the original link and
// is not re-requested here, so check the earliest date afterwards rather than
// assume. `analyse` prints it.
async function update() {
  const accessToken = readEnv()[TOKEN_KEY];
  if (!accessToken) { console.error("   No " + TOKEN_KEY + " in .dev.vars.\n"); process.exit(1); }

  console.log("1. Listing what this link shares today...");
  const before = await call("/accounts/get", { access_token: accessToken });
  if (!before.ok) { explain(before); process.exit(1); }
  for (const a of before.data.accounts) {
    console.log("     " + (a.name || "?").slice(0, 30).padEnd(32) + (a.subtype || "").padEnd(14) + "**" + (a.mask || "----"));
  }

  console.log("\n2. Asking Plaid for an update-mode session...");
  const link = await call("/link/token/create", {
    client_name: "Wayfarer",
    country_codes: ["US"],
    language: "en",
    user: { client_user_id: "wayfarer-" + BANK },
    // No products in update mode: the item already has them.
    access_token: accessToken,
    update: { account_selection_enabled: true },
    hosted_link: {},
  });
  if (!link.ok) { console.log("   refused:"); explain(link); process.exit(1); }
  const hostedUrl = link.data.hosted_link_url;
  if (!hostedUrl) { console.log("   no hosted_link_url; keys: " + Object.keys(link.data).join(", ")); process.exit(1); }

  console.log("   ok - expires " + link.data.expiration + "\n");
  console.log("3. Open this and UNTICK the cards you no longer want shared:\n");
  console.log("   " + hostedUrl + "\n");
  console.log("   The access token does not change, so there is nothing to exchange");
  console.log("   afterwards. Run 'analyse " + BANK + "' to see what is left.\n");
}

async function analyse(tokenArg) {
  const accessToken = tokenArg || readEnv()[TOKEN_KEY];
  if (!accessToken) { console.error("   No " + TOKEN_KEY + " in .dev.vars - run 'finish " + BANK + "' first.\n"); process.exit(1); }

  console.log("5. Accounts:");
  const acc = await call("/accounts/get", { access_token: accessToken });
  if (!acc.ok) { explain(acc); process.exit(1); }
  const names = {};
  for (const a of acc.data.accounts) {
    names[a.account_id] = (a.name || "?") + " **" + (a.mask || "----");
    console.log("     " + (a.name || "?").slice(0, 30).padEnd(32) + (a.subtype || "").padEnd(14) + "**" + (a.mask || "----"));
  }

  console.log("\n6. Pulling transactions (this can take a minute on a fresh link)...");
  let cursor = null, added = [], rounds = 0;
  while (rounds < 40) {
    rounds++;
    const sync = await call("/transactions/sync", cursor ? { access_token: accessToken, cursor } : { access_token: accessToken });
    if (!sync.ok) {
      if (sync.data && sync.data.error_code === "PRODUCT_NOT_READY") {
        if (rounds % 4 === 1) console.log("   still preparing (round " + rounds + ")...");
        await new Promise((r) => setTimeout(r, 5000));
        continue;
      }
      explain(sync); break;
    }
    added = added.concat(sync.data.added || []);
    cursor = sync.data.next_cursor;
    if (!sync.data.has_more) break;
  }
  if (!added.length) { console.log("   no transactions returned\n"); return; }

  const dates = added.map((t) => t.date).sort();
  console.log("   " + added.length + " transactions, " + dates[0] + " to " + dates[dates.length - 1]);
  const span = Math.round((new Date(dates[dates.length - 1]) - new Date(dates[0])) / 86400000);
  console.log("   that is " + span + " days of history (asked for " + DAYS_REQUESTED + ")");

  // ---- what actually counts toward a threshold ---------------------------
  // Charges less genuine merchant refunds. Payments excluded entirely;
  // statement credits recorded but NOT subtracted, because the purchase they
  // offset was still a purchase. See tools/plaid-rules.js for why.
  const YEAR = new Date().getFullYear();
  const byAccount = {};
  for (const t of added) {
    const b = byAccount[t.account_id] = byAccount[t.account_id] || { all: [], year: [] };
    b.all.push(t);
    if (String(t.date).slice(0, 4) === String(YEAR)) b.year.push(t);
  }

  console.log("\n7. Per card - all history returned:\n");
  console.log("   " + "card".padEnd(34) + "charges".padStart(14) + "refunds".padStart(13) +
    "payments".padStart(14) + "credits".padStart(13));
  for (const id of Object.keys(byAccount)) {
    const q = RULES.qualifying(byAccount[id].all);
    console.log("   " + (names[id] || id).slice(0, 32).padEnd(34) +
      money(q.charges).padStart(14) + money(q.refunds).padStart(13) +
      money(q.payments).padStart(14) + money(q.credits).padStart(13));
  }

  console.log("\n8. " + YEAR + " calendar year to date - qualifying spend:\n");
  console.log("   " + "card".padEnd(34) + "qualifying".padStart(14) + "   (charges less refunds)");
  for (const id of Object.keys(byAccount)) {
    console.log("   " + (names[id] || id).slice(0, 32).padEnd(34) +
      money(RULES.qualifying(byAccount[id].year).spend).padStart(14));
  }

  // ---- the reconciliation report -----------------------------------------
  //
  // The patterns are Amex's wording. A description a new bank uses that this
  // does not recognise falls through to "refund", which SUBTRACTS -- so a
  // payment misread here is the $210,000 mistake happening again under another
  // bank's name. These are the negatives that were NOT matched as payments or
  // credits, largest first. Anything obviously a card payment means the rules
  // need this bank's phrasing adding to them.
  console.log("\n9. Negatives treated as MERCHANT REFUNDS (these subtract from spend):\n");
  const unmatched = RULES.describeNegatives(added);
  if (!unmatched.length) console.log("     (none)");
  for (const u of unmatched.slice(0, 12)) {
    console.log("     " + u.name.padEnd(48) + String(u.count).padStart(5) +
      money(u.total).padStart(15) + "  " + u.category.slice(0, 30));
  }

  for (const id of Object.keys(byAccount)) {
    const q = RULES.qualifying(byAccount[id].all);
    const rate = q.charges ? Math.abs(q.refunds) / q.charges : 0;
    if (rate > 0.08) {
      console.log("\n   ** " + (names[id] || id) + ": refunds are " + (rate * 100).toFixed(0) +
        "% of charges. On a card settled monthly that is the signature of");
      console.log("      payments being read as refunds -- exactly the Amex mistake. Check");
      console.log("      the list above before this card's total is trusted.");
    }
  }

  console.log("\n   CHECK the qualifying figure against the bank's own year-to-date total");
  console.log("   before anything depends on it. That reconciliation is what caught both");
  console.log("   earlier versions of these rules.\n");
}

if (!["start", "finish", "analyse", "update"].includes(MODE)) {
  console.error("\nUsage:  node tools/plaid-connect.js start|finish|analyse|update [bank]\n");
  process.exit(1);
}
console.log("\nPlaid - " + MODE + " - " + BANK);
console.log("  environment  " + PLAID_ENV + "   client_id " + shape(CLIENT_ID) + "\n");
if (PLAID_ENV === "sandbox") { console.log("  PLAID_ENV is sandbox, not your real bank.\n"); process.exit(1); }

(MODE === "start" ? start() : MODE === "finish" ? finish() : MODE === "update" ? update() : analyse()).catch((e) => {
  console.error("\nUnexpected failure: " + (e && e.message ? e.message : e) + "\n");
  process.exit(1);
});
