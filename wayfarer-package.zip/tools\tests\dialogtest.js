// U23 -- the dialogs are dialogs.
//
// All 22 of them are built from plain divs by the shared overlay() helper, so
// this is one change in one place. Before it:
//   - assistive technology announced them as nothing in particular
//   - keyboard focus stayed on the page behind, so a screen reader carried on
//     reading the dashboard while a modal backdrop covered it
//   - Tab walked straight out of the panel into the controls underneath --
//     focusable, invisible and unclickable at the same time
//   - closing dropped focus at the top of the document, so a keyboard user had
//     to walk all the way back to the row they had been on
//
// Verified live on trip 1141871, opening Edit on a hotel row:
//   role="dialog", aria-modal="true", aria-labelledby -> "Edit “Palacio Duhau -
//     Park Hyatt Buenos Aires”" (the U14 title, so the label is the real name)
//   18 focusable elements, first an INPUT, last the Save button
//   Tab from the last     -> prevented, wrapped to the first, still inside
//   Shift+Tab from first  -> prevented, wrapped to the last
//   Shift+Tab from panel  -> wrapped to the last
//   Tab in the middle     -> NOT prevented; the browser handles it
//   Escape                -> closed, focus back on the "✎ Edit" chip
//   backdrop click        -> closed, focus back on the exact trigger element
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

const ov = (() => {
  const at = app.indexOf("  function overlay(cls, onBackdrop)");
  let depth = 0, i = app.indexOf("{", at);
  for (; i < app.length; i++) {
    if (app[i] === "{") depth++;
    else if (app[i] === "}") { depth--; if (!depth) break; }
  }
  return app.slice(at, i + 1);
})();
if (ov.length < 1500) { console.log("  FAIL  overlay slice is " + ov.length); process.exit(1); }

console.log("\nit announces itself as a dialog");
t("role", /panel\.setAttribute\("role", "dialog"\);/.test(ov), true);
// aria-modal is what tells a screen reader the rest of the page is not
// available; without it the virtual cursor wanders behind the backdrop.
t("and modal", /panel\.setAttribute\("aria-modal", "true"\);/.test(ov), true);
// On the PANEL, not the backdrop: the backdrop is the dimmed page, the panel is
// the dialog. Labelling the backdrop would name the wrong element.
t("on the panel rather than the backdrop", /back\.setAttribute\("role"/.test(ov), false);
t("with somewhere for focus to land", /panel\.tabIndex = -1;/.test(ov), true);

console.log("\nand it is named by its own title");
// The caller builds the title AFTER overlay() returns, so the label can only be
// wired on the next tick -- the same reason the clean-state snapshot is there.
t("the heading is found once the dialog is built", /var head = panel\.querySelector\("\.form-title, h2, h3"\);/.test(ov), true);
t("given an id if it has none", /if \(!head\.id\) head\.id = "dlg-title-" \+ \(\+\+dialogSeq\);/.test(ov), true);
t("and pointed at", /panel\.setAttribute\("aria-labelledby", head\.id\);/.test(ov), true);
// Ids must not collide across stacked dialogs.
t("the counter is shared, not per-dialog", /var dialogSeq = 0;/.test(app), true);
// A dialog with no heading is still better named than not named at all.
t("a dialog with no heading still gets a name", /panel\.setAttribute\("aria-label", "Dialog"\);/.test(ov), true);

console.log("\nTab cannot leave");
t("there is a trap", /back\.addEventListener\("keydown", function \(ev\) \{\s*\n\s*if \(ev\.key !== "Tab"\) return;/.test(ov), true);
t("forward from the last wraps to the first",
  /else if \(!ev\.shiftKey && here === last\) \{ ev\.preventDefault\(\); first\.focus\(\); \}/.test(ov), true);
t("backward from the first wraps to the last",
  /if \(ev\.shiftKey && \(here === first \|\| here === panel\)\) \{ ev\.preventDefault\(\); last\.focus\(\); \}/.test(ov), true);
// The event fires on the panel itself when nothing inside has focus yet, so
// ev.target would be the panel and never match a field.
t("it reads the active element, not the event target", /var here = document\.activeElement;/.test(ov), true);
// A dialog whose fields are all hidden would otherwise let Tab escape.
t("a dialog with nothing focusable keeps focus anyway",
  /if \(!items\.length\) \{ ev\.preventDefault\(\); panel\.focus\(\); return; \}/.test(ov), true);
// Stacked dialogs are SIBLINGS under body, never nested, so an event inside the
// inner panel never bubbles to the outer backdrop's listener. That is what lets
// each dialog carry its own trap without them interfering.
t("every overlay is a direct child of body", /document\.body\.appendChild\(back\);/.test(ov), true);

console.log("\nwhat counts as focusable is what you can actually reach");
t("there is a shared selector", /var FOCUSABLE = "a\[href\], button:not\(\[disabled\]\)/.test(app), true);
t("hidden inputs are excluded", /input:not\(\[disabled\]\):not\(\[type=hidden\]\)/.test(app), true);
t("and tabindex -1 is not tabbable", /\[tabindex\]:not\(\[tabindex=/.test(app), true);
// These panels hide whole field groups -- the seat and gate boxes vanish on a
// hire car -- and a trap that cycles through hidden fields strands you on a
// control you cannot see.
t("invisible controls are filtered out",
  /return !n\.disabled && \(n\.offsetWidth \|\| n\.offsetHeight \|\| n\.getClientRects\(\)\.length\);/.test(app), true);

console.log("\nfocus goes in, and comes back");
t("where it was is remembered", /var returnTo = document\.activeElement;/.test(ov), true);
// A dialog closes several ways -- backdrop, Escape, a Save handler calling
// back.remove(), tearDownDetail sweeping the lot -- so this watches for the
// backdrop leaving rather than hooking each one.
t("removal is watched for", /var watcher = new MutationObserver\(function \(\) \{/.test(ov), true);
t("and the watcher stops once it has fired", /watcher\.disconnect\(\);/.test(ov), true);
t("focus is restored", /returnTo\.focus\(\);/.test(ov), true);
// Only if focus is actually adrift. A dialog opened on top, or a redrawn trip,
// has taken focus deliberately and must not have it snatched back.
t("but not if something else has taken it",
  /if \(now && now !== document\.body && now !== document\.documentElement\) return;/.test(ov), true);
// The trigger can be gone -- the row it sat on may have been redrawn.
t("and not into an element that has left the page", /returnTo\.isConnected/.test(ov), true);
t("a focus that throws does not break the close", /try \{ returnTo\.focus\(\); \} catch \(e\) \{\}/.test(ov), true);

console.log("\nand focus starts inside");
// A floor, not a policy: formDialog focuses its first field at 30ms and wins.
// What this covers is every overlay that is NOT a formDialog -- the cover
// picker, Trip Ideas, the traveller sheet -- where focus used to stay on
// whatever was behind the backdrop.
t("the panel takes focus if nothing else has", /if \(!panel\.contains\(document\.activeElement\)\) panel\.focus\(\);/.test(app), true);
t("and a dialog that wants a field still gets one",
  /setTimeout\(function \(\) \{ var f0 = panel\.querySelector\("input,textarea,select"\); if \(f0\) f0\.focus\(\); \}, 30\);/.test(app), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
