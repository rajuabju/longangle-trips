// The timezone round trip.
//
// Every timed thing on an itinerary is stored as UTC with an IANA zone beside
// it, and edited through <input type="datetime-local">, which speaks local
// wall-clock and nothing else. toLocalInput and fromLocalInput are the only
// bridge between the two, so if they are off by an hour then opening a flight
// and pressing Save moves it — silently, and by exactly the amount you would
// not notice until the gate closed.
//
// Nothing else in the app is as load-bearing and nothing else was untested.
//
// No trip data here: every case is a constructed instant.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");

function grab(name) {
  const i = src.indexOf("  function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
globalThis.MS_H = 3600000;
eval(["tzShift", "toLocalInput", "fromLocalInput", "shiftIso"].map(grab).join("\n") +
  ";Object.assign(globalThis,{tzShift,toLocalInput,fromLocalInput,shiftIso});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

// What the app actually stores: an ISO instant, seconds precision, no millis.
const iso = (s) => new Date(s).toISOString().replace(".000", "");

// ---- what the edit form shows -----------------------------------------------
// A flight leaving LAX at 1:00 PM Pacific is stored as 20:00Z in April. The form
// must say 13:00, because that is what the ticket says.
t("a Pacific afternoon reads as the local clock",
  toLocalInput("2026-04-15T20:00:00Z", "America/Los_Angeles"), "2026-04-15T13:00");
t("UTC is itself", toLocalInput("2026-04-15T20:00:00Z", "UTC"), "2026-04-15T20:00");
t("Tokyo is ahead, and can cross into the next day",
  toLocalInput("2026-04-15T20:00:00Z", "Asia/Tokyo"), "2026-04-16T05:00");
t("Los Angeles can cross back into the previous day",
  toLocalInput("2026-04-15T04:00:00Z", "America/Los_Angeles"), "2026-04-14T21:00");
// Half- and quarter-hour zones are where a naive implementation loses minutes.
t("India is +5:30", toLocalInput("2026-04-15T00:00:00Z", "Asia/Kolkata"), "2026-04-15T05:30");
t("Nepal is +5:45", toLocalInput("2026-04-15T00:00:00Z", "Asia/Kathmandu"), "2026-04-15T05:45");
t("the Chathams are +12:45",
  toLocalInput("2026-06-15T00:00:00Z", "Pacific/Chatham"), "2026-06-15T12:45");
t("Newfoundland is -3:30",
  toLocalInput("2026-01-15T12:00:00Z", "America/St_Johns"), "2026-01-15T08:30");

// ---- and the round trip back ------------------------------------------------
// This is the one that matters: open the form, change nothing, press Save. The
// instant that comes back must be the instant that went in.
const ZONES = ["UTC", "America/Los_Angeles", "America/New_York", "America/St_Johns",
  "Europe/London", "Europe/Lisbon", "Europe/Madrid", "Africa/Cairo",
  "Asia/Kolkata", "Asia/Kathmandu", "Asia/Tokyo", "Australia/Sydney",
  "Pacific/Chatham", "Pacific/Kiritimati", "America/Costa_Rica", "America/Phoenix"];
const INSTANTS = [
  "2026-01-15T12:00:00Z", "2026-03-08T09:00:00Z", "2026-06-21T23:30:00Z",
  "2026-10-25T00:15:00Z", "2026-12-31T23:59:00Z", "2027-01-22T02:45:00Z",
  "2027-07-04T16:20:00Z",
];
let roundTrips = 0, roundTripFails = [];
ZONES.forEach((z) => INSTANTS.forEach((i) => {
  roundTrips++;
  const back = fromLocalInput(toLocalInput(i, z), z);
  if (back !== iso(i)) roundTripFails.push(z + " " + i + " -> " + back);
}));
t("every zone/instant pair survives the round trip", roundTripFails, []);
t("that was a real sweep, not an empty one", roundTrips, ZONES.length * INSTANTS.length);

// ---- daylight saving --------------------------------------------------------
// The two hours a year that break naive conversions. US spring-forward 2026 is
// 08 March at 02:00 local; fall-back is 01 November at 02:00 local.
// The jump is at 07:00Z: 01:59 EST becomes 03:00 EDT.
t("the minute before the jump is still standard time",
  toLocalInput("2026-03-08T06:59:00Z", "America/New_York"), "2026-03-08T01:59");
t("the minute after it is daylight time, and 02:xx never happens",
  toLocalInput("2026-03-08T07:00:00Z", "America/New_York"), "2026-03-08T03:00");
t("later that morning is daylight time",
  toLocalInput("2026-03-08T09:59:00Z", "America/New_York"), "2026-03-08T05:59");
t("a winter instant is standard time",
  toLocalInput("2026-01-15T17:00:00Z", "America/New_York"), "2026-01-15T12:00");
t("a summer instant is daylight time",
  toLocalInput("2026-07-15T16:00:00Z", "America/New_York"), "2026-07-15T12:00");
// Phoenix does not observe it at all, which is why it is in the sweep above.
t("Phoenix is the same offset in July as in January",
  toLocalInput("2026-07-15T19:00:00Z", "America/Phoenix"),
  toLocalInput("2026-01-15T19:00:00Z", "America/Phoenix").replace("01-15", "07-15"));

// A wall-clock time that does not exist: 02:30 on spring-forward morning. It
// cannot round-trip — there is no such instant — but it must resolve to a real
// one rather than NaN or an hour in the previous day.
const nonexistent = fromLocalInput("2026-03-08T02:30", "America/New_York");
t("a nonexistent wall-clock time still yields a valid instant",
  isFinite(Date.parse(nonexistent)), true);
t("and lands on the right morning", String(nonexistent).slice(0, 10), "2026-03-08");
// The repeated hour, which is the bug this suite was written to catch. On
// 2026-10-25 in London both 00:15Z and 01:15Z read "01:15" — the clocks go back
// at 01:00Z. The old solver always resolved that reading to the SECOND
// occurrence, so a booking inside that hour moved an hour later every time the
// form was opened and saved. The first occurrence is the answer: it is the one
// a printed ticket means.
t("the repeated hour resolves to its first occurrence",
  fromLocalInput("2026-10-25T01:15", "Europe/London"), "2026-10-25T00:15:00Z");
t("and so the round trip is exact through it",
  fromLocalInput(toLocalInput("2026-10-25T00:15:00Z", "Europe/London"), "Europe/London"),
  "2026-10-25T00:15:00Z");
// Saving twice must not walk the time forward an hour each time.
let walk = "2026-10-25T00:15:00Z";
for (let n = 0; n < 5; n++) walk = fromLocalInput(toLocalInput(walk, "Europe/London"), "Europe/London");
t("five opens and saves do not move it", walk, "2026-10-25T00:15:00Z");
// The hour either side of it is unambiguous and must be untouched.
t("the hour before is unchanged",
  fromLocalInput(toLocalInput("2026-10-24T23:30:00Z", "Europe/London"), "Europe/London"),
  "2026-10-24T23:30:00Z");
t("the hour after is unchanged",
  fromLocalInput(toLocalInput("2026-10-25T02:30:00Z", "Europe/London"), "Europe/London"),
  "2026-10-25T02:30:00Z");
// The same night in New York, a week later, on its own schedule.
t("New York's repeated hour resolves the same way",
  fromLocalInput("2026-11-01T01:30", "America/New_York"), "2026-11-01T05:30:00Z");
const ambiguous = fromLocalInput("2026-11-01T01:30", "America/New_York");
t("and it is a valid instant on the right morning",
  isFinite(Date.parse(ambiguous)) && String(ambiguous).slice(0, 10) === "2026-11-01", true);
// Southern-hemisphere zones go the other way, in April.
t("Sydney's repeated hour also takes the first",
  fromLocalInput("2026-04-05T02:30", "Australia/Sydney"), "2026-04-04T15:30:00Z");

// ---- the shape the API is given ---------------------------------------------
t("no milliseconds in what is stored",
  /\.\d{3}Z$/.test(fromLocalInput("2026-04-15T13:00", "America/Los_Angeles")), false);
t("it is a Z instant",
  /Z$/.test(fromLocalInput("2026-04-15T13:00", "America/Los_Angeles")), true);
t("a known pair is exact",
  fromLocalInput("2026-04-15T13:00", "America/Los_Angeles"), "2026-04-15T20:00:00Z");

// ---- empty and malformed ----------------------------------------------------
// Blank fields are ordinary: an activity with no end time saves an empty box.
t("blank in, null out", fromLocalInput("", "America/Los_Angeles"), null);
t("null in, null out", fromLocalInput(null, "America/Los_Angeles"), null);
t("blank iso in, blank string out", toLocalInput("", "America/Los_Angeles"), "");
t("an unparseable iso does not throw", toLocalInput("not a date", "UTC"), "");
// A zone the browser does not know must not take the value down with it.
// tzShift returns 0 on a bad zone, so the value is treated as UTC — wrong by an
// offset, but present and editable rather than lost.
t("an unknown zone falls back rather than throwing",
  toLocalInput("2026-04-15T20:00:00Z", "Mars/Olympus"), "2026-04-15T20:00");
t("and round-trips within that fallback",
  fromLocalInput(toLocalInput("2026-04-15T20:00:00Z", "Mars/Olympus"), "Mars/Olympus"),
  "2026-04-15T20:00:00Z");
t("an absent zone is treated as UTC",
  toLocalInput("2026-04-15T20:00:00Z", null), "2026-04-15T20:00");

// ---- shifting a trip --------------------------------------------------------
// "Shift times" is a bulk edit over a whole itinerary, so an error here is an
// error everywhere at once.
//
// Hours and minutes are absolute; DAYS ARE NOT. "A week later" means the same
// time on a later date, and adding 7 × 86400000 ms is a week only when no
// daylight saving falls in between. Pushing a trip from October into November
// turned every 1:00 PM flight into noon — precisely the situation the feature
// exists for.
const LA = "America/Los_Angeles";
// 2026-10-30 13:00 Pacific is 20:00Z (PDT). A week later is 2026-11-06 13:00
// Pacific, which is 21:00Z (PST): a different offset, the same clock reading.
t("a week later keeps the clock across the change",
  shiftIso("2026-10-30T20:00:00Z", LA, 7, "days"), "2026-11-06T21:00:00Z");
t("and the wall time is unchanged",
  toLocalInput(shiftIso("2026-10-30T20:00:00Z", LA, 7, "days"), LA).slice(11), "13:00");
t("a week earlier does the same in reverse",
  toLocalInput(shiftIso("2026-11-06T21:00:00Z", LA, -7, "days"), LA).slice(11), "13:00");
t("two days across the change keep the clock",
  toLocalInput(shiftIso("2026-10-31T20:00:00Z", LA, 2, "days"), LA).slice(11), "13:00");
// Within one offset it is the plain answer.
t("a day in ordinary time is 24 hours",
  shiftIso("2026-06-10T20:00:00Z", LA, 1, "days"), "2026-06-11T20:00:00Z");
// Hours and minutes stay absolute — two hours is two real hours, even when the
// clocks change during them.
t("two hours is two real hours",
  shiftIso("2026-11-01T07:30:00Z", "America/New_York", 2, "hours"), "2026-11-01T09:30:00Z");
t("ninety minutes is ninety real minutes",
  shiftIso("2026-06-10T20:00:00Z", LA, 90, "minutes"), "2026-06-10T21:30:00Z");
t("a negative hour goes back",
  shiftIso("2026-06-10T20:00:00Z", LA, -3, "hours"), "2026-06-10T17:00:00Z");
// Month and year ends must not need a special case.
t("a day across a month end",
  toLocalInput(shiftIso("2026-01-31T20:00:00Z", LA, 1, "days"), LA).slice(0, 10), "2026-02-01");
t("a day across a year end",
  toLocalInput(shiftIso("2026-12-31T20:00:00Z", LA, 1, "days"), LA).slice(0, 10), "2027-01-01");
t("a day into a leap day",
  toLocalInput(shiftIso("2028-02-28T20:00:00Z", LA, 1, "days"), LA).slice(0, 10), "2028-02-29");
t("thirty days forward",
  toLocalInput(shiftIso("2026-01-15T20:00:00Z", LA, 30, "days"), LA).slice(0, 10), "2026-02-14");
// Southern hemisphere, where the change runs the other way.
t("Sydney keeps its clock across its April change",
  toLocalInput(shiftIso("2026-04-01T02:00:00Z", "Australia/Sydney", 7, "days"), "Australia/Sydney").slice(11),
  toLocalInput("2026-04-01T02:00:00Z", "Australia/Sydney").slice(11));
// Nothing in, nothing out — half a booking has no end time.
t("no instant, no shift", shiftIso(null, LA, 1, "days"), null);
t("empty instant, no shift", shiftIso("", LA, 1, "days"), null);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
