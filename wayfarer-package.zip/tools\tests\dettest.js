// detectTravellers / partySizeHint
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");
function grab(n) {
  const i = src.indexOf("  function " + n + "(");
  if (i < 0) throw new Error("missing " + n);
  let d = 0, s = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; s = true; } else if (src[j] === "}") { d--; if (s && !d) return src.slice(i, j + 1); }
  }
}
globalThis.state = { me: {} };
eval(["travellers", "travellerById", "travellerName", "tripTravellers", "seatList", "nameInText", "detectTravellers", "partySizeHint"]
  .map(grab).join("\n") + ";Object.assign(globalThis,{detectTravellers,partySizeHint});");

state.me.travellers = [
  { id: "alex", name: "Alex" }, { id: "sam", name: "Sam" },
  { id: "jo", name: "Jo" }, { id: "robin", name: "Robin" },
  { id: "casey", name: "Casey" }, { id: "marie", name: "Marie" },
];

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const ok = JSON.stringify(got) === JSON.stringify(want);
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + JSON.stringify(want) + "\n        got  " + JSON.stringify(got));
};
const TRIP = {};

// --- source 1: an existing seat assignment is proof ---
t("a seat assignment names its traveller",
  detectTravellers(TRIP, { transports: [{ pax: [{ id: "jo", seat: "6D" }, { id: "casey", seat: "6E" }] }] }),
  ["jo", "casey"]);

// --- source 2: a roster name in the booking text (all real formats) ---
t("activity name — 'Jo Ski School Lesson'",
  detectTravellers(TRIP, { activities: [{ name: "Jo Ski School Lesson" }] }), ["jo"]);
t("room description — 'Sam Rivera (room 1 of 2) - Alex's room'",
  detectTravellers(TRIP, { hostings: [{ provider_reservation_description: "Sam Rivera (room 1 of 2) - Alex's room" }] }),
  ["alex", "sam"]);
t("passenger list in the notes",
  detectTravellers(TRIP, { transports: [{ notes: "Passengers: Sam Rivera, Cristian Rosales, Santiago Rosales" }] }),
  ["sam"]);
t("driver line", detectTravellers(TRIP, { transports: [{ notes: "Driver: DANIEL RIVERA. Vehicle: Hyundai" }] }), []);
t("results follow roster order, not discovery order",
  detectTravellers(TRIP, { activities: [{ name: "Casey and Jo and Alex" }] }), ["alex", "jo", "casey"]);

// --- word boundaries ---
t("a name inside another word does not match",
  detectTravellers(TRIP, { activities: [{ name: "Noahs Ark Cruise Terminal Sarahville" }] }), []);
t("possessive still matches", detectTravellers(TRIP, { activities: [{ name: "Alex's Massage" }] }), ["alex"]);
t("case insensitive", detectTravellers(TRIP, { hostings: [{ notes: "GUEST: SAM" }] }), ["sam"]);

// --- nothing to find ---
t("no roster -> nothing", (() => { const keep = state.me.travellers; state.me.travellers = [];
  const r = detectTravellers(TRIP, { activities: [{ name: "Jo Ski School" }] }); state.me.travellers = keep; return r; })(), []);
t("empty trip -> nothing", detectTravellers(TRIP, {}), []);
t("a booking with no text -> nothing", detectTravellers(TRIP, { transports: [{ company: "Delta" }] }), []);
t("Marie is found once she appears in a booking",
  detectTravellers(TRIP, { activities: [{ name: "Marie — babysitting" }] }), ["marie"]);

// A regex-special character in a name must not blow up the matcher.
state.me.travellers = state.me.travellers.concat([{ id: "odd", name: "A.J. (Bo)" }]);
t("a name with regex metacharacters is matched literally",
  detectTravellers(TRIP, { activities: [{ name: "dinner with A.J. (Bo)" }] }), ["odd"]);
t("...and does not match a near-miss", detectTravellers(TRIP, { activities: [{ name: "AXJX Bo" }] }), []);
state.me.travellers = state.me.travellers.filter((x) => x.id !== "odd");

// --- partySizeHint ---
t("largest seat count wins", partySizeHint({ transports: [{ seat_number: "1A, 1B" }, { seat_number: "6D, 6A, 6F, 6C, 7D" }] }), 5);
t("no seats -> 0", partySizeHint({ transports: [{}] }), 0);
t("no transports -> 0", partySizeHint({}), 0);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
