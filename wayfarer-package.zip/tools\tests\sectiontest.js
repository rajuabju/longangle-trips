// The order of the trip's side column.
//
// Two things make this trickier than a constant. The order is stored per
// DEVICE in localStorage, so editing SECTION_KEYS moves nothing on a phone
// that already has a saved order. And normalizeSections heals a missing key by
// appending it -- which, for a key added later, means the bottom of the list.
// "Cancellation policies" is deliberately last, so a newly added "ideas" key
// healing in below it is precisely wrong.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");

const decl = (n) => {
  const h = "  var " + n;
  const i = app.indexOf(h);
  if (i < 0) throw new Error("missing " + n);
  return app.slice(i, app.indexOf(";", i) + 1);
};
const grab = (n) => {
  const h = "  function " + n + "(";
  const i = app.indexOf(h);
  if (i < 0) throw new Error("missing " + n);
  let d = 0, seen = false;
  for (let j = i; j < app.length; j++) {
    if (app[j] === "{") { d++; seen = true; }
    else if (app[j] === "}") { d--; if (seen && !d) return app.slice(i, j + 1); }
  }
  throw new Error("unterminated " + n);
};
eval(decl("SECTION_KEYS") + decl("SECTION_LABEL") + decl("SECTIONS_REV") +
  grab("migrateSections") + grab("normalizeSections") +
  ";Object.assign(globalThis,{SECTION_KEYS,SECTION_LABEL,SECTIONS_REV,migrateSections,normalizeSections});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};
const keys = (l) => normalizeSections(l).map((s) => s.key);

console.log("\nthe order that was asked for");
t("exactly this", SECTION_KEYS,
  ["map", "check", "budget", "tasks", "docs", "packing", "ideas", "cancel"]);
t("map is first", SECTION_KEYS[0], "map");
// Consulted rarely and urgently. Nothing should have to be scrolled past it.
t("cancellation policies are last", SECTION_KEYS[SECTION_KEYS.length - 1], "cancel");
t("every key has a label", SECTION_KEYS.filter((k) => !SECTION_LABEL[k]), []);
t("and no label is orphaned",
  Object.keys(SECTION_LABEL).filter((k) => SECTION_KEYS.indexOf(k) < 0), []);

console.log("\nideas is a section, not a passenger");
// It was mounted into built.tasks: no switch, no position, and turning off the
// to-do list took it too. Same bug Packing had before it.
t("it has its own key", SECTION_KEYS.indexOf("ideas") > -1, true);
t("it renders into its own container",
  app.indexOf("renderSuggested(built.ideas, t)") > -1, true);
t("and no longer into the to-do list",
  app.indexOf("renderSuggested(built.tasks, t)") > -1, false);
t("which exists to receive it", /ideas: el\("div"\)/.test(app), true);

console.log("\nan order saved before ideas existed");
const stored = () => ({
  sections: ["map", "check", "packing", "budget", "docs", "tasks", "cancel"]
    .map((k) => ({ key: k, on: true })),
});
// Healing alone appends, which is the wrong end of the list.
t("healing alone would bury it under cancellations",
  keys(stored().sections).slice(-2), ["cancel", "ideas"]);
// So the stored order is replaced once instead.
const migrated = stored();
t("migration reports that it acted", migrateSections(migrated), true);
t("and produces the asked-for order", keys(migrated.sections), SECTION_KEYS);
t("with cancellations still last", keys(migrated.sections).slice(-1), ["cancel"]);

console.log("\nbut only once");
t("a second pass is a no-op", migrateSections(migrated), false);
// Otherwise every repaint would undo a reorder made in Settings.
const reordered = { sections: [{ key: "cancel", on: true }, { key: "map", on: true }],
  sectionsRev: SECTIONS_REV };
migrateSections(reordered);
t("a deliberate reorder afterwards survives",
  reordered.sections.map((s) => s.key), ["cancel", "map"]);
t("and its missing keys still heal in", keys(reordered.sections).length, SECTION_KEYS.length);

console.log("\nordinary healing still works");
t("a junk key is dropped", keys([{ key: "nonsense", on: true }]), SECTION_KEYS);
t("a duplicate is taken once",
  keys([{ key: "map", on: true }, { key: "map", on: true }]).filter((k) => k === "map").length, 1);
t("an off switch is preserved",
  normalizeSections([{ key: "map", on: false }])[0].on, false);
t("nothing stored gives the default order", keys([]), SECTION_KEYS);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
