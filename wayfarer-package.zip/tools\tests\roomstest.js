// Two rooms are not two hotels.
//
// Trip Check warns when two stays overlap. The wording used to add "one may be
// a duplicate", and it was wrong every time it ever fired: measured across all
// 182 trips it produced 40 warnings, of which 27 were the same hotel booked
// twice for identical nights and 13 the same hotel with the two confirmations
// typed up an hour or a day apart. Two DIFFERENT hotels overlapping -- the
// thing it was written to catch -- had happened exactly zero times.
//
// Booking a second room is ordinary in this household, so the rule was telling
// a traveller that a room they were asleep in might be a duplicate. It now
// fires only when the hotels differ.
//
// Fixtures are invented; the SHAPES are the ones the measurement found.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");

function grab(name) {
  const i = src.indexOf("  function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
eval(grab("clashingStays") + ";globalThis.clashingStays = clashingStays;");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};
const stay = (name, a, b) => ({ name: name, starts_at: a, ends_at: b });

console.log("\na second room is not a clash");
// The exact shape of both Camino pairs: same hotel, same times to the second,
// no confirmation number on either. Twenty-seven records look like this.
t("same hotel, identical times",
  clashingStays(stay("Hyatt Regency Lisbon", "2026-08-17T14:00:00Z", "2026-08-19T10:00:00Z"),
                stay("Hyatt Regency Lisbon", "2026-08-17T14:00:00Z", "2026-08-19T10:00:00Z")), false);
// Thirteen more differ only because the two confirmations were entered
// separately -- an hour here, a day there. Still one hotel, still two rooms.
t("same hotel, check-out an hour apart",
  clashingStays(stay("Pendry West Hollywood", "2023-03-16T22:00:00Z", "2023-03-17T19:00:00Z"),
                stay("Pendry West Hollywood", "2023-03-16T22:00:00Z", "2023-03-17T18:00:00Z")), false);
t("same hotel, one room booked a day later",
  clashingStays(stay("Beverly Wilshire", "2014-12-19T23:00:00Z", "2014-12-21T20:00:00Z"),
                stay("Beverly Wilshire", "2014-12-20T23:00:00Z", "2014-12-21T20:00:00Z")), false);
t("same hotel, one room held longer",
  clashingStays(stay("Grand Hyatt New York", "2012-11-22T21:00:00Z", "2012-11-27T16:00:00Z"),
                stay("Grand Hyatt New York", "2012-11-22T21:00:00Z", "2012-11-30T16:00:00Z")), false);
// Names arrive from two different confirmation emails, so casing and stray
// whitespace vary. They are the same hotel and must be read as one.
t("casing does not make it a different hotel",
  clashingStays(stay("Hyatt Regency Lisbon", "2026-08-17T14:00:00Z", "2026-08-19T10:00:00Z"),
                stay("HYATT REGENCY LISBON", "2026-08-17T14:00:00Z", "2026-08-19T10:00:00Z")), false);
t("nor does trailing whitespace",
  clashingStays(stay("Grand Hyatt Denver", "2026-01-22T22:00:00Z", "2026-01-24T18:00:00Z"),
                stay("Grand Hyatt Denver  ", "2026-01-22T22:00:00Z", "2026-01-24T18:00:00Z")), false);

console.log("\ntwo different hotels still warn");
// Never yet seen in 182 trips, which is exactly why the check is kept rather
// than deleted -- it is a real mistake, it just has not been made.
t("moved hotels without shortening the first",
  clashingStays(stay("Hyatt Regency Lisbon", "2026-08-17T14:00:00Z", "2026-08-19T10:00:00Z"),
                stay("Four Seasons Ritz Lisbon", "2026-08-18T14:00:00Z", "2026-08-19T10:00:00Z")), true);
t("and only by a night",
  clashingStays(stay("Grand Hyatt Denver", "2026-01-22T22:00:00Z", "2026-01-24T18:00:00Z"),
                stay("Park Hyatt Beaver Creek", "2026-01-23T22:00:00Z", "2026-01-25T18:00:00Z")), true);

console.log("\nnot overlapping at all");
// Back to back is the normal way a trip moves between hotels, and warning on it
// would be worse than the bug being fixed.
t("checking out the morning you check in elsewhere",
  clashingStays(stay("Park Hyatt Beaver Creek", "2026-01-18T22:00:00Z", "2026-01-22T18:00:00Z"),
                stay("Grand Hyatt Denver", "2026-01-22T22:00:00Z", "2026-01-24T18:00:00Z")), false);
t("touching exactly, to the second",
  clashingStays(stay("A", "2026-01-18T22:00:00Z", "2026-01-22T18:00:00Z"),
                stay("B", "2026-01-22T18:00:00Z", "2026-01-24T18:00:00Z")), false);

console.log("\nwhat it refuses to guess");
// The Ranch has no confirmation number and some older records have no name
// at all. Without a name on both sides there is no way to tell a second room
// from a second hotel, and a warning nobody can act on is noise.
t("no name on the second", clashingStays(stay("Hyatt Regency Lisbon", "2026-08-17T14:00:00Z", "2026-08-19T10:00:00Z"),
  stay("", "2026-08-18T14:00:00Z", "2026-08-19T10:00:00Z")), false);
t("no name on the first", clashingStays(stay(null, "2026-08-17T14:00:00Z", "2026-08-19T10:00:00Z"),
  stay("Hyatt Regency Lisbon", "2026-08-18T14:00:00Z", "2026-08-19T10:00:00Z")), false);
t("nothing to compare against", clashingStays(stay("A", "2026-08-17T14:00:00Z", "2026-08-19T10:00:00Z"), null), false);
t("no first stay", clashingStays(null, stay("B", "2026-08-18T14:00:00Z", "2026-08-19T10:00:00Z")), false);
t("an open-ended first stay",
  clashingStays({ name: "A", starts_at: "2026-08-17T14:00:00Z" },
                stay("B", "2026-08-18T14:00:00Z", "2026-08-19T10:00:00Z")), false);

console.log("\nthe wording, and the button");
// "one may be a duplicate" is the sentence that was wrong 40 times out of 40.
t("no longer calls a second room a duplicate",
  /overlap\. If you moved hotels, shorten the first one\.["']/.test(src), true);
t("and the duplicate wording is gone entirely",
  /otherwise one may be a duplicate/.test(src), false);
// `var s2` was function-scoped and shared by every closure, so each Review
// button opened whichever stay the loop stopped on rather than the one it named.
t("Review opens the stay it reported, not the last one",
  /run: function \(\) \{ editHosting\(t, first\); \}/.test(src), true);
t("the C-style loop that caused it is gone", /for \(var s2 = 0/.test(src), false);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
