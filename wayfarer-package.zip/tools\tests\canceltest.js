// Cancellation policies.
//
// These moved out of the to-do list, where they were read-only and inflated the
// open-task count. What matters here is which bookings have terms at all, the
// order they appear in, and — the one that could lose real data — that saving a
// policy does not take the rest of the terms object with it.
//
// Fixtures are invented. Real confirmation numbers and rates do not belong here.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");

function grab(name) {
  const i = src.indexOf("  function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
function grabVar(name) {
  const i = src.indexOf("  var " + name + " = ");
  if (i < 0) throw new Error("missing " + name);
  return src.slice(i, src.indexOf(";", i) + 1);
}

globalThis.transName = (o) => [o.company, o.transport_number].filter(Boolean).join(" ") || "Transport";

eval([grabVar("CANCEL_PATH"),
  ...["termsOf", "allItems", "cancelRows", "cancelSort", "cancelDays", "cancelCountdown"].map(grab)].join("\n") +
  ";Object.assign(globalThis,{CANCEL_PATH,termsOf,allItems,cancelRows,cancelSort,cancelDays,cancelCountdown});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

const DAY = 86400000;
const at = (days) => new Date(Date.now() + days * DAY).toISOString();

const TRIP = {
  transports: [
    { id: 1, company: "Delta Air Lines", transport_number: "DL395",
      terms: { cancel_by: at(3), cancel_policy: "Non-refundable after check-in opens", baggage: "1 bag" } },
    { id: 2, company: "Adobe Rent A Car" },
  ],
  hostings: [
    { id: 10, name: "Hotel Example", terms: { cancel_by: at(30), rate_type: "pre-paid" } },
    { id: 11, name: "Nayara Tented Camp", terms: { cancel_policy: "Free until 48h before" } },
    { id: 12, name: "Friend's spare room" },
  ],
  activities: [
    { id: 20, name: "Walking tour", terms: { cancel_by: at(-5), cancel_policy: "Window closed" } },
    { id: 21, name: "Find a coffee place" },
  ],
};

// ---- which bookings have terms --------------------------------------------
const rows = cancelRows(TRIP);
t("every booking is considered", rows.length, 7);
t("only the ones with terms are listed", rows.filter((r) => r.has).length, 4);
// A date alone is enough, and so is prose alone. Requiring both would drop the
// camp, whose policy is a standing rule with no date attached.
t("a date with no prose counts",
  rows.filter((r) => r.item.name === "Hotel Example")[0].has, true);
t("prose with no date counts",
  rows.filter((r) => r.item.name === "Nayara Tented Camp")[0].has, true);
t("a booking with no terms at all does not",
  rows.filter((r) => r.item.name === "Friend's spare room")[0].has, false);
// The importer writes cancel_by from an email; a malformed one must not become
// an Invalid Date that renders as "NaN days".
t("an unparseable date is treated as no date",
  cancelRows({ hostings: [{ id: 1, name: "X", terms: { cancel_by: "sometime in May" } }] })[0].when, null);
t("but its prose still lists it",
  cancelRows({ hostings: [{ id: 1, name: "X", terms: { cancel_by: "nope", cancel_policy: "Ask" } }] })[0].has, true);
t("terms that are not an object are ignored",
  cancelRows({ hostings: [{ id: 1, name: "X", terms: "free" }] })[0].has, false);

// ---- order -----------------------------------------------------------------
const listed = cancelSort(rows.filter((r) => r.has)).map((r) => r.item.name);
t("soonest deadline first, undated last",
  listed, ["Walking tour", "Delta Air Lines DL395", "Hotel Example", "Nayara Tented Camp"]);
// A passed deadline stays in the list. Knowing the window closed is worth as
// much as knowing it is open — it tells you the money is already committed.
t("a passed deadline is still listed", listed.indexOf("Walking tour"), 0);

// ---- the countdown ---------------------------------------------------------
// Calendar days, not 24-hour blocks. Build the fixtures from midnight so the
// suite means the same thing whatever time of day it runs.
const midnight = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };
const onDay = (n, h) => new Date(midnight().getTime() + n * DAY + (h == null ? 12 : h) * 3600000);

t("a future date counts down", cancelCountdown(onDay(5)), "in 5 days");
t("tomorrow is named", cancelCountdown(onDay(1)), "tomorrow");
t("a past date says so", cancelCountdown(onDay(-2)), "passed");
t("no date, no countdown", cancelCountdown(null), "");

// The regression. Ceiling a fractional day made every positive gap read at
// least "tomorrow", so a deadline this afternoon looked like one you had
// another night to think about — the exact case a countdown exists to prevent.
//
// The expectation is DERIVED, not written as a literal "today". Both of these
// asserted "today" unconditionally, which is wrong near midnight: run at 23:01
// local, an hour from now IS tomorrow and cancelCountdown is right to say so.
// The suite failed for one hour every night and passed the other twenty-three.
//
// The regression is still fully covered. If the ceiling came back, a gap of 90
// seconds would read "tomorrow" while sameDay() says it is today, and that is
// precisely the mismatch these two lines catch -- at any hour.
const sameDay = (d) => d.toDateString() === new Date().toDateString();
const soon = new Date(Date.now() + 90 * 1000);
const hour = new Date(Date.now() + 3600 * 1000);
t("later today is today", cancelCountdown(soon), sameDay(soon) ? "today" : "tomorrow");
t("in an hour is today, unless an hour from now is not",
  cancelCountdown(hour), sameDay(hour) ? "today" : "tomorrow");
t("just before midnight tonight is still today",
  cancelCountdown(new Date(midnight().getTime() + DAY - 1000)), "today");
t("just after midnight is tomorrow",
  cancelCountdown(new Date(midnight().getTime() + DAY + 1000)), "tomorrow");
// "passed" is the instant, not the day: a 6am deadline read at noon has gone,
// even though the two are the same date.
t("earlier today has passed", cancelCountdown(new Date(Date.now() - 3600 * 1000)), "passed");

// The day count the styling reads, which must agree with the words.
t("today is zero days out", cancelDays(onDay(0)), 0);
t("tomorrow is one", cancelDays(onDay(1)), 1);
t("a week out is seven", cancelDays(onDay(7)), 7);
t("yesterday is negative", cancelDays(onDay(-1)), -1);
// Early and late on the same day are the same number of days away — the hour
// must not tip it over.
t("6am and 11pm on the same day agree", cancelDays(onDay(3, 6)), cancelDays(onDay(3, 23)));

// ---- the write path --------------------------------------------------------
// PATCH spreads the body over the stored blob ONE level deep, so `terms` is
// replaced wholesale rather than merged. Sending only the two fields edited
// here would silently drop the rate type, baggage allowance and deposit that
// the importer parsed out of the confirmation. This is the merge that prevents
// that, mirrored from editCancellation.
const merge = (tm, cancel_by, cancel_policy) =>
  Object.assign({}, tm, { cancel_by: cancel_by || null, cancel_policy: cancel_policy || null });
const flight = TRIP.transports[0].terms;
t("editing the policy keeps the baggage allowance",
  merge(flight, at(3), "New wording").baggage, "1 bag");
t("and writes the new wording",
  merge(flight, at(3), "New wording").cancel_policy, "New wording");
t("clearing both fields leaves nulls, not undefined",
  merge(flight, "", ""), { cancel_by: null, cancel_policy: null, baggage: "1 bag" });
t("a booking with no prior terms starts clean",
  merge({}, "", "Ask at the desk"), { cancel_by: null, cancel_policy: "Ask at the desk" });

// ---- kind maps to the API path ---------------------------------------------
// Checked against the ROUTER, not against a copy of the same assumption. The
// first version of this suite asserted CANCEL_PATH.transport === "transport"
// and passed while every save 404'd, because both the code and the test were
// wrong in the same direction. allItems calls lodging "lodging" and the route
// is /hosting; a transport's route is /transportation, and "transport" is not
// an alias for it.
const api = fs.readFileSync("functions/api/_core.js", "utf8");
const SINGULARS = new Set(
  [...api.matchAll(/singular:\s*"([a-z]+)"/g)].map((m) => m[1]));
t("the router was found at all", SINGULARS.size >= 4, true);
t("lodging writes to hosting", CANCEL_PATH.lodging, "hosting");
t("transport writes to transportation", CANCEL_PATH.transport, "transportation");
t("activity writes to activity", CANCEL_PATH.activity, "activity");
t("every path is one the router answers on",
  Object.values(CANCEL_PATH).filter((p) => !SINGULARS.has(p)), []);
t("every kind allItems produces has a path",
  allItems(TRIP).every((it) => !!CANCEL_PATH[it.kind]), true);

// ---- an empty trip ---------------------------------------------------------
t("nothing at all is no rows", cancelRows({}).length, 0);
t("and sorts to nothing", cancelSort([]).length, 0);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
