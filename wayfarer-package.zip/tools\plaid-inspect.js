// What ARE those negative transactions?
//
// The first pass classed anything negative that was not obviously a card
// payment as a refund, and produced a 65% refund rate on the Business Platinum
// -- which is not a thing that happens. Refunds plus payments came to $670,051
// against $683,707 of charges, and on a charge card settled monthly that is the
// signature of payments being counted as refunds.
//
// This prints the negatives grouped by Plaid category and by merchant name, so
// the classification can be corrected from evidence rather than guessed at
// again. Amounts are aggregates; individual descriptions are truncated.
//
//   node tools/plaid-inspect.js
const fs = require("fs");
const path = require("path");

const ENV_FILE = path.join(process.cwd(), ".dev.vars");
const env = {};
for (const line of fs.readFileSync(ENV_FILE, "utf8").split(/\r?\n/)) {
  const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/.exec(line);
  if (m) env[m[1]] = m[2].replace(/^["']|["']$/g, "");
}
const BASE = "https://" + (env.PLAID_ENV || "production") + ".plaid.com";
const money = (n) => (n < 0 ? "-" : "") + "$" + Math.abs(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

async function call(endpoint, body) {
  const res = await fetch(BASE + endpoint, {
    method: "POST", headers: { "content-type": "application/json" },
    body: JSON.stringify(Object.assign({ client_id: env.PLAID_CLIENT_ID, secret: env.PLAID_SECRET }, body)),
  });
  return { ok: res.ok, data: await res.json().catch(() => null) };
}

(async () => {
  const token = env.PLAID_AMEX_ACCESS_TOKEN;
  const acc = await call("/accounts/get", { access_token: token });
  const names = {};
  for (const a of acc.data.accounts) names[a.account_id] = (a.name || "?") + " **" + (a.mask || "");

  let cursor = null, added = [], rounds = 0;
  while (rounds++ < 40) {
    const s = await call("/transactions/sync", cursor ? { access_token: token, cursor } : { access_token: token });
    if (!s.ok) break;
    added = added.concat(s.data.added || []);
    cursor = s.data.next_cursor;
    if (!s.data.has_more) break;
  }

  const negatives = added.filter((t) => t.amount < 0);
  console.log("\n" + negatives.length + " negative transactions of " + added.length + " total\n");

  // ---- by category, which is what a classifier can actually key on --------
  const byCat = {};
  for (const t of negatives) {
    const pfc = t.personal_finance_category || {};
    const key = (pfc.primary || "(none)") + " / " + (pfc.detailed || "(none)");
    byCat[key] = byCat[key] || { n: 0, sum: 0 };
    byCat[key].n++; byCat[key].sum += t.amount;
  }
  console.log("BY CATEGORY");
  console.log("  " + "category".padEnd(58) + "count".padStart(7) + "total".padStart(16));
  for (const k of Object.keys(byCat).sort((a, b) => byCat[a].sum - byCat[b].sum)) {
    console.log("  " + k.slice(0, 56).padEnd(58) + String(byCat[k].n).padStart(7) + money(byCat[k].sum).padStart(16));
  }

  // ---- the biggest ones by merchant name ---------------------------------
  const byName = {};
  for (const t of negatives) {
    const key = (t.name || "(no name)").slice(0, 46);
    byName[key] = byName[key] || { n: 0, sum: 0, cat: ((t.personal_finance_category || {}).detailed) || "" };
    byName[key].n++; byName[key].sum += t.amount;
  }
  const top = Object.keys(byName).sort((a, b) => byName[a].sum - byName[b].sum).slice(0, 15);
  console.log("\nLARGEST NEGATIVE TOTALS BY DESCRIPTION");
  console.log("  " + "description".padEnd(48) + "count".padStart(7) + "total".padStart(16) + "  category");
  for (const k of top) {
    console.log("  " + k.padEnd(48) + String(byName[k].n).padStart(7) + money(byName[k].sum).padStart(16) +
      "  " + byName[k].cat.slice(0, 34));
  }

  // ---- does it balance? --------------------------------------------------
  console.log("\nPER CARD: does charges = payments + refunds, as a settled card should?\n");
  const per = {};
  for (const t of added) {
    per[t.account_id] = per[t.account_id] || { pos: 0, neg: 0 };
    if (t.amount > 0) per[t.account_id].pos += t.amount; else per[t.account_id].neg += t.amount;
  }
  console.log("  " + "card".padEnd(34) + "charges".padStart(15) + "all negatives".padStart(16) + "difference".padStart(15));
  for (const id of Object.keys(per)) {
    const p = per[id];
    console.log("  " + (names[id] || id).slice(0, 32).padEnd(34) +
      money(p.pos).padStart(15) + money(p.neg).padStart(16) + money(p.pos + p.neg).padStart(15));
  }
  console.log("\n  A card settled in full should show a difference near its current balance,");
  console.log("  not near zero and not enormous. That is the sanity check on the split.\n");
})();
