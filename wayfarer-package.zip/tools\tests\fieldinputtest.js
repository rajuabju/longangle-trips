// The fields you type into.
//
// Four faults, all in the same forms.
//
// There was not one inputmode, autocapitalize, autocorrect or spellcheck in the
// entire app, so every field summoned the full QWERTY keyboard with
// sentence-case capitalisation and autocorrect fighting entries like LAX and
// HRK4TQ. Coordinates meant four keyboard-plane switches per number.
//
// The fields are divs rather than a <form>, so Enter did nothing -- retyping an
// amount and pressing Enter, the most common edit flow there is, silently
// failed. Only five fields in the whole app had their own Enter handler.
//
// The transport form skipped coordinate validation entirely: a pasted
// "34.05, -118.24" became NaN, JSON.stringify turned NaN into null, and the
// PATCH silently CLEARED the stored coordinate.
//
// And a misspelled time zone did not fail at all. tzShift wraps Intl in a
// try/catch returning 0, so "America/Los_Angles" was swallowed and every
// datetime on the booking converted as if UTC -- wrong by hours, surfacing days
// later as a feasibility warning with nothing pointing back to the typo.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");

const fn = (decl) => {
  const i = app.indexOf(decl);
  if (i < 0) throw new Error("missing " + decl);
  let d = 0, seen = false;
  for (let j = i; j < app.length; j++) {
    if (app[j] === "{") { d++; seen = true; }
    else if (app[j] === "}") { d--; if (seen && !d) return app.slice(i, j + 1); }
  }
  throw new Error("unterminated " + decl);
};
eval(fn("  function coordPair(latStr, lonStr) {") +
     fn("  function ApiError(msg, status) {") +
     ";globalThis.coordPair = coordPair; globalThis.ApiError = ApiError;");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};
const threw = (f) => { try { f(); return null; } catch (e) { return e.message; } };

console.log("\na pasted coordinate pair is a pair");
// Every map copies coordinates as one string, and it all lands in the first box.
t("split from the latitude box alone", coordPair("34.05, -118.24", ""), { latitude: 34.05, longitude: -118.24 });
t("spacing does not matter", coordPair("34.05,-118.24", ""), { latitude: 34.05, longitude: -118.24 });
t("negative latitudes too", coordPair("-33.87, 151.21", ""), { latitude: -33.87, longitude: 151.21 });
t("a real pair is untouched", coordPair("34.05", "-118.24"), { latitude: 34.05, longitude: -118.24 });
t("both blank is still blank", coordPair("", ""), { latitude: null, longitude: null });
// Only when the second box is EMPTY -- otherwise it is two conflicting answers.
t("not split when a longitude was also given",
  threw(() => coordPair("34.05, -118.24", "12")) !== null, true);
t("half a pair is still refused",
  threw(() => coordPair("34.05", "")), "Give both a latitude and a longitude, or leave both blank.");
t("and nonsense still is", threw(() => coordPair("north", "west")) !== null, true);

console.log("\nthe transport form validates like every other one");
// It was the ONLY location form doing a bare Number() with no checks.
t("the unchecked path is gone", /\["departure_latitude", "departure_longitude", "arrival_latitude", "arrival_longitude"\]\.forEach/.test(app), false);
t("both legs go through coordPair", /return coordPair\(v\[prefix \+ "_latitude"\], v\[prefix \+ "_longitude"\]\);/.test(app), true);
// A form with two pairs needs to say which one is wrong.
t("and the error names which leg", /throw new ApiError\(label \+ " — " \+ e\.message, 0\);/.test(app), true);
t("departure is labelled", /leg\("departure", "Departure"\)/.test(app), true);
t("arrival is labelled", /leg\("arrival", "Arrival"\)/.test(app), true);

console.log("\nthe right keyboard, derived from the field name");
// Declared per call site, the next field added is the one that gets missed.
t("codes are uppercased and left unautocorrected",
  /autocapitalize: "characters", autocorrect: "off", spellcheck: "false"/.test(app), true);
t("coordinates and money get a decimal pad", /inputmode: "decimal"/.test(app), true);
t("counts get a numeric pad", /inputmode: "numeric"/.test(app), true);
t("phone gets the tel keyboard", /\{ on: \/\^phone\$\/, set: \{ type: "tel"/.test(app), true);
t("links get the url keyboard", /type: "url", inputmode: "url"/.test(app), true);
t("it is applied to every field built", /applyFieldAttrs\(f\.name, input\);/.test(app), true);
// An explicit spec must still win over a name-derived default.
t("and a field can override it", /if \(f\.attrs\) Object\.keys\(f\.attrs\)\.forEach/.test(app), true);
// type is a property with behaviour attached, not just an attribute.
t("a type asked for explicitly is never downgraded",
  /if \(k === "type"\) \{ if \(input\.type === "text"\) input\.type = rule\.set\[k\]; \}/.test(app), true);

console.log("\nEnter saves");
t("a keydown handler on the panel", /if \(e\.key !== "Enter" \|\| e\.defaultPrevented\) return;/.test(app), true);
// Fields that handle Enter themselves -- the place search picks a result --
// arrive with defaultPrevented set and must be left alone.
t("anything already handled is left alone", /e\.defaultPrevented/.test(app), true);
t("textareas keep their newlines", /el2\.tagName === "TEXTAREA"/.test(app), true);
t("buttons and links keep their own activation", /el2\.tagName === "BUTTON" \|\| el2\.tagName === "A"/.test(app), true);
t("and it does not fire while already saving", /if \(save\.disabled\) return;/.test(app), true);

console.log("\na time zone has to be one");
t("the field offers the real list", /input\.setAttribute\("list", timezoneListId\(\)\)/.test(app), true);
t("built from what the browser knows", /Intl\.supportedValuesOf\("timeZone"\)/.test(app), true);
// The authority is the same Intl that will be asked to convert with it.
t("and checked against the same Intl", /new Intl\.DateTimeFormat\("en-US", \{ timeZone: String\(z\) \}\)/.test(app), true);
t("a bad zone stops the save", /if \(val && !knownTimezone\(val\)\) badZone = val;/.test(app), true);
t("and says so inline rather than saving quietly",
  /is not a time zone\. Start typing a city and pick from the list\./.test(app), true);
// Missing in some browsers; the field then simply has no suggestions.
t("a browser without the list still works", /zones = \[\]; \}/.test(app), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
