// "How do I get from the airport to the hotel."
//
// feasibility.js already computes ground travel time between two points — that
// is how it decides a connection is impossible. The number was only ever used
// to complain; shown between a landing and a check-in it answers the question
// you actually have standing at the carousel.
//
// What matters is when it stays QUIET. A wrong or pointless hint on every row
// is how a useful line becomes one you stop reading.
//
// Fixtures are invented.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");
const feas = fs.readFileSync("public/feasibility.js", "utf8");

function grab(name) {
  const i = src.indexOf("  function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
function grabVar(name) {
  const i = src.indexOf("  var " + name + " = ");
  if (i < 0) throw new Error("missing " + name);
  return src.slice(i, src.indexOf(";", i) + 1);
}

// The real feasibility module, not a stand-in: the whole point is that one
// distance model serves both the check and the hint.
globalThis.window = globalThis;
eval(feas);
globalThis.MS_H = 3600000;
globalThis.dayKey = (utc) => (utc ? String(utc).slice(0, 10) : null);

eval([grabVar("NOT_DRIVEN"), grabVar("TRANSFER_MIN_KM"), grabVar("TRANSFER_MAX_KM"),
  grabVar("TRANSFER_MAX_GAP_H"), grabVar("HOME"), grabVar("HOME_MIN_KM"), grabVar("HOME_MAX_KM"),
  grabVar("KNOWN_PLACES"), grabVar("PLACE_RADIUS_KM"), grabVar("SELF_DRIVEN"),
  grabVar("WALK_MAX_KM"), ...["walkMinutes"].map(grab),
  ...["endPoint", "startPoint", "transferHint", "homeHint", "homeHintBack", "tripHasFlight", "fmtDrive", "routeKey", "knownPlaceFor",
   "lodgingForNight", "prevDayKey", "lodgingWokeIn", "lodgingPoint", "isSameLodging", "endTimeOf"]
    .map(grab)].join(String.fromCharCode(10)) +
  ";Object.assign(globalThis,{endPoint,startPoint,transferHint,homeHint,homeHintBack,tripHasFlight,fmtDrive,routeKey,knownPlaceFor,KNOWN_PLACES,HOME,lodgingForNight,prevDayKey,lodgingWokeIn,lodgingPoint,isSameLodging,endTimeOf,walkMinutes,WALK_MAX_KM,TRANSFER_MIN_KM});");

const HOME_PT = () => ({ lat: HOME.lat, lon: HOME.lng });

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

// Liberia airport (LIR) to the Waldorf at Papagayo — the real shape of the case.
const LIR = { lat: 10.5933, lon: -85.5444 };
const HOTEL = { lat: 10.6392, lon: -85.6631 };

const landing = (over) => ({
  kind: "transport", when: "2027-01-23T18:00:00Z",
  obj: Object.assign({
    transportation_type: "airplane",
    departure_latitude: 33.9425, departure_longitude: -118.408,
    arrival_latitude: LIR.lat, arrival_longitude: LIR.lon,
    arrival_at: "2027-01-23T18:00:00Z",
  }, over || {}),
});
const checkin = (over) => ({
  kind: "hosting", when: "2027-01-23T21:00:00Z",
  obj: Object.assign({ latitude: HOTEL.lat, longitude: HOTEL.lon }, over || {}),
});

// ---- the case it exists for -------------------------------------------------
const hint = transferHint(landing(), checkin());
t("a landing then a hotel gets a hint", !!hint, true);
t("the distance is the straight line between them", Math.round(hint.km), 14);
t("and the time is plausible for it", hint.minutes > 15 && hint.minutes < 45, true);
// The flight's own row is its departure, but it leaves you at the far end —
// measuring from LAX would give 4,000 km and no hint at all.
t("a flight is measured from where it lands",
  Math.round(endPoint(landing()).lat * 100) / 100, 10.59);
t("and the next item from where it begins",
  Math.round(startPoint(checkin()).lat * 100) / 100, 10.64);

// ---- when it stays quiet ----------------------------------------------------
// Already there: a hotel restaurant, a terminal transfer.
t("no hint across the car park",
  transferHint(landing(), checkin({ latitude: LIR.lat + 0.002, longitude: LIR.lon })), null);
// Too far to be a transfer — that is a missing leg, which the trip check
// reports. Repeating it here as a cheerful "6 h drive" would be worse.
t("no hint across a continent",
  transferHint(landing(), checkin({ latitude: 40.7, longitude: -74.0 })), null);
// Nothing to measure from.
t("no hint without coordinates on the first",
  transferHint(landing({ arrival_latitude: null, arrival_longitude: null }), checkin()), null);
t("no hint without coordinates on the second",
  transferHint(landing(), checkin({ latitude: null, longitude: null })), null);
// 0,0 is a failed geocode, not the Gulf of Guinea.
t("no hint from null island",
  transferHint(landing({ arrival_latitude: 0, arrival_longitude: 0 }), checkin()), null);
t("nor to it", transferHint(landing(), checkin({ latitude: 0, longitude: 0 })), null);
// These two used to assert that a hint was suppressed whenever the next item
// was a flight or a train. That rule was wrong and has gone: it also hid the
// drive from a hotel to the airport, which is one of the two cases this exists
// for. What matters is the DISTANCE, and 14 km to a different airport or
// station is a real drive that should be said.
t("a flight departing from somewhere else is a real drive",
  !!transferHint(landing(), { kind: "transport", when: "2027-01-23T21:00:00Z",
    obj: { transportation_type: "airplane", departure_latitude: HOTEL.lat, departure_longitude: HOTEL.lon } }), true);
t("so is a train from another station",
  !!transferHint(landing(), { kind: "transport", when: "2027-01-23T21:00:00Z",
    obj: { transportation_type: "train", departure_latitude: HOTEL.lat, departure_longitude: HOTEL.lon } }), true);
// A hire car is a transfer you drive yourself, so it still gets one.
t("a hire car pick-up elsewhere still gets a hint",
  !!transferHint(landing(), { kind: "transport", when: "2027-01-23T21:00:00Z",
    obj: { transportation_type: "car", departure_latitude: HOTEL.lat, departure_longitude: HOTEL.lon } }), true);
// A long gap is not a transfer; you did something else in between.
t("no hint across a fourteen-hour gap",
  transferHint(landing(), checkin({}) && { kind: "hosting", when: "2027-01-24T09:00:00Z",
    obj: { latitude: HOTEL.lat, longitude: HOTEL.lon } }), null);
// Times out of order mean the data is wrong, not that you time-travelled.
t("no hint when the next item is earlier",
  transferHint(landing(), { kind: "hosting", when: "2027-01-23T17:00:00Z",
    obj: { latitude: HOTEL.lat, longitude: HOTEL.lon } }), null);
t("no hint from nothing", transferHint(null, checkin()), null);
t("nor to nothing", transferHint(landing(), null), null);

// ---- the drive to the airport ----------------------------------------------
// The case the first version got wrong. Checking out of a hotel and driving to
// the airport is one of the two things this exists for, and the next item there
// IS a flight — which the old rule suppressed, hiding exactly the hint wanted.
const checkout = (over) => ({
  kind: "hosting", when: "2027-01-31T18:00:00Z", isCheckout: true,
  obj: Object.assign({ latitude: HOTEL.lat, longitude: HOTEL.lon,
    ends_at: "2027-01-31T18:00:00Z" }, over || {}),
});
const departure = (over) => ({
  kind: "transport", when: "2027-01-31T21:00:00Z",
  obj: Object.assign({ transportation_type: "airplane",
    departure_latitude: LIR.lat, departure_longitude: LIR.lon }, over || {}),
});
t("hotel to airport now gets a hint", !!transferHint(checkout(), departure()), true);
t("and it measures to the departure airport, not the arrival one",
  Math.round(transferHint(checkout(), departure()).km), 14);
// The reason the suppression existed: a connection, or a return leg from the
// same airport. Those are zero kilometres apart and the distance floor drops
// them without needing a rule about flights.
t("a connection at the same airport still says nothing",
  transferHint({ kind: "transport", when: "2027-01-31T18:00:00Z",
    obj: { transportation_type: "airplane", arrival_latitude: LIR.lat, arrival_longitude: LIR.lon,
      arrival_at: "2027-01-31T18:00:00Z" } }, departure()), null);
// A genuinely different airport is a real drive and should be said.
t("but a transfer between two airports is real",
  !!transferHint(checkout({ latitude: LIR.lat, longitude: LIR.lon }),
    departure({ departure_latitude: 10.7, departure_longitude: -85.4 })), true);

// ---- the drive from home, on a trip you drive to ---------------------------
// your home city to Mammoth is five hours that the itinerary used to begin
// after, as though you had arrived by magic.
const MAMMOTH = { lat: 37.6485, lon: -118.9721 };
const VEGAS = { lat: 36.1147, lon: -115.1728 };
t("home to Mammoth is a leg", !!homeHint(MAMMOTH), true);
t("and it is a long one", homeHint(MAMMOTH).km > 300, true);
t("home to Las Vegas is a leg", !!homeHint(VEGAS), true);
// A hotel down the road is a staycation, not a drive. Five trips on record are
// your home city itself, and the map's driving route uses the same ten-mile test.
t("a hotel in your home city is not a journey",
  homeHint({ lat: HOME.lat + 0.01, lon: HOME.lng }), null);
t("nor is one across town", homeHint({ lat: HOME.lat + 0.05, lon: HOME.lng }), null);
// Beyond about a thousand kilometres nobody is driving it for a long weekend,
// and a trip that far with no flight recorded is a gap in the data.
t("Chicago is not a drive to a long weekend", homeHint({ lat: 41.88, lon: -87.63 }), null);
t("nothing to measure to", homeHint(null), null);
t("null island is not a destination", homeHint({ lat: 0, lon: 0 }), null);
// The way back is the same road in the other direction.
t("the return leg exists", !!homeHintBack(MAMMOTH), true);
t("and runs from the destination to home",
  [homeHintBack(MAMMOTH).to.lat, homeHintBack(MAMMOTH).to.lon], [HOME.lat, HOME.lng]);
t("while the outbound runs from home",
  [homeHint(MAMMOTH).from.lat, homeHint(MAMMOTH).from.lon], [HOME.lat, HOME.lng]);

// Only when nothing flies. With a flight, the first leg is the drive to the
// airport, which the ordinary item-to-item rule already covers.
t("a trip with a flight has one", tripHasFlight({ transports: [{ transportation_type: "airplane" }] }), true);
t("a trip with only a hire car does not",
  tripHasFlight({ transports: [{ transportation_type: "car" }] }), false);
t("nor one with no transport at all", tripHasFlight({ hostings: [{ id: 1 }] }), false);
t("nor an empty trip", tripHasFlight({}), false);

// ---- how a drive is written -------------------------------------------------
t("under an hour, minutes", fmtDrive(19), "19 min");
t("exactly an hour", fmtDrive(60), "1 h");
t("over an hour, both parts", fmtDrive(372), "6 h 12 min");
t("a round number of hours drops the minutes", fmtDrive(120), "2 h");
t("nothing rounds to zero", fmtDrive(0.2), "1 min");

// One lookup per pair per session; a trip re-renders on every save.
t("the same pair is one key",
  routeKey({ lat: 34.0537, lon: -118.2427 }, MAMMOTH) ===
  routeKey({ lat: 34.0537, lon: -118.2427 }, MAMMOTH), true);
t("a different destination is a different key",
  routeKey(HOME_PT(), MAMMOTH) === routeKey(HOME_PT(), VEGAS), false);
t("and direction matters", routeKey(HOME_PT(), MAMMOTH) === routeKey(MAMMOTH, HOME_PT()), false);

// ---- a place you go back to -------------------------------------------------
// Pinecrest is ten trips to the same house, and NINE of them have no itinerary
// items at all — a name and two dates. A rule keyed off the first located item
// finds nothing on exactly the trips where the drive is the only fact there is.
const RANCH_HOUSE = { lat: 33.2504, lon: -115.6012 };
t("the house is on the list", KNOWN_PLACES.length >= 1, true);
t("named for what it is", KNOWN_PLACES[0].label, "The Ranch");

// By name, which is all an empty trip has.
t("an empty trip called Pinecrest is recognised",
  (knownPlaceFor({ name: "Pinecrest" }, {}) || {}).key, "pinecrest");
t("case does not matter", (knownPlaceFor({ name: "pinecrest weekend" }, {}) || {}).key, "pinecrest");
t("and a compound name still counts",
  (knownPlaceFor({ name: "Pinecrest / San Diego" }, {}) || {}).key, "pinecrest");
// A word boundary, so a longer word that merely contains it does not fire.
t("Pinecrestland is somewhere else", knownPlaceFor({ name: "Pinecrestland" }, {}), null);
t("an unrelated trip is not it", knownPlaceFor({ name: "Las Vegas" }, {}), null);
t("a trip with no name at all", knownPlaceFor({}, {}), null);

// By coordinates, which beat a name: an item sitting on the house is proof.
t("a booking at the house is recognised without the name",
  (knownPlaceFor({ name: "Thanksgiving" },
    { hostings: [{ latitude: RANCH_HOUSE.lat, longitude: RANCH_HOUSE.lon }] }) || {}).key, "pinecrest");
t("an activity there counts too",
  (knownPlaceFor({ name: "Thanksgiving" },
    { activities: [{ latitude: RANCH_HOUSE.lat, longitude: RANCH_HOUSE.lon }] }) || {}).key, "pinecrest");
// The same house geocoded slightly differently is still the same house.
t("a few kilometres out is still the house",
  (knownPlaceFor({ name: "x" },
    { hostings: [{ latitude: RANCH_HOUSE.lat + 0.02, longitude: RANCH_HOUSE.lon }] }) || {}).key, "pinecrest");
t("but the next town is not",
  knownPlaceFor({ name: "x" }, { hostings: [{ latitude: 32.72, longitude: -117.16 }] }), null);
t("an item with no coordinates decides nothing",
  knownPlaceFor({ name: "x" }, { hostings: [{ name: "Somewhere" }] }), null);

// The drive itself, which is the point.
t("home to the house is a real leg", !!homeHint(RANCH_HOUSE), true);
t("and about the right distance", Math.round(homeHint(RANCH_HOUSE).km / 10) * 10, 260);

// ---- where you are based each day -------------------------------------------
// A day has a shape: you wake in a hotel, go out, and come back to it. The hotel
// is days earlier on the itinerary, so nothing joined it to this morning's tour
// and the longest drive of the day went unmentioned.
const STAY = { id: 7, name: "Waldorf", latitude: 10.572957, longitude: -85.697565,
  starts_at: "2027-01-22T20:45:00Z", ends_at: "2027-01-27T17:00:00Z" };
const DATA = { hostings: [STAY] };

// A stay covers the NIGHTS between check-in and check-out.
t("the night of check-in is covered", (lodgingForNight("2027-01-22", DATA) || {}).id, 7);
t("a night in the middle is covered", (lodgingForNight("2027-01-25", DATA) || {}).id, 7);
t("the night of check-out is NOT", lodgingForNight("2027-01-27", DATA), null);
t("nor the night before check-in", lodgingForNight("2027-01-21", DATA), null);

// Which makes waking and sleeping different on a check-out day — the whole
// reason to model them apart.
t("you wake on the 25th where you slept on the 24th",
  (lodgingWokeIn("2027-01-25", DATA) || {}).id, 7);
t("you wake in the hotel on check-out day", (lodgingWokeIn("2027-01-27", DATA) || {}).id, 7);
t("but you do not sleep there that night", lodgingForNight("2027-01-27", DATA), null);
t("and you wake nowhere on arrival day", lodgingWokeIn("2027-01-22", DATA), null);

t("the day before is the day before", prevDayKey("2027-01-25"), "2027-01-24");
t("across a month end", prevDayKey("2027-02-01"), "2027-01-31");
t("across a year end", prevDayKey("2027-01-01"), "2026-12-31");

// A stay with no check-out is open-ended; covering every night thereafter would
// claim a base for the rest of the trip.
t("an open-ended stay covers only its own night",
  (lodgingForNight("2027-01-22", { hostings: [{ id: 8, latitude: 1, longitude: 1,
    starts_at: "2027-01-22T20:45:00Z" }] }) || {}).id, 8);
t("and not the night after",
  lodgingForNight("2027-01-23", { hostings: [{ id: 8, latitude: 1, longitude: 1,
    starts_at: "2027-01-22T20:45:00Z" }] }), null);
// A stay with no coordinates cannot be a base; there is nothing to drive to.
t("a lodging with no coordinates is not a base",
  lodgingForNight("2027-01-25", { hostings: [{ id: 9, starts_at: "2027-01-22T20:45:00Z",
    ends_at: "2027-01-27T17:00:00Z" }] }), null);
t("no lodging at all", lodgingForNight("2027-01-25", {}), null);

// The hotel's own rows are not a drive to the hotel.
t("the check-in row IS the base",
  isSameLodging({ kind: "hosting", obj: STAY }, STAY), true);
t("a different hotel is not",
  isSameLodging({ kind: "hosting", obj: { id: 99 } }, STAY), false);
t("nor is an activity", isSameLodging({ kind: "activity", obj: { id: 7 } }, STAY), false);

// ---- when the previous thing actually ended ---------------------------------
// The mirror of endPoint, and wrong in the same ways if written carelessly. A
// hire car's pick-up row carries arrival_at — the DROP-OFF, eight days later —
// and a hotel's check-in row carries ends_at, which is check-out. Both read as
// "this ended in the future", the gap test sees a negative interval, and a
// twenty-minute leg is rejected. This is why the drive from the rental counter
// to the hotel stayed missing even after endPoint was fixed.
const CAR = { transportation_type: "car", departure_at: "2027-01-22T19:30:00Z",
  arrival_at: "2027-01-30T21:30:00Z",
  departure_latitude: 10.634127, departure_longitude: -85.439819,
  arrival_latitude: 10.002864, arrival_longitude: -84.187475 };
t("a hire car's pick-up ends when you pick it up",
  endTimeOf({ kind: "transport", obj: CAR, when: CAR.departure_at }), "2027-01-22T19:30:00Z");
t("its drop-off row ends when you drop it off",
  endTimeOf({ kind: "transport", obj: CAR, isCheckout: true, when: CAR.arrival_at }), "2027-01-30T21:30:00Z");
t("a flight ends when it lands",
  endTimeOf({ kind: "transport", obj: { transportation_type: "airplane",
    arrival_at: "2027-01-22T18:25:00Z" }, when: "2027-01-22T10:30:00Z" }), "2027-01-22T18:25:00Z");
t("a check-in ends on arrival, not at check-out",
  endTimeOf({ kind: "hosting", obj: STAY, when: STAY.starts_at }), STAY.starts_at);
t("a check-out ends at check-out",
  endTimeOf({ kind: "hosting", obj: STAY, isCheckout: true, when: STAY.ends_at }), STAY.ends_at);

// And the point, likewise: a pick-up leaves you at the counter with the keys.
t("a hire car pick-up leaves you at the counter",
  Math.round(endPoint({ kind: "transport", obj: CAR }).lat * 1000) / 1000, 10.634);
t("its drop-off row leaves you at the drop-off",
  Math.round(endPoint({ kind: "transport", obj: CAR, isCheckout: true }).lat * 1000) / 1000, 10.003);
t("a flight still leaves you where it lands",
  Math.round(endPoint({ kind: "transport", obj: { transportation_type: "airplane",
    arrival_latitude: 10.6, arrival_longitude: -85.5 } }).lat * 10) / 10, 10.6);
// The whole reason: rental counter to hotel is a real leg and used to vanish.
t("counter to hotel is a real drive",
  !!transferHint({ kind: "transport", obj: CAR, when: CAR.departure_at },
    { kind: "hosting", obj: STAY, when: STAY.starts_at }), true);
t("and it is the short one, not the drop-off distance",
  Math.round(transferHint({ kind: "transport", obj: CAR, when: CAR.departure_at },
    { kind: "hosting", obj: STAY, when: STAY.starts_at }).km), 29);

// ---- a few blocks is a walk, not a drive ------------------------------------
// The floor used to be 1.5 km, which is a fifteen-minute walk, and it quietly
// swallowed most of a city day: the old San Francisco apartment to Parnassus is
// 870 m and Parnassus to the Academy of Sciences 1.07 km, and neither said
// anything at all.
//
// And a distance is not the whole answer. "3 min" for a 900 m drive is true of
// the driving and false of the trip — it leaves out the parking, which is the
// part that costs you. So a short hop is reported on foot.
const near = (m) => ({ kind: "activity", when: "2026-09-28T17:00:00Z",
  obj: { latitude: HOTEL.lat + m / 111000, longitude: HOTEL.lon } });
const atHotel = { kind: "hosting", when: "2026-09-28T16:00:00Z",
  obj: { latitude: HOTEL.lat, longitude: HOTEL.lon } };

t("two entrances of one building say nothing", transferHint(atHotel, near(150)), null);
t("a few hundred metres is a walk", (transferHint(atHotel, near(600)) || {}).mode, "walk");
t("870 m — the apartment to Parnassus — is a walk",
  (transferHint(atHotel, near(870)) || {}).mode, "walk");
t("1.07 km — Parnassus to the Academy — is a walk",
  (transferHint(atHotel, near(1070)) || {}).mode, "walk");
// 1.8 km is SFO's terminal to its rental centre. Nobody walks it; there is a
// train. At a 2 km threshold this came out as "about 35 min on foot".
t("1.8 km is not a walk", (transferHint(atHotel, near(1800)) || {}).mode, "drive");
t("and neither is anything longer", (transferHint(atHotel, near(9000)) || {}).mode, "drive");
t("the threshold sits between the two", WALK_MAX_KM > 1.07 && WALK_MAX_KM < 1.8, true);
t("and the floor is low enough for a city block", TRANSFER_MIN_KM <= 0.3, true);

// Walking pace, with the same winding allowance roads get.
t("870 m is about a quarter of an hour", Math.round(walkMinutes(0.87) / 5) * 5, 15);
t("a kilometre is a bit under twenty minutes", Math.round(walkMinutes(1.0)), 19);
t("and it scales", Math.round(walkMinutes(0.4)), 7);
// A walk is never handed to the driving router: OSRM would answer with a
// three-minute drive, which is true of the car and false of the errand.
t("a walk is not upgraded to a driving route", /if \(!walk\) upgradeWithRoute/.test(src), true);

// ---- the model is the shared one --------------------------------------------
t("the check and the hint use one distance model",
  /F\.km\(a\.lat, a\.lon, b\.lat, b\.lon\)/.test(src), true);
t("and one drive-time model", /F\.driveMinutes\(d\)/.test(src), true);
t("it degrades to silence if feasibility.js has not loaded",
  /if \(!F \|\| !F\.km \|\| !F\.driveMinutes\) return null;/.test(src), true);
// A hint is a note between two items, not a third item on the day.
t("the day count ignores hints", /querySelectorAll\("\.itin-row"\)\.length/.test(src), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
