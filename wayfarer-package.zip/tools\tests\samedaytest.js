// A stay that checks out on the day it checks in.
//
// Worth zero nights, and until now it said so nowhere. Found across 15 of 218
// stays, and the shape is consistent enough to name: the check-IN carries the
// check-OUT's date, so a one-night stay collapses to none.
//
//   Alila Marea Beach Resort   28 Feb 2026   trip ran 27–28 Feb
//   Hyatt Place Peña Station   27 Mar 2026   trip ran 26–27 Mar
//   Kimpton La Peer            07 Jan 2025   trip ran 06–07 Jan
//   Courtyard Pasadena         20 Nov 2021   trip ran 19–20 Nov
//
// It is not cosmetic. The night is missing from every total, the lodging-gap
// check reports that night as uncovered when a hotel was in fact booked, and
// the first two above silently withheld night credit from the Globalist goal --
// which is how they were found at all. See [[hyatt-globalist-nights]].
//
// The comparison is on LOCAL calendar days, because that is what a hotel stay
// is measured in. A stay can straddle midnight UTC and still be one calendar
// day where the hotel stands, and the reverse.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

// The real block out of auditTrip, not a copy of its logic.
function liftFrom(hay, decl) {
  const at = hay.indexOf(decl);
  if (at < 0) throw new Error("not found: " + decl);
  let depth = 0, i = hay.indexOf("{", at);
  for (; i < hay.length; i++) {
    if (hay[i] === "{") depth++;
    else if (hay[i] === "}") { depth--; if (!depth) break; }
  }
  return hay.slice(at, i + 1);
}
const audit = liftFrom(app, "function auditTrip(t, data) {");
const hostBlock = liftFrom(audit, "host.forEach(function (h) {");
const dayKey = liftFrom(app, "function dayKey(utc, tz)");

// Run the real block against stubs, collecting what it would report.
function findings(stays) {
  const out = [];
  const src =
    dayKey + "\n" +
    "var host = stays;\n" +
    "var add = function (level, title, detail, fix, soft) { out.push({ level: level, title: title, soft: !!soft }); };\n" +
    "var editHosting = function () {};\n" +
    "var t = {};\n" +
    // liftFrom stops at the callback's closing brace; the call still needs closing.
    hostBlock + ");\nreturn out;";
  return new Function("stays", "out", src)(stays, out);
}

const LA = "America/Los_Angeles";
const sameDay = (f) => f.filter((x) => /checks out the day it checks in/.test(x.title));

console.log("\nthe stay that is worth nothing");
{
  // Alila Marea, as actually stored.
  const f = findings([{ name: "Alila Marea Beach Resort", starts_at: "2026-02-28T20:00:00Z", ends_at: "2026-02-28T22:00:00Z", timezone: LA }]);
  t("it is reported", sameDay(f).length, 1);
  t("as an issue, not a warning", sameDay(f)[0].level, "issue");
  // The rule the older findings already follow: a finding about MISSING data is
  // noise once a trip is over, but one that distorts a total is not. Thirteen
  // of the fifteen are in the past and still wrong.
  t("and NOT soft, so it survives on a past trip", sameDay(f)[0].soft, false);
  t("the name is in the title", /Alila Marea/.test(sameDay(f)[0].title), true);
  t("an unnamed stay still reports", /^Lodging checks out/.test(sameDay(findings([{ starts_at: "2026-02-28T20:00:00Z", ends_at: "2026-02-28T22:00:00Z", timezone: LA }]))[0].title), true);
}

console.log("\nan ordinary stay is left alone");
{
  t("one night reports nothing",
    sameDay(findings([{ name: "Park Hyatt", starts_at: "2026-01-18T23:00:00Z", ends_at: "2026-01-19T18:00:00Z", timezone: LA }])).length, 0);
  t("four nights report nothing",
    sameDay(findings([{ name: "Park Hyatt", starts_at: "2026-01-18T23:00:00Z", ends_at: "2026-01-22T18:00:00Z", timezone: LA }])).length, 0);
}

console.log("\nlocal days, not UTC days");
{
  // 28 Feb 20:00 and 1 Mar 00:00 UTC are different UTC dates and the SAME
  // calendar day in Los Angeles, where the hotel is. A UTC comparison would
  // miss this one.
  t("a stay straddling midnight UTC is still one local day",
    sameDay(findings([{ name: "Alila", starts_at: "2026-02-28T20:00:00Z", ends_at: "2026-03-01T00:00:00Z", timezone: LA }])).length, 1);
  // And the reverse: same UTC date, two different local days in Tokyo.
  t("and a real night is not falsely reported because UTC agrees",
    sameDay(findings([{ name: "Hyatt Tokyo", starts_at: "2026-03-01T06:00:00Z", ends_at: "2026-03-01T20:00:00Z", timezone: "Asia/Tokyo" }])).length, 0);
}

console.log("\nit does not disturb the check that was already there");
{
  const f = findings([{ name: "Open ended", starts_at: "2026-02-28T20:00:00Z", ends_at: null, timezone: LA }]);
  t("a stay with no check-out still reports that", f.filter((x) => /has no check-out/.test(x.title)).length, 1);
  // Missing data on a finished trip IS noise, so that one stays soft.
  t("and that one is still soft", f.filter((x) => /has no check-out/.test(x.title))[0].soft, true);
  t("without also claiming it checks out the same day", sameDay(f).length, 0);
  t("a stay with no dates at all reports neither",
    findings([{ name: "Nothing", starts_at: null, ends_at: null }]).length, 0);
}

console.log("\n" + pass + " passed, " + fail + " failed\n");
process.exit(fail ? 1 : 0);
