// The duration chip on an activity idea.
//
// Viator's duration field means two different things depending on what the
// product is, and nothing in the payload distinguishes them: for a tour it is
// how long you are out, for a rental it is how long you keep the kit. The
// numbers below are the real ones from a Mammoth Lakes and a Valle de Guadalupe
// search. Nothing here is trip data — they are public product durations.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");

function grab(name) {
  const i = src.indexOf("  function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
// tourDurationLabel reads this. Miss it and every call throws rather than
// quietly misbehaving, but extract it anyway so the ceiling under test is the
// one the app ships rather than a copy that can drift.
const max = src.slice(src.indexOf("  var TOUR_MAX_MINUTES"), src.indexOf(";", src.indexOf("  var TOUR_MAX_MINUTES")) + 1);

eval(max + "\n" + grab("tourDurationLabel") +
  ";Object.assign(globalThis,{tourDurationLabel,TOUR_MAX_MINUTES});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const ok = got === want;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + JSON.stringify(want) + "\n        got  " + JSON.stringify(got));
};

// ---- the case that motivated this ------------------------------------------
// Mammoth Mountain Performance Ski Rental Including Delivery, 16389P5. 7200
// minutes is a five-day hire, and the panel rendered it as "120h" beside a
// $131.10 price.
t("a five-day hire period gets no chip", tourDurationLabel(7200), null);

// ---- ordinary tours still say how long they are ----------------------------
t("a half-day tour", tourDurationLabel(240), "4h");            // La Bufadora
t("a six-hour wine route", tourDurationLabel(360), "6h");      // Guadalupe 31612P1
t("a climbing class", tourDurationLabel(420), "7h");           // Mammoth 419153P1
t("a long day out", tourDurationLabel(720), "12h");            // Guadalupe 485787P3
t("rounding is to the nearest hour", tourDurationLabel(100), "2h");
t("…and rounds down below the half", tourDurationLabel(80), "1h");

// ---- the boundary ----------------------------------------------------------
t("the ceiling is a day", TOUR_MAX_MINUTES, 1440);
t("exactly a day still renders", tourDurationLabel(1440), "24h");
t("a minute over a day does not", tourDurationLabel(1441), null);
t("a two-day package does not", tourDurationLabel(2880), null);

// ---- absent or meaningless input -------------------------------------------
// The importer omits the field entirely when the value would be a hire period,
// so an absent chip must be the quiet default rather than "0h" or "NaNh".
t("an absent duration", tourDurationLabel(undefined), null);
t("a null duration", tourDurationLabel(null), null);
t("a zero duration", tourDurationLabel(0), null);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
