// Things you have to be able to see and hit.
//
// U13 -- the status pills used one colour as BOTH the text and, mixed 16-20%
// into the surface, its own background, so on a light theme the two were always
// a few percent apart. Measured against each theme's real mixed background:
//
//            before          after
//   warn     2.32 / 2.15     5.07 / 4.71   (Sunny / Desert)
//   ok       2.70 / 2.50     5.15 / 4.78
//   issue    4.41 / 4.09     5.27 / 4.84
//
// against the 4.5:1 that 14px text needs. Dark themes already passed and keep
// their bright hues -- darkening them there would make them worse.
//
// U7 -- hit areas, measured at the default text size: .check 22x22, the budget
// chips ~26x22 with 4px between them, the link-remove x ~16x12. Apple's floor
// is 44pt. The controls are deliberately small (a 44px tick beside every
// packing line would be a wall of boxes) so the TARGET grows and the drawing
// does not.
//
// U18 -- both phone bars hide their scrollbars, so a row that happens to break
// at a chip boundary was indistinguishable from a complete one.
const fs = require("fs");
const css = fs.readFileSync("public/styles.css", "utf8");
const app = fs.readFileSync("public/app.js", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

console.log("\npill colours are tokens, set per theme");
t("light themes get darkened foregrounds",
  /:root \{ --pill-ok:#1c6b3f; --pill-warn:#8a5210; --pill-changed:#8a5210; --pill-issue:#a52d23; \}/.test(css), true);
// One definition per dark theme, not three on one of them -- an anchor that is
// a prefix of its own replacement put all three on `dark` the first time.
t("each dark theme gets exactly one",
  (css.match(/--pill-ok:#4fbf82; --pill-warn:#e8a34e; --pill-changed:#e8a34e; --pill-issue:var\(--danger\);/g) || []).length, 3);
t("no theme carries a duplicate",
  /--pill-issue:var\(--danger\); --pill-issue/.test(css), false);
["ok", "warn", "issue"].forEach(function (k) {
  t("." + k + " reads from its token", new RegExp("\\.health-pill\\." + k + "\\s+\\{[^}]*color:var\\(--pill-" + k + "\\)").test(css), true);
});
// The changed-chip had the same fault: #d9822b on a 10% wash of itself.
t("the changed chip too", /color:var\(--pill-changed\)/.test(css), true);

console.log("\nhit areas grow, drawings do not");
t("a transparent pseudo-element does the work",
  /\.check::before, \.bud-acts \.linkchip::before, \.bucket-linkx::before \{/.test(css), true);
// .sec-arrow used to be in this list and in the two rules below it. It was
// dead: no element in the app has ever carried that class -- it is nowhere in
// app.js or index.html. U7 built a tap target for a control that does not
// exist, and this suite asserted it was working.
t("and no rule survives for a control that does not exist", /sec-arrow/.test(css), false);
t("anchored to a positioned parent", /\.check, \.bud-acts \.linkchip, \.bucket-linkx \{\s*position:relative;/.test(css), true);
// .check has 189px of vertical room between rows and nothing beside it.
// .check keeps the full -11px, and the ROW is what makes that safe.
//
// The comment here used to claim ".check has 189px of vertical room between
// rows". Measured, the gap between two ticks is 14px at the large text size
// and 11px at medium and small -- so a -11px inset ran 8px into the next tick
// at large and the whole 11px at the other two. Probed: a tap just below a
// tick hit a .check that was not the one being aimed at, and since the row
// itself is not clickable that ticked the wrong line.
//
// At a 44px row the pitch is 44 and the tick is 22, so the gap is 22 and two
// -11px insets tile it exactly -- touching, never overlapping -- at every
// text size, and a larger size only widens the gap.
t(".check takes the full 44 both ways", /\.check::before \{ inset:-11px; \}/.test(css), true);
t("and the row is tall enough that it cannot reach the next tick",
  /\.pack-row \{ min-height:44px; \}/.test(css), true);
// A uniform inset big enough for 44 would make neighbours overlap, and then the
// wrong control wins the tap -- the mis-tap this exists to prevent.
t("packed rows expand vertically, not into each other",
  /\.bud-acts \.linkchip::before \{ inset:-11px -4px; \}/.test(css), true);
// NOT the traveller chips -- this claim was wrong when it was written.
//
// They live in .pax-bar, which is overflow-x:auto on a phone, and a scroll
// container clips an absolutely-positioned pseudo-element to its box. Measured
// in the real bar: a tap 3px above or 3px below a chip landed on .detail-inner,
// not the chip. Of the intended 55px target, 11px was clipped above and 9px
// below -- the expansion delivered no target at all, while its 11px overhang
// still counted toward the bar's scrollable height and made the row pan
// vertically as you dragged it sideways.
//
// So they are the size instead. The tick beside every packing line cannot be --
// it repeats down the page and 44px boxes would be a wall -- but these sit in
// one horizontal row, so the height is paid once.
t("the traveller chips are 44 for real, not by pseudo-element",
  /\.pax-chip, \.pax-manage, \.pax-empty \{[^}]*min-height:44px; display:inline-flex; align-items:center;/.test(css), true);
t("and carry no hit-area pseudo-element at all", /\.pax-(chip|manage)::before/.test(css), false);
// Measured after: chip 44px tall, hit at its top, centre and bottom alike,
// where before only the centre worked.

console.log("\nthe travellers bar scrolls one way");
// Setting overflow-x:auto promotes overflow-y from visible to auto -- the spec
// does it, nothing here asked for it. With the pseudo-element hanging 11px
// below each chip that became an 8px vertical scroll range, and a sideways drag
// panned the row up and down. Reported as the chips feeling "loose".
t("vertical overflow is shut off", /\.pax-bar \{[\s\S]*?overflow-y:hidden;/.test(css), true);
t("and the gesture layer is told the same", /touch-action:pan-x;/.test(css), true);
// Measured after: 0px vertical overflow, scrollTop cannot move off zero, and
// the bar still scrolls sideways (958 vs 363).
t("and the smallest control gets the most", /\.bucket-linkx::before \{ inset:-14px -9px; \}/.test(css), true);
t("delete also moves away from edit", /\.bud-acts \{ gap:12px; \}/.test(css), true);
// Inside the phone block: this is a touch problem, not a pointer one.
const phone = css.slice(css.indexOf("@media (max-width:700px)"));
t("all of it is phone-only", /\.check::before \{ inset:-11px; \}/.test(phone), true);

console.log("\nthe scrolling bars say so");
t("a right-edge fade", /--fade: linear-gradient\(to right, #000 calc\(100% - 26px\), transparent\)/.test(css), true);
t("on both bars", /\.detail-actions, \.pax-bar \{ --fade/.test(css), true);
// Otherwise it sits at the end of the row promising content that is not there.
t("removed once there is nothing more", /\.detail-actions:not\(\.at-end\), \.pax-bar:not\(\.at-end\)/.test(css), true);
t("a scroll listener sets that", /function wireOverflowFade\(root\)/.test(app), true);
t("with slack for fractional scrolling", /bar\.scrollLeft \+ bar\.clientWidth >= bar\.scrollWidth - 2/.test(app), true);
t("and it is wired when a trip renders", /wireOverflowFade\(content\);/.test(app), true);
// Manage sorted last meant the only actionable control was first off-screen.
t("Manage comes before the names",
  app.indexOf("bar.appendChild(manage);") < app.indexOf('going.forEach(function (p) { bar.appendChild(el("span", "pax-chip on is-static", p.name)); });'), true);

console.log("\na flight's times get their own line on a phone");
// .itin-time floats right, so the title text flows AROUND it. On a transport
// row the meta is long -- "Dep 8:05 PM . Arr 2:35 PM" is 193px of a 302px body
// -- which left the title about 107px of first-line room and broke it mid-name:
// "Delta Air" / "Lines DL1715". Measured across five trips at 390px: nine of
// twelve transport rows were squeezed to 104-111px, and eight of fifteen
// wrapped. After: 0 of 12 wrap, and every meta sits below its name.
t("the transport body stacks", /\.itin-row\[data-item-kind="transportation"\] \.itin-body \{ display:flex; flex-direction:column; \}/.test(css), true);
// order:-1 lifts the title above the time and leaves everything after it in
// source order -- time, sub, details, chips. Done in CSS rather than by
// reordering the DOM, because a float must PRECEDE the content that wraps
// around it: changing the append order would fix the phone and break desktop.
t("the name is lifted above the meta", /\.itin-row\[data-item-kind="transportation"\] \.itin-title \{ order:-1; \}/.test(css), true);
t("and the meta stops floating", /\.itin-row\[data-item-kind="transportation"\] \.itin-time \{[^}]*float:none; margin-left:0; margin-top:2px;/.test(css), true);
// Every other row keeps the float. A bare "4:00 PM" is 66px and costs the title
// nothing, and no non-transport row in the database carries a Dep/Arr meta.
t("every other row keeps its floated time", /\.itin-time \{ float:right;/.test(css), true);
// Phone only: on desktop the body is 736px, the float works, and it saves a
// line. Verified there -- all 12 metas still float right, 0 titles wrap.
t("and this is phone-only", /\.itin-row\[data-item-kind="transportation"\] \.itin-body/.test(phone), true);

console.log("\nthe trip itself is editable");
t("an edit chip sits with the others", /el\("button", "type-toggle trip-edit is-edit", "✎ Edit"\)/.test(app), true);
t("it opens the whole record", /function editTripDetails\(t\)/.test(app), true);
["name", "timezone", "starts_at", "ends_at", "number_of_days", "description"].forEach(function (f) {
  t("  " + f + " is editable", new RegExp('name: "' + f + '"[^}]*value:').test(app), true);
});
t("the end date cannot precede the start", /The end date is before the start date\./.test(app), true);
t("the dashboard card is updated too", /state\.own = \(state\.own \|\| \[\]\)\.map\(function \(x\) \{ return x\.id === t\.id \? fresh : x; \}\);/.test(app), true);
// Changing the dates changes which day every item falls under.
t("and the itinerary is rebuilt rather than reused", /openTrip\(fresh\);/.test(app), true);
t("the old dates-only dialog is gone", /formDialog\("Trip dates"/.test(app), false);

console.log("\nrefresh refreshes, it does not navigate");
// handleHash honours a DEEP LINK. Running it on every loadAll was harmless
// while #trip/N was the only route and the trip was already open; once panels
// had addresses it meant Refresh re-opened History from a stale hash.
t("the deep link is handled once", /var deepLinkHandled = false;/.test(app), true);
t("and only on the first load", /if \(!deepLinkHandled\) \{ deepLinkHandled = true; handleHash\(\); \}/.test(app), true);
t("back and forward still route", /window\.addEventListener\("popstate", handleHash\);/.test(app), true);
t("as do address-bar edits", /window\.addEventListener\("hashchange", handleHash\);/.test(app), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
