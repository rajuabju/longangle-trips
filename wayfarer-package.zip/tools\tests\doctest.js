// Exercise tripLeavesCountry and the travel-document audit rules.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");
function grab(n) {
  const i = src.indexOf("  function " + n + "(");
  if (i < 0) throw new Error("missing " + n);
  let d = 0, s = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; s = true; } else if (src[j] === "}") { d--; if (s && !d) return src.slice(i, j + 1); }
  }
}
const boxes = src.slice(src.indexOf("  var US_BOXES ="), src.indexOf("];", src.indexOf("  var US_BOXES =")) + 2);
eval(boxes + grab("tripLeavesCountry") + grab("addDays") + ";globalThis.LC = tripLeavesCountry; globalThis.AD = addDays;");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const ok = JSON.stringify(got) === JSON.stringify(want);
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label + (ok ? "" : "   want " + JSON.stringify(want) + " got " + JSON.stringify(got)));
};

// --- tripLeavesCountry, using coordinates lifted from the live database ---
const P = (la, lo) => ({ latitude: la, longitude: lo });
t("Las Vegas is domestic", LC({ hostings: [P(36.1073, -115.1765)] }), false);
t("Kauai is domestic", LC({ hostings: [P(22.05, -159.5)] }), false);
t("Anchorage is domestic", LC({ hostings: [P(61.2, -149.9)] }), false);
t("Honolulu is domestic", LC({ hostings: [P(21.3, -157.85)] }), false);
t("Lisbon is international", LC({ hostings: [P(38.7, -9.19)] }), true);
t("Cabo San Lucas is international", LC({ hostings: [P(22.89, -109.91)] }), true);
t("Arenal, Costa Rica is international", LC({ hostings: [P(10.46, -84.7)] }), true);
t("CDG as a flight endpoint alone flips it", LC({ transports: [{ departure_latitude: 49.0032, departure_longitude: 2.567, arrival_latitude: 33.94, arrival_longitude: -118.4 }] }), true);
t("null island is ignored (the Kauai taxi)", LC({ hostings: [P(22.05, -159.5)], transports: [{ departure_latitude: 0, departure_longitude: 0 }] }), false);
t("missing coordinates are ignored", LC({ hostings: [P(null, null), P(36.1, -115.1)] }), false);
t("no coordinates at all is not international", LC({ hostings: [], transports: [], activities: [] }), false);
t("string coordinates still work", LC({ hostings: [P("38.7", "-9.19")] }), true);

// --- addDays ---
t("addDays 182 across a year", AD("2027-01-31", 182), "2027-08-01");
t("addDays across a leap day", AD("2028-02-28", 2), "2028-03-01");
t("addDays 0", AD("2026-08-14", 0), "2026-08-14");

// --- the six-month rule arithmetic, as the audit applies it ---
const sixMonthRule = (tripEnd, expires) => expires < AD(tripEnd, 182);
t("Costa Rica ends 2027-01-31, passport to 2027-06-01 -> flagged", sixMonthRule("2027-01-31", "2027-06-01"), true);
t("Costa Rica ends 2027-01-31, passport to 2028-06-01 -> quiet", sixMonthRule("2027-01-31", "2028-06-01"), false);
t("expiry exactly at the six-month mark -> quiet", sixMonthRule("2027-01-31", "2027-08-01"), false);
t("expiry one day inside the mark -> flagged", sixMonthRule("2027-01-31", "2027-07-31"), true);

// --- isNextUpcomingTrip: an expired document must be reported once, not per trip ---
const today = new Date().toISOString().slice(0, 10);
const future = (n) => { const d = new Date(); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };
const TT = (id, s, e) => ({ id, name: "t" + id, starts_at: s, ends_at: e, has_dates: true });

globalThis.state = { own: [] };
eval(grab("isNextUpcomingTrip") + ";globalThis.NX = isNextUpcomingTrip;");

const soonest = TT(1, future(5), future(8));
const later = TT(2, future(40), future(45));
const past = TT(3, future(-40), future(-35));
const ongoing = TT(4, future(-2), future(3));   // already started, not finished

state.own = [later, soonest, past];
t("the soonest upcoming trip is the one chosen", NX(soonest), true);
t("a later trip is not", NX(later), false);
t("a finished trip is not", NX(past), false);

state.own = [later, soonest, ongoing];
t("a trip already under way outranks one starting later", NX(ongoing), true);
t("...and the later one goes quiet", NX(soonest), false);

// Ties must resolve deterministically, or the finding flickers between trips.
const tieA = TT(10, future(5), future(8)), tieB = TT(11, future(5), future(9));
state.own = [tieB, tieA];
t("same start date breaks on the lower id", NX(tieA), true);
t("...and the higher id stays quiet", NX(tieB), false);
state.own = [tieA, tieB];
t("tie-break is order-independent", NX(tieA) && !NX(tieB), true);

state.own = [past];
t("no upcoming trips at all -> nothing is the next trip", NX(past), false);
state.own = [];
t("empty trip list is safe", NX(soonest), false);
t("undated trip is never the next one", NX({ id: 9, has_dates: false }), false);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
