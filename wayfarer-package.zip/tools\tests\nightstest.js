// Goals counted in nights, where spend is only one of three sources.
//
// World of Hyatt Globalist is 60 qualifying nights a year. The card grants 5
// for being held, 2 more per $5,000 spent, and every night actually slept in a
// Hyatt counts one. That is why $140,000 of pure card spend reaches it with no
// stays at all: 5 + 2 x 28 = 61.
//
// The arithmetic is the easy half -- and it was wrong three ways before the
// 2026-08-28 audit: a stay you were IN THE MIDDLE OF credited every night on
// check-in day, a second room on a future booking counted as already earned,
// and a stay spanning New Year gave all its nights to the check-in year while
// the new year saw none. Each is pinned below.
//
// The hard half is deciding which stays are
// Hyatt's, and the 2026 itinerary breaks a name match in both directions:
//
//   "Hotel Seville NoMad"      IS a Hyatt -- the card statement reads HYATT
//                              SEVILLE NOMAD -- and nothing in the stored name
//                              says so. Three nights would have vanished.
//   "Alila Marea", "Andaz",    Hyatt brands that never print the word, so a
//   "Unbound Collection"       reader who only knows "Hyatt" undercounts.
//   Same hotel, same dates,    A SECOND ROOM, not a duplicate -- measured 40/40
//   listed twice               across 182 trips. Counting both doubles the stay.
//
// So the brand match is a default and card_stay_marks is the correction. These
// tests pin both, and the fixtures are synthetic -- no real trips here, see
// run.js.
const fs = require("fs");
const core = fs.readFileSync("functions/api/_core.js", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

function lift(decl) {
  const at = core.indexOf(decl);
  if (at < 0) throw new Error("not found: " + decl);
  let depth = 0, i = core.indexOf("{", at);
  for (; i < core.length; i++) {
    if (core[i] === "{") depth++;
    else if (core[i] === "}") { depth--; if (!depth) break; }
  }
  return core.slice(at, i + 1);
}

// The real brand table and the real night counter, lifted rather than copied.
const BRANDS = lift("const STAY_BRANDS = ");
const api = new Function("nowIso",
  BRANDS + "\n" + lift("function stayNights(") + "\n" + lift("function dayAfter(") + "\n" +
  lift("async function nightsFromStays(") +
  "\nreturn { STAY_BRANDS: STAY_BRANDS, stayNights: stayNights, nightsFromStays: nightsFromStays };"
)(() => "2026-08-27T12:00:00.000Z");

// The goal's own window, as cardsPayload now passes it.
const WIN_2026 = { from: "2026-01-01", to: "2026-12-31" };
const WIN_2027 = { from: "2027-01-01", to: "2027-12-31" };

console.log("\nnights between two calendar dates");
{
  t("a four-night stay", api.stayNights("2026-01-18", "2026-01-22"), 4);
  t("a one-night stay", api.stayNights("2026-08-05", "2026-08-06"), 1);
  // Same day in and out earns nothing. Almost always a missing check-out, and
  // the panel flags it rather than letting the night disappear into a zero.
  t("same day in and out is zero, not one", api.stayNights("2026-02-28", "2026-02-28"), 0);
  t("a timestamp is trimmed to its date", api.stayNights("2026-01-18T15:00:00Z", "2026-01-22T11:00:00Z"), 4);
  t("nothing at all is zero", api.stayNights(null, null), 0);
  t("backwards dates are zero, not negative", api.stayNights("2026-03-10", "2026-03-01"), 0);
}

console.log("\nthe Hyatt brands that never say Hyatt");
{
  const hy = api.STAY_BRANDS.hyatt;
  const yes = ["Park Hyatt Beaver Creek", "Grand Hyatt Denver", "Hyatt Place Scottsdale - North",
    "Alila Marea Beach Resort Encinitas", "Andaz Amsterdam Prinsengracht",
    "Carmel Valley Ranch - The Unbound Collection by Hyatt", "Thompson Hotel Madrid",
    "Miraval Arizona Resort", "Hyatt Ziva Cancun"];
  for (const n of yes) t("counts " + n.slice(0, 38), hy.test(n), true);
  const no = ["Fontainebleau Las Vegas", "Waldorf Astoria Los Cabos Pedregal", "voco Laguna Hills",
    "The Langham Huntington, Pasadena", "Crockfords Las Vegas, LXR Hotels & Resorts", "Airbnb - Judy"];
  for (const n of no) t("skips " + n.slice(0, 38), hy.test(n), false);
  // The one no pattern can catch, which is the whole reason for the override.
  t("and MISSES Hotel Seville NoMad, which is why marks exist", hy.test("Hotel Seville NoMad"), false);
}

console.log("\ncounting a year of stays");
{
  // A stub D1 shaped like the two queries nightsFromStays makes.
  const build = (hostings, marks) => ({
    prepare(sql) {
      const rows = /card_stay_marks/.test(sql) ? (marks || []) : hostings;
      return { bind: () => ({ all: async () => ({ results: rows }) }) };
    },
  });
  const H = (id, name, from, to) => ({ id, name, starts_at: from, ends_at: to });

  const hostings = [
    H(1, "Park Hyatt Beaver Creek", "2026-01-18", "2026-01-22"),   // 4
    H(2, "Park Hyatt Beaver Creek", "2026-01-18", "2026-01-22"),   // second room, 4
    H(3, "Grand Hyatt Denver", "2026-01-22", "2026-01-24"),        // 2
    H(4, "Fontainebleau Las Vegas", "2026-03-15", "2026-03-16"),   // not Hyatt
    H(5, "Alila Marea Beach Resort", "2026-02-28", "2026-02-28"),  // Hyatt, zero nights
    H(6, "Hotel Seville NoMad", "2026-04-08", "2026-04-11"),       // Hyatt, unmatched, 3
    H(7, "Hyatt Regency Lisbon", "2026-11-17", "2026-11-19"),      // Hyatt, still ahead, 2
  ];
  const goal = { id: 103, stay_brand: "hyatt" };

  return api.nightsFromStays(build(hostings), goal, WIN_2026).then(async (r) => {
    t("only stayed nights count toward the total", r.counted, 6);       // 4 + 2
    t("a second room is held back separately", r.extra, 4);
    t("a booked stay later this year is not earned yet", r.ahead, 2);
    t("every stay is listed, counted or not", r.stays.length, 7);

    const by = {};
    for (const s of r.stays) by[s.hosting_id] = s;
    t("the second room is marked as one", by[2].room, 2);
    t("the non-Hyatt is listed but not counted", by[4].counts, false);
    t("the zero-night stay is flagged", by[5].suspect, true);
    t("and Seville is missed by the match", by[6].counts, false);
    t("the November stay is marked as still to come", by[7].future, true);

    // ---- the correction ----
    const marked = await api.nightsFromStays(
      build(hostings, [{ hosting_id: 6, counts: 1 }]), goal, WIN_2026);
    t("marking Seville adds its three nights", marked.counted, 9);
    const s6 = marked.stays.find((s) => s.hosting_id === 6);
    t("and the panel says the answer was set by hand", s6.overridden, true);

    // A mark works the other way too: dropping a stay the match claimed.
    const dropped = await api.nightsFromStays(
      build(hostings, [{ hosting_id: 1, counts: 0 }]), goal, WIN_2026);
    t("unticking a matched stay removes its nights", dropped.counted, 2);
    t("which is also recorded as an override",
      dropped.stays.find((s) => s.hosting_id === 1).overridden, true);

    console.log("\na stay you are in the middle of");
    {
      // Today is stubbed as 2026-08-27. Six booked nights, two slept. The
      // pre-audit code credited all six the moment the stay began -- status
      // you had not stayed for.
      const mid = await api.nightsFromStays(
        build([H(20, "Grand Hyatt", "2026-08-25", "2026-08-31")]), goal, WIN_2026);
      t("the nights already slept are earned", mid.counted, 2);
      t("the nights still to come are booked ahead", mid.ahead, 4);
    }

    console.log("\na second room on a future booking");
    {
      // The pre-audit branch order tested room BEFORE future, so the second
      // room of a not-yet-started stay landed in `extra` -- which, with
      // count_extra_rooms on, was added to EARNED progress today.
      const fut = await api.nightsFromStays(
        build([H(30, "Park Hyatt", "2026-11-10", "2026-11-13"),
               H(31, "Park Hyatt", "2026-11-10", "2026-11-13")]), goal, WIN_2026);
      t("room one's future nights are ahead", fut.ahead, 3);
      t("room two's future nights are extraAhead, not extra", fut.extraAhead, 3);
      t("nothing future lands in the earned buckets", fut.counted + fut.extra, 0);
    }

    console.log("\na stay spanning New Year belongs to both years");
    {
      // 29 Dec - 2 Jan: three nights of the old year, one of the new. The
      // pre-audit query keyed on starts_at alone, so the old year took all
      // four and the new year never saw the stay at all.
      const straddle = [H(40, "Hyatt Regency", "2026-12-29", "2027-01-02")];
      const old = await api.nightsFromStays(build(straddle), goal, WIN_2026);
      const nyr = await api.nightsFromStays(build(straddle), goal, WIN_2027);
      t("the old year gets three nights", old.ahead, 3);
      t("the new year gets the fourth", nyr.ahead, 1);
      t("nothing is counted twice", old.ahead + nyr.ahead, 4);
      t("the list still shows the stay's own length", old.stays[0].nights, 4);
      t("and does not call it suspect", old.stays[0].suspect, false);
    }

    console.log("\nthe window is the goal's, not the calendar's");
    {
      // A march-period goal in its 2026-27 year: a January 2026 stay is
      // outside it, a January 2027 stay is inside. The pre-audit code counted
      // stays over the CALENDAR year while spend used the march window -- the
      // two halves of one progress figure measured over different periods.
      const MARCH = { from: "2026-03-01", to: "2027-02-28" };
      const jan26 = await api.nightsFromStays(
        build([H(50, "Andaz", "2026-01-10", "2026-01-12")]), goal, MARCH);
      const jan27 = await api.nightsFromStays(
        build([H(51, "Andaz", "2027-01-10", "2027-01-12")]), goal, MARCH);
      t("January before the window contributes nothing", jan26.counted + jan26.ahead + jan26.extra + jan26.extraAhead, 0);
      t("January inside the window contributes its nights", jan27.ahead, 2);
    }

    console.log("\nwhat the three sources add up to");
    {
      // The real formula out of cardsPayload, with the Hyatt card's numbers.
      const reach = (spend, stays, held) =>
        held + Math.floor(spend / 5000) * 2 + stays;
      t("five nights before a dollar is spent", reach(0, 0, 5), 5);
      // $4,999 buys nothing: the step is credited only once complete.
      t("a part-finished step buys nothing", reach(4999, 0, 5), 5);
      t("and completing it buys two", reach(5000, 0, 5), 7);
      // Alex's stated figure, which is what pins the 5-night base: $140,000
      // is the smallest multiple of $5,000 that reaches 60 with no stays.
      t("$140,000 alone reaches Globalist", reach(140000, 0, 5) >= 60, true);
      t("and $135,000 alone does not", reach(135000, 0, 5) >= 60, false);
    }

    console.log("\n" + pass + " passed, " + fail + " failed\n");
    process.exit(fail ? 1 : 0);
  });
}
