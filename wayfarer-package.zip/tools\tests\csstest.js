// Shared class names, and what happens when you style one of them.
//
// On 2026-08-23 the "Open in maps" chips were touching on desktop, so
// .sheet-list got a base rule: display:flex, flex-wrap:wrap, gap:8px. Trip
// Ideas immediately started scrolling SIDEWAYS.
//
// Not because it became a row. Trip Ideas carries three classes --
// "sheet-list pax-list bucket-list" -- and .bucket-list sets
// flex-direction:column while .pax-list sets max-height:46vh. What the new
// rule actually contributed was flex-wrap:wrap, which .bucket-list never
// resets. A wrapping COLUMN with a capped height does not scroll down; it
// spills into fresh columns to the right.
//
// The lesson is in the comment already sitting above .bucket-list: that class
// exists precisely because .sheet-list and .pax-list are shared. Styling a
// shared class reaches every user of it, including the ones whose layout you
// have never looked at.
const fs = require("fs");
const css = fs.readFileSync("public/styles.css", "utf8");
const app = fs.readFileSync("public/app.js", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

// Top-level rules only: a declaration inside @media is scoped by definition.
const topLevel = (() => {
  const out = [];
  let depth = 0, buf = "";
  for (const line of css.split("\n")) {
    if (depth === 0) buf = line;
    if (!/@media/.test(line) && depth === 0) out.push(line);
    depth += (line.match(/{/g) || []).length - (line.match(/}/g) || []).length;
    if (depth < 0) depth = 0;
  }
  return out.join("\n");
})();

console.log("\nhow many lists share the class");
const users = (app.match(/"sheet-list[^"]*"/g) || []);
t("more than one, which is the whole point", users.length > 1, true);
// If this ever drops to one, the class is no longer shared and the rule below
// could safely relax. Until then it cannot.
t("Trip Ideas is one of them",
  users.some((u) => /bucket-list/.test(u)), true);
t("so are the traveller and seat sheets",
  users.filter((u) => /pax-list/.test(u)).length >= 2, true);

console.log("\nthe shared class carries no layout of its own");
// The exact declaration that broke it. flex-wrap on a column with a height cap
// is the sideways-scroll bug.
t("no top-level .sheet-list rule sets flex-wrap",
  /^\.sheet-list\s*{[^}]*flex-wrap/m.test(topLevel), false);
t("nor display:flex",
  /^\.sheet-list\s*{[^}]*display:\s*flex/m.test(topLevel), false);

console.log("\nthe map picker asks for the row explicitly");
t("it has its own modifier class",
  /\.sheet-list\.sheet-row\s*{[^}]*display:\s*flex/.test(css), true);
t("and the markup uses it", app.indexOf('"sheet-list sheet-row"') > -1, true);
// One caller, deliberately. Anything else adopting it inherits a horizontal row.
t("only the map picker does",
  (app.match(/"sheet-list sheet-row"/g) || []).length, 1);

console.log("\nmobile still wins");
// .sheet-list.sheet-row is (0,2,0) and the mobile .sheet-list is (0,1,0), so
// without an equally specific override the desktop row survives on a phone and
// the two map choices stay side by side on a 375px screen.
const mobile = css.slice(css.indexOf("@media (max-width:700px)"));
t("the mobile block overrides the row at matching specificity",
  /\.sheet-list\.sheet-row\s*{[^}]*flex-direction:\s*column/.test(mobile), true);
t("and still stacks the plain sheet",
  /\.sheet-list\s*{[^}]*flex-direction:\s*column/.test(mobile), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
