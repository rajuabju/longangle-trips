#!/usr/bin/env node
// Regenerate functions/api/airports-data.js from OurAirports.
//
//   node tools/build-airports.js
//
// OurAirports is in the PUBLIC DOMAIN, so this ships with nothing to attribute
// and nothing to breach. The source CSV is ~13MB; what lands in the repo is
// ~145KB, because everything that cannot be flown to on a ticket is dropped.
//
// Airports change rarely enough that this is a hand-run tool, not a build step.
// Re-run it if a destination is missing a sensible airport.
const fs = require("fs");
const path = require("path");

const SRC = "https://davidmegginson.github.io/ourairports-data/airports.csv";
// Actual airline routes, used to corroborate OurAirports' scheduled_service
// flag -- see the filter below for why that flag alone is not enough.
const ROUTES = "https://raw.githubusercontent.com/jpatokal/openflights/master/data/routes.dat";

// Airports with no scheduled passenger service that every automatic signal
// gets wrong. Kept as an explicit list rather than a cleverer rule, because
// every cleverer rule tried so far also discards real regional airports.
//
// Why a hand list is unavoidable. Three signals exist and each is wrong on its
// own:
//
//   type                 Le Bourget is typed large_airport. So is Heathrow.
//   scheduled_service    OurAirports flags LBG, TEB, HHR, BED and OPF "yes".
//                        All five are business-aviation fields.
//   route data           Correct about all of them -- but it is a 2014
//                        snapshot, so absence means EITHER "no service" OR
//                        "did not exist yet". It cannot tell LBG from Berlin
//                        Brandenburg, and BER is the reason large airports
//                        skip the route check at all.
//
// That exemption is the hole this list plugs. It covers 93 airports worldwide
// (printed at the end of every build -- read them), overwhelmingly genuine
// post-2014 international builds: Daxing, Tianfu, Navi Mumbai, Techo,
// Felipe Angeles, Pokhara, Kualanamu. The handful below are the exceptions:
// airports that existed in 2014, carried no scheduled service then, and carry
// none now.
const NOT_COMMERCIAL = new Set([
  "TEB",   // Teterboro -- charter and business only
  "LBG",   // Paris-Le Bourget -- business aviation; ORY and CDG are the answer
  "SBD",   // San Bernardino -- Amazon Air freight and GA, no scheduled pax
  "DIA",   // Doha International -- superseded by Hamad (DOH); state/military
  "BXY",   // Baikonur Krayniy -- cosmodrome charters
]);
const OUT = path.join(__dirname, "..", "functions", "api", "airports-data.js");

// Minimal RFC4180: fields may be quoted and contain commas. Airport names are
// full of them ("Cologne Bonn Airport, Konrad Adenauer").
function parseLine(line) {
  const out = []; let cur = "", q = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (q) {
      if (c === '"') { if (line[i + 1] === '"') { cur += '"'; i++; } else q = false; }
      else cur += c;
    } else if (c === '"') q = true;
    else if (c === ",") { out.push(cur); cur = ""; }
    else cur += c;
  }
  out.push(cur);
  return out;
}

(async function main() {
  process.stdout.write("fetching " + SRC + " … ");
  const res = await fetch(SRC);
  if (!res.ok) { console.error("failed: HTTP " + res.status); process.exit(1); }
  const raw = await res.text();
  console.log((raw.length / 1048576).toFixed(1) + "MB");

  const lines = raw.split(/\r?\n/).filter(Boolean);
  const head = parseLine(lines[0]);
  const ix = (n) => {
    const i = head.indexOf(n);
    if (i < 0) { console.error("column missing: " + n + " — the source schema changed"); process.exit(1); }
    return i;
  };
  const I = { type: ix("type"), name: ix("name"), lat: ix("latitude_deg"), lon: ix("longitude_deg"),
    country: ix("iso_country"), muni: ix("municipality"), sched: ix("scheduled_service"), iata: ix("iata_code") };

  // ---- which airports actually carry scheduled passenger flights ----
  //
  // OurAirports' own scheduled_service flag is NOT sufficient. It marks
  // Hawthorne (HHR), Bedford (BED) and Opa-locka (OPF) as scheduled, and all
  // three are business-aviation fields with no airline service -- HHR turned up
  // as a suggested airport for a Palos Verdes trip, which is how this was found.
  //
  // So a MEDIUM airport must also appear in real airline route data. Large
  // airports are exempt from that check: they are hubs by definition, and the
  // route data is a 2014 snapshot that predates Berlin Brandenburg, which would
  // otherwise be dropped as unserved.
  process.stdout.write("fetching route data … ");
  const rres = await fetch(ROUTES);
  if (!rres.ok) { console.error("failed: HTTP " + rres.status); process.exit(1); }
  const served = new Set();
  for (const line of (await rres.text()).split(/\r?\n/)) {
    if (!line) continue;
    const f = line.split(",");
    if (f[2] && f[2] !== "\\N") served.add(f[2].trim());
    if (f[4] && f[4] !== "\\N") served.add(f[4].trim());
  }
  console.log(served.size + " airports appear in routes");

  const rows = [], exempt = [], blocked = [];
  for (let i = 1; i < lines.length; i++) {
    const f = parseLine(lines[i]);
    const iata = (f[I.iata] || "").trim().toUpperCase();
    if (!/^(large|medium)_airport$/.test(f[I.type])) continue;
    // No scheduled service means no ticket, which means no routing value.
    if (f[I.sched] !== "yes") continue;
    if (!/^[A-Z]{3}$/.test(iata)) continue;
    const lat = Number(f[I.lat]), lon = Number(f[I.lon]);
    if (!isFinite(lat) || !isFinite(lon)) continue;
    const big = f[I.type] === "large_airport" ? 1 : 0;
    if (NOT_COMMERCIAL.has(iata)) { blocked.push(iata); continue; }
    // A large airport skips the route check -- see NOT_COMMERCIAL for why that
    // is necessary and what it costs. Record every one that takes the exemption
    // so the cost stays visible: anything on this list is trusted purely on
    // OurAirports' say-so, and OurAirports is demonstrably wrong sometimes.
    if (big && !served.has(iata)) exempt.push(iata + " " + (f[I.muni] || f[I.name] || "").trim());
    if (!big && !served.has(iata)) continue;   // medium needs corroboration
    rows.push({ iata, lat: +lat.toFixed(4), lon: +lon.toFixed(4),
      city: (f[I.muni] || f[I.name] || "").trim(), cc: f[I.country], big });
  }
  // A sudden collapse means the upstream schema moved and the filter is now
  // matching nothing. Better to refuse than to overwrite good data with 12 rows.
  if (rows.length < 2000) { console.error("only " + rows.length + " airports — refusing to write"); process.exit(1); }
  rows.sort((a, b) => (b.big - a.big) || a.iata.localeCompare(b.iata));

  const existing = fs.existsSync(OUT) ? fs.readFileSync(OUT, "utf8") : "";
  const header = existing.slice(0, existing.indexOf("export const AIRPORTS = [")) ||
    "// Generated by tools/build-airports.js from OurAirports (public domain).\n";
  const body = rows.map((a) => JSON.stringify([a.iata, a.lat, a.lon, a.city, a.big, a.cc])).join(",\n");
  fs.writeFileSync(OUT, header + "export const AIRPORTS = [\n" + body + "\n];\n");
  console.log("wrote " + rows.length + " airports (" +
    rows.filter((r) => r.big).length + " large) to " + path.relative(process.cwd(), OUT));

  console.log("\nblocked by hand: " + (blocked.join(" ") || "(none)"));
  // Read this list. Every entry is a large airport that no route data
  // corroborates, kept solely because OurAirports typed it large -- exactly the
  // hole Le Bourget came through. Most are real post-2014 builds. Any that is
  // not belongs in NOT_COMMERCIAL above.
  console.log("\ntrusted on type alone, unverified by any route (" + exempt.length + "):");
  for (const line of exempt.sort()) console.log("  " + line);
})();
