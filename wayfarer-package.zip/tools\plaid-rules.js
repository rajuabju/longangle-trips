// The one classifier. Everything that computes qualifying spend requires this
// file, because three divergent copies of a rule that was wrong twice is
// exactly how the wrong one comes back.
//
// The authority is functions/api/_core.js -- that is what the app actually
// runs -- and tools/tests/cardstest.js pins THIS file against it, so the two
// cannot drift apart unnoticed. This module exists so the command-line tools
// agree with the app instead of each carrying their own drifting copy -- which
// is not hypothetical: plaid-spend.js carried a stale pre-Chase copy for a
// day, and plaid-thresholds.js and plaid-smoke.js were deleted on 2026-08-28
// rather than repointed, one superseded by the app's own panel and the other a
// sandbox pipeline unreachable under the production configuration.
//
// Validated against Alex's real Amex on 2026-08-25, reconciling to 96 cents
// against American Express's own figure -- the 96 cents being a rounded input.
// The two wrong answers it replaced both looked entirely plausible:
//
//   1. Keying off Plaid's personal_finance_category. Plaid files "PAYMENT
//      RECEIVED - THANK YOU" as INCOME_SALARY, so $427,904 of Amex payments
//      were read as refunds and SUBTRACTED, understating the Business Platinum
//      by about $210,000. The tell was a 65% refund rate, which is not a thing
//      that happens on a charge card.
//
//   2. Treating every remaining negative as a refund. That subtracted statement
//      credits -- the Aspire's Hilton resort credits, $550 -- which are not
//      reversals: the purchase they offset still counts toward the threshold.
//
// A WARNING FOR EVERY BANK AFTER AMEX. These patterns are Amex's wording.
// Chase and Citi describe payments and statement credits differently, and a
// description this classifier does not recognise falls through to "refund" --
// which SUBTRACTS. A payment misread as a refund is the $210,000 mistake
// happening again under a different bank's name.
//
// CHASE, added 2026-08-27, and it broke three of these rules on contact --
// which is why the reconciliation below is not optional:
//
//   "AUTOMATIC PAYMENT - THANK"   truncated by Chase, so the THANK YOU pattern
//                                 missed it, "AUTOPAY" did not match "AUTOMATIC
//                                 PAYMENT", and $109,000 of card payments fell
//                                 through to the category test -- which files
//                                 them as INCOME_SALARY, INCOME_CONTRACTOR and
//                                 TRANSFER_IN. They landed in "credit". That
//                                 bucket is excluded from spend too, so the
//                                 total survived by luck, not by design.
//   "CREDIT BALANCE REFUND"       positive, so the sign shortcut called it a
//                                 charge. It is the bank returning an
//                                 overpayment: $501.52 of phantom spend.
//   "Offer:Hyatt Unbound Colle"   a Chase Offers statement credit, which read
//                                 as a merchant refund and subtracted $60.
//
// So: after linking a new institution, run the reconciliation before anything
// depends on the total. `node tools/plaid-spend.js <bank>` prints what it
// treated as a payment and as a credit, and `describeNegatives` below exists
// precisely to show what did NOT match. A refund rate above a few percent on a
// card settled monthly means a payment slipped through.

// Money settling the balance. Amex is consistent in the description, which is
// the only signal that can be trusted here.
const PAYMENT = /\bPAYMENT\b.*THANK|AUTOPAY|AUTOMATIC\s+PAYMENT|REMITTANCE\s+RECEIVED|\bPAYMENT\s+RECEIVED\b/i;

// Statement credits and points redemptions. Negative, but NOT a reversal of
// spend -- the original charge still counts toward the threshold.
// Amex prints its benefit credits as ordinary negatives, and four of them were
// subtracting as though a merchant had refunded something (found 2026-08-27):
//
//   AMEX Airline Fee Reimbursement   $100 flat, BANK_FEES
//   AMEX Flight Credit               BANK_FEES
//   TSA Global Entry Fee Credit      $120 flat
//   Dell Credit                      $200 flat, the Business Platinum benefit
//
// What was NOT reclassified, on the same evidence: "AMEX Fine Hotels and
// AmexTravel.com" at $494.33, $253.07 and $236.97 is not the flat $100 FHR
// property credit -- those are refunds of hotel bookings, and they belong in
// the refund bucket. Global Blue is a VAT reimbursement on goods bought, which
// genuinely reduces what was spent. Nordstrom, Zara, Banana Republic, Home
// Depot and the rest are plain returns.
//
// The list grows by reading the feed, never by guessing at benefit names.
const CREDIT = /PAY\s*WITH\s*POINTS|\bPwP\b|STATEMENT\s+CREDIT|REDEEM\s+CRED|FHR\b|HOTEL\s+CREDIT|AIRLINE\s+CREDIT|ADJ\s+REDIST|MEMBERSHIP\s+REWARD|^\s*Offer:|AMEX\s.*\bCREDIT\b|\bFEE\s+(?:CREDIT|REIMBURSEMENT)\b|\bDELL\s+CREDIT\b/i;

// Positive, and NOT spend: the bank returning an overpayment. Chase files it
// under LOAN_PAYMENTS_CREDIT_CARD_PAYMENT, but the amount is positive, so the
// "anything positive is a charge" shortcut counted $501.52 of it as spend.
const BALANCE_REFUND = /CREDIT\s+BALANCE\s+REFUND/i;

// charge | payment | credit | refund. Order matters: description first, and
// the category only as a fallback for what the wording did not catch.
function classify(t) {
  const name = (t.name || "") + " " + (t.merchant_name || "");
  // Before the sign test, because this one is positive and still not spend.
  if (BALANCE_REFUND.test(name)) return "payment";
  if (t.amount > 0) return "charge";
  if (PAYMENT.test(name)) return "payment";
  if (CREDIT.test(name)) return "credit";
  const pfc = t.personal_finance_category || {};
  if (/CREDIT_CARD_PAYMENT/.test(pfc.detailed || "")) return "payment";
  // A statement credit does not arrive from a merchant, so Plaid files it under
  // INCOME_* or TRANSFER_IN_*; a genuine refund lands in a spending category.
  // This rule was the whole of a $549.04 gap against Amex.
  if (/^(INCOME|TRANSFER_IN)/.test(pfc.primary || "")) return "credit";
  return "refund";
}

// Qualifying spend: charges less genuine merchant refunds. Payments excluded
// entirely; statement credits recorded but NOT subtracted.
function qualifying(txns) {
  let charges = 0, refunds = 0, payments = 0, credits = 0;
  for (const t of txns) {
    const k = classify(t);
    if (k === "charge") charges += t.amount;
    else if (k === "refund") refunds += t.amount;
    else if (k === "payment") payments += t.amount;
    else credits += t.amount;
  }
  return { charges, refunds, payments, credits, spend: charges + refunds };
}

// What a new bank's wording did NOT match, largest first. This is the report to
// read before trusting a Chase or Citi total: anything here that is obviously a
// card payment means the patterns above need that bank's phrasing adding.
function describeNegatives(txns) {
  const byName = {};
  for (const t of txns) {
    if (t.amount >= 0) continue;
    if (classify(t) !== "refund") continue;
    const key = (t.name || "(no name)").slice(0, 46);
    byName[key] = byName[key] || { n: 0, sum: 0, cat: ((t.personal_finance_category || {}).detailed) || "" };
    byName[key].n++; byName[key].sum += t.amount;
  }
  return Object.keys(byName)
    .sort((a, b) => byName[a].sum - byName[b].sum)
    .map((k) => ({ name: k, count: byName[k].n, total: byName[k].sum, category: byName[k].cat }));
}

module.exports = { PAYMENT, CREDIT, BALANCE_REFUND, classify, qualifying, describeNegatives };
