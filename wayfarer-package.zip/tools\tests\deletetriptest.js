// Deleting a trip, with the confirmation built into the control.
//
// A confirm() dialog is one reflex away from being no confirmation at all:
// with daily use you learn to dismiss it without reading it, which is the
// finding already recorded against the item-delete path. A control that
// changes under the cursor and has to be aimed at a second time cannot be
// clicked through the same way -- the second click lands somewhere the first
// one was not, and that difference IS the confirmation.
//
// Safe to expose at two clicks because the server soft-deletes: the row keeps
// its data and gains a deleted_at, and so does every transport, hosting,
// activity, expense and document on the trip. Nothing is destroyed.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");
const css = fs.readFileSync("public/styles.css", "utf8");
const core = fs.readFileSync("functions/api/_core.js", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

console.log("\nthe control");
t("a delete chip exists", /el\("button", "type-toggle trip-del is-edit", "🗑 Delete"\)/.test(app), true);
// Next to the business/personal toggle, which is where the trip's other
// state-changing control already lives.
// The header is two rows now: the name and dates identify the trip, and these
// four chips -- countdown, kind, edit, delete -- are what you can do to it.
// They used to share one wrapping row with the h2, which broke in a different
// place on every trip name.
t("it sits beside the type toggle",
  app.indexOf("chipRow.appendChild(typeBtn);") < app.indexOf("chipRow.appendChild(delBtn);"), true);
t("and both are in the chip row, not the title row", /chipRow\.appendChild\(delBtn\);/.test(app), true);
t("edit sits between them",
  app.indexOf("chipRow.appendChild(typeBtn);") < app.indexOf("chipRow.appendChild(editBtn);") &&
  app.indexOf("chipRow.appendChild(editBtn);") < app.indexOf("chipRow.appendChild(delBtn);"), true);
// The countdown is not in this row any more -- it is a badge on the cover,
// as it is on a dashboard card. Three controls here, not four.
t("and the countdown is not among them", /chipRow\.appendChild\(el\("span", "cd-pill"/.test(app), false);
// is-edit is hidden by body.role-view, so a View account never sees it.
t("View accounts do not get it", /"type-toggle trip-del is-edit"/.test(app), true);
t("which the stylesheet enforces", /body\.role-view #newtrip-btn,\s*body\.role-view \.is-edit \{ display:none !important; \}/.test(css), true);

console.log("\nthe first click arms, it does not delete");
// Shortened from "Delete - click again": in a four-chip row that must not
// wrap at 375px, it was nearly twice the width of any other chip.
t("it flips to a second-click label", /delBtn\.textContent = "🗑 Again\?";/.test(app), true);
t("and returns without deleting", /armTimer = setTimeout\(disarm, 5000\);\s*return;/.test(app), true);
t("only an armed chip sends the request", /if \(!armed\) \{/.test(app), true);

console.log("\nand it gives the click back");
// A chip left armed must not be fireable by a stray click minutes later.
t("it disarms itself after a few seconds", /setTimeout\(disarm, 5000\)/.test(app), true);
t("aiming elsewhere disarms it too",
  /delBtn\.addEventListener\("blur", function \(\) \{ if \(armed\) disarm\(\); \}\);/.test(app), true);
t("disarming clears the pending timer", /clearTimeout\(armTimer\);/.test(app), true);

console.log("\nwhat the second click does");
t("it deletes the trip", /await api\("\/v1\/trip\/" \+ t\.id, \{ method: "DELETE" \}\);/.test(app), true);
// Drop it locally first, or the dashboard shows the deleted trip until the
// reload lands.
t("the dashboard drops it immediately",
  /state\.own = \(state\.own \|\| \[\]\)\.filter\(function \(x\) \{ return x\.id !== t\.id; \}\);/.test(app), true);
t("the panel closes", /closeDetail\(\);/.test(app), true);
t("and it says what went", /undoToast\("Deleted “" \+ \(t\.name \|\| "trip"\) \+ "”",/.test(app), true);
// U8: the delete that takes the most with it is the one that most needs
// taking back -- a trip carries its whole itinerary out.
t("and can be taken back", /await api\("\/v1\/trip\/" \+ t\.id \+ "\/restore", \{ method: "POST" \}\);/.test(app), true);
t("with the dashboard rebuilt from the server", /await loadAll\(\);/.test(app), true);
t("and confirms the restore", /toast\("Restored /.test(app), true);
t("a failure re-enables the chip rather than stranding it",
  /delBtn\.disabled = false;\s*disarm\(\);/.test(app), true);

console.log("\nthe server end");
// PATCH and GET lived on /v1/trip/{id} while DELETE existed only on the plural
// route, so the client's own address returned "Unknown endpoint" on delete.
t("DELETE works at the same address as GET and PATCH",
  /if \(method === "DELETE"\) return softDelete\(db, "trips", tripId\);/.test(core), true);
t("and it soft-deletes", /UPDATE \$\{table\} SET deleted_at=\?, updated_at=\? WHERE id=\?/.test(core), true);
t("cascading to every child collection",
  /for \(const t of \["transportations", "hostings", "activities", "expenses", "documents"\]\)/.test(core), true);

console.log("\nit looks like what it does");
// Quiet until armed: a permanently red button beside the trip name reads as an
// alarm rather than a control.
t("unarmed is an outline", /\.trip-del \{ border-color:color-mix\(in srgb,var\(--danger\)/.test(css), true);
t("armed is filled", /\.trip-del\.is-armed \{ background:var\(--danger\)/.test(css), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
