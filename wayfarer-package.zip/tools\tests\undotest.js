// U8 -- delete, then change your mind.
//
// The rows were ALWAYS recoverable in the database: delete sets deleted_at and
// keeps every column. What did not exist was any way to exercise that from the
// app -- while the confirm dialog said, in as many words, "Deletes are
// recoverable." A promise the interface cannot keep is worse than no promise,
// so this adds the missing half and then removes the dialog, because a confirm
// asks you to predict a regret that undo simply lets you have.
//
// The subtle part is the trip cascade. softDelete stamps every child with the
// TRIP's deleted_at; restore matches that exact timestamp, so it returns what
// that one delete took and nothing else. Restoring by trip_id would resurrect
// every item ever removed from the trip.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");
const core = fs.readFileSync("functions/api/_core.js", "utf8");
const css = fs.readFileSync("public/styles.css", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

const restore = core.slice(core.indexOf("async function restoreDeleted"),
                           core.indexOf("async function softDelete"));

console.log("\nthe server can put a row back");
t("there is a restore", /async function restoreDeleted\(db, table, id\)/.test(core), true);
t("it clears the tombstone", /SET deleted_at=NULL, updated_at=\? WHERE id=\?/.test(restore), true);
t("and stamps the row as touched", /const ts = nowIso\(\);/.test(restore), true);
// Restoring something that was never deleted would silently "succeed" and tell
// the caller nothing -- worse, it would bump updated_at on a live row.
t("restoring a live row is refused", /if \(!was\) return err\("That is not deleted\.", 409\);/.test(restore), true);
t("a missing row is a 404", /if \(!row\) return err\("Not found\.", 404\);/.test(restore), true);
t("a bad id is rejected before any SQL", restore.indexOf("Bad id.") < restore.indexOf("SELECT deleted_at"), true);
t("the restored row comes back to the caller", /return back \? json\(hydrate\(back, table\)\) : err/.test(restore), true);

console.log("\na trip brings back exactly what went with it");
t("the same five child tables softDelete cascades to",
  /for \(const t of \["transportations", "hostings", "activities", "expenses", "documents"\]\)/.test(restore), true);
// The whole point. deleted_at=? not trip_id alone.
t("matched on the delete's own timestamp", /WHERE trip_id=\? AND deleted_at=\?/.test(restore), true);
t("bound to the trip's former deleted_at", /\.bind\(ts, id, was\)/.test(restore), true);
t("items deleted earlier stay deleted", /WHERE trip_id=\? AND deleted_at IS NULL/.test(restore), false);
// The timestamp match only discriminates if two deletes cannot share a stamp.
// toISOString carries milliseconds (2026-08-24T04:13:13.159Z), so an unrelated
// item delete would have to land inside the same millisecond as the trip's --
// and the cost even then is one extra row restored, not a row lost.
t("and the stamp has millisecond resolution",
  /const nowIso = \(\) => new Date\(\)\.toISOString\(\);/.test(core), true);

// Verified live against the dev DB on a throwaway trip (2026-08-24):
//   delete one activity        -> 204, list drops to 1
//   restore it                 -> 200, list back to 2
//   restore it again           -> 409 "That is not deleted."
//   delete a SECOND activity, then the trip, then restore the trip
//                              -> list is 1, holding only the activity that was
//                                 still live when the trip went. The one deleted
//                                 a second earlier stayed deleted.

console.log("\nboth addresses route to it");
t("a trip: /v1/trip/{id}/restore",
  /if \(what === "restore" && method === "POST"\) return restoreDeleted\(db, "trips", tripId\);/.test(core), true);
t("an item: /v1/trip/{t}/{kind}/{id}/restore",
  /if \(segs\[4\] === "restore" && method === "POST"\) return restoreDeleted\(db, table, itemId\);/.test(core), true);
// segs[4] is checked before the PATCH/DELETE fallthrough, or the verb decides
// first and a POST to .../restore falls off the end as an unknown endpoint.
t("checked before the other verbs on that path",
  core.indexOf('segs[4] === "restore"') < core.indexOf("if (method === \"PATCH\" || method === \"PUT\") return patchRow(db, table, itemId"), true);

console.log("\nthe toast carries the action");
t("there is an undo toast", /function undoToast\(msg, undo\)/.test(app), true);
t("it lasts longer than either default", /var TOAST_MS = 2600, TOAST_ERROR_MS = 6000, TOAST_UNDO_MS = 9000;/.test(app), true);
t("because toast\(\) now takes a duration", /opts\.ms \|\| \(bad \? TOAST_ERROR_MS : TOAST_MS\)/.test(app), true);
// The layer is pointer-events:none so a toast never eats a tap meant for the
// page. A toast with a button in it has to opt back in, or the button is paint.
t("the layer still ignores pointer events", /\.toast-layer \{[\s\S]*?pointer-events:none;/.test(css), true);
t("but a toast with a control does not", /\.toast\.has-action \{ pointer-events:auto;/.test(css), true);
t("and the class is set when there is one", /t\.classList\.add\("has-action"\);/.test(app), true);
t("the button is not a submit", /b\.type = "button";/.test(app), true);
// Measured in the browser at 68x38 first, under the 44 floor U7 established --
// and this control has a nine-second life, so a miss costs you the undo. Made
// 44 for real rather than via a pseudo-element: nothing sits beside it to
// overlap. Re-measured 76x44, hit-testable at both the centre and the corner.
t("the button clears 44", /min-height:44px; padding:0 16px;/.test(css), true);
t("it says so while it works", /b\.textContent = "Undoing/.test(app), true);
t("and cannot be pressed twice", /b\.disabled = true;/.test(app), true);
// A failed undo has to say so. Silently removing the toast would read as
// success and leave the row deleted.
t("a failed undo is reported", /toast\("Couldn't undo: " \+ \(e && e\.message \? e\.message : e\)\);/.test(app), true);

console.log("\nthe confirms it replaces are gone");
t("no dialog on item delete", /Delete this " \+ kind \+ "\?/.test(app), false);
// Comments stripped: undoToast's own comment quotes the sentence it retired,
// and a negative assertion that its own explanation can satisfy is worthless.
const code = app.replace(/^\s*\/\/.*$/gm, "");
t("and the claim it could not keep went with it", /Deletes are recoverable/.test(code), false);
t("no confirm survives on either delete path", /window\.confirm\("Delete this/.test(code), false);
const del = app.slice(app.indexOf("async function deleteItem"),
                      app.indexOf("// ---- expense report ----"));
if (del.length < 200 || del.length > 3000) { console.log("  FAIL  deleteItem slice is " + del.length + " chars"); process.exit(1); }
t("the item is deleted first", del.indexOf('method: "DELETE"') < del.indexOf("undoToast("), true);
// Redraw BEFORE the toast: the row has to be visibly gone for "Deleted" to
// mean anything, and the toast has to outlive the redraw to be pressable.
t("the itinerary is redrawn before the offer", del.indexOf("redrawAfterWrite") < del.indexOf("undoToast("), true);
t("undo posts to restore", /await api\(base \+ "\/restore", \{ method: "POST" \}\);/.test(del), true);
t("and redraws again after", (del.match(/redrawAfterWrite/g) || []).length, 2);
t("the path is built once and reused", /var base = "\/v1\/trip\/" \+ trip\.id \+ "\/" \+ kind \+ "\/" \+ o\.id;/.test(del), true);
// Naming what went beats "Deleted" -- on a six-hotel trip the generic message
// cannot tell you which row you just lost.
// U14 moved the naming into recordLabel so the toast, the dialog title and
// the itinerary row all call a record the same thing.
t("the toast names the record", /undoToast\("Deleted " \+ \(recordLabel\(kind, o\) \|\| kind\)/.test(del), true);

console.log("\nso does the trip chip");
t("the trip delete offers it too", /undoToast\("Deleted \u201c" \+ \(t\.name \|\| "trip"\) \+ "\u201d",/.test(app), true);
t("posting to the trip's own restore", /await api\("\/v1\/trip\/" \+ t\.id \+ "\/restore", \{ method: "POST" \}\);/.test(app), true);
// The panel is already closed and the dashboard re-rendered from local state,
// so the trip has to come back from the server, not from a stale array.
t("and reloading rather than trusting local state", /await loadAll\(\);/.test(app), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
