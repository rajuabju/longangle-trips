// Every future item has to say where it is.
//
// The rule, set 2026-08-19: an item on a trip that has not happened yet carries
// an address, or coordinates, or the "No location" box ticked. Anything with
// none of the three is flagged in Trip check.
//
// The point is not tidiness. The itinerary draws the drive from one place to
// the next, and an item with no location breaks the chain either side of it
// SILENTLY — a missing leg looks exactly like a short walk. That is the failure
// this exists to make visible.
//
// Measured before shipping, across every upcoming trip: 41 activities and
// stays, of which 2 lack both, and both are notes. All 13 transportations carry
// both ends. So it starts at zero and catches what gets added next.
//
// Fixtures are invented.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");

function grab(name) {
  const i = src.indexOf("  function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
eval(["hasText", "hasPlace"].map(grab).join("\n") +
  ";Object.assign(globalThis,{hasText,hasPlace});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

console.log("\nwhat counts as saying where you are");
t("an address is enough", hasPlace({ address: "245 S Wetherly Dr" }, "activity"), true);
t("coordinates are enough", hasPlace({ latitude: 34.07, longitude: -118.39 }, "activity"), true);
t("both is obviously enough",
  hasPlace({ address: "Pinecrest", latitude: 32.47, longitude: -116.38 }, "hosting"), true);
t("neither is not", hasPlace({ name: "Dinner somewhere" }, "activity"), false);
// A blank string is what an emptied form field sends, and it is not an address.
t("an empty address is not an address", hasPlace({ address: "" }, "activity"), false);
t("nor is whitespace", hasPlace({ address: "   " }, "activity"), false);
// Latitude 0 is the Gulf of Guinea, not "missing". A truthiness check here
// would call a real coordinate blank.
t("latitude zero is a real coordinate", hasPlace({ latitude: 0, longitude: 0 }, "activity"), true);

console.log("\nthe exemption");
t("ticking the box settles it", hasPlace({ no_location: true }, "activity"), true);
t("even with nothing else at all", hasPlace({ no_location: true, address: "" }, "hosting"), true);
// Unticked has to behave exactly like never-set, or clearing the box would
// leave the item permanently exempt.
t("unticking it puts the item back in scope", hasPlace({ no_location: false }, "activity"), false);
// A note has no address or coordinate fields on its form at all, so flagging
// one would be a warning with no way to act on it but ticking a box on every
// note ever written.
t("a note is exempt by nature", hasPlace({ activity_type: "note", name: "Book the ferry" }, "activity"), true);
// ...but only when it IS a note. The exemption is by type, not by lacking data.
t("an ordinary activity is not", hasPlace({ activity_type: "general", name: "Ferry" }, "activity"), false);
// A lodging called "note" is a hotel with an odd name, not a note.
t("the note exemption is scoped to activities",
  hasPlace({ activity_type: "note", name: "The Note Hotel" }, "hosting"), false);
t("nothing to judge is not a failure", hasPlace(null, "activity"), true);

console.log("\ntransport needs both ends");
const leg = (from, to) => hasPlace(
  { departure_address: from, arrival_address: to }, "transport");
t("both addresses", leg("LAX", "LIR"), true);
// One end draws no leg at all, so one end is not enough. This is the case that
// makes transport different from everything else.
t("departure only", leg("LAX", ""), false);
t("arrival only", leg("", "LIR"), false);
t("neither", leg("", ""), false);
t("coordinates count at either end",
  hasPlace({ departure_latitude: 33.94, arrival_address: "LIR" }, "transport"), true);
t("mixed: address out, coordinates back",
  hasPlace({ departure_address: "LAX", arrival_latitude: 10.59 }, "transport"), true);
t("a hire car with no addresses is flagged",
  hasPlace({ company: "SIXT", departure_address: null, arrival_address: null }, "transport"), false);
t("and the box exempts a whole leg",
  hasPlace({ no_location: true, departure_address: "" }, "transport"), true);

console.log("\nhasText on its own");
t("a real string", hasText("LAX"), true);
t("empty", hasText(""), false);
t("whitespace", hasText("  \t "), false);
t("null", hasText(null), false);
t("undefined", hasText(undefined), false);
// A number is a legitimate address in exactly nobody's data, but String() of it
// is non-empty and it must not throw.
t("a number does not throw", hasText(0), true);

console.log("\nwhat Trip check does with it");
// A standing requirement with an action attached, not a note.
t("it is a warning", /add\("warn", placeless\.length \+ " item"/.test(src), true);
// Soft findings are dropped once a trip is over — which is exactly the
// "upcoming trips only" scope, handled by machinery that already existed.
const block = src.slice(src.indexOf("var placeless = [].concat("),
  src.indexOf("// A separate, softer point"));
// The fourth argument used to be a literal `null`; the finding now carries a
// "Find N locations" fix, so soft-ness is asserted on the trailing flag.
t("and soft, so past trips are left alone", /^\s*true\);/m.test(block), true);
t("and it offers the lookup", /openFindTripLocations\(t, data/.test(block), true);
t("transport is checked too, which the old rule never did",
  /trans\.filter\(function \(x\) \{ return !hasPlace\(x, "transport"\); \}\)/.test(src), true);
t("it offers the exemption in the wording", /tick “No location” in the edit form/.test(src), true);

console.log("\nand the quieter point it does not repeat");
// An address satisfies the rule but does not draw a pin: nothing geocodes at
// render. That is worth saying — but only about items that HAVE an address, or
// it restates the warning above in a softer voice on the same items.
const soft = src.slice(src.indexOf("var addressOnly = [].concat("),
  src.indexOf("// ---- days whose journey cannot be worked out ----"));
t("it only looks at items that have an address", /hasText\(x\.address\)/.test(soft), true);
t("and skips the ones you exempted", /!x\.no_location/.test(soft), true);
t("still just information", /add\("info", addressOnly\.length/.test(soft), true);

console.log("\nthe box itself");
t("offered on lodging, activities and transport",
  (src.match(/name: "no_location", label: "No location", type: "checkbox"/g) || []).length, 3);
t("and saved by all three", (src.match(/no_location: !!v\.no_location/g) || []).length, 3);
// .value on a checkbox is the string "on" whether ticked or not, so reading it
// the ordinary way makes every box look ticked.
t("the tick is read from .checked, not .value",
  /i\.type === "checkbox" \? i\.checked : i\.value/.test(src), true);
t("a note form is not offered the box",
  src.slice(src.indexOf("var isNote = kind ==="), src.indexOf('formDialog((isNew ? "Add " : "Edit ") + (isNote'))
    .indexOf("no_location") > src.slice(src.indexOf("var isNote = kind ==="),
      src.indexOf('formDialog((isNew ? "Add " : "Edit ") + (isNote')).indexOf("if (!isNote)"), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
