// Minimal QR Code encoder — byte mode, error-correction level M, versions 1–15.
//
// Why this is here rather than a CDN or an image API: the codes it renders are
// event tickets and boarding passes. Sending those values to a third-party QR
// service would hand someone else's server a scannable copy of the ticket, and a
// code that only renders when a remote host is up is no use in a venue queue.
// Everything below runs offline, inside the service-worker-cached bundle.
//
// Level M (≈15% recovery) is what ticketing systems generally use, and versions
// up to 15 hold 415 data codewords — far more than any ticket barcode.
(function (root) {
  "use strict";

  // ---- GF(256) for Reed–Solomon, primitive polynomial 0x11D ----
  var EXP = new Uint8Array(512), LOG = new Uint8Array(256);
  (function () {
    var x = 1;
    for (var i = 0; i < 255; i++) {
      EXP[i] = x; LOG[x] = i;
      x <<= 1;
      if (x & 0x100) x ^= 0x11d;
    }
    for (var j = 255; j < 512; j++) EXP[j] = EXP[j - 255];
  })();
  function mul(a, b) { return (a === 0 || b === 0) ? 0 : EXP[LOG[a] + LOG[b]]; }

  // Generator polynomial for `degree` error-correction codewords.
  function rsPoly(degree) {
    var poly = [1];
    for (var d = 0; d < degree; d++) {
      var next = new Array(poly.length + 1).fill(0);
      // Coefficients run highest-degree first, so multiplying by x keeps the
      // index and multiplying by the root α^d moves it one along.
      for (var i = 0; i < poly.length; i++) {
        next[i] ^= poly[i];
        next[i + 1] ^= mul(poly[i], EXP[d]);
      }
      poly = next;
    }
    return poly;
  }
  function rsEncode(data, ecLen) {
    var gen = rsPoly(ecLen);
    var res = new Array(ecLen).fill(0);
    for (var i = 0; i < data.length; i++) {
      var factor = data[i] ^ res[0];
      res.shift(); res.push(0);
      for (var j = 0; j < ecLen; j++) res[j] ^= mul(gen[j + 1], factor);
    }
    return res;
  }

  // ---- Per-version block structure at EC level M ----
  // [ecCodewordsPerBlock, group1Blocks, group1DataCodewords, group2Blocks, group2DataCodewords]
  var BLOCKS_M = {
    1: [10, 1, 16, 0, 0], 2: [16, 1, 28, 0, 0], 3: [26, 1, 44, 0, 0],
    4: [18, 2, 32, 0, 0], 5: [24, 2, 43, 0, 0], 6: [16, 4, 27, 0, 0],
    7: [18, 4, 31, 0, 0], 8: [22, 2, 38, 2, 39], 9: [22, 3, 36, 2, 37],
    10: [26, 4, 43, 1, 44], 11: [30, 1, 50, 4, 51], 12: [22, 6, 36, 2, 37],
    13: [22, 8, 37, 1, 38], 14: [24, 4, 40, 5, 41], 15: [24, 5, 41, 5, 42]
  };
  var ALIGN = {
    1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34],
    7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50],
    11: [6, 30, 54], 12: [6, 32, 58], 13: [6, 34, 62],
    14: [6, 26, 46, 66], 15: [6, 26, 48, 70]
  };
  function dataCodewords(v) {
    var b = BLOCKS_M[v];
    return b[1] * b[2] + b[3] * b[4];
  }
  // Byte mode: 4 mode bits + an 8-bit length below v10, 16-bit from v10 up.
  function capacityBytes(v) {
    var headerBits = 4 + (v < 10 ? 8 : 16);
    return dataCodewords(v) - Math.ceil(headerBits / 8);
  }

  function toUtf8(str) {
    var out = [];
    var enc = unescape(encodeURIComponent(str));
    for (var i = 0; i < enc.length; i++) out.push(enc.charCodeAt(i));
    return out;
  }

  // ---- Bit stream ----
  function BitBuf() { this.bits = []; }
  BitBuf.prototype.put = function (val, len) {
    for (var i = len - 1; i >= 0; i--) this.bits.push((val >>> i) & 1);
  };

  function buildCodewords(bytes, version) {
    var buf = new BitBuf();
    buf.put(0b0100, 4);                                  // byte mode
    buf.put(bytes.length, version < 10 ? 8 : 16);
    for (var i = 0; i < bytes.length; i++) buf.put(bytes[i], 8);
    var total = dataCodewords(version) * 8;
    // Terminator, then pad to a byte boundary, then the alternating pad bytes.
    for (var t = 0; t < 4 && buf.bits.length < total; t++) buf.bits.push(0);
    while (buf.bits.length % 8 !== 0) buf.bits.push(0);
    var pads = [0xec, 0x11], p = 0;
    while (buf.bits.length < total) { buf.put(pads[p++ % 2], 8); }

    var all = [];
    for (var b = 0; b < buf.bits.length; b += 8) {
      var v = 0;
      for (var k = 0; k < 8; k++) v = (v << 1) | buf.bits[b + k];
      all.push(v);
    }

    // Split into blocks, error-correct each, then interleave.
    var spec = BLOCKS_M[version];
    var ecLen = spec[0];
    var blocks = [], ecBlocks = [], pos = 0, n;
    for (n = 0; n < spec[1]; n++) { blocks.push(all.slice(pos, pos + spec[2])); pos += spec[2]; }
    for (n = 0; n < spec[3]; n++) { blocks.push(all.slice(pos, pos + spec[4])); pos += spec[4]; }
    blocks.forEach(function (blk) { ecBlocks.push(rsEncode(blk, ecLen)); });

    var out = [], maxData = Math.max(spec[2], spec[4] || 0), i2, j2;
    for (i2 = 0; i2 < maxData; i2++) {
      for (j2 = 0; j2 < blocks.length; j2++) if (i2 < blocks[j2].length) out.push(blocks[j2][i2]);
    }
    for (i2 = 0; i2 < ecLen; i2++) {
      for (j2 = 0; j2 < ecBlocks.length; j2++) out.push(ecBlocks[j2][i2]);
    }
    return out;
  }

  // ---- Matrix ----
  function newMatrix(size) {
    var m = [];
    for (var i = 0; i < size; i++) m.push(new Array(size).fill(null));
    return m;
  }
  function placeFinder(m, r, c) {
    for (var i = -1; i <= 7; i++) {
      for (var j = -1; j <= 7; j++) {
        var rr = r + i, cc = c + j;
        if (rr < 0 || cc < 0 || rr >= m.length || cc >= m.length) continue;
        var on = (i >= 0 && i <= 6 && (j === 0 || j === 6)) ||
                 (j >= 0 && j <= 6 && (i === 0 || i === 6)) ||
                 (i >= 2 && i <= 4 && j >= 2 && j <= 4);
        m[rr][cc] = on ? 1 : 0;
      }
    }
  }
  function placeAlignment(m, version) {
    var centers = ALIGN[version];
    for (var a = 0; a < centers.length; a++) {
      for (var b = 0; b < centers.length; b++) {
        var r = centers[a], c = centers[b];
        if (m[r][c] !== null) continue;     // skips the three finder corners
        for (var i = -2; i <= 2; i++) {
          for (var j = -2; j <= 2; j++) {
            m[r + i][c + j] = (Math.max(Math.abs(i), Math.abs(j)) !== 1) ? 1 : 0;
          }
        }
      }
    }
  }
  function bch(value, poly, polyLen) {
    var v = value << (polyLen - 1);
    while (bitLen(v) >= polyLen) v ^= poly << (bitLen(v) - polyLen);
    return v;
  }
  function bitLen(v) { var n = 0; while (v) { n++; v >>>= 1; } return n; }

  function placeFormat(m, mask) {
    // EC level M is 0b00; 15-bit BCH(0x537), masked with 0x5412.
    var data = (0b00 << 3) | mask;
    var bits = ((data << 10) | bch(data, 0x537, 11)) ^ 0x5412;
    var size = m.length;
    for (var i = 0; i < 15; i++) {
      var bit = (bits >> i) & 1;
      // Copy 1, around the top-left finder.
      if (i < 6) m[i][8] = bit;
      else if (i < 8) m[i + 1][8] = bit;
      else if (i === 8) m[8][7] = bit;
      else m[8][14 - i] = bit;
      // Copy 2, split between the other two finders.
      if (i < 8) m[8][size - 1 - i] = bit;
      else m[size - 15 + i][8] = bit;
    }
    m[size - 8][8] = 1;                       // the always-dark module
  }
  function placeVersion(m, version) {
    if (version < 7) return;
    var bits = (version << 12) | bch(version, 0x1f25, 13);
    var size = m.length;
    for (var i = 0; i < 18; i++) {
      var bit = (bits >> i) & 1;
      var r = Math.floor(i / 3), c = i % 3;
      m[r][size - 11 + c] = bit;
      m[size - 11 + c][r] = bit;
    }
  }

  function maskFn(n, r, c) {
    switch (n) {
      case 0: return (r + c) % 2 === 0;
      case 1: return r % 2 === 0;
      case 2: return c % 3 === 0;
      case 3: return (r + c) % 3 === 0;
      case 4: return (Math.floor(r / 2) + Math.floor(c / 3)) % 2 === 0;
      case 5: return ((r * c) % 2) + ((r * c) % 3) === 0;
      case 6: return (((r * c) % 2) + ((r * c) % 3)) % 2 === 0;
      default: return (((r + c) % 2) + ((r * c) % 3)) % 2 === 0;
    }
  }

  function penalty(m) {
    var size = m.length, score = 0, i, j, run, last, dark = 0;
    // Rule 1 — runs of five or more in a row or column.
    for (i = 0; i < size; i++) {
      run = 1; last = m[i][0];
      for (j = 1; j < size; j++) {
        if (m[i][j] === last) { run++; } else { if (run >= 5) score += 3 + (run - 5); run = 1; last = m[i][j]; }
      }
      if (run >= 5) score += 3 + (run - 5);
      run = 1; last = m[0][i];
      for (j = 1; j < size; j++) {
        if (m[j][i] === last) { run++; } else { if (run >= 5) score += 3 + (run - 5); run = 1; last = m[j][i]; }
      }
      if (run >= 5) score += 3 + (run - 5);
    }
    // Rule 2 — 2×2 blocks of one colour.
    for (i = 0; i < size - 1; i++) {
      for (j = 0; j < size - 1; j++) {
        var v = m[i][j];
        if (v === m[i][j + 1] && v === m[i + 1][j] && v === m[i + 1][j + 1]) score += 3;
      }
    }
    // Rule 3 — the 1:1:3:1:1 finder-lookalike pattern, with four light modules
    // on either side.
    var p1 = [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0];
    var p2 = [0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1];
    function match(get, at) {
      for (var k = 0; k < 11; k++) if (get(at + k) !== p1[k]) return false;
      return true;
    }
    function match2(get, at) {
      for (var k = 0; k < 11; k++) if (get(at + k) !== p2[k]) return false;
      return true;
    }
    for (i = 0; i < size; i++) {
      for (j = 0; j <= size - 11; j++) {
        var rowGet = (function (r) { return function (x) { return m[r][x]; }; })(i);
        var colGet = (function (c) { return function (x) { return m[x][c]; }; })(i);
        if (match(rowGet, j) || match2(rowGet, j)) score += 40;
        if (match(colGet, j) || match2(colGet, j)) score += 40;
      }
    }
    // Rule 4 — deviation from an even split of dark and light.
    for (i = 0; i < size; i++) for (j = 0; j < size; j++) if (m[i][j]) dark++;
    var pct = (dark * 100) / (size * size);
    score += Math.floor(Math.abs(pct - 50) / 5) * 10;
    return score;
  }

  function build(text, forceMask) {
    var bytes = toUtf8(text);
    var version = 0;
    for (var v = 1; v <= 15; v++) { if (bytes.length <= capacityBytes(v)) { version = v; break; } }
    if (!version) throw new Error("Too much data for a level-M QR code (max " + capacityBytes(15) + " bytes).");

    var size = version * 4 + 17;
    var codewords = buildCodewords(bytes, version);

    // The function patterns go down first so the data placement can skip them.
    var base = newMatrix(size);
    placeFinder(base, 0, 0);
    placeFinder(base, 0, size - 7);
    placeFinder(base, size - 7, 0);
    placeAlignment(base, version);
    for (var i = 8; i < size - 8; i++) {
      var bit = (i % 2 === 0) ? 1 : 0;
      if (base[6][i] === null) base[6][i] = bit;
      if (base[i][6] === null) base[i][6] = bit;
    }
    // Reserve the format and version areas so data never lands there.
    var reserved = newMatrix(size);
    placeFormat(reserved, 0);
    placeVersion(reserved, version);
    // `func` marks every module the mask must leave alone — the finders, timing,
    // alignment and the reserved format/version strips. Masking those too is the
    // classic way to produce a QR code that renders but never scans.
    var func = [];
    var r, c;
    for (r = 0; r < size; r++) {
      func.push(new Array(size).fill(false));
      for (c = 0; c < size; c++) {
        if (base[r][c] !== null || reserved[r][c] !== null) func[r][c] = true;
      }
    }
    for (r = 0; r < size; r++) for (c = 0; c < size; c++) if (reserved[r][c] !== null && base[r][c] === null) base[r][c] = 0;

    // Zigzag data placement, right to left, skipping the vertical timing column.
    var bitIdx = 0, upward = true;
    for (var col = size - 1; col > 0; col -= 2) {
      if (col === 6) col--;
      for (var n = 0; n < size; n++) {
        var row = upward ? size - 1 - n : n;
        for (var k = 0; k < 2; k++) {
          var cc = col - k;
          if (base[row][cc] !== null) continue;
          var b = 0;
          if (bitIdx < codewords.length * 8) {
            b = (codewords[bitIdx >> 3] >> (7 - (bitIdx & 7))) & 1;
          }
          base[row][cc] = b;
          bitIdx++;
        }
      }
      upward = !upward;
    }

    // Try every mask, keep the lowest-penalty one.
    var best = null, bestScore = Infinity;
    for (var mk = 0; mk < 8; mk++) {
      if (forceMask != null && mk !== forceMask) continue;
      var m = [];
      for (var rr = 0; rr < size; rr++) {
        m.push(base[rr].slice());
      }
      for (var y = 0; y < size; y++) {
        for (var x = 0; x < size; x++) {
          if (func[y][x]) continue;
          if (maskFn(mk, y, x)) m[y][x] ^= 1;
        }
      }
      placeFormat(m, mk);
      placeVersion(m, version);
      var s = penalty(m);
      if (s < bestScore) { bestScore = s; best = m; }
    }
    return { size: size, version: version, modules: best };
  }

  // Render to an <svg> string. SVG keeps the modules crisp at any size and
  // prints correctly, which a canvas at a fixed pixel size does not.
  function svg(text, opts) {
    opts = opts || {};
    var q = build(text, opts.mask);
    var quiet = opts.quiet == null ? 4 : opts.quiet;
    var dim = q.size + quiet * 2;
    var parts = [];
    for (var r = 0; r < q.size; r++) {
      for (var c = 0; c < q.size; c++) {
        if (q.modules[r][c]) parts.push("M" + (c + quiet) + " " + (r + quiet) + "h1v1h-1z");
      }
    }
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + dim + " " + dim +
      '" shape-rendering="crispEdges" role="img" aria-label="QR code">' +
      '<rect width="' + dim + '" height="' + dim + '" fill="#fff"/>' +
      '<path d="' + parts.join("") + '" fill="#000"/></svg>';
  }

  root.RiveraQR = { build: build, svg: svg, capacity: capacityBytes(15) };
})(window);
