// The dashboard toolbar's chip lists.
//
// The bar builds each chip as a `var`, then names them twice more: `actions`
// (what moves into the phone sheet) and `order` (left-to-right at full width).
// Deleting a chip means deleting it in three places, and missing one is not a
// syntax error — it is a ReferenceError the moment the dashboard renders, which
// takes the whole toolbar with it.
//
// That is exactly what happened removing the Flights and Documents chips on
// 2026-08-23: both lists still named `fl` and `dc` after the buttons were gone,
// and `node --check` was perfectly happy with it.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

// The toolbar block: from the first chip to where the layout runs.
const i = src.indexOf('var h = el("button", "chip audit-all chip-history"');
const j = src.indexOf("layoutToolbar()", i);
t("the toolbar block is findable", i > 0 && j > i, true);
const block = src.slice(i, j);

const declared = [...block.matchAll(/var ([a-zA-Z_$][\w$]*) = el\(/g)].map((m) => m[1]);
const listOf = (name) => {
  const m = block.match(new RegExp("var " + name + " = \\[([^\\]]*)\\]"));
  return m ? m[1].split(",").map((s) => s.trim()).filter(Boolean) : null;
};

console.log("\nevery named chip exists");
["actions", "order"].forEach((name) => {
  const ids = listOf(name);
  t(name + " is declared", Array.isArray(ids), true);
  t("every chip in " + name + " was actually built",
    ids.filter((x) => declared.indexOf(x) < 0), []);
});

console.log("\nthe two lists agree");
// order is the visual sequence, actions is what collapses into the sheet. They
// hold the same chips today; if they ever diverge it should be on purpose, and
// this is where that decision gets noticed.
t("actions and order hold the same chips",
  listOf("actions").slice().sort(), listOf("order").slice().sort());

console.log("\nthe removed features are gone for good");
// Cross-trip Flights and Documents: an index of every flight and every document
// across all 183 trips. Removed because they answered questions nobody asked.
// The client feature, its two API endpoints and its CSS all went together --
// a dead endpoint is a maintenance cost and a slice of attack surface.
t("no cross-trip browser in the client", /openCrossTrip/.test(src), false);
t("nor its row builders", /function flightRow|function docRow/.test(src), false);
const core = fs.readFileSync("functions/api/_core.js", "utf8");
t("the /v1/flights endpoint is gone", /segs\[0\] === "flights"/.test(core), false);
t("the /v1/alldocs endpoint is gone", /segs\[0\] === "alldocs"/.test(core), false);
const css = fs.readFileSync("public/styles.css", "utf8");
t("and the CSS that dressed them", /\.cross-bar|\.cross-row|\.cross-trip-head/.test(css), false);
// The per-trip documents sidebar is a different thing entirely and stays.
t("per-trip documents still exist", /\/documents/.test(core), true);

console.log("\nthe More sheet describes what it opens");
// The tooltip listed Flights and Documents long after they were deleted, which
// is the kind of stale label nobody notices from inside the code.
// U15 lifted the tooltip into a constant so drawMoreBadge can put it back
// after a badge is cleared -- read it from there.
const more = (src.match(/var MORE_TITLE = "([^"]*)"/) || [])[1] || "";
t("the tooltip names only chips that exist",
  ["Flights", "Documents"].filter((x) => more.indexOf(x) >= 0), []);
t("and names the ones that do",
  ["History", "Changes", "Calendar", "Trip Ideas"].every((x) => more.indexOf(x) >= 0), true);

console.log("\nthe chip and the panel it opens agree on the name");
// They did not. The chip said "Bucket List" and the panel said "Trip Ideas",
// which was accurate when the list held names and confusing once it held
// addresses, seasons and routing -- it read as two separate features.
const chipLabel = (src.match(/chip-bucket", "[^A-Za-z]*([^"]*)"/) || [])[1] || "";
const panelTitle = (src.match(/"form-title", "([^"]*)"\)\);\s*\n\s*panel\.appendChild\(el\("div", "place-hint"/) || [])[1] || "";
t("the chip is named", chipLabel, "Trip Ideas");
t("the panel agrees", panelTitle, "Trip Ideas");
t("and the More tooltip uses the same name", more.indexOf(chipLabel) >= 0, true);
t("the old name is gone from every label a person reads",
  /"[^"]*Bucket List[^"]*"/.test(src), false);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
