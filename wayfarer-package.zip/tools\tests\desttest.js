// Where a trip IS, as opposed to where it starts.
//
// geoPoints lists transports first, so its first entry is the DEPARTURE point:
// home, or the airport you left from. Everything anchored on it described the
// place being left rather than the place being visited.
//
// That is not hypothetical. Opening El Camino de Santiago on 2026-08-28 showed
// the first coordinate as Los Angeles International Airport — so the weather
// line on a trip to Spain had been reporting Los Angeles, and did so for as
// long as the feature has existed. It was found only because three new features
// were about to inherit the same anchor.
//
// Lodging first, because where you sleep is where you are. Then an activity,
// then a transport ARRIVAL, and only then a departure — by which point nothing
// records a destination at all and the departure is the only coordinate there.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

function lift(decl) {
  const at = app.indexOf(decl);
  if (at < 0) throw new Error("not found: " + decl);
  let depth = 0, i = app.indexOf("{", at);
  for (; i < app.length; i++) {
    if (app[i] === "{") depth++;
    else if (app[i] === "}") { depth--; if (!depth) break; }
  }
  return app.slice(at, i + 1);
}

// The real pair, so a change to either fails here rather than drifting.
const api = new Function(
  "transIcon", "actIcon",
  lift("function destPoint(data)") + "\n" + lift("function geoPoints(data)") +
  "\nreturn destPoint;"
)(() => "", () => "");
const clockOf = new Function(lift("function clockOf(iso)") + "\nreturn clockOf;")();

// The shape that caused it: a flight out of LAX to a hotel in Santiago.
const LAX = { departure_latitude: 33.9434, departure_longitude: -118.4082, departure_at: "2026-08-04T20:00:00Z",
  arrival_latitude: 42.8963, arrival_longitude: -8.4152, arrival_at: "2026-08-05T14:00:00Z" };
const HOTEL = { latitude: 42.8805, longitude: -8.5457, starts_at: "2026-08-05T16:00:00Z", name: "Parador" };

console.log("\nthe destination, not the departure");
{
  const p = api({ transports: [LAX], hostings: [HOTEL], activities: [] });
  t("lodging wins over the airport you left from", [p.lat, p.lng], [42.8805, -8.5457]);
  // Proof the old anchor really did point at Los Angeles.
  const old = new Function("transIcon", "actIcon", lift("function geoPoints(data)") + "\nreturn geoPoints;")(() => "", () => "");
  t("the old anchor was the departure airport",
    Math.round(old({ transports: [LAX], hostings: [HOTEL] })[0].lat), 34);
  t("and the new one is not", Math.round(p.lat), 43);
}

console.log("\nfalling back, in order");
{
  t("no lodging, so an activity",
    [api({ transports: [LAX], hostings: [], activities: [{ latitude: 42.88, longitude: -8.54, starts_at: "2026-08-06" }] }).lat], [42.88]);
  // An arrival is still the far end of a journey; a departure is not.
  t("no lodging or activity, so the ARRIVAL",
    [api({ transports: [LAX], hostings: [], activities: [] }).lat], [42.8963]);
  t("only a departure exists, so that is all there is",
    [api({ transports: [{ departure_latitude: 33.9434, departure_longitude: -118.4082 }], hostings: [] }).lat], [33.9434]);
  t("nothing with coordinates at all", api({ transports: [], hostings: [], activities: [] }), null);
  t("missing collections do not throw", api({}), null);
}

console.log("\nthe earliest of each kind, not whichever was stored first");
{
  const late = { latitude: 1, longitude: 1, starts_at: "2026-08-20T00:00:00Z" };
  const early = { latitude: 2, longitude: 2, starts_at: "2026-08-05T00:00:00Z" };
  t("lodging is taken in date order", api({ hostings: [late, early] }).lat, 2);
  // A stay with no date must not sort ahead of one that has a real date. The
  // first version of this very assertion EXPECTED the undated one to win --
  // "".localeCompare sorts before every real date, the code obliged, and the
  // test pinned the bug under a label claiming the opposite. Caught by the
  // 2026-08-28 audit; undated rows now sort under a high sentinel.
  t("an undated stay does not outrank a dated one",
    api({ hostings: [{ latitude: 9, longitude: 9 }, early] }).lat, 2);
}

console.log("\na layover is not the destination");
{
  // LAX -> JFK -> MAD as the importer stores it: one row per leg, and the
  // EARLIEST arrival is the layover. Anchoring there put a Madrid trip's
  // weather in New York. A layover is an arrival some other leg departs from
  // (about the same coordinates) within a day.
  const toJFK = { departure_latitude: 33.9434, departure_longitude: -118.4082, departure_at: "2026-08-04T20:00:00Z",
    arrival_latitude: 40.6413, arrival_longitude: -73.7781, arrival_at: "2026-08-05T04:00:00Z" };
  const toMAD = { departure_latitude: 40.6413, departure_longitude: -73.7781, departure_at: "2026-08-05T06:00:00Z",
    arrival_latitude: 40.4722, arrival_longitude: -3.5608, arrival_at: "2026-08-05T14:00:00Z" };
  t("the connection is skipped, Madrid wins",
    Math.round(api({ transports: [toJFK, toMAD], hostings: [], activities: [] }).lng), -4);

  // A round trip must NOT be broken by the filter: the return departs days
  // later, so the outbound arrival is no layover and stays the earliest.
  const outMAD = { departure_latitude: 33.9434, departure_longitude: -118.4082, departure_at: "2026-06-01T20:00:00Z",
    arrival_latitude: 40.4722, arrival_longitude: -3.5608, arrival_at: "2026-06-02T14:00:00Z" };
  const backLAX = { departure_latitude: 40.4722, departure_longitude: -3.5608, departure_at: "2026-06-08T10:00:00Z",
    arrival_latitude: 33.9434, arrival_longitude: -118.4082, arrival_at: "2026-06-08T20:00:00Z" };
  t("a round trip still lands on the destination",
    Math.round(api({ transports: [outMAD, backLAX], hostings: [], activities: [] }).lng), -4);
}

console.log("\nreading a clock off an Open-Meteo timestamp");
{
  // "2026-08-28T19:24" — only the clock is wanted, in the reader's own format.
  t("an evening time", /7:24/.test(clockOf("2026-08-28T19:24")), true);
  t("a morning time", /6:24/.test(clockOf("2026-08-28T06:24")), true);
  t("junk yields nothing rather than NaN", clockOf("nope"), "");
  t("and so does nothing at all", clockOf(null), "");
}

console.log("\n" + pass + " passed, " + fail + " failed\n");
process.exit(fail ? 1 : 0);
