// Trip ideas: the bucket list grown into a pre-trip planner.
//
// An idea carries three things a bucket list could not — WHERE it is, WHEN you
// would go, and WHEN it is worth going — and each has a way of being subtly
// wrong that no amount of looking at the screen would reveal:
//
//   a season may WRAP the year (a ski property is December to March, and
//   December is not "after" March);
//   a target window is a year, a month or a day in ONE field, so the label and
//   the season check both have to cope with all three resolutions;
//   the flight estimate is an ESTIMATE and must never be dressed as a schedule.
//
// Fixtures are invented. The 16-of-17-are-properties figure is real, and is
// why address and coordinates exist on an idea at all.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");

function grab(name) {
  const i = src.indexOf("  function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
const MONTHS_SRC = src.slice(src.indexOf("  var MONTHS = ["),
  src.indexOf("];", src.indexOf("  var MONTHS = [")) + 2);
const HOME_SRC = src.slice(src.indexOf("  var HOME = {"),
  src.indexOf(";", src.indexOf("  var HOME = {")) + 1);
const HOMEMAX_SRC = src.slice(src.indexOf("  var HOME_MAX_KM = "),
  src.indexOf(";", src.indexOf("  var HOME_MAX_KM = ")) + 1);
// Not the same number: HOME_MAX_KM decides whether to draw a driving route on
// a booked trip; DRIVE_MAX_KM decides whether an idea is a drive at all.
const DRIVEMAX_SRC = src.slice(src.indexOf("  var DRIVE_MAX_KM = "),
  src.indexOf(";", src.indexOf("  var DRIVE_MAX_KM = ")) + 1);

eval([MONTHS_SRC, HOME_SRC, HOMEMAX_SRC, DRIVEMAX_SRC,
  grab("km"), grab("targetLabel"), grab("inSeason"), grab("seasonLabel"),
  grab("targetMonths"), grab("seasonClash"), grab("flightHours"),
  grab("nearestAirport"), grab("reachability"), grab("reachLabel")].join("\n") +
  ";Object.assign(globalThis,{MONTHS,HOME,HOME_MAX_KM,DRIVE_MAX_KM,km,targetLabel,inSeason,seasonLabel," +
  "targetMonths,seasonClash,flightHours,nearestAirport,reachability,reachLabel});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

console.log("\nwhen you'd go — one field, three resolutions");
t("a bare year", targetLabel("2027", ""), "2027");
t("a month", targetLabel("2027-09", ""), "September 2027");
t("a specific week", targetLabel("2027-09-14", ""), "Sep 14, 2027");
t("a range", targetLabel("2027-09", "2027-10"), "September 2027 – October 2027");
// Both ends the same is one answer, not a range of one.
t("the same both ends collapses", targetLabel("2027-09", "2027-09"), "September 2027");
t("nothing set says nothing", targetLabel("", ""), "");
t("only an end still reads", targetLabel("", "2028"), "2028");

console.log("\nbest season — and the wrap that breaks naive checks");
t("inside a summer season", inSeason(7, 5, 10), true);
t("outside it", inSeason(2, 5, 10), false);
t("the boundary months are inside", inSeason(5, 5, 10) && inSeason(10, 5, 10), true);
// THE case: a ski property is 12–3. A month >= from && <= to test says December
// is not in it, which is wrong in the most expensive way — it would warn you
// off the only time worth going.
t("a ski season wraps the year: December", inSeason(12, 12, 3), true);
t("  ...January", inSeason(1, 12, 3), true);
t("  ...March", inSeason(3, 12, 3), true);
t("  ...but not July", inSeason(7, 12, 3), false);
t("no season set never fails anything", inSeason(7, null, null), true);
t("half a season is no season", inSeason(7, 5, null), true);
t("the label", seasonLabel(5, 10), "May–Oct");
t("a wrapping label reads the same way", seasonLabel(12, 3), "Dec–Mar");
t("no season, no label", seasonLabel(null, null), "");

console.log("\nthe months a window covers");
t("a month is itself", targetMonths("2027-09", ""), [9]);
t("a day is its month", targetMonths("2027-09-14", ""), [9]);
// A bare year is "I have not chosen" — every month, so nothing to warn about.
t("a bare year covers nothing specific", targetMonths("2027", ""), []);
t("a range walks forward", targetMonths("2027-09", "2027-11"), [9, 10, 11]);
t("and wraps the new year", targetMonths("2027-11", "2028-02"), [11, 12, 1, 2]);

console.log("\nwindow against season — a note, never a block");
t("a bare year warns about nothing",
  seasonClash({ target_from: "2027", season_from: 5, season_to: 10 }), null);
t("September at a summer place is fine",
  seasonClash({ target_from: "2027-09", season_from: 5, season_to: 10 }), null);
t("February is not", seasonClash({ target_from: "2027-02", season_from: 5, season_to: 10 }),
  "Outside its season (May–Oct)");
t("a window straddling the edge says PARTLY",
  seasonClash({ target_from: "2027-10", target_to: "2027-11", season_from: 5, season_to: 10 }),
  "Partly outside its season (May–Oct)");
t("January at a ski place is fine",
  seasonClash({ target_from: "2028-01", season_from: 12, season_to: 3 }), null);
t("July at a ski place is not",
  seasonClash({ target_from: "2027-07", season_from: 12, season_to: 3 }),
  "Outside its season (Dec–Mar)");
t("no season, no opinion", seasonClash({ target_from: "2027-02" }), null);

console.log("\nhow far away — exact distance, estimated time");
// Real coordinates: LAX-adjacent home, and airports out of his own history.
const PORTS = [
  { code: "LAX", latitude: 33.9434, longitude: -118.4084, legs: 120 },
  { code: "HNL", latitude: 21.3258, longitude: -157.9217, legs: 4 },
  { code: "JFK", latitude: 40.6423, longitude: -73.7882, legs: 4 },
  { code: "EGE", latitude: 39.6399, longitude: -106.9135, legs: 8 },
];
const near = (lat, lon) => nearestAirport(PORTS, lat, lon);
t("Vail picks EGE, not the busier LAX", near(39.64, -106.37).code, "EGE");
t("Waikiki picks HNL", near(21.28, -157.83).code, "HNL");
t("and carries how often you have used it", near(39.64, -106.37).legs, 8);
t("no coordinates, no airport", near(null, null), null);
t("no airport list, no answer", nearestAirport([], 21.28, -157.83), null);

// Santa Barbara is a drive, not a flight. Calling it "2 hours in the air" would
// be worse than saying nothing.
const sb = reachability({ latitude: 34.4208, longitude: -119.6982 }, PORTS);
t("Santa Barbara is drivable", sb.drivable, true);
t("so it gets no flight time", sb.hours, null);
t("and says so", /drivable/.test(reachLabel(sb)), true);

const maui = reachability({ latitude: 20.7984, longitude: -156.3319 }, PORTS);
t("Hawaii is not drivable", maui.drivable, false);
t("it gets an estimate", maui.hours > 4 && maui.hours < 8, true);
// The estimate must read as one. A number without a tilde is a schedule.
t("the label marks it as approximate", /~/.test(reachLabel(maui)), true);
t("and gives the distance in miles", /mi from home/.test(reachLabel(maui)), true);
t("an idea with no coordinates has no reachability",
  reachability({ place: "Somewhere" }, PORTS), null);
t("and produces no label", reachLabel(null), "");

console.log("\nthe estimate is an estimate");
// 800 km/h cruise plus 45 minutes on the ground and in the climb. Not a
// schedule, and there is no route search behind it -- see /v1/airports.
t("a short hop is mostly overhead", Math.round(flightHours(400) * 10) / 10, 1.3);
t("LAX-JFK lands near five and a half", Math.round(flightHours(3970) * 10) / 10, 5.7);
t("nothing in, nothing out", flightHours(null), null);

console.log("\nwhat the app does with it");
t("the list reads the table, not the old settings blob",
  /api\("\/v1\/ideas"\)/.test(src), true);
t("and the old blob reader is gone", /state\.me\.bucket_list/.test(src), false);
// The whole point: 16 of 17 ideas were properties, and the old conversion made
// a trip NAMED after a hotel with no hotel in it.
t("converting creates the lodging too",
  /api\("\/v1\/trip\/" \+ made\.id \+ "\/hostings"/.test(src), true);
t("only when it knows where the place is",
  /var willLodge = !!\(item\.address \|\| item\.latitude != null\)/.test(src), true);
t("a failed lodging write does not strand the trip",
  /Trip created, but the lodging did not save/.test(src), true);
// The target window is a wish about a month, not dates. Inventing dates from it
// would be writing a guess into the database.
t("conversion still makes an undated trip", /has_dates: false/.test(src), true);
t("the airport list decorates and never blocks the first paint",
  /airports\(\)\.then\(function \(a\)/.test(src), true);

console.log("\nnear enough to drive");
// The boundary moved from 1100km to 402 (250 miles), and the point of the move
// is the middle band: Las Vegas and Mammoth used to read as "drivable" here and
// now read as flights worth pricing. Both are still drives once BOOKED -- that
// is HOME_MAX_KM's job, and a different question.
const at = (d) => reachability({ latitude: HOME.lat + d / 111, longitude: HOME.lng }, []);
t("a forty-mile idea is a drive", at(64).drivable, true);
t("two hundred miles is still a drive", at(320).drivable, true);
t("and carries no flight time", at(320).hours, null);
// 435km: Las Vegas. Inside the old threshold, outside the new one.
t("Las Vegas is now a flight to price", at(435).drivable, false);
t("which means it gets an estimate", at(435).hours > 0, true);
t("Hawaii was never in doubt", at(4000).drivable, false);
// The label must not offer an airport for somewhere you would drive to.
t("a drive says so and stops", reachLabel(at(64)).indexOf("drivable") > 0, true);
t("and does not mention air time", /h in the air/.test(reachLabel(at(64))), false);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
