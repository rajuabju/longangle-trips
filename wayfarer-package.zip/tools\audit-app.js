// Self-audit. Each check is a defect class this session actually produced —
// so these are regressions waiting to happen, not hypotheticals.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");
const css = fs.readFileSync("public/styles.css", "utf8");
const sw = fs.readFileSync("public/sw.js", "utf8");
const html = fs.readFileSync("public/index.html", "utf8");

// The source with comments and string literals blanked out, for the checks that
// look for CALLS. Scanning raw text found `word (` in English and reported
// thirty "undefined functions" — "editing (inline forms)", "weather (Open-Meteo,
// free/keyless)", "later (+)" — none of them code. A check whose every hit is
// noise is a check nobody reads, so this one is given only the code.
//
// Deliberately crude: it blanks rather than deletes, so byte offsets (and so
// lineOf) still line up with the real file.
function codeOnly(src) {
  let out = "", i = 0;
  const blank = (n) => " ".repeat(n);
  while (i < src.length) {
    const c = src[i], nx = src[i + 1];
    if (c === "/" && nx === "/") { const e = src.indexOf(String.fromCharCode(10), i); const j = e < 0 ? src.length : e; out += blank(j - i); i = j; continue; }
    if (c === "/" && nx === "*") { const e = src.indexOf("*/", i + 2); const j = e < 0 ? src.length : e + 2; out += blank(j - i); i = j; continue; }
    if (c === '"' || c === "'" || c === "`") {
      let j = i + 1;
      while (j < src.length && src[j] !== c) { if (src[j] === "\\") j++; j++; }
      j = Math.min(j + 1, src.length);
      out += c + blank(j - i - 1); i = j; continue;
    }
    out += c; i++;
  }
  return out;
}
const appCode = codeOnly(app);

const findings = [];
const flag = (sev, what, detail) => findings.push({ sev, what, detail });
const lineOf = (src, idx) => src.slice(0, idx).split("\n").length;

// A1 — href built from a helper that forgets its scheme. (v85: telHref)
{
  const bad = [];
  const re = /\.href\s*=\s*([A-Za-z_$][\w$]*)\(/g;
  let m;
  while ((m = re.exec(app))) {
    const fn = m[1];
    if (/^(telHref|mailtoHref|gmaps|amaps|mapsUrl)$/.test(fn)) continue;
    bad.push(fn + " @L" + lineOf(app, m.index));
  }
  if (bad.length) flag("check", "href assigned from a helper", bad.join(", "));
}

// A2 — every scheme-bearing helper must actually emit its scheme.
["telHref"].forEach((fn) => {
  const i = app.indexOf("function " + fn + "(");
  if (i < 0) return flag("high", fn + " missing", "referenced but not defined");
  const body = app.slice(i, i + 700);
  if (!/["']tel:["']/.test(body)) flag("high", fn + " emits no tel: scheme", "a bare number in an href is a relative path");
});

// A3 — respondWith(undefined): caches.match with no miss guard. (v86)
{
  const re = /catch\s*\(\s*function\s*\(\s*\)\s*\{\s*return\s+caches\.match\([^)]*\)\s*;\s*\}\s*\)/g;
  const hits = [...sw.matchAll(re)].map((m) => "L" + lineOf(sw, m.index));
  if (hits.length) flag("high", "service worker can respondWith(undefined)", hits.join(", "));
}

// A4 — print rules that will lose the cascade. (v88: .dossier-panel)
{
  const printBlocks = [...css.matchAll(/@media print\s*\{/g)].map((m) => m.index);
  for (const start of printBlocks) {
    let d = 0, end = start;
    for (let i = css.indexOf("{", start); i < css.length; i++) {
      if (css[i] === "{") d++; else if (css[i] === "}") { d--; if (!d) { end = i; break; } }
    }
    const block = css.slice(start, end);
    // Any selector in a print block that is overridden later in the file by an
    // equal-or-higher specificity rule, without !important, is the v88 bug.
    const sels = [...block.matchAll(/\n\s*([.#][\w.#\-\s:()\[\]="']+?)\s*\{([^}]*)\}/g)];
    for (const s of sels) {
      const sel = s[1].trim(), decls = s[2];
      if (/!important/.test(decls)) continue;
      if (!/max-height|overflow|position|display/.test(decls)) continue;
      const simple = sel.split(/[\s>]/).pop();
      if (!/^\.[\w-]+$/.test(simple)) continue;
      // does a later rule re-set the same property on a selector containing it?
      const after = css.slice(end);
      const re2 = new RegExp("(^|[\\s,}])" + simple.replace(".", "\\.") + "[\\w.\\-]*\\s*\\{[^}]*(max-height|overflow)", "m");
      if (re2.test(after)) flag("high", "print rule overridden later", sel + " @L" + lineOf(css, start));
    }
  }
}

// A5 — unhandled promise from a fire-and-forget clipboard/fetch. (v87: copy)
{
  const re = /try\s*\{\s*navigator\.clipboard\.writeText\([^)]*\)\s*;\s*\}\s*catch/g;
  if (re.test(app)) flag("high", "clipboard write in a try/catch", "writeText rejects, it does not throw");
}

// A6 — asset hashes must agree across index.html, sw.js and disk.
{
  const grab = (s) => [...s.matchAll(/(app|styles|qr|feasibility)\.[a-f0-9]+\.(js|css)/g)].map((m) => m[0]);
  const inHtml = [...new Set(grab(html))].sort();
  const inSw = [...new Set(grab(sw))].sort();
  const onDisk = fs.readdirSync("public").filter((f) => /^(app|styles|qr|feasibility)\.[a-f0-9]+\.(js|css)$/.test(f)).sort();
  // Subset, not equality -- the same reasoning as smoke.js. The service worker
  // may hold MORE than the page links: qr.js is loaded on demand by the ticket
  // dialog and is precached so that dialog still works offline. An extra is only
  // legitimate when something references it, which for a lazily-loaded asset
  // means app.js carries its hashed name; otherwise it is a stale entry.
  for (const a of inHtml) if (!inSw.includes(a)) flag("high", "index.html asset is not precached", a);
  for (const a of inSw) {
    if (!inHtml.includes(a) && app.indexOf(a) < 0) flag("high", "sw.js precaches an asset nothing references", a);
  }
  for (const a of inHtml) if (!onDisk.includes(a)) flag("high", "index.html references a missing asset", a);
  for (const a of inSw) if (!onDisk.includes(a)) flag("high", "sw.js precaches a missing asset", a);
}

// A7 — the build marker must match the committed bundle.
{
  const v = (app.match(/__WAYFARER_BUILD = "(v\d+\.\d+)"/) || [])[1];
  const bundle = (html.match(/app\.[a-f0-9]+\.js/) || [])[0];
  const built = bundle && fs.existsSync("public/" + bundle) ? fs.readFileSync("public/" + bundle, "utf8") : "";
  // Whitespace-tolerant: the shipped bundle is minified, so this reads
  // __WAYFARER_BUILD="v120.6" with no spaces, while the source has them.
  const bv = (built.match(/__WAYFARER_BUILD\s*=\s*"(v\d+\.\d+)"/) || [])[1];
  if (v !== bv) flag("high", "source and built bundle disagree on version", v + " vs " + bv);
}

// A8 — every function called must exist (catches renames like the v83 travelers div).
{
  const defined = new Set([...app.matchAll(/function\s+([A-Za-z_$][\w$]*)\s*\(/g)].map((m) => m[1]));
  const builtins = /^(if|for|while|switch|catch|return|typeof|function|new|await|Number|String|Boolean|Array|Object|JSON|Math|Date|RegExp|Promise|Error|parseInt|parseFloat|isNaN|isFinite|encodeURIComponent|decodeURIComponent|setTimeout|setInterval|clearTimeout|clearInterval|alert|confirm|prompt|fetch|el|require|requestAnimationFrame|cancelAnimationFrame|structuredClone|queueMicrotask|btoa|atob)$/;
  // Not preceded by a hyphen, or `linear-gradient(` reads as a call to gradient().
  const called = new Set([...appCode.matchAll(/(?:^|[^.\-\w$])([a-z][\w$]*)\s*\(/g)].map((m) => m[1]));
  // A name in a parameter list is supplied by the caller. This is how `fmt` came
  // to be reported: `fmt ? fmt(r) : r.name` calls a parameter, and guards it.
  const params = new Set();
  for (const m of app.matchAll(/function\s*[A-Za-z_$\w]*\s*\(([^)]*)\)/g)) {
    m[1].split(",").forEach((x) => { const n = x.trim().split(/[\s=]/)[0]; if (n) params.add(n); });
  }
  const missing = [...called].filter((n) => !defined.has(n) && !builtins.test(n) && !params.has(n) &&
    !new RegExp("(var|let|const)\\s+" + n + "\\b").test(app) &&
    !new RegExp("\\b" + n + "\\s*[:=]\\s*(function|async|\\()").test(app));
  if (missing.length) flag("check", "called but not obviously defined", missing.slice(0, 12).join(", "));
}

// A9 — CSS classes referenced from JS that no stylesheet defines.
{
  // A class with no rule of its own is a defect only when NOTHING on the element
  // is styled. `el("button", "chip audit-all chip-history")` carries two styled
  // classes and one identifier the JS uses as a handle; flagging the handle
  // reported ten of these, not one of them a bug — which is the quickest way to
  // teach someone to stop reading an audit.
  const styled = (c) => new RegExp("\\." + c.replace(/[-]/g, "\\-") + "\\b").test(css);
  // Structural wrappers whose layout comes entirely from the PARENT, so having
  // no rule of their own is correct rather than missing:
  //
  //   insight-col  a grid item inside .insight-cols, which sets the columns
  //   dc-name      a flex child of .dc-row, which sets justify-content
  //   trip-main    a plain block inside .trip-cols, which is display:block
  //
  // Each was checked against the stylesheet before being listed here. They are
  // listed because a check that reports the same three non-issues on every
  // single run is a check people stop reading -- exactly what the comment above
  // warns about. Anything genuinely unstyled still shows up.
  const BY_PARENT = new Set(["insight-col", "dc-name", "trip-main"]);
  const orphan = [];
  for (const m of app.matchAll(/el\(\s*"[a-z0-9]+"\s*,\s*"([^"]+)"/g)) {
    const group = m[1].split(/\s+/).filter(Boolean);
    if (!group.length || group.some(styled) || group.some((c) => BY_PARENT.has(c))) continue;
    group.forEach((c) => { if (!orphan.includes(c)) orphan.push(c); });
  }
  if (orphan.length) flag("check", "class used in JS with no CSS rule", orphan.slice(0, 15).join(", "));
}

// A10 — CSS rules nothing references (the .travelers leftovers).
{
  const declared = [...css.matchAll(/^\.([\w-]+)/gm)].map((m) => m[1]);
  const dead = [...new Set(declared)].filter((c) =>
    !new RegExp('"[^"]*\\b' + c + '\\b[^"]*"').test(app) && !new RegExp('\\b' + c + '\\b').test(html));
  if (dead.length) flag("info", "CSS class with no user in JS or HTML", dead.slice(0, 15).join(", "));
}

// A11 — balance.
{
  let d = 0; for (const ch of css) { if (ch === "{") d++; else if (ch === "}") d--; }
  if (d !== 0) flag("high", "styles.css brace imbalance", String(d));
  const o = (css.match(/\/\*/g) || []).length, c = (css.match(/\*\//g) || []).length;
  if (o !== c) flag("high", "styles.css comment imbalance", o + " open, " + c + " close");
}

const order = { high: 0, check: 1, info: 2 };
findings.sort((a, b) => order[a.sev] - order[b.sev]);
if (!findings.length) console.log("  clean — no findings");
for (const f of findings) console.log("  [" + f.sev.toUpperCase() + "] " + f.what + "\n        " + f.detail + "\n");
console.log("  " + findings.filter(f => f.sev === "high").length + " high, " +
  findings.filter(f => f.sev === "check").length + " to check, " +
  findings.filter(f => f.sev === "info").length + " info");
