// Goals that do not run on the calendar, and goals anchored to a number this
// app cannot compute.
//
// Every threshold began as a calendar year, which is an assumption rather than
// a fact about loyalty programmes. American's Loyalty Point year runs 1 March
// to the end of February, so on 27 August 2026 the year in progress started
// five months earlier -- and every figure keyed off 1 January is wrong for it:
// which transactions are in scope, days elapsed, days remaining, the pace.
//
// The second half is the anchor. Loyalty Points come from card spend AND from
// flying, and the flying half is not derivable here: every flight in the
// itinerary carries price = 0, so the app knows where Alex flew and never what
// the ticket cost. Estimating it would present a fabricated half of a
// two-source total as progress -- the exact shape of the two spend mistakes
// this panel has already made. So American's own figure anchors it and only
// card spend recorded AFTER that day is added.
//
// The failure that matters most is DOUBLE COUNTING: charges from before the
// anchor are already inside it, and adding them again inflates the total.
const fs = require("fs");
const core = fs.readFileSync("functions/api/_core.js", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

function lift(decl) {
  const at = core.indexOf(decl);
  if (at < 0) throw new Error("not found: " + decl);
  let depth = 0, i = core.indexOf("{", at);
  for (; i < core.length; i++) {
    if (core[i] === "{") depth++;
    else if (core[i] === "}") { depth--; if (!depth) break; }
  }
  return core.slice(at, i + 1);
}

const api = new Function(
  lift("function goalWindow(") + "\n" + lift("function daysInclusive(") +
  "\nreturn { goalWindow: goalWindow, daysInclusive: daysInclusive };"
)();
const on = (day, period) => api.goalWindow(period, Date.parse(day + "T12:00:00Z"));

console.log("\nthe calendar year, unchanged");
{
  const w = on("2026-08-27", "calendar");
  t("runs January to December", [w.from, w.to], ["2026-01-01", "2026-12-31"]);
  t("and is labelled by its year", w.label, "2026");
  t("an unset period is the calendar", on("2026-08-27", null).from, "2026-01-01");
  t("so is an unknown one, rather than an error", on("2026-08-27", "quarterly").from, "2026-01-01");
}

console.log("\nAmerican's year runs March to February");
{
  const w = on("2026-08-27", "march");
  t("August 2026 sits in the year that began in March", [w.from, w.to], ["2026-03-01", "2027-02-28"]);
  t("labelled across the two years it spans", w.label, "2026–27");

  // The boundary is the whole point: in January you are still in LAST March's
  // year, and a naive getFullYear() would start it two months in the future.
  t("January belongs to the year that began last March", on("2026-01-15", "march").from, "2025-03-01");
  t("and so does the last day of February", on("2026-02-28", "march").to, "2026-02-28");
  t("the first of March starts the new one", on("2026-03-01", "march").from, "2026-03-01");
  t("the last day of the window is still inside it", on("2027-02-28", "march").from, "2026-03-01");

  // Day 0 of March is the last day of February, so leap years need no thought.
  t("a leap year ends on the 29th", on("2028-01-05", "march").to, "2028-02-29");
  t("and a common year on the 28th", on("2026-08-27", "march").to, "2027-02-28");
}

console.log("\ndays across a window");
{
  t("a common year", api.daysInclusive("2026-01-01", "2026-12-31"), 365);
  t("a leap year", api.daysInclusive("2028-01-01", "2028-12-31"), 366);
  // The AAdvantage year that ENDS in a leap February is itself 366 days.
  t("an AAdvantage year ending in a leap February", api.daysInclusive("2027-03-01", "2028-02-29"), 366);
  t("both ends are counted", api.daysInclusive("2026-03-01", "2026-03-01"), 1);
}

console.log("\nan anchored total counts only what came after the anchor");
{
  // The real accumulation out of cardsPayload, with the AAdvantage rate of one
  // point per dollar. A charge on the anchor day itself is already inside the
  // figure American gave, so the comparison is <= and not <.
  const rows = [
    { date: "2026-03-10", amount: 20000, name: "SUPPLIER", category: "GENERAL_SERVICES_OTHER" },
    { date: "2026-07-01", amount: 10000, name: "SUPPLIER", category: "GENERAL_SERVICES_OTHER" },
    { date: "2026-08-01", amount: 500, name: "SAME DAY AS THE ANCHOR", category: "GENERAL_SERVICES_OTHER" },
    { date: "2026-08-15", amount: 5000, name: "SUPPLIER", category: "GENERAL_SERVICES_OTHER" },
    { date: "2026-08-16", amount: -113, name: "Nordstrom", category: "GENERAL_MERCHANDISE_DEPARTMENT_STORES" },
    { date: "2026-08-20", amount: -9000, name: "AUTOPAY", category: "LOAN_PAYMENTS_CREDIT_CARD_PAYMENT" },
  ];
  const classify = new Function(
    core.slice(core.indexOf("const CARD_PAYMENT_RE ="), core.indexOf("\n", core.indexOf("const CARD_PAYMENT_RE ="))) + "\n" +
    core.slice(core.indexOf("const CARD_CREDIT_RE ="), core.indexOf("\n", core.indexOf("const CARD_CREDIT_RE ="))) + "\n" +
    core.slice(core.indexOf("const CARD_BALANCE_REFUND_RE ="), core.indexOf("\n", core.indexOf("const CARD_BALANCE_REFUND_RE ="))) + "\n" +
    lift("function classifyCardTxn(") + "\nreturn classifyCardTxn;"
  )();

  const since = (anchorDay) => {
    let n = 0;
    for (const r of rows) {
      if (anchorDay && r.date <= anchorDay) continue;
      const k = classify(r.name, r.category, r.amount);
      if (k === "charge" || k === "refund") n += r.amount;
    }
    return n;
  };

  t("only spend after the anchor day is added", since("2026-08-01"), 5000 - 113);
  t("the anchor day itself is already inside the figure", since("2026-08-01") === since("2026-07-31") - 500, true);
  t("with no anchor at all the whole window counts", since(null), 35500 - 113);
  // The payment must stay excluded regardless of the anchor, or settling the
  // card would read as losing status.
  t("a payment never subtracts from a points total", since("2026-03-01") > 0, true);

  const progress = (baseline, anchorDay) => baseline + Math.floor(since(anchorDay) * 1);
  t("the anchor plus what followed it", progress(84500, "2026-08-01"), 84500 + 4887);
  // The mistake this design exists to prevent.
  t("and NOT the anchor plus the whole window", progress(84500, "2026-08-01") !== 84500 + 35387, true);
}

console.log("\n" + pass + " passed, " + fail + " failed\n");
process.exit(fail ? 1 : 0);
