// A live tracking link for the flight you are about to be on.
//
// Flightradar24 by deep link, not by API. The subscription covers the site and
// the app, not their commercial API — and a link needs neither. On a phone the
// FR24 app claims fr24.com links and opens there instead of the browser.
//
// The URL form was VERIFIED against the live site rather than assumed:
// /data/flights/as1412 answered "Flight history for Alaska Airlines flight
// AS1412". The other documented form, fr24.com/<callsign>, wants the ICAO
// callsign (ASA1412) and would mean shipping an airline lookup table to the
// client to reach the same page.
//
// Fixtures are invented; the flight-number SHAPES are real — all 206 distinct
// numbers in the database match the pattern under test.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");

function grab(name) {
  const i = src.indexOf("  function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
eval(["fr24Url", "trackable"].map(grab).join("\n") +
  ";Object.assign(globalThis,{fr24Url,trackable});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};
const air = (n) => ({ transportation_type: "airplane", transport_number: n });

console.log("\nthe link");
t("a flight number becomes a flight page",
  fr24Url(air("AS1412")), "https://www.flightradar24.com/data/flights/as1412");
// Real shapes from the database: two-letter codes, one to four digits.
t("a short number", fr24Url(air("AA14")), "https://www.flightradar24.com/data/flights/aa14");
t("a four-digit number", fr24Url(air("AA1923")), "https://www.flightradar24.com/data/flights/aa1923");
// A three-character code is legitimate too — some carriers have one.
t("a three-character code", fr24Url(air("EJU8412")), "https://www.flightradar24.com/data/flights/eju8412");
// Confirmations are inconsistent about spacing and case.
t("a space in the middle is tolerated", fr24Url(air(" AS 1412 ")), "https://www.flightradar24.com/data/flights/as1412");
t("lower case in, lower case out", fr24Url(air("as1412")), "https://www.flightradar24.com/data/flights/as1412");

console.log("\nwhat gets no link");
// Only a flight has a flight number to look up. A hire car's "company" is not
// one, and the whole point of the last change was that cars are not flights.
t("a hire car", fr24Url({ transportation_type: "car", transport_number: "SIXT" }), null);
t("a road trip", fr24Url({ transportation_type: "roadtrip", transport_number: "AA100" }), null);
t("a flight with no number", fr24Url(air("")), null);
t("a flight with a null number", fr24Url(air(null)), null);
// Junk must not be pasted into a URL. A confirmation code is not a flight
// number and would produce a page about nothing.
t("a confirmation code is refused", fr24Url(air("DZQKRT")), null);
t("a route is refused", fr24Url(air("LAX-LIR")), null);
t("a bare number is refused", fr24Url(air("1412")), null);
t("nothing at all", fr24Url(null), null);

console.log("\nwhen it is offered");
// The always-on chip was tried and removed once already, for spending a slot on
// every one of 275 flight rows forever. Gated to the flight's own window it
// costs nothing on the other 270.
const DEP = Date.parse("2027-01-22T16:57:00Z");
const ARR = Date.parse("2027-01-22T23:30:00Z");
const flight = { transportation_type: "airplane", transport_number: "AS1412",
  departure_at: "2027-01-22T16:57:00Z", arrival_at: "2027-01-22T23:30:00Z" };
const H = 3600000;
t("in the air", trackable(flight, DEP + 2 * H), true);
t("at the gate, an hour before", trackable(flight, DEP - H), true);
// The night before, because that is when the question is "where is the
// aircraft now" — the inbound is what makes tomorrow's departure real.
t("the evening before", trackable(flight, DEP - 20 * H), true);
t("but not a week out", trackable(flight, DEP - 7 * 24 * H), false);
t("exactly 24h before, just in", trackable(flight, DEP - 24 * H), true);
t("a minute earlier, not yet", trackable(flight, DEP - 24 * H - 60000), false);
// After landing, because that is when someone checks whether the bags made a
// connection.
t("an hour after landing", trackable(flight, ARR + H), true);
t("but not the next day", trackable(flight, ARR + 30 * H), false);
// A flight with no arrival still gets a window rather than none at all.
t("no arrival time still has a window",
  trackable({ transportation_type: "airplane", transport_number: "AS1412",
    departure_at: "2027-01-22T16:57:00Z" }, DEP + 2 * H), true);
t("and that window ends",
  trackable({ transportation_type: "airplane", transport_number: "AS1412",
    departure_at: "2027-01-22T16:57:00Z" }, DEP + 20 * H), false);
// No time, no window — there is nothing to be in the middle of.
t("no departure time, no chip",
  trackable({ transportation_type: "airplane", transport_number: "AS1412" }, DEP), false);
t("an unparseable time, no chip",
  trackable({ transportation_type: "airplane", transport_number: "AS1412",
    departure_at: "not a date" }, DEP), false);
// The link test runs first: a car in its travel window still gets nothing.
t("a car in its window is still not trackable",
  trackable({ transportation_type: "car", transport_number: "SIXT",
    departure_at: "2027-01-22T16:57:00Z" }, DEP), false);

console.log("\nhow it is wired");
t("the chip is gated, not permanent", /if \(trackable\(o, Date\.now\(\)\)\) \{/.test(src), true);
t("and opens in its own tab", /alink\("📡 Track", fr24Url\(o\)\)/.test(src), true);
// alink sets rel=noopener; an external link handed a window reference is a
// tabnabbing vector, and this one goes to a third-party site.
t("external links carry rel=noopener", /a\.target = "_blank"; a\.rel = "noopener"/.test(src), true);
// No API key, no proxy, no scraping — the subscription is for the site and the
// app, and a link uses exactly that.
t("nothing calls an FR24 API", /api\.flightradar24|fr24\.com\/v1|flightradar24.*apikey/i.test(src), false);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
