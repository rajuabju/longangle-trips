// Check-in and check-out times you set yourself.
//
// Hotel status buys early check-in and late check-out, and those are the times
// that matter on the day. They are not what the confirmation says — and the
// confirmation is what the importer trusts. It matches a stay by confirmation
// number, compares field by field and PATCHes anything that differs, so a 4pm
// check-out typed into the app survived exactly until the hotel re-sent its
// standard 11am, at which point it was overwritten and logged as though the
// property had moved it.
//
// A locked field is the app telling the importer to leave that one alone. The
// rules below are what decides which fields are locked after a save.
//
// Fixtures are invented.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");

function grab(name) {
  const i = src.indexOf("  function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
eval(["lockedTimes", "isLocked", "sameInstant"].map(grab).join(String.fromCharCode(10)) +
  ";Object.assign(globalThis,{lockedTimes,isLocked,sameInstant});");

// The reordering half of this lives in the API, not the browser — the importer
// writes there too, and it is the one that moves a flight you did not move.
// Read it from the real file rather than restating it: a copy of CANCEL_PATH in
// a test once agreed with the test and disagreed with the router, and every
// save 404'd with a green suite.
const api = fs.readFileSync("functions/api/_core.js", "utf8");
function grabApi(name) {
  const i = api.indexOf("function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < api.length; j++) {
    if (api[j] === "{") { d++; seen = true; }
    else if (api[j] === "}") { d--; if (seen && !d) return api.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
const decls = api.slice(api.indexOf("const ORDERED_TABLES = "),
  api.indexOf(";", api.indexOf("const TIME_FIELDS = ")) + 1);
eval(decls + String.fromCharCode(10) +
  ["sameMoment", "dayKeyOf", "recordDays", "timeMoved", "daysTouchedBy", "touchesAnyDay"]
    .map(grabApi).join(String.fromCharCode(10)) +
  ";Object.assign(globalThis,{ORDERED_TABLES,TIME_FIELDS,sameMoment,dayKeyOf,recordDays,timeMoved,daysTouchedBy,touchesAnyDay});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

// The decision the save handler makes, mirrored from the hosting branch of
// openItemForm. Kept in step by the assertions at the bottom, which read the
// real source.
function decide(o, newStart, newEnd, keep) {
  const wasLocked = lockedTimes(o);
  const locked = [];
  const lock = (f) => { if (locked.indexOf(f) < 0) locked.push(f); };
  const movedStart = !sameInstant(newStart, o.starts_at);
  const movedEnd = !sameInstant(newEnd, o.ends_at);
  if (keep === "keep") {
    wasLocked.forEach(lock);
    if (movedStart) lock("starts_at");
    if (movedEnd) lock("ends_at");
    if (!locked.length) { lock("starts_at"); lock("ends_at"); }
  } else if (!wasLocked.length) {
    if (movedStart) lock("starts_at");
    if (movedEnd) lock("ends_at");
  }
  return locked;
}

const IN = "2027-01-23T21:00:00Z";     // 3pm local check-in
const OUT = "2027-01-26T17:00:00Z";    // 11am local check-out
const LATE = "2027-01-26T22:00:00Z";   // 4pm — the late check-out
const fresh = () => ({ starts_at: IN, ends_at: OUT });

// ---- reading the flag -------------------------------------------------------
t("a booking with nothing locked", lockedTimes({}), []);
t("a booking that has never been edited", lockedTimes({ starts_at: IN }), []);
t("one locked end", lockedTimes({ locked_times: ["ends_at"] }), ["ends_at"]);
t("isLocked answers per field", isLocked({ locked_times: ["ends_at"] }, "ends_at"), true);
t("and says no for the other one", isLocked({ locked_times: ["ends_at"] }, "starts_at"), false);
// The blob is writable through the API, so the field may be anything at all.
t("a string is not a lock list", lockedTimes({ locked_times: "ends_at" }), []);
t("nor is true", lockedTimes({ locked_times: true }), []);
t("nor an object", lockedTimes({ locked_times: { ends_at: true } }), []);
t("a null booking is not locked", isLocked(null, "ends_at"), false);

// ---- the same moment, written two ways --------------------------------------
// The database holds what the importer wrote, with milliseconds; the form
// round-trips through fromLocalInput, which strips them. A string compare called
// every untouched check-in "changed" and locked it — which quietly stops the
// importer updating a time nobody ever set. Caught in the browser against a real
// stay whose starts_at was "2027-01-23T02:45:00.000Z".
t("millis or not, it is the same instant",
  sameInstant("2027-01-23T02:45:00Z", "2027-01-23T02:45:00.000Z"), true);
t("an offset form is the same instant too",
  sameInstant("2027-01-23T02:45:00Z", "2027-01-22T20:45:00-06:00"), true);
t("a different minute is not", sameInstant("2027-01-23T02:45:00Z", "2027-01-23T02:46:00Z"), false);
t("both absent is the same", sameInstant(null, null), true);
t("one absent is not", sameInstant("2027-01-23T02:45:00Z", null), false);
t("blank counts as absent", sameInstant("", null), true);
t("two unparseable values fall back to a string compare",
  sameInstant("sometime", "sometime"), true);
t("and differ when the strings do", sameInstant("sometime", "later"), false);
// The regression itself, end to end.
t("saving an untouched stay whose times carry millis locks nothing",
  decide({ starts_at: "2027-01-23T02:45:00.000Z", ends_at: "2027-01-27T17:00:00.000Z" },
    "2027-01-23T02:45:00Z", "2027-01-27T17:00:00Z", ""), []);

// ---- editing a time locks that time, and only that time ---------------------
t("changing check-out locks check-out", decide(fresh(), IN, LATE, ""), ["ends_at"]);
t("and leaves check-in alone", decide(fresh(), IN, LATE, "").indexOf("starts_at"), -1);
t("changing check-in locks check-in", decide(fresh(), "2027-01-23T18:00:00Z", OUT, ""), ["starts_at"]);
t("changing both locks both",
  decide(fresh(), "2027-01-23T18:00:00Z", LATE, ""), ["starts_at", "ends_at"]);
// Editing the room number must not lock the times as a side effect.
t("saving with no time change locks nothing", decide(fresh(), IN, OUT, ""), []);
// A booking with no check-out yet: filling one in is setting it, not overriding.
t("filling in a missing check-out locks it",
  decide({ starts_at: IN }, IN, OUT, ""), ["ends_at"]);

// ---- the explicit control ---------------------------------------------------
t("asking to keep, with nothing edited, locks both ends",
  decide(fresh(), IN, OUT, "keep"), ["starts_at", "ends_at"]);
// The case the automatic rule cannot reach: the time you want is already what
// the confirmation says, and you want it kept when a later one disagrees.
t("keep works even when the value is unchanged",
  decide(fresh(), IN, OUT, "keep").length, 2);
// Saving an untouched booking must not WIDEN the lock. Only check-out was
// locked; leaving the control alone and pressing Save keeps exactly that. The
// control is labelled "keep the times I have set" rather than naming both ends,
// because that is what it does.
t("keeping preserves the existing lock without widening it",
  decide({ starts_at: IN, ends_at: OUT, locked_times: ["ends_at"] }, IN, OUT, "keep"),
  ["ends_at"]);
t("and an edit alongside it adds only the edited end",
  decide({ starts_at: IN, ends_at: OUT, locked_times: ["ends_at"] },
    "2027-01-23T18:00:00Z", OUT, "keep"), ["ends_at", "starts_at"]);

// ---- releasing --------------------------------------------------------------
// "Update the times from the confirmation" is the deliberate opposite of a lock
// and wins over the automatic rule, so undoing one is a single explicit choice
// rather than a puzzle about which edit counted.
t("choosing to update releases the lock",
  decide({ starts_at: IN, ends_at: LATE, locked_times: ["ends_at"] }, IN, LATE, ""), []);
t("and releases even if a time was edited in the same save",
  decide({ starts_at: IN, ends_at: LATE, locked_times: ["ends_at"] }, IN, OUT, ""), []);
t("releasing an unlocked booking is still nothing",
  decide(fresh(), IN, OUT, ""), []);

// ---- a hire car's pick-up and drop-off, by the same rules -------------------
// A hire car gets extended by a phone call to the desk. The confirmation keeps
// saying the original drop-off, so without a lock every re-sent email puts it
// back and logs it as though the rental company had moved it.
const DEP = "2027-01-22T19:30:00Z";      // pick-up
const DROP = "2027-01-30T21:30:00Z";     // drop-off as booked
const LATE_DROP = "2027-01-31T02:00:00Z";
const car = (over) => Object.assign({ departure_at: DEP, arrival_at: DROP }, over || {});

// decideT mirrors the transport branch, which is the same shape as lodging's
// with departure_at/arrival_at in place of starts_at/ends_at.
function decideT(o, newDep, newArr, keep) {
  const wasLocked = lockedTimes(o);
  const locked = [];
  const lock = (f) => { if (locked.indexOf(f) < 0) locked.push(f); };
  const movedDep = !sameInstant(newDep, o.departure_at);
  const movedArr = !sameInstant(newArr, o.arrival_at);
  if (keep === "keep") {
    wasLocked.forEach(lock);
    if (movedDep) lock("departure_at");
    if (movedArr) lock("arrival_at");
    if (!locked.length) { lock("departure_at"); lock("arrival_at"); }
  } else if (!wasLocked.length) {
    if (movedDep) lock("departure_at");
    if (movedArr) lock("arrival_at");
  }
  return locked;
}

t("extending the drop-off locks the drop-off",
  decideT(car(), DEP, LATE_DROP, ""), ["arrival_at"]);
t("and leaves the pick-up alone",
  decideT(car(), DEP, LATE_DROP, "").indexOf("departure_at"), -1);
t("an earlier pick-up locks the pick-up",
  decideT(car(), "2027-01-22T17:00:00Z", DROP, ""), ["departure_at"]);
t("changing neither locks nothing", decideT(car(), DEP, DROP, ""), []);
t("asking to keep locks both ends", decideT(car(), DEP, DROP, "keep"), ["departure_at", "arrival_at"]);
t("choosing to update releases",
  decideT(car({ locked_times: ["arrival_at"] }), DEP, LATE_DROP, ""), []);
// The millisecond trap again: stored values carry them, the form's do not.
t("an untouched car locks nothing",
  decideT({ departure_at: "2027-01-22T19:30:00.000Z", arrival_at: "2027-01-30T21:30:00.000Z" },
    DEP, DROP, ""), []);

t("the transport form sends locked_times", /locked_times: lockedT/.test(src), true);
t("and offers the control", /name: "keep_times", label: "If this booking is re-sent"/.test(src), true);
t("a locked transport time is marked on the itinerary", /isLocked\(tr, "arrival_at"\)/.test(src), true);

// ---- a changed time puts the day back in order ------------------------------
// The itinerary sorts by day, then sort_order, then time — and sort_order wins
// when set, which a drag sets for every row on that day. So after one manual
// reorder, changing a booking's time left it exactly where it was.
t("moving a departure counts as a time change",
  timeMoved({ departure_at: DEP }, { departure_at: LATE_DROP }), true);
t("moving a check-out counts", timeMoved({ ends_at: DROP }, { ends_at: LATE_DROP }), true);
t("changing the room number does not",
  timeMoved({ departure_at: DEP }, { room_number: "402" }), false);
// The millisecond trap: what is stored carries them, what a form sends does not.
t("nor re-saving the same instant with milliseconds",
  timeMoved({ departure_at: "2027-01-22T19:30:00.000Z" }, { departure_at: DEP }), false);
t("clearing a time that was set counts",
  timeMoved({ ends_at: DROP }, { ends_at: null }), true);
t("a field absent from the patch is not a change",
  timeMoved({ departure_at: DEP, arrival_at: DROP }, { departure_at: DEP }), false);

// Which days an edit disturbs: a stay and a spanning car each open on one day
// and close on another, and both ends need putting back in order.
t("a car spans two days", recordDays(car()), ["2027-01-22", "2027-01-30"]);
t("a stay does too",
  recordDays({ starts_at: "2027-01-22T20:45:00Z", ends_at: "2027-01-27T17:00:00Z" }),
  ["2027-01-22", "2027-01-27"]);
t("a single-moment activity is one day",
  recordDays({ starts_at: "2027-01-25T16:00:00Z" }), ["2027-01-25"]);
t("nothing timed touches no day", recordDays({ name: "A note" }), []);

// The day is the LOCAL one. A 4:45am UTC start in Los Angeles is still the
// evening of the 22nd there; reading it as the 23rd would clear the wrong
// day's order and leave the right one pinned.
t("the day is read in the booking's own zone",
  recordDays({ starts_at: "2027-01-23T04:45:00Z", timezone: "America/Los_Angeles" }),
  ["2027-01-22"]);
t("a flight that lands the next day touches both",
  recordDays({ departure_at: "2027-01-22T23:30:00Z", departure_timezone: "America/Los_Angeles",
    arrival_at: "2027-01-23T18:05:00Z", arrival_timezone: "Europe/Paris" }),
  ["2027-01-22", "2027-01-23"]);
t("arrival falls back to the departure zone when it has none",
  recordDays({ departure_at: "2027-01-23T04:00:00Z", arrival_at: "2027-01-23T05:30:00Z",
    departure_timezone: "America/Los_Angeles" }), ["2027-01-22"]);
// Not the runtime's zone: this must answer the same on a laptop and in a Worker.
t("no zone at all is read as UTC",
  recordDays({ starts_at: "2027-01-23T04:45:00Z" }), ["2027-01-23"]);

// Which rows get their manual order cleared.
t("the days disturbed are the old ones and the new ones",
  daysTouchedBy({ starts_at: "2027-01-25T16:00:00Z" }, { starts_at: "2027-01-27T16:00:00Z" }),
  ["2027-01-25", "2027-01-27"]);
t("a move within one day disturbs only that day",
  daysTouchedBy({ starts_at: "2027-01-25T16:00:00Z" }, { starts_at: "2027-01-25T22:00:00Z" }),
  ["2027-01-25"]);
const DISTURBED = ["2027-01-22"];
t("a row on the disturbed day is cleared",
  touchesAnyDay({ starts_at: "2027-01-22T18:00:00Z" }, DISTURBED), true);
t("a row on another day is left alone",
  touchesAnyDay({ starts_at: "2027-01-25T18:00:00Z" }, DISTURBED), false);
// A stay is two rows on the itinerary, the day it opens and the day it closes.
// It does not print on the days between, so those must not clear its order.
t("a stay spanning the disturbed day but opening before it is left alone",
  touchesAnyDay({ starts_at: "2027-01-20T18:00:00Z", ends_at: "2027-01-24T17:00:00Z" }, DISTURBED), false);
t("a stay that checks out on the disturbed day is cleared",
  touchesAnyDay({ starts_at: "2027-01-20T18:00:00Z", ends_at: "2027-01-22T17:00:00Z" }, DISTURBED), true);
t("an untimed row is never cleared", touchesAnyDay({ name: "A note" }, DISTURBED), false);

// Only the three kinds that appear on the itinerary. Expenses carry a date and
// a sort_order of their own, and re-dating a receipt must not reshuffle a day.
t("the ordered tables are the itinerary's three",
  [...ORDERED_TABLES].sort(), ["activities", "hostings", "transportations"]);
// Named for real tables, not for the API's singular route names — patchRow is
// handed a table. "transportation" here would silently never reorder anything.
const KIND_TABLES = [...api.matchAll(/table: "([a-z]+)"/g)].map((m) => m[1]);
t("and every one of them is a real table",
  [...ORDERED_TABLES].every((x) => KIND_TABLES.includes(x)), true);
t("expenses are deliberately not among them", ORDERED_TABLES.has("expenses"), false);

// Zero is the documented "no manual order, use the clock" state.
t("the fix clears sort_order rather than renumbering",
  /SET sort_order=0,/.test(api), true);
// The blob is the copy compare-and-set reads; the column is the one the API
// hands back. Writing only one of them leaves them disagreeing.
t("and clears it in the blob as well as the column",
  /json_set\(data,'\$\.sort_order',0/.test(api), true);
t("rows already chronological are never touched",
  /sort_order IS NOT NULL AND sort_order<>0/.test(api), true);
t("only the trip being edited is reflowed", /WHERE trip_id=\? AND deleted_at IS NULL/.test(api), true);
// Before the read-back, or the PATCH answers with the order it just replaced.
const patchFn = grabApi("patchRow");
t("the reflow runs inside patchRow, before the row is read back",
  patchFn.indexOf("await reflowDays(") > 0 &&
  patchFn.indexOf("await reflowDays(") < patchFn.indexOf("const after ="), true);
t("and it is gated on the table and on a moved time",
  /ORDERED_TABLES\.has\(table\) && timeMoved\(stored, body\)/.test(api), true);
// The browser used to do this. Two copies of a rule drift, and one of them was
// blind to the importer.
t("the browser no longer does it itself", /restoreChronological/.test(src), false);

// ---- the source really does this -------------------------------------------
// decide() above is a copy, so it is worth proving the real branch agrees on the
// parts that are easy to get wrong later.
const form = src.slice(src.indexOf('if (kind === "hosting")'), src.indexOf('if (kind === "expense")'));
t("the form sends locked_times", /locked_times: locked/.test(form), true);
t("the explicit control exists", /name: "keep_times"/.test(form), true);
t("it defaults to keep when something is locked",
  /value: lockedTimes\(o\)\.length \? "keep" : ""/.test(form), true);
t("an edited check-in locks starts_at", /if \(movedStart\) lock\("starts_at"\)/.test(form), true);
t("an edited check-out locks ends_at", /if \(movedEnd\) lock\("ends_at"\)/.test(form), true);
t("and the comparison is by instant, not by string",
  /sameInstant\(newStart, o\.starts_at\)/.test(form) && /sameInstant\(newEnd, o\.ends_at\)/.test(form), true);
// The itinerary has to say so, or a 4pm check-out reads as the hotel's policy.
t("a locked time is marked on the itinerary", /isLocked\(h, "ends_at"\)/.test(src), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
