// Whether a message reaches the person it is for.
//
// Three faults, all in one small function and one CSS rule:
//
//   .toast sat at z-index 40 and .form-overlay sits at 50, so every message
//   fired from an open dialog -- validation refusals, save failures, the 403
//   notice -- painted BEHIND that dialog's darkened, blurred backdrop. The one
//   moment a toast carries load-bearing information is the moment a dialog is
//   open.
//
//   Every toast was position:fixed at the same coordinates, so a second one
//   landed exactly on top of a first that was still showing.
//
//   And 2.6 seconds was the duration for "Saved" and for "Couldn't save"
//   alike. Look away for three seconds -- the ordinary state of a phone -- and
//   the only record that a write failed is gone, with the UI showing the
//   pre-action state and nothing saying it did not happen.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");
const css = fs.readFileSync("public/styles.css", "utf8");

const fn = (decl) => {
  const i = app.indexOf(decl);
  if (i < 0) throw new Error("missing " + decl);
  let d = 0, seen = false;
  for (let j = i; j < app.length; j++) {
    if (app[j] === "{") { d++; seen = true; }
    else if (app[j] === "}") { d--; if (seen && !d) return app.slice(i, j + 1); }
  }
  throw new Error("unterminated " + decl);
};
const toastFn = fn("  function toast(msg, opts) {");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

// The rule that decides tone, lifted out and run directly rather than described.
const isBad = (msg) => /^(Couldn't|Couldn’t|Could not|Failed|.*failed)/.test(String(msg));

console.log("\na failure is recognised as one");
t("Couldn't save", isBad("Couldn't save: network"), true);
t("a curly apostrophe counts too", isBad("Couldn’t save"), true);
t("Upload failed", isBad("Upload failed"), true);
t("Delete failed", isBad("Delete failed"), true);
t("Couldn't reach the clipboard", isBad("Couldn't reach the clipboard."), true);
console.log("\nand an ordinary message is not");
t("Saved", isBad("Saved"), false);
t("Deleted", isBad("Deleted"), false);
t("Copied", isBad("Copied"), false);
t("2 trips have changed since your last visit", isBad("2 trips have changed since your last visit"), false);

console.log("\nthe tone is derived, not annotated at 32 call sites");
t("the pattern lives in toast()", /opts\.error != null \? !!opts\.error/.test(toastFn), true);
t("and a caller can still override it either way",
  /opts\.error != null/.test(toastFn), true);
// U8 added opts.ms so an undo toast can outlive both defaults (9s).
t("failures last longer than successes",
  /var TOAST_MS = 2600, TOAST_ERROR_MS = 6000, TOAST_UNDO_MS = 9000;/.test(app), true);
// An undo has to outlive both: you need time to notice what vanished.
t("and an undo outlives both", /ms: TOAST_UNDO_MS/.test(app), true);
t("callers can name their own duration", /opts\.ms \|\| \(bad \? TOAST_ERROR_MS : TOAST_MS\)/.test(app), true);
t("and the duration follows the tone", /bad \? TOAST_ERROR_MS : TOAST_MS/.test(toastFn), true);

console.log("\nassistive tech is told, at the right urgency");
// A live region that already exists is announced when its contents change; a
// div that appears and vanishes is announced unreliably or not at all.
t("one persistent live region", /function toastLayer\(\)/.test(app), true);
t("it is a status region", /toastHost\.setAttribute\("role", "status"\)/.test(app), true);
t("announced politely", /toastHost\.setAttribute\("aria-live", "polite"\)/.test(app), true);
// An alert interrupts; a status waits its turn. A failed save has earned it.
t("but a failure is an alert", /t\.setAttribute\("role", "alert"\)/.test(toastFn), true);

console.log("\nand it is actually on screen");
t("the layer outranks every overlay", /\.toast-layer \{[\s\S]*?z-index:60;/.test(css), true);
t("which is above .form-overlay's 50", /\.form-overlay \{[^}]*z-index:50;/.test(css), true);
// Stacking, not overlapping: a new toast pushes older ones up.
t("toasts stack in a column", /flex-direction:column-reverse;/.test(css), true);
t("with a gap between them", /\.toast-layer \{[\s\S]*?gap:8px;/.test(css), true);
t("and no longer position themselves", /\.toast \{[^}]*position:fixed/.test(css), false);
// bottom:26px alone sits inside the iPhone home-indicator band in the PWA.
t("clear of the home indicator", /bottom:calc\(26px \+ env\(safe-area-inset-bottom\)\)/.test(css), true);
// It must not become a transparent sheet that eats clicks meant for the dialog.
t("the layer does not steal clicks", /\.toast-layer \{[\s\S]*?pointer-events:none;/.test(css), true);
t("a failure looks like one", /\.toast-error \{[^}]*background:var\(--danger\)/.test(css), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
