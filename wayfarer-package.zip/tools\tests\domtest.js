// Form construction, actually executed.
//
// Every other suite here tests pure functions or asserts against the source
// text. That is the right shape for arithmetic and for rules, and it is blind
// to an entire class of bug: code that is correct in isolation and wrong in the
// order it runs.
//
// One got through on 2026-08-22. bucketFields called attachPlaceSearch BEFORE
// appending its container, so the host resolved to a node with no parentNode
// and `host.parentNode.insertBefore` threw. The throw escaped mid-build, so
// EVERY bucket-list idea's Edit dialog rendered as an empty box -- no address,
// no coordinates, no target window, no season, no airport. All 1349 tests
// passed. The feature was unreachable through the UI and nothing said so.
//
// So this suite runs the DOM-building code against a small fake DOM. It is not
// a browser and does not try to be; it implements exactly the four things the
// bug turned on -- appendChild, insertBefore, parentNode, nextSibling -- which
// is enough to catch an element being wired up before it exists.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");

function grab(name) {
  const head = "  function " + name + "(";
  const i = app.indexOf(head);
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < app.length; j++) {
    if (app[j] === "{") { d++; seen = true; }
    else if (app[j] === "}") { d--; if (seen && !d) return app.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}

// ---- the smallest DOM that can reproduce the failure -----------------------
function makeEl(tag) {
  const node = {
    tagName: tag, className: "", textContent: "", children: [], parentNode: null,
    appendChild(c) {
      if (c.parentNode) c.parentNode.remove(c);
      c.parentNode = this; this.children.push(c); return c;
    },
    insertBefore(c, ref) {
      c.parentNode = this;
      const i = ref ? this.children.indexOf(ref) : -1;
      if (i < 0) this.children.push(c); else this.children.splice(i, 0, c);
      return c;
    },
    remove(c) {
      const i = this.children.indexOf(c);
      if (i > -1) this.children.splice(i, 1);
    },
    addEventListener() {},
    focus() {}, select() {}, setAttribute() {}, removeAttribute() {},
    // bucketFields toggles classes and re-queries its own subtree.
    classList: null,
    querySelectorAll(sel) {
      const want = sel.replace(/^[.#]/, ""), out = [];
      const walk = (n) => n.children.forEach((c) => {
        if ((c.className || "").split(" ").indexOf(want) > -1) out.push(c);
        walk(c);
      });
      walk(this); return out;
    },
    get nextSibling() {
      if (!this.parentNode) return null;
      const i = this.parentNode.children.indexOf(this);
      return this.parentNode.children[i + 1] || null;
    },
  };
  const cl = new Set();
  node.classList = {
    add: (c) => { cl.add(c); node.className = [...cl].join(" "); },
    remove: (c) => { cl.delete(c); node.className = [...cl].join(" "); },
    toggle: (c, on) => { on ? cl.add(c) : cl.delete(c); node.className = [...cl].join(" "); },
    contains: (c) => cl.has(c),
  };
  return node;
}
function el(tag, cls, text) {
  const n = makeEl(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}
// Only reached when the Find button is pressed, which these tests never do.
const ext = async () => ({ results: [] });

eval(grab("attachPlaceSearch") + ";globalThis.attachPlaceSearch=attachPlaceSearch;");

// ---- bucketFields, executed ------------------------------------------------
//
// The suite exists because this function once rendered every idea as an empty
// box. It now also decides whether to render the airport half at all -- under
// 250 miles from home an idea is a drive, and asserting that in source text
// only proves the string is present, not that the field is gone from the form.
const decl = (start) => app.slice(app.indexOf(start), app.indexOf(";", app.indexOf(start)) + 1);
eval([
  decl("  var HOME = {"), decl("  var DRIVE_MAX_KM = "), decl("  var DEFAULT_NIGHTS = "),
  decl("  var MONTHS = ["), grab("km"), grab("coordPair"),
].join("\n") + ";Object.assign(globalThis,{HOME,DRIVE_MAX_KM,DEFAULT_NIGHTS,MONTHS,km,coordPair});");
const api = async () => ({});
// Your own flown-airport history, fetched alongside the nearby list so the
// chips can say "you have flown here 4x". Empty here: these tests are about
// what the form BUILDS, and the chips arrive later from a promise.
const airports = async () => [];
const toast = () => {};
const prettyHost = (u) => String(u);
const addLinkRow = (host) => host.appendChild(el("div", "link-row"));
eval(grab("bucketFields") + ";globalThis.bucketFields=bucketFields;");

// Every label and input the form puts on screen, flattened.
const labels = (panel) => {
  const out = [];
  const walk = (n) => n.children.forEach((c) => {
    if (c.textContent) out.push(String(c.textContent));
    walk(c);
  });
  walk(panel); return out;
};
const inputs = (panel) => {
  const out = [];
  const walk = (n) => n.children.forEach((c) => {
    if (c.tagName === "input") out.push(c.className + ":" + (c.value || ""));
    walk(c);
  });
  walk(panel); return out;
};


let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};
const tryIt = (fn) => { try { fn(); return null; } catch (e) { return e.message; } };
const classes = (n) => n.children.map((c) => c.className);

console.log("\nthe ordinary case — an address row already in the form");
{
  const wrap = el("div", "wrap"), panel = el("div", "panel");
  panel.appendChild(wrap);
  const row = el("div", null), addr = el("input", "form-input");
  row.appendChild(addr); wrap.appendChild(row);
  const coords = el("div", "peek-coords");
  const lat = el("input", "peek-coord"), lon = el("input", "peek-coord");
  coords.appendChild(lat); coords.appendChild(lon); wrap.appendChild(coords);

  const boom = tryIt(() => attachPlaceSearch(wrap,
    { name: el("input"), address: addr, latitude: lat, longitude: lon }, {}));
  t("it does not throw", boom, null);
  // Directly beneath the address it fills in, and above the coordinates it writes.
  t("the search bar lands after the address row",
    classes(wrap), [null, "place-search", "place-results", "peek-coords"].map((c) => c || ""));
}

console.log("\nthe bug — wired up before the container exists");
{
  // Exactly the old bucketFields shape: `wrap` is not attached to anything yet,
  // and the address input is a direct child of it, so the host IS `wrap`.
  const wrap = el("div", "wrap");
  const addr = el("input", "form-input");
  wrap.appendChild(addr);
  const lat = el("input", "peek-coord"), lon = el("input", "peek-coord");
  const coords = el("div", "peek-coords");
  coords.appendChild(lat); coords.appendChild(lon); wrap.appendChild(coords);

  const boom = tryIt(() => attachPlaceSearch(wrap,
    { name: el("input"), address: addr, latitude: lat, longitude: lon }, {}));
  // THE regression. This threw, and the throw escaped mid-build and took the
  // entire dialog with it. One misused argument must cost its own feature, not
  // every field below it.
  t("an unattached container no longer throws", boom, null);
  t("the search bar still gets a home", classes(wrap).includes("place-search"), true);
  t("and so do the results", classes(wrap).includes("place-results"), true);
}

console.log("\nand it still declines when there is nothing to fill in");
{
  const wrap = el("div", "wrap"), panel = el("div", "panel");
  panel.appendChild(wrap);
  const row = el("div", null), addr = el("input", "form-input");
  row.appendChild(addr); wrap.appendChild(row);
  // No coordinate inputs: there is nowhere to put a result, so there should be
  // no search bar offering to find one.
  const boom = tryIt(() => attachPlaceSearch(wrap, { address: addr }, {}));
  t("no coordinate fields, no search bar", boom, null);
  t("and nothing was added", classes(wrap).includes("place-search"), false);
}

console.log("\nthe call site that broke");
// Belt and braces alongside the behavioural test above: in bucketFields the
// rows must be in the tree BEFORE the search is attached.
const bf = app.slice(app.indexOf("  function bucketFields("));
const body = bf.slice(0, bf.indexOf("attachPlaceSearch("));
t("the address row is appended first", /wrap\.appendChild\(addrRow\)/.test(body), true);
t("the coordinate row too", /wrap\.appendChild\(coordRow\)/.test(body), true);
t("the address input is not a bare child of wrap",
  /wrap\.appendChild\(addrIn\)/.test(bf), false);
t("the fallback exists in the function itself",
  /var anchor = host\.parentNode;/.test(app), true);
t("and it appends rather than throwing",
  /host\.appendChild\(bar\); host\.appendChild\(out\);/.test(app), true);

console.log("\nthe fields the planner added are all still built");
// The empty dialog had none of these. Each is asserted by the label it renders,
// so deleting one fails here rather than silently shipping a shorter form.
["Address", "When you'd go", "Best season", "Fly into", "Links"].forEach((L) => {
  t('"' + L + '" is in the form',
    bf.indexOf('"peek-label", "' + L + '"') > -1, true);
});

console.log("\nan idea you would fly to");
{
  // Nantucket: 2,653 miles. The airport half belongs.
  const panel = el("div", "panel");
  const boom = tryIt(() => bucketFields(panel, {
    place: "The Nantucket Hotel", latitude: 41.2835, longitude: -70.0995,
    airport: "ACK", airport_auto: true,
  }));
  t("it builds without throwing", boom, null);
  t("and is not an empty box", panel.children.length > 0, true);
  t("it offers somewhere to fly into",
    labels(panel).some((x) => /Fly into/.test(x)), true);
  t("and does not claim you would drive",
    labels(panel).some((x) => /near enough to drive/.test(x)), false);
}

console.log("\nan idea you would drive to");
{
  // Terranea: 22 miles down the coast. It was being offered LAX.
  const panel = el("div", "panel");
  const boom = tryIt(() => bucketFields(panel, {
    place: "Terranea Resort", latitude: 33.7397558, longitude: -118.3978141,
    airport: null, airport_auto: null,
  }));
  t("it builds without throwing", boom, null);
  t("and is still a full form, not an empty box", panel.children.length > 0, true);
  t("the airport field is gone entirely",
    labels(panel).some((x) => /Fly into/.test(x)), false);
  t("and so is its input",
    inputs(panel).some((x) => /ap-in|airport/i.test(x)), false);
  t("it says why, so it does not read as broken",
    labels(panel).some((x) => /near enough to drive/.test(x)), true);
  t("and shows the distance it decided on",
    labels(panel).some((x) => /23 miles from home/.test(x)), true);
  // The rest of the form must survive the amputation.
  t("the place field is still there",
    inputs(panel).some((x) => /Terranea/.test(x)), true);
}

console.log("\nan idea with no location at all");
{
  // Whitewater rafting: no address yet, by decision. Neither branch applies.
  const panel = el("div", "panel");
  const boom = tryIt(() => bucketFields(panel, {
    place: "Whitewater Rafting", latitude: null, longitude: null, no_location: 1,
  }));
  t("it builds without throwing", boom, null);
  t("and offers the airport field, since nothing rules it out",
    labels(panel).some((x) => /Fly into/.test(x)), true);
  t("without claiming a drive it cannot measure",
    labels(panel).some((x) => /near enough to drive/.test(x)), false);
}

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
