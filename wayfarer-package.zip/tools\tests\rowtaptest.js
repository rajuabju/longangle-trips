// U26 -- tapping an itinerary row opens the thing it describes.
//
// Every control on these rows already called stopPropagation. They were written
// to guard a row handler that did not exist, so the row was built as though it
// were tappable, looked tappable, and did nothing. The only way into an item
// was a 22px pencil pinned to the end of a chip row that scrolls sideways on a
// phone.
//
// Check-out rows are the sharp end of it. They deliberately carry no Edit chip
// -- a second copy of the same controls on the same booking is worse clutter --
// which left them with no way in at all. Measured on trip 1141871: of 13 rows,
// 3 had no Edit chip. Those three were unreachable from the itinerary.
//
// Verified live:
//   tapping a check-out row  -> Edit "Palacio Duhau - Park Hyatt Buenos Aires"
//   tapping an ordinary row  -> Edit "LATAM Airlines LA2605"
//   tapping the Maps chip    -> its own sheet, and NOT the row editor
//   cursors                  -> grab on draggable rows, pointer on check-out
//   all 13 rows              -> is-tappable
//
// NOT browser-verified: the text-selection guard. Programmatic selections do not
// take in the preview pane -- String(getSelection()) reads empty immediately
// after addRange, because the document is not focused -- so the threshold is
// exercised here instead, against the real expression.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");
const css = fs.readFileSync("public/styles.css", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

console.log("\nthe row opens the item");
t("a click handler exists on the row", /row\.classList\.add\("is-tappable"\);\s*\n\s*row\.addEventListener\("click", function \(\) \{/.test(app), true);
// cfg is the same object the Edit chip calls, so the row and the chip cannot
// drift into opening different things.
t("through the same opener the Edit chip uses", /if \(cfg\) \{\s*\n\s*row\.classList\.add\("is-tappable"\)/.test(app), true);
t("and the chip still calls it too", /ed\.addEventListener\("click", function \(ev\) \{ ev\.stopPropagation\(\); cfg\.open\(\); \}\);/.test(app), true);

console.log("\ncheck-out rows are included on purpose");
// The drag block is gated on !e.isCheckout; the tap block is NOT. That
// difference is the fix: those rows had no other way in.
t("dragging is still limited to non-checkout rows", /if \(cfg && !e\.isCheckout\) \{\s*\n\s*row\.setAttribute\("draggable", "true"\);/.test(app), true);
t("but tapping is not", /if \(cfg\) \{\s*\n\s*row\.classList\.add\("is-tappable"\);/.test(app), true);
// And the chips stay as they were -- this adds a way in without adding clutter.
t("check-out rows still carry no edit or delete chip", /if \(cfg && !e\.isCheckout\) \{\s*\n\s*var ed = el\("button", "linkchip is-edit"/.test(app), true);

console.log("\nchild controls keep their own jobs");
// These were already stopping propagation for a handler that did not exist.
// Now that one does, they are load-bearing rather than decorative.
["box", "tog", "rTog", "tb", "att", "ed", "del"].forEach(function (v) {
  t("  " + v + " stops propagation", new RegExp("\\b" + v + "\\.addEventListener\\(\"click\", function \\(ev\\) \\{ ev\\.stopPropagation\\(\\);").test(app), true);
});

console.log("\nselecting text is not tapping");
// Dragging across a confirmation code to copy it ends in a click event on the
// row. Without this, letting go opens the editor over the text you were
// selecting. Run against the real expression rather than described.
const guard = (selText) => {
  const sel = selText === null ? null : { toString: () => selText };
  return !(sel && String(sel).replace(/\s/g, "").length > 2);   // true = the tap proceeds
};
t("no selection at all lets the tap through", guard(null), true);
t("an empty selection too", guard(""), true);
// A stray one or two characters is a slipped click, not an attempt to copy.
t("one stray character is not a selection", guard("A"), true);
t("nor two", guard("AB"), true);
t("three is", guard("ABC"), false);
t("a confirmation code blocks it", guard("XKCD42"), false);
// Whitespace does not count toward the threshold: selecting across a gap
// between two chips can pick up newlines and nothing else.
t("whitespace alone does not block", guard("   \n  \t "), true);
t("and is not counted toward the three", guard(" A  B "), true);
t("but real text around it is", guard(" LATAM 2605 "), false);
t("the source uses exactly that test", /if \(sel && String\(sel\)\.replace\(\/\\s\/g, ""\)\.length > 2\) return;/.test(app), true);

console.log("\nit looks like something you can tap");
// A draggable row keeps grab: it really is draggable, and that is the more
// specific affordance. A check-out row is not draggable and is the main reason
// this exists, so it gets the pointer.
t("pointer only where the row is not draggable",
  /\.itin-row\.is-tappable:not\(\[draggable="true"\]\) \{ cursor:pointer; \}/.test(css), true);
t("and draggable rows keep grab", /\.itin-row\[draggable="true"\] \{ cursor:grab; \}/.test(css), true);
t("both get a hover wash", /\.itin-row\.is-tappable:hover \{ background:color-mix/.test(css), true);
// There is no hover on touch, and a sticky hover state on a phone reads as a
// selected row that will not deselect.
t("but only where hover exists", /@media \(hover:hover\) \{\s*\n\s*\.itin-row\.is-tappable:hover/.test(css), true);

console.log("\nthe keyboard path is the chip, not the row");
// The row contains real buttons, so it is deliberately NOT given role=button
// or a tabindex: a container with role=button wrapping buttons is invalid, and
// screen readers flatten it and lose the controls inside.
//
// That decision was asserted negatively at first -- "no role is set", "not
// tabbable" -- which check-vacuous rightly rejected: neither pattern matched
// any of 226 versions, because the code they forbid was never written. An
// assertion that has never been capable of failing guards nothing. What is
// worth stating is the thing that IS true and must stay true: the chip is a
// real focusable button, and it is what a keyboard reaches.
t("the Edit chip is a real button", /var ed = el\("button", "linkchip is-edit", "✎ Edit"\); ed\.type = "button";/.test(app), true);
t("and it is pinned so overflow cannot bury it", /ed\.dataset\.alwaysShow = "1";/.test(app), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
