// Flight status from AeroAPI.
//
// Two things decide whether this is worth having. It must be free — the
// Personal tier includes $5 of usage a month and nothing here is worth an
// unexpected bill — and it must not corrupt the itinerary with a delay.
//
// So the tests are mostly about restraint: when NOT to query, what NOT to
// overwrite, and what to do when the feed says nothing.
//
// Fixtures are invented. No key, no network: the pure functions are exercised
// directly and the run loop's contract is asserted against the source.
const fs = require("fs");
const path = require("path");
const W = path.join("workers", "flight-status", "src", "index.js");
const src = fs.readFileSync(W, "utf8");
const app = fs.readFileSync("public/app.js", "utf8");

// The Worker is an ES module; pull the pure exports out by hand rather than
// dragging in a loader.
function grab(name) {
  const i = src.indexOf("export function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1).replace(/^export /, ""); }
  }
  throw new Error("unterminated " + name);
}
const ICAO_SRC = src.slice(src.indexOf("const ICAO = {"), src.indexOf("};", src.indexOf("const ICAO = {")) + 2);
const MAXF = src.slice(src.indexOf("export const MAX_FUTURE_MS"), src.indexOf(";", src.indexOf("export const MAX_FUTURE_MS")) + 1).replace(/^export /, "");
eval(ICAO_SRC + String.fromCharCode(10) + MAXF + String.fromCharCode(10) +
  ["aeroIdent", "checkIntervalMinutes", "dueForCheck", "statusDiff", "liveStatus", "pickFlight", "withinAeroWindow"]
  .map(grab).join(String.fromCharCode(10)) +
  ";Object.assign(globalThis,{aeroIdent,checkIntervalMinutes,dueForCheck,statusDiff,liveStatus,pickFlight,withinAeroWindow,MAX_FUTURE_MS});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

// ---- which flight to ask about ---------------------------------------------
// The database stores IATA ("AS1412"); AeroAPI resolves ICAO exactly, and an
// IATA code can be shared by two carriers in different regions.
t("Alaska", aeroIdent("AS1412"), "ASA1412");
t("American", aeroIdent("AA1595"), "AAL1595");
t("Southwest", aeroIdent("WN22"), "SWA22");
t("Delta", aeroIdent("DL395"), "DAL395");
t("Air France", aeroIdent("AF1025"), "AFR1025");
t("a numeric-letter code", aeroIdent("Y4885"), "VOI885");
t("lower case and spaces are tolerated", aeroIdent(" as 1412 "), "ASA1412");
// An unmapped carrier is not an error; the IATA ident usually works.
t("an unknown carrier passes through", aeroIdent("XX123"), "XX123");
t("something that is not a flight number passes through", aeroIdent("N628TS"), "N628TS");
t("nothing in, nothing out", aeroIdent(""), null);
t("null in, nothing out", aeroIdent(null), null);
// Every carrier in the database resolves. This is the closed set the comment
// promises; if a new airline appears the map needs a line, not a lookup service.
["AA", "AF", "AM", "AS", "B6", "BA", "CX", "DL", "HA", "JL", "LA", "TO", "UA", "WN", "Y4"]
  .forEach((c) => t("carrier " + c + " is mapped", aeroIdent(c + "100").length > 5, true));

// ---- when to ask, which is what keeps it free ------------------------------
const HOUR = 3600000;
const now = Date.parse("2026-09-27T09:00:00Z");
const flight = (over) => Object.assign({
  departure_at: "2026-09-27T16:30:00Z", arrival_at: "2026-09-27T19:00:00Z",
}, over || {});

t("far out, four times a day", checkIntervalMinutes(20 * 60), 360);
t("same day, hourly", checkIntervalMinutes(6 * 60), 60);
t("close in, every ten minutes", checkIntervalMinutes(60), 10);
t("in the air, every ten minutes", checkIntervalMinutes(-30), 10);

t("never asked, so ask", dueForCheck(flight(), now), true);
t("asked a minute ago, seven hours out: not yet",
  dueForCheck(flight({ last_status_check: new Date(now - 60000).toISOString() }), now), false);
t("asked two hours ago, seven hours out: yes",
  dueForCheck(flight({ last_status_check: new Date(now - 2 * HOUR).toISOString() }), now), true);
// An hour before departure the cadence tightens.
const soon = Date.parse("2026-09-27T15:45:00Z");
t("asked five minutes ago, forty-five out: not yet",
  dueForCheck(flight({ last_status_check: new Date(soon - 5 * 60000).toISOString() }), soon), false);
t("asked fifteen minutes ago, forty-five out: yes",
  dueForCheck(flight({ last_status_check: new Date(soon - 15 * 60000).toISOString() }), soon), true);
// Landed and settled: stop. This is the rule that stops a finished flight being
// polled forever at ten-minute intervals.
const later = Date.parse("2026-09-27T22:00:00Z");
t("three hours after landing, stop asking", dueForCheck(flight(), later), false);
t("one hour after landing, still asking",
  dueForCheck(flight(), Date.parse("2026-09-27T19:30:00Z")), true);
t("a flight with no departure time is not asked about",
  dueForCheck({ departure_at: null }, now), false);
t("nor one with an unparseable time",
  dueForCheck({ departure_at: "next Tuesday" }, now), false);

// ---- what gets written, and what does not ----------------------------------
const stored = { departure_gate: "22", departure_terminal: "6", departure_at: "2026-09-27T16:30:00Z" };

t("a new gate is a change",
  statusDiff(stored, { gate_origin: "31" }), { departure_gate: "31" });
t("the same gate is not", statusDiff(stored, { gate_origin: "22" }), {});
t("a numeric gate matching a stored string is not",
  statusDiff({ departure_gate: "22" }, { gate_origin: 22 }), {});
// The one that matters. Gates are assigned late, so the feed is empty for most
// of a flight's life; letting that blank through would erase the gate from the
// confirmation email every single run.
t("an empty gate never erases a known one", statusDiff(stored, { gate_origin: "" }), {});
t("nor does a missing one", statusDiff(stored, {}), {});
t("nor null", statusDiff(stored, { gate_origin: null }), {});
t("a gate arriving for the first time is a change",
  statusDiff({}, { gate_origin: "31" }), { departure_gate: "31" });
t("terminals travel the same way",
  statusDiff({}, { terminal_origin: "6", terminal_destination: "B" }),
  { departure_terminal: "6", arrival_terminal: "B" });
// The booked time is never touched. A delay is a different fact from a schedule
// change, and overwriting the ticket's time loses what you would argue from.
t("a delay does not rewrite the booked departure",
  Object.keys(statusDiff(stored, { estimated_out: "2026-09-27T17:50:00Z", gate_origin: "22" })), []);
t("the run body never sets departure_at", /body\.departure_at\s*=/.test(src), false);
t("nor arrival_at", /body\.arrival_at\s*=/.test(src), false);

// ---- the status block ------------------------------------------------------
const ls = liveStatus({
  scheduled_out: "2026-09-27T16:30:00Z", estimated_out: "2026-09-27T17:50:00Z",
  cancelled: false, status: "En Route", progress_percent: 40,
}, "2026-09-27T09:00:00Z");
t("a delay is computed in minutes", ls.delay_minutes, 80);
t("and the source is named", ls.source, "FlightAware AeroAPI");
t("early is negative", liveStatus({ scheduled_out: "2026-09-27T16:30:00Z",
  estimated_out: "2026-09-27T16:10:00Z" }, "x").delay_minutes, -20);
t("no estimate, no delay", liveStatus({ scheduled_out: "2026-09-27T16:30:00Z" }, "x").delay_minutes, null);
t("an actual departure counts as the estimate",
  liveStatus({ scheduled_out: "2026-09-27T16:30:00Z", actual_out: "2026-09-27T16:35:00Z" }, "x").delay_minutes, 5);
t("cancelled is carried through", liveStatus({ cancelled: true }, "x").cancelled, true);
t("and is a boolean even when the feed is loose",
  liveStatus({ cancelled: 1 }, "x").cancelled, true);

// ---- picking our flight out of the feed ------------------------------------
// The same flight number flies every day and the query window spans more than
// one, so the ident alone is not enough.
const feed = [
  { scheduled_out: "2026-09-26T16:30:00Z", gate_origin: "yesterday" },
  { scheduled_out: "2026-09-27T16:30:00Z", gate_origin: "ours" },
  { scheduled_out: "2026-09-28T16:30:00Z", gate_origin: "tomorrow" },
];
t("the nearest scheduled departure wins",
  pickFlight(feed, "2026-09-27T16:30:00Z").gate_origin, "ours");
t("a small schedule drift still matches",
  pickFlight(feed, "2026-09-27T16:55:00Z").gate_origin, "ours");
t("more than a day apart is a different flight",
  pickFlight(feed, "2026-10-15T16:30:00Z"), null);
t("an empty feed matches nothing", pickFlight([], "2026-09-27T16:30:00Z"), null);
t("a feed of junk matches nothing", pickFlight([{ ident: "x" }], "2026-09-27T16:30:00Z"), null);
t("no departure to compare against", pickFlight(feed, null), null);

// ---- AeroAPI will not answer about next week -------------------------------
// Found by the first live probe, which failed on all three upcoming flights at
// once: "Invalid end bound: time is too far in the future (limit: 2 days)".
// The window was departure +/- 24h, so a flight leaving tomorrow put `end` 2.4
// days out and the whole call came back 400. Every scheduled run would have
// failed exactly this way, reporting errors and never a single status.
const NOW = Date.parse("2026-08-18T02:00:00Z");
t("a flight in six hours is answerable",
  withinAeroWindow("2026-08-18T08:00:00Z", NOW), true);
t("a flight in a day and a half is answerable",
  withinAeroWindow("2026-08-19T14:00:00Z", NOW), true);
t("a flight in three days is not", withinAeroWindow("2026-08-21T02:00:00Z", NOW), false);
t("nor one next month", withinAeroWindow("2026-09-27T02:00:00Z", NOW), false);
t("a flight in the past is still answerable", withinAeroWindow("2026-08-17T22:00:00Z", NOW), true);
t("an unparseable date is not", withinAeroWindow("soon", NOW), false);
t("the ceiling stops short of the stated two days", MAX_FUTURE_MS < 48 * 3600000, true);
// The window sent to AeroAPI is clamped, not just checked.
t("the request end is clamped to the ceiling", /Math\.min\(dep \+ 12 \* 3600000, ceiling\)/.test(src), true);
t("and the start cannot exceed it either", /Math\.min\(dep - 12 \* 3600000, ceiling - 3600000\)/.test(src), true);
t("the run skips what AeroAPI cannot answer", /if \(!withinAeroWindow\(row\.departure_at, nowMs\)\)/.test(src), true);

// ---- the cost ceiling ------------------------------------------------------
// The part that makes "free" a guarantee rather than an estimate.
t("a monthly cap exists", /AEROAPI_MONTHLY_CAP/.test(src), true);
t("the run refuses to start past it", /usage\.queries >= cap/.test(src), true);
t("and stops mid-run at it", /if \(usage\.queries >= cap\) \{ report\.capped = true; break; \}/.test(src), true);
t("the counter resets with the month", /v\.month !== month/.test(src), true);
// A failed call is not a billed call. Counting attempts meant one systematic
// error — a bad window, an expired key — could burn the whole month's allowance
// without producing a single answer, and lock it out for calls never charged.
t("only a successful query is counted", src.indexOf("usage.queries++") > src.indexOf("live = pickFlight(await fetchStatus"), true);
t("failures have their own ceiling instead", /attempts >= MAX_ATTEMPTS/.test(src), true);
t("only one page is ever requested, since billing is per page", /max_pages=1/.test(src), true);
t("a flight that answers nothing still stamps the check",
  /const body = \{ last_status_check: nowIso \};/.test(src), true);
t("the window is bounded either side of departure", /24 \* 3600000/.test(src), true);
t("a dry run writes nothing", /if \(!dry\)/.test(src), true);

// ---- how it reaches the app ------------------------------------------------
t("writes go through the ingest API, not the D1 binding",
  /API_BASE \+ "\/trip\/" \+ tripId \+ "\/transportation\/"/.test(src), true);
t("guarded by the importer key", /"X-Importer-Key": env\.IMPORTER_KEY/.test(src), true);
t("the manual endpoint is closed without it", /return new Response\("Not found", \{ status: 404 \}\)/.test(src), true);
t("changes are appended, not replaced", /prior\.concat\(entries\)/.test(src), true);
t("and trimmed to the same twenty the importer keeps", /slice\(-MAX_CHANGES\)/.test(src), true);

// ---- what the app does with it ---------------------------------------------
t("the client reads live_status", /function liveStatusOf\(o\)/.test(app), true);
t("stale status is not shown", /STATUS_STALE_H/.test(app), true);
t("a cancellation reads as one", /"Cancelled"/.test(app), true);
t("the pill goes on the row", /statusPill\(o\)/.test(app), true);
// A check-out row is the second half of one booking; two pills for one flight
// would read as two flights.
t("not on a second-half row", /lsPill && !e\.isCheckout/.test(app), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
