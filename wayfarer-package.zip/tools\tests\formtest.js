// Fields that only belong on some items.
//
// Two removals, both measured against the whole database first:
//
//   room_number   — 0 of 216 lodging records carry one, and it had TWO editors:
//                   the lodging form and the room-assignment sheet.
//   seat, cabin, terminal, gate — 275 flights carry between 127 and 178 of
//                   them each; the 94 cars and road trips carry ZERO. Not one,
//                   across every transportation ever imported.
//
// So on a hire car those four were empty boxes asking a question with no
// answer, and Room number was an empty box on every hotel there has ever been.
//
// Fixtures are invented.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

// The transport branch, from its opening to the end of its save.
const transport = src.slice(src.indexOf('if (kind === "transport") {'),
  src.indexOf('await saveItem(trip, "transportation", "transportations"'));

console.log("\nseat, cabin, terminal and gate are a flight's business");
t("gated on the type", /var isFlight = \(o\.transportation_type \|\| "airplane"\) === "airplane";/.test(transport), true);
t("and only added when it is one", /if \(isFlight\) \{\s*tFields\.push\(/.test(transport), true);
["seat_number", "seat_class", "departure_terminal", "departure_gate"].forEach((f) => {
  const line = transport.slice(transport.indexOf("if (isFlight) {"), transport.indexOf("tFields.push(\n        { name: \"vehicle_description\""));
  t("  " + f + " is inside the flight branch", line.indexOf('name: "' + f + '"') > 0, true);
});
// A new transportation defaults to airplane, so adding a flight still offers
// them without having to save and reopen first.
t("a new item defaults to airplane and gets them", /o\.transportation_type \|\| "airplane"/.test(transport), true);

console.log("\nwhat a car's save does with them");
// Absent keys, not nulls. patchRow merges what it is sent, so an absent key
// leaves whatever is stored alone while null would wipe it. Nothing but a
// flight has any today, but "does not ask" and "erases" are different promises
// and only one of them was made.
t("a car sends no seat key at all", /body\.seat_number = /.test(transport), true);
t("and only inside the flight branch",
  /if \(isFlight\) \{\s*body\.seat_number = v\.seat_number \|\| null;/.test(transport), true);
t("all four are written for a flight",
  ["seat_number", "seat_class", "departure_terminal", "departure_gate"]
    .every((f) => new RegExp("body\\." + f + " = v\\." + f).test(transport)), true);
// The old unconditional line would have written null over a flight's real seat
// the moment the field stopped being rendered.
t("nothing writes them unconditionally any more",
  /^\s*seat_number: v\.seat_number \|\| null,/m.test(transport), false);

console.log("\nroom number is gone");
t("not on the lodging form", /name: "room_number", label: "Room number"/.test(src), false);
t("nor saved by it", /room_number: v\.room_number/.test(src), false);
// Removing one input and leaving an identical one two taps away is half a job.
t("nor on the room-assignment sheet", /el\("span", "seat-who", "Room number"\)/.test(src), false);
t("nor written by it", /room_number: room \|\| null/.test(src), false);
t("and no longer shown on the itinerary", /"Room " \+ o\.room_number/.test(src), false);
t("nor named in the changed-since list", /room_number: "Room"/.test(src), false);

console.log("\nwhat the room sheet still does");
// The question it is actually for: who is in this booking. A second room is a
// whole second booking here — all 42 same-property same-night pairs are stored
// that way — so the room label was never what distinguished them.
t("it still records who is in the booking",
  /var pax = people\.filter\(function \(p\) \{ return picked\[p\.id\]; \}\)/.test(src), true);
t("pax entries are just people now",
  /\.map\(function \(p\) \{ return \{ id: p\.id \}; \}\)/.test(src), true);
// The compare-and-set guard on pax is what stops two devices clobbering each
// other, and it must survive the field removal.
t("and the concurrent-edit guard survives",
  /if_match: \{ pax: Array\.isArray\(o\.pax\) \? o\.pax : \[\] \}/.test(src), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
