// U20 -- an upload that says how far along it is.
//
// It used to announce the filename in an ordinary toast and vanish after 2.6
// seconds. On anything larger than a screenshot that is most of the way BEFORE
// the upload starts, and for the rest of it the app looked idle -- which is
// exactly when somebody taps Attach again and uploads the same file twice. The
// limit is 25 MB, so this is not a hypothetical file size.
//
// fetch has an event for bytes received and none for bytes sent, so an upload
// that reports progress has to go through XMLHttpRequest. Nothing else in the
// app does; api() is untouched.
//
// Verified live on a throwaway trip:
//   a 3 MB PDF uploaded through the real picker -> document row written with
//     size 3145728, so the XHR path carries multipart correctly
//   instrumenting XMLHttpRequest.open and XMLHttpRequestUpload.addEventListener
//     -> POST /v1/trip/{id}/documents/upload with one "progress" listener
//        attached, and zero uploads left going through fetch
//   the bar, measured at 1280x800 with the transition disabled:
//     0 / 65 / 130 / 195 / 260 px on a 260px track -- exactly proportional
//   the toast is 292px, the label sits on one line, the bar sits under it, and
//     an ordinary toast beside it stays 77px rather than being stretched
//   and captured as it appeared, mid-upload, on the real code path:
//     role="progressbar", aria-label "Uploading ZZ-aria-check.pdf…",
//     valuemin 0, valuemax 100, valuenow 0, the toast itself with NO aria-live
//     (the layer host already has one), display flex / column, and the sticky
//     toast gone afterwards leaving "Uploaded ZZ-aria-check.pdf"
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");
const css = fs.readFileSync("public/styles.css", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

const up = app.slice(app.indexOf("function uploadWithProgress"), app.indexOf("// Dismantling the trip view"));
const pick = app.slice(app.indexOf("function pickAndUpload"), app.indexOf("// Attaching from an itinerary row."));

console.log("\nprogress needs XHR, so uploads use XHR");
t("there is an upload with progress", /function uploadWithProgress\(path, fd, onProgress\)/.test(app), true);
t("it is an XMLHttpRequest", /var xhr = new XMLHttpRequest\(\);/.test(up), true);
t("posting to the same API base", /xhr\.open\("POST", API_BASE \+ path, true\);/.test(up), true);
t("with the progress event api\\(\\) cannot offer", /xhr\.upload\.addEventListener\("progress"/.test(up), true);
// api()'s header, verbatim -- "Token", not "Bearer".
t("carrying the same auth header as api()", /xhr\.setRequestHeader\("Authorization", "Token " \+ token\);/.test(up), true);
// A FormData body must carry the boundary the browser generated; setting
// Content-Type by hand strips it and the server cannot parse a single part.
t("and no Content-Type of our own", /setRequestHeader\("Content-Type"/.test(up), false);

console.log("\nthe numbers it reports are honest");
// Some servers and proxies strip the length. A bar that invents a percentage is
// worse than one that admits it does not know.
t("an unknown total reports null rather than guessing",
  /ev\.lengthComputable && ev\.total \? ev\.loaded \/ ev\.total : null/.test(up), true);
t("and the bar goes indeterminate on null", /if \(fraction == null\) \{/.test(app), true);
t("rather than sitting at zero", /track\.classList\.add\("is-indeterminate"\);/.test(app), true);
// The last byte SENT is not the last thing that happens: the server still has
// to write to R2 and D1. 100% with no explanation reads as stuck.
t("the wait after the last byte is named", /xhr\.upload\.addEventListener\("load", function \(\) \{ onProgress\(1, "Saving/.test(up), true);
t("a fraction outside 0..1 cannot escape", /Math\.max\(0, Math\.min\(1, fraction\)\)/.test(app), true);

console.log("\nevery way it can end, ends the toast");
t("success resolves with the parsed body", /resolve\(data\);/.test(up), true);
t("a non-2xx rejects with the server's words", /\(data && \(data\.detail \|\| data\.error\)\)/.test(up), true);
// A network failure has no status and no body; "Upload failed (0)" is not a
// sentence anyone can act on.
t("a dead connection gets its own message", /reject\(new Error\("The connection failed\."\)\);/.test(up), true);
t("a timeout too", /reject\(new Error\("The upload timed out\."\)\);/.test(up), true);
t("and an abort", /reject\(new Error\("Upload cancelled\."\)\);/.test(up), true);
// api() clears the panel cache on every write. This path bypasses api(), and a
// document added here can change what Check Trips reports.
t("a successful upload still invalidates the sweeps", /panelCache = \{\};/.test(up), true);

console.log("\nthe toast stays for the length of the work");
t("toast() can be told not to expire", /if \(!opts\.sticky\) \{/.test(app), true);
t("progressToast uses it", /var t = toast\(msg, \{ error: false, sticky: true \}\);/.test(app), true);
// A sticky toast has no timer. If a caller forgets one exit path it sits there
// for ever, so both endings are on the handle rather than left to the caller.
t("it hands back done and fail, not an element", /done: function \(m\) \{ close\(m, false\); \},/.test(app), true);
t("and fail marks the replacement as an error", /fail: function \(m\) \{ close\(m, true\); \},/.test(app), true);
t("the picker ends it on success", /prog\.done\("Uploaded " \+ f\.name\);/.test(pick), true);
t("and on failure", /prog\.fail\("Upload failed: " \+ e\.message\);/.test(pick), true);
t("no ordinary upload toast survives", /toast\("Uploading " \+ f\.name/.test(pick), false);
t("and the upload no longer goes through api()", /await api\(path, \{ method: "POST", body: fd \}\);/.test(app), false);
// toastHost is already a polite live region and this toast sits inside it, so a
// second aria-live nested within announces twice. Only the host declares one.
t("only the layer host is a live region", (app.match(/setAttribute\("aria-live", "polite"\)/g) || []).length, 1);
t("the bar is a real progressbar", /track\.setAttribute\("role", "progressbar"\);/.test(app), true);
t("with bounds", /aria-valuemin[\s\S]{0,80}aria-valuemax/.test(app), true);
t("and a name", /track\.setAttribute\("aria-label", msg\);/.test(app), true);
t("valuenow goes on the element carrying the role", /track\.setAttribute\("aria-valuenow", Math\.round\(pct\)\);/.test(app), true);
// A progressbar with no valuenow is how "working, amount unknown" is said.
// A stale number left behind would be worse than saying nothing.
t("and is dropped when the total is unknown", /track\.removeAttribute\("aria-valuenow"\);/.test(app), true);

console.log("\nthe bar is laid out, not merely styled");
// .toast is a plain block -- only .has-action sets display:flex -- so without
// this the flex-direction below was inert and the bar sat wherever block
// layout put it. Measured before the fix: display block, toast 111px.
t("has-progress declares its own display", /\.toast\.has-progress \{\s*\n\s*display:flex; flex-direction:column;/.test(css), true);
t("stretching to the layer", /align-self:stretch;/.test(css), true);
// The layer is position:fixed with no width, so it is shrink-to-fit around its
// widest toast. min() against 100% resolves to the LAYER, not the viewport, so
// it cannot overflow a narrow screen the way a flat 280px could.
t("sized without a viewport unit", /min-width:min\(280px,100%\); max-width:100%;/.test(css), true);
t("no vw in the progress rules", /\.toast\.has-progress \{[^}]*vw/.test(css), false);
t("the track clips an overfilled bar", /\.toast-track \{[^}]*overflow:hidden;/.test(css), true);
t("and the bar inherits the toast's colour", /\.toast-bar \{[^}]*background:currentColor;/.test(css), true);

console.log("\nand it respects a reduced-motion setting");
// A bar sweeping for ever is precisely the motion this setting exists for. It
// still has to read as busy, so it holds half-filled rather than disappearing.
t("the sweep is switched off", /@media \(prefers-reduced-motion: reduce\) \{[\s\S]*?animation:none; transform:none; width:50%;/.test(css), true);
t("and the fill stops easing", /@media \(prefers-reduced-motion: reduce\) \{[\s\S]*?\.toast-bar \{ transition:none; \}/.test(css), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
