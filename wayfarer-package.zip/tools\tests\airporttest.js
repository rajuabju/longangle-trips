// Which airport serves a place.
//
// /v1/airports answers "where have I flown", from this traveller's own history.
// That is right for distance and for "you have been here before", and WRONG for
// the question this answers: Blackberry Farm needs TYS, and TYS appears nowhere
// in fifteen years of flights. So this reads a real dataset, and the rules that
// matter are about not being confidently wrong with it:
//
//   NEAREST IS NOT ALWAYS BEST. Terranea's closest airport is Hawthorne, a
//   general-aviation field one kilometre nearer than LAX.
//   AN AUTO-FILLED VALUE MUST NEVER BECOME A MANUAL ONE by being saved back
//   unchanged, or it stops following the location forever.
//   AN UNRELATED EDIT MUST NEVER RELOCATE A CHOSEN AIRPORT.
//
// Coordinates below are real; the expected codes are checked against the
// shipped dataset rather than asserted from memory.
const fs = require("fs");
const core = fs.readFileSync("functions/api/_core.js", "utf8");
const app = fs.readFileSync("public/app.js", "utf8");
const gen = fs.readFileSync("tools/build-airports.js", "utf8");
const data = fs.readFileSync("functions/api/airports-data.js", "utf8");

// Anchored on the declaration, not the first bracket: the header comment
// documents the row shape as [IATA, lat, lon, city, isLarge, country].
const DECL = "export const AIRPORTS = ";
globalThis.AIRPORTS = JSON.parse(
  data.slice(data.indexOf(DECL) + DECL.length, data.lastIndexOf("]") + 1));
globalThis.AIRPORT_MAX_KM = Number(/AIRPORT_MAX_KM = (\d+)/.exec(core)[1]);

function grab(name) {
  const i = core.indexOf("function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < core.length; j++) {
    if (core[j] === "{") { d++; seen = true; }
    else if (core[j] === "}") { d--; if (seen && !d) return core.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
eval(grab("haversineKm") + grab("airportsNear") + grab("bestAirport") +
  grab("airportShortlist") +
  ";Object.assign(globalThis,{haversineKm,airportsNear,bestAirport,airportShortlist});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};
const best = (lat, lon) => { const b = bestAirport(airportsNear(lat, lon, 6)); return b ? b.code : null; };

console.log("\nthe dataset");
t("it is big enough to be the real thing", AIRPORTS.length > 2500, true);
t("every row is a three-letter code",
  AIRPORTS.every((a) => /^[A-Z]{3}$/.test(a[0])), true);
t("every row has real coordinates",
  AIRPORTS.every((a) => isFinite(a[1]) && isFinite(a[2]) &&
    Math.abs(a[1]) <= 90 && Math.abs(a[2]) <= 180), true);
t("codes are unique", new Set(AIRPORTS.map((a) => a[0])).size, AIRPORTS.length);
t("there are large airports", AIRPORTS.filter((a) => a[4]).length > 500, true);
// The whole reason this file exists.
t("TYS is in it, and is not in his flight history",
  AIRPORTS.some((a) => a[0] === "TYS"), true);

console.log("\nthe places actually on his list");
t("Blackberry Farm, Walland TN", best(35.6512, -83.9385), "TYS");
t("Alisal Ranch, Solvang CA", best(34.5737, -119.9821), "SBA");
t("Biltmore, Asheville NC", best(35.5405, -82.5515), "AVL");
t("Atlantis, Paradise Island", best(25.0868, -77.3220), "NAS");
t("Airelles, Versailles", best(48.8049, 2.1204), "ORY");
t("Brush Creek Ranch, Saratoga WY", best(41.4553, -106.8067), "LAR");

console.log("\nnearest is not always best");
// Demonstrated on a synthetic list, because the real case that motivated this
// rule -- Hawthorne sitting 1km closer to Terranea than LAX -- no longer exists:
// HHR is a general-aviation field and has been filtered out of the dataset
// entirely. The rule still matters wherever a small field edges out a hub.
const synth = [
  { code: "SML", km: 20, large: false }, { code: "HUB", km: 25, large: true },
  { code: "FAR", km: 300, large: true },
];
t("the closest is the small field", synth[0].code, "SML");
t("but a hub within 1.5x wins", bestAirport(synth).code, "HUB");
t("a hub far beyond it does not",
  bestAirport([{ code: "SML", km: 20, large: false }, { code: "FAR", km: 300, large: true }]).code, "SML");
t("and a close hub is simply taken",
  bestAirport([{ code: "HUB", km: 10, large: true }, { code: "SML", km: 40, large: false }]).code, "HUB");
// And the rule must not run away with it: a hub far beyond the local airport
// does NOT win, or every mountain town would be sent to a capital city.
t("a distant hub does not override a local airport",
  best(34.5737, -119.9821), "SBA");
t("nor for Knoxville, with Atlanta 300km away", best(35.6512, -83.9385), "TYS");

console.log("\ngeneral-aviation fields are not places you can fly to");
// OurAirports' own scheduled_service flag marks all of these as scheduled, and
// every one is a business-aviation field with no airline service. HHR was
// suggested as the airport for a Palos Verdes stay, which is how it surfaced.
// A medium airport must now also appear in real airline route data.
const codes = new Set(AIRPORTS.map((a) => a[0]));
["HHR", "BED", "OPF", "TEB"].forEach(function (c) {
  t(c + " is not offered", codes.has(c), false);
});

// The second class, and a nastier one: airports that pass BOTH OurAirports
// signals. Le Bourget is typed large_airport AND flagged scheduled_service=yes,
// so the only thing that knows better is route data -- which large airports are
// exempt from, because that exemption is what rescues Berlin Brandenburg and
// every other post-2014 build from a 2014 route snapshot. LBG was offered as
// the airport for Versailles, three kilometres from a business-jet apron.
["LBG", "SBD", "DIA", "BXY"].forEach(function (c) {
  t(c + " is blocked by hand", codes.has(c), false);
});
// Blocking Le Bourget must not cost Paris its actual airports.
["ORY", "CDG", "BVA"].forEach(function (c) {
  t("Paris keeps " + c, codes.has(c), true);
});
// ...nor the post-2014 builds the exemption exists for.
["BER", "PKX", "TFU", "NLU", "NMI"].forEach(function (c) {
  t(c + " survives the exemption", codes.has(c), true);
});
t("the generator lists what it blocked",
  /blocked by hand/.test(gen), true);
t("and lists what it trusted on type alone",
  /trusted on type alone, unverified by any route/.test(gen), true);

console.log("\nhow many airports to offer");
// Two when both are major; a third only when one of the closest two is a
// regional field and the next one along is worth comparing.
const S = (list) => airportShortlist(list).map((a) => a.code);
const big = (code, km) => ({ code, km, large: true });
const small = (code, km) => ({ code, km, large: false });
// Every combination of the three nearest, major (*) or regional (-).
// The third slot is shown only when it ADDS something.
t("* *  two majors — a third is noise",
  S([big("ORY", 19), big("CDG", 39), big("BVA", 72)]), ["ORY", "CDG"]);
t("* *  and still two when the third is regional",
  S([big("ORY", 19), big("CDG", 39), small("XXX", 72)]), ["ORY", "CDG"]);
// A major up front means a small third is not somewhere you would fly.
t("* -  major first, regional third — nothing gained",
  S([big("KOA", 12), small("MUE", 53), small("ITO", 100)]), ["KOA", "MUE"]);
t("- *  major second, regional third — same",
  S([small("SAF", 16), big("ABQ", 94), small("ALS", 194)]), ["SAF", "ABQ"]);
// But a major THIRD is the airport you would actually price.
t("- *  regional first, major third — worth comparing",
  S([small("HHH", 14), big("SAV", 38), big("CHS", 110)]), ["HHH", "SAV", "CHS"]);
t("* -  major first, major third — also worth it",
  S([big("TYS", 18), small("AVL", 120), big("CLT", 200)]), ["TYS", "AVL", "CLT"]);
t("- -  nothing major up front, a major third earns its place",
  S([small("BQK", 14), small("A", 40), big("JAX", 85)]), ["BQK", "A", "JAX"]);
// And when nothing near is major, every option counts.
t("- -  none major at all — show all three",
  S([small("ACK", 5), small("HYA", 45), small("EWB", 84)]), ["ACK", "HYA", "EWB"]);
// Never invent a third that is not there.
t("two candidates stay two", S([big("A", 1), big("B", 2)]), ["A", "B"]);
t("one stays one", S([small("A", 1)]), ["A"]);
t("none stays none", S([]), []);
// The stored airport must not change with how many are displayed, or the form
// would show a shortlist that disagrees with the value it saved.
t("the endpoint still considers three before picking",
  core.indexOf("const near = airportsNear(lat, lon, 3);") > -1 &&
  core.indexOf("const best = bestAirport(near);") > -1, true);
t("and trims only what it shows",
  /results: shown/.test(core), true);

console.log("\nhome is a drive, not a flight");
// Two copies of the same two constants -- one the browser reads, one the API
// reads. If they drift, the API fills in an airport the form does not show:
// a value that is live, wrong, and unreachable from the UI.
const appHome = /var HOME = { lat: (-?[0-9.]+), lng: (-?[0-9.]+)/.exec(app);
const apiHome = /const HOME = { lat: (-?[0-9.]+), lon: (-?[0-9.]+)/.exec(core);
t("both files agree where home is",
  appHome[1] + "," + appHome[2], apiHome[1] + "," + apiHome[2]);
t("and on how far you would drive",
  /var DRIVE_MAX_KM = (\d+)/.exec(app)[1], /const DRIVE_MAX_KM = (\d+)/.exec(core)[1]);
t("which is 250 miles", Math.round(+/var DRIVE_MAX_KM = (\d+)/.exec(app)[1] * 0.621371), 250);
// NOT the same constant as HOME_MAX_KM, which is 1100 and decides whether to
// draw a driving route on a trip that already exists. Las Vegas is 435km: a
// drive once booked, but far enough that you would price flights while choosing.
t("it is not HOME_MAX_KM",
  /var HOME_MAX_KM = (\d+)/.exec(app)[1] === /var DRIVE_MAX_KM = (\d+)/.exec(app)[1], false);
t("the API refuses to guess an airport inside that radius",
  /haversineKm\(HOME.lat, HOME.lon, lat, lon\) <= DRIVE_MAX_KM/.test(core), true);
t("and returns no airport rather than a stale one",
  /return { ...body, airport: null, airport_auto: null };/.test(core), true);
t("the form hides the airport field for a drive",
  /if\(!driveOnly\)wrap\.appendChild\(apIn\);/.test(app.replace(/\s+/g, "")), true);
t("and the nearby-airport chips with it",
  /if\(!driveOnly\)wrap\.appendChild\(apAlts\);/.test(app.replace(/\s+/g, "")), true);
t("saying why, so it does not look broken",
  /near enough to drive, so no airport or flights/.test(app), true);
// ...without throwing out the regional airports that genuinely are served.
["ACK", "HHH", "BQK", "SAF", "MSO", "AVL", "JAC", "ASE", "EGE", "SBA", "TYS", "LAR", "CZM", "PSP"]
  .forEach(function (c) { t(c + " is kept", codes.has(c), true); });
// Large airports skip the route check, because the route snapshot predates
// Berlin Brandenburg and would otherwise drop a major hub as unserved.
t("a hub that opened after the route data survives", codes.has("BER"), true);
t("Terranea no longer suggests a GA field", best(33.74, -118.413), "LAX");

console.log("\nwhen there is no answer");
// Point Nemo, the most remote spot in the Pacific. "No airport" is a real
// answer and has to be one.
t("the middle of the Pacific has none", best(-48.87, -123.39), null);
t("and returns an empty list, not a throw", airportsNear(-48.87, -123.39, 6).length, 0);
t("beyond the radius nothing is offered",
  airportsNear(-48.87, -123.39, 6).every((a) => a.km <= AIRPORT_MAX_KM), true);

console.log("\nresults are ordered and bounded");
const near = airportsNear(34.05, -118.24, 6);
t("closest first", near.map((a) => a.km).every((k, i, l) => !i || k >= l[i - 1]), true);
t("limited to what was asked for", near.length <= 6, true);
// Three is the shipped limit: past that it stops being a shortlist.
t("and the endpoint asks for three", (core.match(/airportsNear\(lat, lon, 3\)/g) || []).length, 2);
t("each carries what the form needs to show",
  Object.keys(near[0]).sort(),
  ["city", "code", "country", "km", "large", "latitude", "longitude"]);

console.log("\nthe override rules");
// An auto-filled code saved back unchanged must not become a manual one, or the
// value nobody chose is frozen and stops following the location forever.
t("the form sends the code only when it changed",
  /var apChanged = ap !== apLoaded\.trim\(\)\.toUpperCase\(\)/.test(app), true);
t("and spreads it in conditionally",
  /\.\.\.\(apChanged \? \{ airport: ap \|\| null \} : \{\}\)/.test(app), true);
t("a supplied code is recorded as a choice",
  /return \{ \.\.\.body, airport: code, airport_auto: false \}/.test(core), true);
// An edit to the note must not relocate an airport the traveller picked.
t("an unrelated edit leaves a chosen airport alone",
  /if \(!supplied && blob\.airport && blob\.airport_auto === false\) return body/.test(core), true);
t("clearing the field fills it in again", /Re-fill it/.test(core), true);
t("a location with no airport in range clears any stale code",
  /if \(!best\) return \{ \.\.\.body, airport: null, airport_auto: null \}/.test(core), true);
t("both write paths go through it",
  (core.match(/await withAutoAirport\(/g) || []).length, 2);

console.log("\nthe endpoint");
t("it exists", /segs\[0\] === "nearest-airport" && method === "GET"/.test(core), true);
t("it validates the coordinates",
  /Math\.abs\(lat\) > 90 \|\| Math\.abs\(lon\) > 180/.test(core), true);
t("it returns alternatives, not just one answer",
  core.indexOf("return json({ best, results: shown, max_km: AIRPORT_MAX_KM });") > -1, true);
// It reads a bundled file: no key, no upstream, nothing to spend.
t("it costs nothing, so no admin gate is needed",
  /nearest-airport[\s\S]{0,400}?role !== "admin"/.test(core), false);
t("the form offers the neighbours as one click", /"chip ap-alt"/.test(app), true);
t("and admits straight-line distance ignores terrain", /Alps/.test(app), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
