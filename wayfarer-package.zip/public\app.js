// Wayfarer — client. Talks only to the same-origin API at /api/v1/*, backed
// by Cloudflare D1. Authentication is Cloudflare Access; there is no external
// service involved and no token to store.
// Token lives only in localStorage. API quirk: trip LIST is plural /v1/trips; a trip's itinerary is
// under SINGULAR /v1/trip/{id}/{activities|transportations|hostings|expenses}.
(function () {
  "use strict";
  // localStorage keys keep their original names deliberately. Renaming them
  // would orphan every saved preference — theme, text size, content width,
  // density, snoozed checks, last-seen state — and silently reset the app to
  // defaults on next load. The name is cosmetic; the data is not.
  var TOKEN_KEY = "wayfarer_token", USER_KEY = "wayfarer_user", THEME_KEY = "wayfarer_theme", NOTICE_KEY = "wayfarer_session_notice";
  // Up here, not beside the functions that use them. The toolbar is built at
  // load -- long before those lines run -- and a `var` hoists its declaration
  // without its value, so declared next to readAttention all three were
  // undefined when the More chip was created: the tooltip rendered as the
  // literal string "undefined" and readAttention looked up getItem(undefined),
  // which is null, so no badge ever drew. See drawMoreBadge.
  var ATTN_KEY = "wayfarer_attention_v1", ATTN_MAX_DAYS = 14;
  var MORE_TITLE = "History, Check Trips, Changes, Calendar, Trip Ideas, Card Rewards";
  var $ = function (s) { return document.querySelector(s); };
  var $$ = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };
  var el = function (tag, cls, txt) { var n = document.createElement(tag); if (cls) n.className = cls; if (txt != null) n.textContent = txt; return n; };

  // ---- storage ----
  var API_BASE = "/api/v1";
  // Authentication is Cloudflare Access now: if the page loaded at all, Access
  // has already verified who you are. There is no separate account to sign into,
  // so the old login screen is dead weight — but getToken() stays, because the
  // header it feeds is harmless; it costs nothing to leave in place.
  var USE_ACCESS_AUTH = true;
  function getToken() { try { return localStorage.getItem(TOKEN_KEY); } catch (e) { return null; } }
  function clearToken() { try { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(USER_KEY); } catch (e) {} }
  function setUser(u) { try { localStorage.setItem(USER_KEY, JSON.stringify(u)); } catch (e) {} }
  function getUser() { try { return JSON.parse(localStorage.getItem(USER_KEY) || "null"); } catch (e) { return null; } }

  // ---- api ----
  function ApiError(msg, status) { this.message = msg; this.status = status; }
  // ---- is what you are reading actually current? ----
  //
  // The service worker serves a cached itinerary when the network is gone,
  // which is the point of having one. What it must not do is serve it silently:
  // a gate number from four hours ago looked exactly like one from four seconds
  // ago, and the moment that matters is the moment you cannot check.
  //
  // navigator.onLine is not the test. It reports whether an interface is up,
  // so a hotel wifi that has accepted the connection and routes nowhere reads
  // as online. The honest signal is the worker saying it answered from its own
  // cache -- see labelled() in sw.js.
  var lastCacheAt = null;
  // Set only when the dashboard is painted from the local snapshot AND the
  // refresh has failed -- not merely while one is in flight. Painting a
  // snapshot and replacing it 200ms later is not staleness worth a banner;
  // being stuck on one is.
  var snapshotAt = null;

  // The last trip list that loaded successfully. The service worker already
  // caches the RESPONSE, but only the worker can read that, and only after a
  // five-second network timeout -- so the app kept a skeleton on screen while a
  // complete itinerary sat in Cache Storage. This is the app's own copy, read
  // synchronously before the first request goes out.
  var TRIPS_SNAPSHOT = "wayfarer_trips_snapshot_v1";

  function saveSnapshot(trips) {
    try {
      localStorage.setItem(TRIPS_SNAPSHOT, JSON.stringify({
        at: new Date().toISOString(), trips: trips
      }));
    } catch (e) {
      // Quota, or private browsing. The snapshot is an optimisation and the app
      // works without it, so a failure here is not worth reporting.
    }
  }

  function readSnapshot() {
    try {
      var raw = localStorage.getItem(TRIPS_SNAPSHOT);
      if (!raw) return null;
      var o = JSON.parse(raw);
      if (!o || !Array.isArray(o.trips) || !o.trips.length) return null;
      return o;
    } catch (e) { return null; }
  }

  // Which request's answer the strip is allowed to reflect.
  //
  // noteFreshness runs on every response, and responses do not come back in the
  // order they were sent. The app fires several requests at once -- loadAll,
  // apiAll's pages, whichever panel is open -- and a CACHED answer to a request
  // issued early can land after a FRESH one issued later. The strip then says
  // "Offline" a moment after a successful refresh had cleared it. The reverse
  // is worse: a late fresh answer clears a strip that was telling the truth,
  // and the user reads stale data as current.
  //
  // So every request takes a ticket on its way out, and an answer may only
  // repaint if its ticket is at least as new as the newest that already has.
  // An older request answering later has nothing to add -- its information is
  // out of date by definition, whatever it says.
  var freshSeq = 0, freshSeen = 0;

  function noteFreshness(res, ticket) {
    try {
      if (!res || !res.headers) return;
      // Ties pass: the newest ticket is the one that just answered.
      if (ticket != null) {
        if (ticket < freshSeen) return;
        freshSeen = ticket;
      }
      if (res.headers.get("X-SW-Cache") !== "hit") { lastCacheAt = null; paintOffline(); return; }
      var when = res.headers.get("X-SW-Cached-At");
      var d = when ? new Date(when) : null;
      lastCacheAt = (d && !isNaN(d.getTime())) ? d : new Date();
      paintOffline();
    } catch (e) { /* never let a label break a request */ }
  }

  function paintOffline() {
    var strip = document.getElementById("offline-strip");
    if (!strip) return;
    // Two ways to be looking at old data: the worker answered from its cache,
    // or the app is showing its own snapshot because the refresh failed. Both
    // deserve the strip; they are different sentences because they are
    // different situations -- one means no network, the other means the
    // request came back wrong.
    var when = lastCacheAt || snapshotAt;
    if (!when) { strip.hidden = true; strip.textContent = ""; return; }
    var t = when.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
    var sameDay = when.toDateString() === new Date().toDateString();
    var stamp = sameDay ? "at " + t
      : "on " + when.toLocaleDateString([], { month: "short", day: "numeric" }) + " at " + t;
    strip.textContent = (lastCacheAt ? "Offline — showing what was saved "
      : "Couldn't refresh — showing what was saved ") + stamp;
    strip.hidden = false;
  }

  async function api(path, opts) {
    opts = opts || {};
    var token = getToken();
    // A FormData body must NOT carry a Content-Type we invented: only the
    // browser knows the multipart boundary it generated, and overriding the
    // header strips it, leaving the server unable to parse a single part.
    var isForm = (typeof FormData !== "undefined") && opts.body instanceof FormData;
    var headers = Object.assign(isForm ? {} : { "Content-Type": "application/json" }, opts.headers || {});
    if (token) headers["Authorization"] = "Token " + token;
    // Every request goes to our own D1-backed API on this origin. Nothing
    // external is involved. The service worker's offline rule matches this same
    // prefix — change one and you must change the other.
    // Taken BEFORE the request goes out, so the order is the order they were
    // issued in rather than the order they happened to come back in.
    var ticket = ++freshSeq;
    var res = await fetch(API_BASE + path, Object.assign({}, opts, { headers: headers, cache: "no-store" }));
    noteFreshness(res, ticket);
    // Anything written invalidates every cached sweep. The case that matters is
    // the one this exists for: you open Check Trips, fix a finding, and come
    // back -- the list must not be restored still showing what you just fixed.
    // Scoped to writes, so ordinary reads keep the cache useful.
    if (res.ok && opts.method && opts.method !== "GET") panelCache = {};
    var text = await res.text();
    var data = text ? safeJson(text) : null;
    if (!res.ok) {
      // A 401 under Access means the Access session lapsed, not that a stored
      // token went bad — dumping the user on a dead login screen would strand
      // them. Reload instead: Access re-authenticates and returns them here.
      // A 401 means the Access session lapsed; reload and Access re-authenticates.
      if (res.status === 401) {
        location.reload();
      }
      // A View/Read account reaching a control that should have been hidden.
      // Hiding is done by hand in ~23 places, so something will eventually be
      // missed; this makes the miss say what happened instead of failing mute.
      if (res.status === 403) {
        try { toast((data && data.detail) || "Your account cannot change this."); } catch (e) {}
      }
      var msg = (data && (firstError(data) || data.detail)) || (typeof data === "string" ? data : null) || ("Request failed (" + res.status + ")");
      throw new ApiError(msg, res.status);
    }
    return data;
  }
  function safeJson(t) { try { return JSON.parse(t); } catch (e) { return t; } }
  function firstError(d) { return d && d.non_field_errors && d.non_field_errors[0]; }
  // ---- editing a shared list without losing the other person's edit ----
  //
  // Lists here — tasks, packing, the bucket list, the household roster — are
  // stored as one value and written as one value, so the last writer wins the
  // whole list. Two devices open on the same trip is the ordinary case, not a
  // rare one: add a task on the phone, add another on the laptop from a page
  // loaded five minutes earlier, and the laptop sends its stale array. The
  // phone's task is gone, and nothing anywhere reports it.
  //
  // The fix is not to send the finished array. It is to send the INTENT and let
  // it be re-applied: `mutate` receives whatever the server currently holds and
  // returns the new list, so when a write is refused as stale the same intent
  // runs again against fresh data. "Add this task" survives that; a precomputed
  // array cannot.
  //
  // Returns the list as written, or null if `mutate` declined by returning null.
  var CAS_TRIES = 4;
  async function updateList(read, write, mutate) {
    for (var attempt = 0; attempt < CAS_TRIES; attempt++) {
      var cur = await read();
      var next = mutate(cur);
      if (next == null) return null;
      try {
        await write(next, cur);
        return next;
      } catch (e) {
        // 409 is the server saying someone else got there first. Anything else
        // is a real failure and belongs to the caller.
        if (e.status !== 409) throw e;
      }
    }
    // Four rounds means something is writing continuously, which is not two
    // people with a phone each. Better to stop than to spin.
    throw new ApiError("This list is being changed on another device faster than it can be saved. Try again in a moment.", 0);
  }

  // Where a task sits in a list that may have moved on since you looked.
  //
  // A task carries no id, so identity is its text plus the instant it was added
  // — enough to survive a re-read, which an index is not. Older entries predate
  // `added` and can collide if their text matches; the first match is taken,
  // which is the same answer an index would have given and no worse.
  function taskKey(x) { return String((x && x.text) || "") + "|" + String((x && x.added) || ""); }
  function taskIndex(list, x) {
    var k = taskKey(x);
    for (var i = 0; i < list.length; i++) if (taskKey(list[i]) === k) return i;
    return -1;
  }

  // The trip's to-do list.
  function updateTasks(t, mutate) {
    return updateList(
      async function () {
        var fresh = await api("/v1/trip/" + t.id);
        return Array.isArray(fresh && fresh.tasks) ? fresh.tasks : [];
      },
      function (next, base) {
        return api("/v1/trip/" + t.id, { method: "PATCH",
          body: JSON.stringify({ tasks: next, if_match: { tasks: base } }) });
      },
      mutate
    ).then(function (next) { if (next) t.tasks = next; return next; });
  }

  // A packing item has no id either, so it is identified by its text and who it
  // is for. Two identical entries for the same person are indistinguishable —
  // and interchangeable, so taking the first is right rather than merely close.
  function packKey(x) { return String((x && x.text) || "") + "|" + String((x && x.who) || ""); }
  function packIndex(list, x) {
    var k = packKey(x);
    for (var i = 0; i < list.length; i++) if (packKey(list[i]) === k) return i;
    return -1;
  }
  function updatePacking(l, mutate) {
    return updateList(
      async function () {
        var fresh = await api("/v1/packing/" + l.id);
        return Array.isArray(fresh && fresh.items) ? fresh.items : [];
      },
      function (next, base) {
        return api("/v1/packing/" + l.id, { method: "PATCH",
          body: JSON.stringify({ items: next, if_match: { items: base } }) });
      },
      mutate
    ).then(function (next) { if (next) l.items = next; return next; });
  }

  // Replace a whole-value field, refusing to overwrite a version you never saw.
  //
  // For the lists edited in a dialog — the household roster, travel documents,
  // the bucket list — replacement IS the intent: you are looking at the list and
  // changing it. There is nothing to re-apply automatically, so a conflict stops
  // and says so. That still fixes the loss: the write is refused rather than
  // quietly discarding whatever the other device added, and you can see the
  // current list and redo one edit. The rapid-fire lists — tasks, packing —
  // take the retrying path above instead, because a modal per tick is intolerable.
  async function replaceValue(path, field, next, base) {
    var body = {}; body[field] = next; body.if_match = {}; body.if_match[field] = base || [];
    try { return await api(path, { method: "PATCH", body: JSON.stringify(body) }); }
    catch (e) {
      if (e.status === 409) {
        throw new ApiError("This list changed on another device, so nothing was overwritten. Close and reopen this to see the current one.", 409);
      }
      throw e;
    }
  }

  // A whole-value field on /v1/me: the roster, the travel documents, the bucket
  // list. Read through /v1/me, which returns every setting at once.
  async function apiAll(path) {
    var out = [], page = 1;
    while (true) {
      var sep = path.indexOf("?") >= 0 ? "&" : "?";
      var d = await api(path + sep + "page=" + page);
      if (d && d.results) { out.push.apply(out, d.results); if (!d.next) break; page += 1; }
      else { if (Array.isArray(d)) out.push.apply(out, d); break; }
    }
    return out;
  }

  // ---- state ----
  // Private family app: every trip is ours. There is no "following someone's
  // trip" concept in this database, so there is nothing to filter for.
  // Which trip groups are shown. Upcoming only by default — opening the app on
  // a phone should answer "what's next", not present 175 finished trips you
  // have to scroll past. Past is one tap away and the choice is remembered per
  // device, so anyone who prefers the full history sets it once.
  var FILTERS_KEY = "wayfarer_filters";
  function loadFilters() {
    try {
      var s = JSON.parse(localStorage.getItem(FILTERS_KEY) || "null");
      if (s && typeof s.upcoming === "boolean" && typeof s.past === "boolean") return s;
    } catch (e) {}
    return { upcoming: true, past: false };
  }
  function saveFilters() {
    try { localStorage.setItem(FILTERS_KEY, JSON.stringify(state.filters)); } catch (e) {}
  }
  // The markup ships with a fixed set of active chips; this makes them agree
  // with whatever was actually restored.
  function paintFilterChips() {
    $$("#filters .chip").forEach(function (c) {
      c.classList.toggle("active", !!state.filters[c.getAttribute("data-filter")]);
    });
  }

  var state = { me: null, own: [], categories: {}, filters: loadFilters(), year: "", dest: {} };


  // ---- views ----
  // There is no login screen: Cloudflare Access authenticates before the app
  // loads. Kept as a no-op so any stray caller cannot throw.
  function showLogin() {}
  function showDashboard() {
    $("#dash-view").hidden = false; $("#logout-btn").hidden = false;
    $("#refresh-btn").hidden = false; $("#newtrip-btn").hidden = false;
    paintFilterChips();
    var u = getUser(); if (u) { var w = $("#whoami"); w.textContent = u.name || u.username || u.email || ""; w.hidden = false; }
  }

  // Under Access, signing out means ending the *Access* session — clearing a
  // a stored token achieves nothing, since it no longer authorises
  // anything and Access would wave you straight back in on reload. That is why
  // the button appeared dead.
  $("#logout-btn").addEventListener("click", function () {
    clearToken();
    if (USE_ACCESS_AUTH) { location.href = "/cdn-cgi/access/logout"; return; }
    location.hash = ""; location.reload();
  });

  // ---- display preferences (text size + content width) ----
  // Applied as data attributes on <html>; the stylesheet scales every font-size
  // from --fs and the width knobs from --main-w / --cards-w / --detail-w. The
  // same values are applied in the <head> so there's no flash on load.
  var DISPLAY_KEY = "wayfarer_display_v1";
  // Earlier builds used different names for the same steps; map them forward so
  // an existing preference isn't silently reset.
  var TEXT_MIGRATE = { m: "small", l: "medium", xl: "large", xxl: "huge" };
  var WIDTH_MIGRATE = { comfortable: "compact", wide: "default" };
  var TEXT_OK = { small: 1, medium: 1, large: 1, huge: 1 };
  var WIDTH_OK = { compact: 1, "default": 1, full: 1 };
  var DENSITY_OK = { comfortable: 1, cosy: 1, compact: 1 };
  var SPACING_OK = { tight: 1, normal: 1, relaxed: 1 };
  // The section order is per-DEVICE, in localStorage. So changing SECTION_KEYS
  // moves nothing on a phone that already has a saved order -- and worse,
  // normalizeSections heals a missing key by appending it, which would put
  // "ideas" after "cancel". Cancellation policies are last on purpose.
  //
  // So an order saved before "ideas" existed is replaced with the new default,
  // once, and stamped. Anything reordered from here on is left alone. Bumping
  // DISPLAY_KEY would have done it too, at the cost of resetting text size,
  // width and every other display preference along with it.
  var SECTIONS_REV = 2;
  function migrateSections(d) {
    if (d && d.sectionsRev === SECTIONS_REV) return false;
    d.sections = SECTION_KEYS.map(function (k) { return { key: k, on: true }; });
    d.sectionsRev = SECTIONS_REV;
    return true;
  }

  function getDisplay() {
    var d = {};
    try { d = JSON.parse(localStorage.getItem(DISPLAY_KEY) || "{}"); } catch (e) {}
    // Write it back, or the migration runs on every read and a deliberate
    // reorder made afterwards would be undone on the next paint.
    if (migrateSections(d)) {
      try { localStorage.setItem(DISPLAY_KEY, JSON.stringify(d)); } catch (e) {}
    }
    var text = TEXT_MIGRATE[d.text] || d.text;
    var width = WIDTH_MIGRATE[d.width] || d.width;
    return {
      text: TEXT_OK[text] ? text : "large",
      width: WIDTH_OK[width] ? width : "default",
      density: DENSITY_OK[d.density] ? d.density : "comfortable",
      spacing: SPACING_OK[d.spacing] ? d.spacing : "normal",
      clock: d.clock === "24" ? "24" : "12",
      tripView: d.tripView === "list" ? "list" : "cards",
      units: d.units === "metric" ? "metric" : "imperial",
      dateFmt: /^(us|eu|iso)$/.test(d.dateFmt) ? d.dateFmt : "us",
      landing: /^(list|current)$/.test(d.landing) ? d.landing : "list",
      sections: normalizeSections(d.sections),
      showKinds: {
        transport: d.showKinds ? d.showKinds.transport !== false : true,
        hosting: d.showKinds ? d.showKinds.hosting !== false : true,
        activity: d.showKinds ? d.showKinds.activity !== false : true
      },
      autoCollapsePast: !!d.autoCollapsePast,
      checkLevel: /^(all|warn|issue)$/.test(d.checkLevel) ? d.checkLevel : "all"
    };
  }
  // Side-column sections: order matters, and unknown/missing keys are healed.
  // Map first because it orients the whole trip; then the two things you check
  // on a trip in progress -- what needs attention, and what it is costing.
  // Then what you have to do, the papers you need, what to take. Ideas for free
  // days is speculative, so it sits below everything real. Cancellation
  // policies are last by design: consulted rarely and urgently, and nothing
  // above them should have to be scrolled past on an ordinary day.
  var SECTION_KEYS = ["map", "check", "budget", "tasks", "docs", "packing", "ideas", "cancel"];
  var SECTION_LABEL = { map: "Map", check: "Trip check", budget: "Budget", tasks: "To do",
    docs: "Documents", packing: "Packing", ideas: "Ideas for free days",
    cancel: "Cancellation policies" };
  function normalizeSections(list) {
    var out = [], seen = {};
    (Array.isArray(list) ? list : []).forEach(function (s) {
      if (s && SECTION_KEYS.indexOf(s.key) > -1 && !seen[s.key]) {
        seen[s.key] = 1; out.push({ key: s.key, on: s.on !== false });
      }
    });
    SECTION_KEYS.forEach(function (k) { if (!seen[k]) out.push({ key: k, on: true }); });
    return out;
  }

  // ---- account settings ----
  // These are stored in our own database rather than the browser, so they are
  // shared across your devices. The notification toggles are inert: nothing
  // sends push any more, and the UI says so rather than pretending.
  function openAccountDialog() {
    var o = overlay();
    var back = o.back, panel = o.panel;
    panel.appendChild(el("h3", "form-title", "Account Settings"));
    var body = el("div"); body.appendChild(el("div", "place-hint", "Loading…"));
    panel.appendChild(body);
    var foot = el("div", "form-btns");
    var done = el("button", "primary-btn small", "Done"); done.type = "button";
    done.addEventListener("click", function () { back.remove(); });
    foot.appendChild(done); panel.appendChild(foot);

    api("/v1/me").then(function (me) {
      var p = (me && me.data) ? me.data : me;
      body.innerHTML = "";
      body.appendChild(el("div", "place-hint", "Stored in your own database, shared across your devices."));

      function toggle(label, field, hint) {
        var row = el("div", "sec-row");
        var b = el("button", "sec-tog" + (p[field] ? " on" : ""), p[field] ? "✓" : "○"); b.type = "button";
        b.addEventListener("click", async function () {
          var next = !p[field];
          b.disabled = true;
          try {
            var patch = {}; patch[field] = next;
            await api("/v1/me", { method: "PATCH", body: JSON.stringify(patch) });
            p[field] = next; b.classList.toggle("on", next); b.textContent = next ? "✓" : "○";
            toast("Saved");
          } catch (e) { toast("Couldn't save: " + e.message); }
          finally { b.disabled = false; }
        });
        row.appendChild(b);
        var wrap = el("div"); wrap.style.flex = "1";
        wrap.appendChild(el("div", "sec-name", label));
        if (hint) wrap.appendChild(el("div", "place-hint", hint));
        row.appendChild(wrap);
        return row;
      }

      body.appendChild(el("div", "seg-label", "Notifications (not yet active)"));
      var nl = el("div", "sec-list");
      nl.appendChild(toggle("Flight alerts", "notifications_flights_general_enabled", "Saved, but nothing sends push notifications yet."));
      nl.appendChild(toggle("Departure & arrival", "notifications_flights_departure_and_arrival"));
      nl.appendChild(toggle("Collaborator activity", "notifications_collaborators_new_activities_enabled"));
      body.appendChild(nl);

      // The three calendar toggles that used to sit here are gone. They wrote to
      // the old Tripsy settings table, which this feed has never read, so they
      // did nothing — and two of them ("Lodging as all-day", "Trips as all-day")
      // now describe the opposite of the rule the feed enforces: only a trip may
      // be all-day. Every calendar control lives in Manage Calendar Feeds, per
      // feed, where it actually takes effect.

      body.appendChild(el("div", "seg-label", "Currency"));
      var cur = el("div", "form-field");
      var ci = el("input", "form-input"); ci.value = p.default_currency || "USD"; ci.maxLength = 3;
      ci.addEventListener("change", async function () {
        try { await api("/v1/me", { method: "PATCH", body: JSON.stringify({ default_currency: ci.value.toUpperCase() }) }); toast("Currency saved"); }
        catch (e) { toast("Couldn't save: " + e.message); }
      });
      cur.appendChild(el("span", "form-label", "Default currency (used for converted totals)"));
      cur.appendChild(ci); body.appendChild(cur);

      // ---- travellers ----
      body.appendChild(el("div", "seg-label", "Travellers"));
      body.appendChild(el("div", "place-hint",
        "The people you travel with. Add them once here, then pick who is on each trip — seats and documents match up from there. Separate from who can sign in."));
      var paxList = el("div", "sec-list");
      body.appendChild(paxList);

      var savePax = async function (arr) {
        // The base is what is on screen, which is what you were editing.
        await replaceValue("/v1/me", "travellers", arr, Array.isArray(p.travellers) ? p.travellers : []);
        p.travellers = arr;
        if (state.me) state.me.travellers = arr;
      };
      var paintPax = function () {
        paxList.innerHTML = "";
        var arr = Array.isArray(p.travellers) ? p.travellers : [];
        if (!arr.length) paxList.appendChild(el("div", "place-hint", "Nobody added yet."));
        arr.forEach(function (person, idx) {
          var row = el("div", "sec-row");
          var wrap = el("div"); wrap.style.flex = "1";
          wrap.appendChild(el("div", "sec-name", person.name));
          // Tie the documents already on file to this person by name, so adding
          // a traveller immediately shows what is recorded for them.
          var mine = travelDocs().filter(function (d) {
            return String(d.who || "").toLowerCase() === String(person.name).toLowerCase();
          });
          wrap.appendChild(el("div", "place-hint", mine.length
            ? mine.map(function (d) { return d.kind + " to " + d.expires; }).join(" · ")
            : "No documents on file"));
          row.appendChild(wrap);
          var rm = el("button", "mini-btn is-edit", "Remove"); rm.type = "button";
          rm.addEventListener("click", async function () {
            if (!confirm("Remove " + person.name + " from your travellers? Trips and seats already assigned to them keep the record, but will show the name greyed out.")) return;
            var next = arr.slice(); next.splice(idx, 1);
            try { await savePax(next); paintPax(); toast("Removed"); }
            catch (e) { toast("Couldn't save: " + e.message); }
          });
          row.appendChild(rm);
          paxList.appendChild(row);
        });
      };
      paintPax();

      var paxAdd = el("div", "doc-add");
      var pname = el("input", "form-input"); pname.placeholder = "Name (e.g. Jo)";
      var pbtn = el("button", "mini-btn is-edit", "＋ Add"); pbtn.type = "button";
      var addPerson = async function () {
        var nm = pname.value.trim();
        if (!nm) { toast("Enter a name"); return; }
        var arr = (Array.isArray(p.travellers) ? p.travellers : []).slice();
        if (arr.some(function (x) { return x.name.toLowerCase() === nm.toLowerCase(); })) {
          toast(nm + " is already on the list"); return;
        }
        arr.push({ id: newTravellerId(nm, arr), name: nm });
        pbtn.disabled = true;
        try { await savePax(arr); paintPax(); pname.value = ""; toast("Added"); }
        catch (e) { toast("Couldn't save: " + e.message); }
        finally { pbtn.disabled = false; }
      };
      pbtn.addEventListener("click", addPerson);
      pname.addEventListener("keydown", function (ev) { if (ev.key === "Enter") { ev.preventDefault(); addPerson(); } });
      paxAdd.appendChild(pname); paxAdd.appendChild(pbtn);
      body.appendChild(paxAdd);

      // ---- travel documents ----
      body.appendChild(el("div", "seg-label", "Travel documents"));
      body.appendChild(el("div", "place-hint",
        "Expiry dates only — no document numbers are stored. Recorded once, these are checked against every trip that leaves the country, including the six-month passport rule."));
      var docList = el("div", "sec-list");
      body.appendChild(docList);

      var save = async function (arr) {
        await replaceValue("/v1/me", "travel_documents", arr,
          Array.isArray(p.travel_documents) ? p.travel_documents : []);
        p.travel_documents = arr;
        // Keep the copy the audit reads in step with the one just saved,
        // otherwise the trip check keeps warning about a passport you renewed
        // until the next full reload.
        if (state.me) state.me.travel_documents = arr;
      };

      var paintDocs = function () {
        docList.innerHTML = "";
        var arr = Array.isArray(p.travel_documents) ? p.travel_documents : [];
        if (!arr.length) docList.appendChild(el("div", "place-hint", "Nothing recorded yet."));
        arr.forEach(function (d, idx) {
          var row = el("div", "sec-row");
          var wrap = el("div"); wrap.style.flex = "1";
          wrap.appendChild(el("div", "sec-name", (d.who ? d.who + " · " : "") + (d.kind || "Document")));
          var when = el("div", "place-hint", "Expires " + (d.expires || "—"));
          if (d.expires && d.expires < new Date().toISOString().slice(0, 10)) {
            when.textContent += "  ·  expired";
          }
          wrap.appendChild(when);
          row.appendChild(wrap);
          var rm = el("button", "mini-btn is-edit", "Remove"); rm.type = "button";
          rm.addEventListener("click", async function () {
            if (!confirm("Remove " + (d.who ? d.who + "'s " : "") + (d.kind || "document") + "?")) return;
            var next = arr.slice(); next.splice(idx, 1);
            try { await save(next); paintDocs(); toast("Removed"); }
            catch (e) { toast("Couldn't save: " + e.message); }
          });
          row.appendChild(rm);
          docList.appendChild(row);
        });
      };
      paintDocs();

      var addRow = el("div", "doc-add");
      var who = el("input", "form-input"); who.placeholder = "Who (e.g. Alex)";
      // Offer the roster without forcing it — a document can belong to somebody
      // you have not added as a traveller, and typing the name is still allowed.
      var dl = el("datalist"); dl.id = "traveller-names";
      (Array.isArray(p.travellers) ? p.travellers : []).forEach(function (x) {
        var o = el("option"); o.value = x.name; dl.appendChild(o);
      });
      who.setAttribute("list", "traveller-names");
      addRow.appendChild(dl);
      var kind = el("select", "form-input");
      ["Passport", "Visa", "Global Entry", "TSA PreCheck", "Driver's licence", "Other"].forEach(function (k) {
        var o = el("option", null, k); o.value = k; kind.appendChild(o);
      });
      var exp = el("input", "form-input"); exp.type = "date"; exp.title = "Expiry date";
      var addBtn = el("button", "mini-btn is-edit", "＋ Add"); addBtn.type = "button";
      addBtn.addEventListener("click", async function () {
        if (!exp.value) { toast("Pick an expiry date"); return; }
        var arr = (Array.isArray(p.travel_documents) ? p.travel_documents : []).slice();
        arr.push({ who: who.value.trim(), kind: kind.value, expires: exp.value });
        addBtn.disabled = true;
        try { await save(arr); paintDocs(); who.value = ""; exp.value = ""; toast("Saved"); }
        catch (e) { toast("Couldn't save: " + e.message); }
        finally { addBtn.disabled = false; }
      });
      addRow.appendChild(who); addRow.appendChild(kind); addRow.appendChild(exp); addRow.appendChild(addBtn);
      body.appendChild(addRow);
    }).catch(function (e) {
      body.innerHTML = ""; body.appendChild(el("div", "place-hint", "Couldn't load your profile: " + e.message));
    });
  }

  // ---- server-side change detection ----
  // Trips carry no updated_at, so ask the API which trips changed. The docs note
  // the implementation subtracts 2 days before filtering, so this is a generous
  // net rather than an exact one — it is a prompt to look, not a precise diff.
  var LASTSEEN_KEY = "wayfarer_lastseen_all";
  var changedTripIds = {};
  async function detectChangedTrips() {
    var since = null;
    try { since = localStorage.getItem(LASTSEEN_KEY); } catch (e) {}
    try { localStorage.setItem(LASTSEEN_KEY, new Date().toISOString()); } catch (e) {}
    if (!since) return;                       // first run: nothing to compare against
    try {
      var d = await apiAll("/v1/trips?updatedSince=" + encodeURIComponent(since) + "&fields=id,name");
      changedTripIds = {};
      (d || []).forEach(function (t) { changedTripIds[t.id] = true; });
      var n = Object.keys(changedTripIds).length;
      if (n) { render(); toast(n + (n === 1 ? " trip has" : " trips have") + " changed since your last visit"); }
    } catch (e) { /* advisory only */ }
  }

  // ---- landing view ----
  // Optionally open straight into the trip you're on (or the next one) rather
  // than the list. Never overrides a deep link, and only fires once per load.
  var landingDone = false;
  function maybeOpenLanding() {
    if (landingDone) return;
    landingDone = true;
    if (getDisplay().landing !== "current") return;
    if (location.hash) return;                       // any deep link wins, trip or panel
    var today = new Date().toISOString().slice(0, 10);
    var dated = (state.own || []).filter(function (t) { return t.has_dates && t.starts_at && t.ends_at; });
    var now = dated.filter(function (t) { return t.starts_at <= today && t.ends_at >= today; })
      .sort(function (a, b) { return a.starts_at.localeCompare(b.starts_at); })[0];
    var next = now || dated.filter(function (t) { return t.starts_at > today; })
      .sort(function (a, b) { return a.starts_at.localeCompare(b.starts_at); })[0];
    if (next) openTrip(next);
  }

  // ---- units & date formats ----
  function dateLocale() {
    var f = getDisplay().dateFmt;
    return f === "eu" ? "en-GB" : f === "iso" ? "sv-SE" : "en-US";
  }
  function fmtDistance(km) {
    if (km == null) return "";
    if (getDisplay().units === "metric") {
      return km < 1 ? Math.round(km * 1000) + " m" : (Math.round(km * 10) / 10) + " km";
    }
    var mi = km * 0.621371;
    return mi < 0.19 ? Math.round(mi * 5280) + " ft" : (Math.round(mi * 10) / 10) + " mi";
  }
  // ---- themes ----
  // Three dark palettes and three light ones. The value is written to
  // <html data-theme> and mirrored into localStorage, where the inline script in
  // index.html picks it up before first paint.
  // Grouped dark-first so the Settings picker can lay them out as one row of
  // dark palettes above one row of light ones.
  //
  // `value` is deliberately NOT the display name. Four of these were renamed —
  // Dark to Navy, Light to Sunny, Tangerine to Burnt, Crimson to Rose — and the
  // value is a storage key: it is in localStorage on every device, in the
  // data-theme attribute, in the pre-paint script in index.html, and in six
  // blocks of CSS selectors. Renaming it to match the label would silently drop
  // anyone holding the old value back to the default palette, which is a real
  // cost for a cosmetic change. The label is what anyone sees; the value is
  // what the machine remembers, and only one of them needed to change.
  // The U+FE0F after the sun and the desert is load-bearing, not a typo. Both
  // characters are Emoji_Presentation=No — U+2600 and U+1F3DC default to the
  // TEXT glyph, which is monochrome and takes the surrounding colour, so those
  // two rendered white on the dark palettes and black on the light ones while
  // the other four came out in colour. The variation selector asks for the
  // emoji glyph. Any icon added here should be checked the same way: if it is
  // not Emoji_Presentation=Yes it needs the selector.
  var THEMES = [
    { value: "dark", label: "🌙 Navy", mark: "🌙", color: "#0f1319", dark: true },
    { value: "forest", label: "🌲 Forest", mark: "🌲", color: "#050b08", dark: true },
    { value: "tangerine", label: "🔥 Burnt", mark: "🔥", color: "#140b05", dark: true },
    { value: "light", label: "☀️ Sunny", mark: "☀️", color: "#f9f2d5", dark: false },
    { value: "desert", label: "🏜️ Desert", mark: "🏜️", color: "#e6d5bb", dark: false },
    { value: "crimson", label: "🌹 Rose", mark: "🌹", color: "#fdf1f1", dark: false }
  ];
  // Forest and Burnt are dark palettes, Desert and Rose light ones — anything
  // keyed off brightness (map tiles, chip contrast) must ask this rather than
  // test for the literal "dark".
  function isDarkTheme() { return !!themeDef(currentTheme()).dark; }
  function themeDef(v) {
    return THEMES.filter(function (o) { return o.value === v; })[0] || THEMES[0];
  }
  function currentTheme() {
    var v = document.documentElement.getAttribute("data-theme");
    return THEMES.some(function (o) { return o.value === v; }) ? v : "light";
  }
  function setTheme(v) {
    document.documentElement.setAttribute("data-theme", v);
    try { localStorage.setItem(THEME_KEY, v); } catch (e) {}
    paintThemeButton();
    // Leaflet tiles are inverted for the dark palettes, so a redraw is needed.
    if (leafletMap && current && !$("#detail-overlay").hidden) openTrip(current);
  }
  function paintThemeButton() {
    var b = $("#theme-toggle"); if (!b) return;
    var cur = themeDef(currentTheme());
    b.textContent = cur.mark;
    b.title = cur.label.replace(/^\S+\s/, "") + " — click to switch theme";
    var m = document.querySelector('meta[name="theme-color"]');
    if (m) m.setAttribute("content", cur.color);
  }

  function applyDisplay(d) {
    var r = document.documentElement;
    r.setAttribute("data-text", d.text);
    r.setAttribute("data-width", d.width);
    r.setAttribute("data-density", d.density || "comfortable");
    r.setAttribute("data-spacing", d.spacing || "normal");
    try { localStorage.setItem(DISPLAY_KEY, JSON.stringify(d)); } catch (e) {}
    // The map needs to be told its container resized, or it renders in the old box.
    if (leafletMap) { setTimeout(function () { try { leafletMap.invalidateSize(); } catch (e) {} }, 220); }
  }
  // Several settings change what's rendered rather than just how it looks.
  function redrawAll() {
    if (current && !$("#detail-overlay").hidden) openTrip(current);
    else render();
  }
  function openDisplayDialog() {
    var d = getDisplay();
    var o = overlay("settings");
    var back = o.back, panel = o.panel;
    panel.appendChild(el("h3", "form-title", "Settings"));

    // Say what the two lines are for. Unlabelled, they read as a stray booking
    // someone left at the top of the dialog.
    panel.appendChild(el("div", "seg-label", "Sample Text"));
    var prev = el("div", "seg-preview");
    prev.appendChild(el("div", "p1", "Delta Air Lines DL1715"));
    prev.appendChild(el("div", "p2", "LAX → SFO · Seat 12F · Conf F9GNRJ"));
    panel.appendChild(prev);

    function segment(label, key, options, after) {
      panel.appendChild(el("div", "seg-label", label));
      var wrap = el("div", "seg");
      options.forEach(function (o) {
        var b = el("button", d[key] === o.value ? "on" : "", o.label);
        b.type = "button";
        b.addEventListener("click", function () {
          d[key] = o.value;
          applyDisplay(d);
          [].forEach.call(wrap.children, function (c) { c.classList.remove("on"); });
          b.classList.add("on");
          if (after) after();
        });
        wrap.appendChild(b);
      });
      panel.appendChild(wrap);
    }
    // Theme lives outside the display object — index.html reads it inline before
    // first paint so the page never flashes the wrong palette.
    panel.appendChild(el("div", "seg-label", "Theme"));
    var themeRows = [];
    [true, false].forEach(function (isDark) {
      var rowWrap = el("div", "seg seg-row-tight");
      THEMES.filter(function (o) { return !!o.dark === isDark; }).forEach(function (o) {
        var b = el("button", currentTheme() === o.value ? "on" : "", o.label); b.type = "button";
        b.addEventListener("click", function () {
          setTheme(o.value);
          // Selection is exclusive across both rows, not within one.
          themeRows.forEach(function (rw) { [].forEach.call(rw.children, function (c) { c.classList.remove("on"); }); });
          b.classList.add("on");
        });
        rowWrap.appendChild(b);
      });
      themeRows.push(rowWrap);
      panel.appendChild(rowWrap);
    });
    themeRows[themeRows.length - 1].classList.remove("seg-row-tight");

    segment("Text size", "text", [
      { value: "small", label: "Small" }, { value: "medium", label: "Medium" },
      { value: "large", label: "Large" }, { value: "huge", label: "Huge" }
    ]);
    segment("Line spacing", "spacing", [
      { value: "tight", label: "Tight" }, { value: "normal", label: "Normal" }, { value: "relaxed", label: "Relaxed" }
    ]);
    segment("Density", "density", [
      { value: "comfortable", label: "Comfortable" }, { value: "cosy", label: "Cosy" }, { value: "compact", label: "Compact" }
    ]);
    segment("Content width", "width", [
      { value: "compact", label: "Compact" },
      { value: "default", label: "Default" },
      { value: "full", label: "Full Screen" }
    ]);
    // These two change what's rendered, so redraw after switching.
    segment("Trip list", "tripView", [
      { value: "cards", label: "Cards" }, { value: "list", label: "Compact List" }
    ], function () { render(); });
    segment("Time format", "clock", [
      { value: "12", label: "12-hour" }, { value: "24", label: "24-hour" }
    ], redrawAll);
    segment("Date format", "dateFmt", [
      { value: "us", label: "Sep 27, 2026" }, { value: "eu", label: "27 Sep 2026" }, { value: "iso", label: "2026-09-27" }
    ], redrawAll);
    segment("Units", "units", [
      { value: "imperial", label: "Miles · °F" }, { value: "metric", label: "Kilometres · °C" }
    ], redrawAll);
    segment("Open on load", "landing", [
      { value: "list", label: "Trip List" }, { value: "current", label: "Current / Next Trip" }
    ]);
    segment("Trip check shows", "checkLevel", [
      { value: "all", label: "Everything" }, { value: "warn", label: "Issues & Warnings" }, { value: "issue", label: "Issues Only" }
    ], redrawAll);

    // Escape hatch for snoozes and dismissals made across every trip at once.
    // Restoring has to go through unhideCheck per key rather than clearing a
    // blob: each one is its own row on the server now, and they have to be
    // deleted individually or they would come straight back on the next load.
    // One button per kind, not one for both. They are different decisions with
    // different reach — a dismissal is the household's and a snooze is yours —
    // so bringing back everything you ever set aside just to see one of them
    // again is the wrong trade.
    var hiddenAll = Object.keys(checkMap);
    var dismissedKeys = hiddenAll.filter(function (k) { return checkMap[k] && checkMap[k].mode === "dismissed"; });
    var snoozedKeys = hiddenAll.filter(function (k) { return checkMap[k] && checkMap[k].mode === "snoozed"; });
    if (hiddenAll.length) {
      panel.appendChild(el("div", "seg-label", "Hidden Trip Checks"));
      var hc = el("div", "seg");
      var restorer = function (keys, label, note) {
        if (!keys.length) return;
        var b = el("button", "", label); b.type = "button"; b.title = note;
        b.addEventListener("click", function () {
          keys.forEach(function (k) { unhideCheck(k); });
          b.disabled = true; b.textContent = "Restored"; redrawAll();
        });
        hc.appendChild(b);
      };
      restorer(dismissedKeys, "Restore " + dismissedKeys.length + " Dismissed",
        "Dismissals are household-wide, so this brings them back for everyone.");
      restorer(snoozedKeys, "Restore " + snoozedKeys.length + " Snoozed",
        "Snoozes are yours alone, so this affects only your own devices.");
      panel.appendChild(hc);
    }

    // Admin/Edit only. A feed URL is a credential that works without Cloudflare
    // Access, so handing one out grants more than View/Read holds.
    if (isAdmin()) {
      panel.appendChild(el("div", "seg-label", "Calendar feeds"));
      var cf = el("div", "seg");
      var cfb = el("button", "", "Manage Calendar Feeds"); cfb.type = "button";
      cfb.addEventListener("click", function () { openCalendarFeeds(); });
      cf.appendChild(cfb); panel.appendChild(cf);
    }

    // Only shown to Admin/Edit. The server refuses /v1/users to anyone else, so
    // this is about not advertising a door that will not open.
    if (isAdmin()) {
      panel.appendChild(el("div", "seg-label", "People"));
      var pp = el("div", "seg");
      var ppb = el("button", "", "Manage Access"); ppb.type = "button";
      ppb.addEventListener("click", function () { openPeople(); });
      pp.appendChild(ppb); panel.appendChild(pp);
    }

    // Which build is actually running, and a way out when it is the wrong one.
    // Without this, "did my refresh update the app?" is unanswerable from the
    // device — which is precisely the question an installed PWA provokes, because
    // it keeps its own service worker and caches and gives no address bar to
    // interrogate.
    panel.appendChild(el("div", "seg-label", "App version"));
    var vr = el("div", "seg");
    // A readout, not an action — so it is a label. Rendered as a disabled button
    // it looked like something you had failed to be allowed to press.
    // The version alone no longer distinguishes anything -- it and APP_VERSION
    // are generated from the same number now. What this pill is FOR is telling
    // "I refreshed" apart from "I have the new code", so it names the bundle
    // actually executing, read off the script tag that loaded it. Two devices
    // reporting the same version but different hashes is the stale-cache case,
    // and it is otherwise invisible on a phone.
    var running = (function () {
      try {
        var tags = document.querySelectorAll('script[src]');
        for (var i = 0; i < tags.length; i++) {
          var m = /app\.([0-9a-f]{6,})\.js/.exec(tags[i].src || "");
          if (m) return m[1];
        }
      } catch (e) {}
      return null;
    })();
    var vlabel = el("span", "version-pill", "Running " + (window.__WAYFARER_BUILD || "unknown") +
      (running ? " · " + running : ""));
    var force = el("button", "", "Force Update"); force.type = "button";
    force.title = "Drop every cache, discard the service worker and reload from the network";
    force.addEventListener("click", async function () {
      force.disabled = true; force.textContent = "Updating…";
      try {
        // Unregister first: a live worker can re-serve the shell it just had
        // deleted, which is how a "cleared" cache comes back on the next paint.
        try {
          var regs = await navigator.serviceWorker.getRegistrations();
          await Promise.all(regs.map(function (r) { return r.unregister(); }));
        } catch (e) {}
        try {
          var keys = await caches.keys();
          await Promise.all(keys.map(function (k) { return caches.delete(k); }));
        } catch (e) {}
      } finally {
        // Cache-busted so an intermediary cannot hand back the same index.html.
        location.replace(location.pathname + "?u=" + Date.now());
      }
    });
    vr.appendChild(vlabel); vr.appendChild(force); panel.appendChild(vr);

    // Itinerary item types
    panel.appendChild(el("div", "seg-label", "Show in itinerary"));
    var kinds = el("div", "seg");
    [["transport", "Transport"], ["hosting", "Lodging"], ["activity", "Activities"]].forEach(function (k) {
      var b = el("button", d.showKinds[k[0]] ? "on" : "", k[1]); b.type = "button";
      b.addEventListener("click", function () {
        var on = !d.showKinds[k[0]];
        // Never let all three be switched off — that would blank the itinerary.
        if (!on && !Object.keys(d.showKinds).some(function (x) { return x !== k[0] && d.showKinds[x]; })) return;
        d.showKinds[k[0]] = on; b.classList.toggle("on", on);
        applyDisplay(d); redrawAll();
      });
      kinds.appendChild(b);
    });
    panel.appendChild(kinds);

    // Auto-collapse toggle
    panel.appendChild(el("div", "seg-label", "Past days"));
    var ac = el("div", "seg");
    var acb = el("button", d.autoCollapsePast ? "on" : "", "Collapse Automatically"); acb.type = "button";
    acb.addEventListener("click", function () {
      d.autoCollapsePast = !d.autoCollapsePast; acb.classList.toggle("on", d.autoCollapsePast);
      applyDisplay(d); collapsedDays = {}; redrawAll();
    });
    ac.appendChild(acb); panel.appendChild(ac);

    // Side sections: visibility + order
    panel.appendChild(el("div", "seg-label", "Trip detail sections"));
    var secWrap = el("div", "sec-list");
    function paintSections() {
      secWrap.innerHTML = "";
      d.sections.forEach(function (s, i) {
        var row = el("div", "sec-row");
        var tog = el("button", "sec-tog" + (s.on ? " on" : ""), s.on ? "✓" : "○"); tog.type = "button";
        tog.title = s.on ? "Shown" : "Hidden";
        tog.addEventListener("click", function () { s.on = !s.on; applyDisplay(d); paintSections(); redrawAll(); });
        row.appendChild(tog);
        row.appendChild(el("span", "sec-name", SECTION_LABEL[s.key] || s.key));
        var up = el("button", "sec-move", "↑"); up.type = "button"; up.disabled = i === 0;
        up.addEventListener("click", function () {
          d.sections.splice(i - 1, 0, d.sections.splice(i, 1)[0]);
          applyDisplay(d); paintSections(); redrawAll();
        });
        var dn = el("button", "sec-move", "↓"); dn.type = "button"; dn.disabled = i === d.sections.length - 1;
        dn.addEventListener("click", function () {
          d.sections.splice(i + 1, 0, d.sections.splice(i, 1)[0]);
          applyDisplay(d); paintSections(); redrawAll();
        });
        row.appendChild(up); row.appendChild(dn);
        secWrap.appendChild(row);
      });
    }
    paintSections();
    panel.appendChild(secWrap);
    // ---- full data export ----
    // Item endpoints are per-trip, so a complete snapshot is ~540
    // requests. That is trivial here (a few seconds, in parallel) but far too
    // many tool calls for the scheduled importer — which is why the full export
    // lives in the dashboard and the weekly task only captures what changed.
    panel.appendChild(el("div", "seg-label", "Backup"));
    var exp = el("div", "seg");
    var eb = el("button", "", "⬇ Export Everything"); eb.type = "button";
    var lastExp = null;
    try { lastExp = JSON.parse(localStorage.getItem("wayfarer_last_export") || "null"); } catch (e) {}
    var estat = el("div", "place-hint", lastExp
      ? "Last export " + new Date(lastExp.at).toLocaleDateString(dateLocale(), { year: "numeric", month: "short", day: "numeric" }) +
        " — " + lastExp.trips + " trips, " + lastExp.items + " items."
      : "A complete copy of every trip and every item, as JSON. Nothing is sent anywhere — the file is written straight from this browser.");
    eb.addEventListener("click", async function () {
      eb.disabled = true;
      try { await exportEverything(function (m) { estat.textContent = m; }); }
      catch (e) { estat.textContent = "Export failed: " + e.message; }
      eb.disabled = false;
    });
    exp.appendChild(eb); panel.appendChild(exp); panel.appendChild(estat);

    panel.appendChild(el("div", "seg-label seg-gap", "Account"));
    var acct = el("div", "seg");
    var ab = el("button", "", "⚙ Notifications & Currency"); ab.type = "button";
    ab.addEventListener("click", function () { back.remove(); openAccountDialog(); });
    acct.appendChild(ab); panel.appendChild(acct);
    panel.appendChild(el("div", "place-hint", "Display settings are remembered on this device. Account settings apply everywhere, including the iOS app."));

    // Which build this device is actually running. The app is a PWA behind a
    // service worker, so "I refreshed" and "I have the new code" are different
    // claims -- this is how you tell them apart without opening a console, and
    // it is the only way to check the phone at all. APP_VERSION is kept in step
    // with package.json by the build.
    panel.appendChild(el("div", "app-version", "Wayfarer " + APP_VERSION));

    var foot = el("div", "form-btns");
    var reset = el("button", "mini-btn", "Reset"); reset.type = "button";
    reset.addEventListener("click", function () { back.remove(); applyDisplay({ text: "large", width: "default" }); openDisplayDialog(); });
    var done = el("button", "primary-btn small", "Done"); done.type = "button";
    done.addEventListener("click", function () { back.remove(); });
    foot.appendChild(reset); foot.appendChild(done); panel.appendChild(foot);

  }
  $("#display-btn").addEventListener("click", openDisplayDialog);
  $("#newtrip-btn").addEventListener("click", function () { openNewTripDialog(); });
  applyDisplay(getDisplay());

  // Is a newer build deployed than the one running? index.html is served
  // no-cache and points at content-hashed assets, so comparing its script
  // reference against the loaded one is an exact check — no version numbers to
  // maintain and no guessing.
  async function newBuildAvailable() {
    try {
      var running = null;
      var tags = document.querySelectorAll('script[src*="/app."]');
      for (var i = 0; i < tags.length; i++) {
        var m = (tags[i].getAttribute("src") || "").match(/\/app\.[0-9a-f]+\.js/);
        if (m) running = m[0];
      }
      if (!running) return false;
      var html = await fetch("/index.html", { cache: "no-store" }).then(function (r) { return r.text(); });
      var latest = (html.match(/\/app\.[0-9a-f]+\.js/) || [])[0];
      return !!latest && latest !== running;
    } catch (e) { return false; }   // offline: never block a refresh on this
  }

  // One button, both jobs. It re-pulls your data in place — keeping you inside
  // the trip you were reading — and, if a new version has shipped, drops the
  // caches and reloads into it. Previously that second job needed a separate
  // control, which is a distinction nobody should have to remember.
  $("#refresh-btn").addEventListener("click", async function () {
    var btn = this;
    if (btn.disabled) return;
    btn.disabled = true; btn.classList.add("spinning");
    try {
      // Let the service worker notice a new build before we ask.
      try {
        var reg = await navigator.serviceWorker.getRegistration();
        if (reg) await reg.update();
      } catch (e) {}

      if (await newBuildAvailable()) {
        toast("Updating to the latest version…");
        try {
          var keys = await caches.keys();
          await Promise.all(keys.map(function (k) { return caches.delete(k); }));
        } catch (e) {}
        location.reload();
        return;   // the reload takes over; leave the button spinning
      }

      var detailOpen = !$("#detail-overlay").hidden && current;
      if (detailOpen) { await openTrip(current); }
      else { await loadAll(); }
      toast(detailOpen ? "Trip refreshed" : "Trips refreshed");
    } catch (e) {
      toast("Refresh failed: " + (e.message || e));
    } finally {
      btn.disabled = false; btn.classList.remove("spinning");
    }
  });

  // ---- dates ----
  function toDate(s) { if (!s) return null; var d = new Date(s.length <= 10 ? s + "T00:00:00" : s); return isNaN(d) ? null : d; }
  function spanDays(t) { var s = toDate(t.starts_at), e = toDate(t.ends_at); if (!s || !e) return t.starts_at ? 1 : 0; return Math.round((e - s) / 86400000) + 1; }
  // "Sep 14" -- a day without its year, in the date format the user chose.
  // Three call sites built this by hand from the same option object. NOT used
  // for every short date in the app: the offline strip deliberately passes []
  // rather than dateLocale() so it follows the browser rather than the app
  // setting, and several others also want a weekday or a year.
  function fmtMD(d) {
    return d.toLocaleDateString(dateLocale(), { month: "short", day: "numeric" });
  }

  function fmtRange(t) {
    if (!t.has_dates) return "No dates set";
    var s = toDate(t.starts_at), e = toDate(t.ends_at); if (!s) return "No dates set";
    if (getDisplay().dateFmt === "iso") {
      return t.ends_at && t.ends_at !== t.starts_at ? t.starts_at + " – " + t.ends_at : t.starts_at;
    }
    var mo = { month: "short", day: "numeric" }, yr = { year: "numeric" };
    var sm = s.toLocaleDateString(dateLocale(), mo);
    if (!e || +e === +s) return sm + ", " + s.toLocaleDateString(dateLocale(), yr);
    var sameMonth = s.getFullYear() === e.getFullYear() && s.getMonth() === e.getMonth();
    return sm + " – " + (sameMonth ? e.getDate() : e.toLocaleDateString(dateLocale(), mo)) + ", " + e.toLocaleDateString(dateLocale(), yr);
  }
  function countdown(t) {
    var s = toDate(t.starts_at), e = toDate(t.ends_at); if (!s) return "";
    var now = new Date(); now.setHours(0, 0, 0, 0);
    var d0 = new Date(s); d0.setHours(0, 0, 0, 0);
    if (e && now >= new Date(s.setHours(0, 0, 0, 0)) && now <= toDate(t.ends_at)) return "Happening now";
    var diff = Math.round((d0 - now) / 86400000);
    if (diff === 0) return "Today";
    if (diff === 1) return "Tomorrow";
    if (diff > 1) return "In " + diff + " days";
    return "";
  }

  // ---- timezone input helpers ----
  // Every timed value is stored as UTC and carries the location's IANA zone
  // alongside it. <input type="datetime-local"> speaks local wall-clock, so these
  // convert both ways. Verified round-trip against live data (incl. DST + date-crossing).
  function tzShift(date, tz) {
    try {
      var f = new Intl.DateTimeFormat("en-US", { timeZone: tz, hour12: false, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" });
      var m = {}; f.formatToParts(date).forEach(function (p) { m[p.type] = p.value; });
      var h = parseInt(m.hour, 10); if (h === 24) h = 0;
      return Date.UTC(+m.year, +m.month - 1, +m.day, h, +m.minute, +m.second) - date.getTime();
    } catch (e) { return 0; }
  }
  function toLocalInput(iso, tz) {
    if (!iso) return "";
    var d = new Date(iso); if (isNaN(d)) return "";
    return new Date(d.getTime() + tzShift(d, tz || "UTC")).toISOString().slice(0, 16);
  }
  function fromLocalInput(val, tz) {
    if (!val) return null;
    // Most of the year this is one subtraction, and the old two-pass solver was
    // right. It was wrong for one hour a year, in the direction that matters.
    //
    // On the night the clocks go back an hour happens twice: in London on
    // 2026-10-25, both 00:15Z and 01:15Z read "01:15". The old version
    // converged on whichever offset applied at the instant it was already
    // looking at, which is always the SECOND occurrence — so a booking timed
    // inside that hour came back an hour LATER than it went in. Open the
    // flight, change nothing, press Save, and it has moved.
    //
    // So both offsets in play around that wall time are tried — the one a day
    // before and the one a day after — and a candidate counts only if rendering
    // it back produces the wall time that was asked for. When two do, the
    // earlier wins: the clock reads that hour the first time before it reads it
    // the second, and a printed ticket means the first.
    //
    // When NONE fits, the wall time does not exist — 02:30 on the morning the
    // clocks go forward — and there is no right answer. It falls back to the
    // old result, which is at least a real instant on the right morning.
    var zone = tz || "UTC";
    var wall = new Date(val + ":00Z").getTime();
    var twoPass = wall - tzShift(new Date(wall - tzShift(new Date(wall), zone)), zone);
    var DAY = 86400000;
    var fits = function (ms) { return ms + tzShift(new Date(ms), zone) === wall; };
    var ok = [wall - tzShift(new Date(wall - DAY), zone),
              wall - tzShift(new Date(wall + DAY), zone),
              twoPass].filter(fits);
    var g = ok.length ? Math.min.apply(Math, ok) : twoPass;
    return new Date(g).toISOString().replace(".000", "");
  }
  // Move an instant by an amount, in the sense a person means it.
  //
  // Hours and minutes are absolute: "two hours later" is two real hours.
  //
  // DAYS ARE NOT. "A week later" means the same time on a different date, and
  // this used to add 7 × 86400000 ms — which is a week only when no daylight
  // saving falls in between. Push a trip from October to November and every
  // 1:00 PM flight became noon. The whole reason to shift a trip by days is
  // that the plans moved and the clock did not, so the calendar date is moved
  // and the wall-clock reading is carried across unchanged, in the item's own
  // zone.
  function shiftIso(iso, tz, n, unit) {
    if (!iso) return null;
    if (unit !== "days") {
      var ms = unit === "minutes" ? n * 60000 : n * MS_H;
      return new Date(Date.parse(iso) + ms).toISOString().replace(".000", "");
    }
    var local = toLocalInput(iso, tz);          // "YYYY-MM-DDTHH:MM"
    if (!local) return null;
    var d = local.slice(0, 10).split("-");
    // Date.UTC normalises an out-of-range day, so month and year ends need no
    // special case: 31 Jan + 1 is 1 Feb, 31 Dec + 1 is 1 Jan of the next year.
    var day = new Date(Date.UTC(+d[0], +d[1] - 1, +d[2] + n));
    return fromLocalInput(day.toISOString().slice(0, 10) + local.slice(10), tz);
  }

  var LOCAL_TZ = (function () { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC"; } catch (e) { return "UTC"; } })();
  function tripTz(t, data) {
    if (data) {
      var a = (data.activities || [])[0], h = (data.hostings || [])[0], x = (data.transports || [])[0];
      if (a && a.timezone) return a.timezone;
      if (h && h.timezone) return h.timezone;
      if (x && x.departure_timezone) return x.departure_timezone;
    }
    return (t && t.timezone) || LOCAL_TZ;
  }
  // ---- external free services (proxied through /api/ext/*) ----
  async function ext(path) {
    var r = await fetch("/api/ext/" + path, { cache: "no-store" });
    if (!r.ok) throw new Error("ext " + r.status);
    return r.json();
  }
  // Attaches a "🔎 Find address" control to a form that fills name/address/lat/long
  // from an OpenStreetMap lookup, so coordinates never have to be typed by hand.
  function attachPlaceSearch(panel, inputs, opts) {
    opts = opts || {};
    var latKey = opts.lat || "latitude", lonKey = opts.lon || "longitude";
    var addrKey = opts.address || "address", nameKey = opts.name || "name";
    if (!inputs[latKey] || !inputs[lonKey]) return;
    var host = inputs[addrKey] ? inputs[addrKey].parentNode : inputs[latKey].parentNode;
    var bar = el("div", "place-search");
    var q = el("input", "form-input"); q.type = "search";
    q.placeholder = opts.placeholder || "Search a place or address…";
    var go = el("button", "mini-btn", "🔎 Find"); go.type = "button";
    var out = el("div", "place-results"); out.hidden = true;
    bar.appendChild(q); bar.appendChild(go);
    // The host is normally a row already sitting in the form, so the search bar
    // slots in directly beneath it. A caller whose container is not attached
    // yet leaves parentNode null, and that used to throw HERE -- taking the
    // whole form down with it and rendering an empty dialog with no visible
    // clue why. One bad argument should cost its own feature, not the form, so
    // it falls back to sitting inside the host instead.
    var anchor = host.parentNode;
    if (anchor) {
      anchor.insertBefore(bar, host.nextSibling);
      anchor.insertBefore(out, bar.nextSibling);
    } else {
      host.appendChild(bar); host.appendChild(out);
    }

    async function run() {
      var term = q.value.trim();
      if (term.length < 3) return;
      go.disabled = true; go.textContent = "…";
      out.hidden = false; out.innerHTML = "";
      out.appendChild(el("div", "place-hint", "Searching…"));
      try {
        var d = await ext("geocode?q=" + encodeURIComponent(term));
        out.innerHTML = "";
        // Same trap as the bulk lookup: /api/ext/geocode reports an upstream
        // rate-limit as a 200 with {results: [], error: "geocoder 429"}. Shown
        // as "No matches" that sends you off to type coordinates by hand for a
        // place that would have resolved a minute later.
        if (d && d.error) {
          out.appendChild(el("div", "place-hint is-bad",
            "Lookup unavailable (" + d.error + ") — try again shortly."));
          return;
        }
        if (!d.results || !d.results.length) { out.appendChild(el("div", "place-hint", "No matches.")); return; }
        d.results.forEach(function (p) {
          var b = el("button", "place-hit"); b.type = "button";
          b.appendChild(el("div", "place-hit-name", p.name || p.label));
          b.appendChild(el("div", "place-hit-sub", p.label));
          b.addEventListener("click", function () {
            inputs[latKey].value = p.lat;
            inputs[lonKey].value = p.lon;
            if (inputs[addrKey]) inputs[addrKey].value = p.label;
            if (inputs[nameKey] && !inputs[nameKey].value) inputs[nameKey].value = p.name || "";
            out.hidden = true;
          });
          out.appendChild(b);
        });
        out.appendChild(el("div", "place-hint", d.attribution || ""));
      } catch (e) {
        out.innerHTML = ""; out.appendChild(el("div", "place-hint", "Lookup failed — enter coordinates manually."));
      } finally { go.disabled = false; go.textContent = "🔎 Find"; }
    }
    go.addEventListener("click", run);
    q.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); run(); } });
  }

  // ---- custom activity categories ----
  // You can define categories of your own (e.g. "Skiing") with an icon and
  // colour; their slugs show up as activity_type values. The API returns icon_name
  // (an asset name we cannot draw), so map it to a sensible glyph and use the
  // category's real name and colour.
  var CUSTOM_ICON = { ski: "⛷️", snow: "🎿", surf: "🏄", golf: "⛳", hike: "🥾", bike: "🚴",
    dive: "🤿", sail: "⛵", boat: "⛵", fish: "🎣", climb: "🧗", run: "🏃", spa: "💆",
    work: "💼", camp: "🏕️", horse: "🐎", tennis: "🎾", wine: "🍷" };
  function customIcon(c) {
    var key = ((c.icon_name || "") + " " + (c.name || "")).toLowerCase();
    for (var k in CUSTOM_ICON) if (key.indexOf(k) > -1) return CUSTOM_ICON[k];
    return "🏷️";
  }
  function catFor(slug) { return slug && state.categories && state.categories[slug] ? state.categories[slug] : null; }

  // `insurance` is an activity type rather than a table of its own, which buys
  // it the edit form, the documents attachment, `terms` and the contact fields
  // for nothing. What it needs beyond that is to be found and read quickly, so
  // it gets its own dossier block and two checks — see insuranceOf below.
  //
  // It sits first because it is the one entry you go looking for rather than
  // browse past.
  var ACT_TYPES = ["insurance", "general", "restaurant", "bar", "cafe", "bakery", "museum", "tour", "event", "concert", "theater",
    "movieTheater", "shopping", "foodMarket", "park", "nationalPark", "beach", "zoo", "aquarium", "amusementPark",
    "stadium", "winery", "brewery", "nightlife", "fit", "fitnessCenter", "relax", "kids", "meeting", "note", "parking",
    "publicTransport", "gasStation", "evCharger", "bank", "atm", "pharmacy", "hospital", "laundry", "library", "marina",
    "campground", "school", "university", "postOffice", "police", "fireStation", "restroom"];
  var TRANS_TYPES = ["airplane", "car", "roadtrip", "train", "bus", "ferry", "cruise", "bike", "motorcycle", "walk"];

  // ---- load ----
  // Paint first, ask second.
  //
  // This used to clear the list, show the skeleton, and wait for the network
  // before rendering anything -- so on a connection that is alive but slow, the
  // screen stayed a skeleton for up to the service worker's five-second
  // timeout while a complete itinerary sat in Cache Storage. For a daily-use
  // phone the common case is "barely changed since this morning", which is
  // exactly the case that was paying the most.
  //
  // Now: render the snapshot immediately if there is one, then replace it in
  // place when the network answers. A refresh over an already-painted list
  // never blanks it, so the online/refresh paths stop flashing too.
  async function loadAll() {
    var loading = $("#dash-loading"), groups = $("#dash-groups"), empty = $("#dash-empty");
    empty.hidden = true;

    var snap = null;
    if (!state.own.length) {
      snap = readSnapshot();
      if (snap) {
        state.own = snap.trips;
        loading.hidden = true;
        buildYearOptions();
        render();
      }
    }
    // The skeleton is for having nothing to show, not for being busy. If a
    // snapshot or a previous load is already on screen, leave it alone.
    var blank = !state.own.length;
    if (blank) { loading.hidden = false; groups.innerHTML = ""; }

    // Check state is NOT in the gate below. It feeds the trip-detail health
    // sections, never the cards being painted, and it awaits a replay of any
    // writes queued while offline -- serially, one round trip each. That made
    // the one thing first paint does not need into its slowest dependency,
    // precisely on the bad networks it was written for.
    loadCheckState();

    try {
      var results = await Promise.all([
        apiAll("/v1/trips"),
        api("/v1/categories").catch(function () { return { results: [] }; })
      ]);
      var all = results[0] || [];
      state.own = all;
      saveSnapshot(all);
      snapshotAt = null; paintOffline();
      (((results[1] && results[1].results) || [])).forEach(function (c) { if (c.slug) state.categories[c.slug] = c; });
      loading.hidden = true;
      buildYearOptions();
      render();
      maybeOpenLanding();
      detectChangedTrips();
      if (!deepLinkHandled) { deepLinkHandled = true; handleHash(); }
      indexDestinations();
    } catch (err) {
      loading.hidden = true;
      if (err.status === 401) return;
      if (!blank) {
        // Something is already on screen and it is not current. Say so rather
        // than replacing a usable itinerary with an error, or -- worse --
        // leaving stale data up with no indication at all.
        if (snap) { var d = new Date(snap.at); snapshotAt = isNaN(d.getTime()) ? new Date() : d; paintOffline(); }
        return;
      }
      empty.hidden = false; empty.textContent = "Couldn't load trips: " + (err.message || "error");
    }
  }

  // Background index of each trip's lodging + activity locations so search matches
  // cities/places, not just trip names. Cached in localStorage (versioned key).
  // The dashboard's search matches hotel names and addresses, which live on the
  // itinerary rather than the trip, so they have to be indexed separately.
  //
  // This used to fetch every trip's hostings and activities one trip at a time
  // -- two requests each, four workers, up to 362 requests on a device with an
  // empty localStorage -- fired immediately after first paint, competing with
  // the cover images for the connection. The server builds the whole index in
  // two SQL queries now, so it is one request.
  //
  // The localStorage cache is kept: it means a warm device does no network work
  // at all, and it is also the fallback if the endpoint fails.
  async function indexDestinations() {
    var KEY = "tdest2_";
    var trips = state.own;
    trips.forEach(function (t) {
      try { var c = localStorage.getItem(KEY + t.id); if (c != null) state.dest[t.id] = c; } catch (e) {}
    });
    var todo = trips.filter(function (t) { return state.dest[t.id] === undefined; });
    if (!todo.length) return;
    try {
      var d = await api("/v1/destinations");
      var got = (d && d.results) || {};
      todo.forEach(function (t) {
        // Absent means the trip genuinely has no places, not that the lookup
        // failed -- store "" so it is not asked for again on every load.
        var s = got[t.id] || "";
        state.dest[t.id] = s;
        try { localStorage.setItem(KEY + t.id, s); } catch (e) {}
      });
    } catch (e) {
      // Leave them unindexed rather than caching a wrong empty answer: search
      // misses a few trips this load and tries again on the next.
    }
  }

  // ---- stats ----
  // The dashboard used to carry five stat tiles above the trip list. They cost
  // three rows of vertical space on a phone on every single load, to answer
  // questions nobody asks while looking for tomorrow's flight. They now live in
  // History, which is where you go when you actually want them.
  //
  // Still computed from state.own rather than /v1/insights, deliberately: these
  // are the exact figures shown for the last year, and the server counts nights
  // between dates where this counts inclusive days. Recomputing them elsewhere
  // would quietly move every number.
  function tripStats() {
    var dated = state.own.filter(function (t) { return t.has_dates && toDate(t.starts_at); });
    var days = 0, byYearN = {}, byYearD = {}, thisYear = new Date().getFullYear();
    var thisYearN = 0, thisYearD = 0, minYear = 9999;
    dated.forEach(function (t) {
      var d = spanDays(t); days += d;
      var y = toDate(t.starts_at).getFullYear();
      byYearN[y] = (byYearN[y] || 0) + 1; byYearD[y] = (byYearD[y] || 0) + d;
      minYear = Math.min(minYear, y);
      if (y === thisYear) { thisYearN++; thisYearD += d; }
    });
    var busiest = Object.keys(byYearN).sort(function (a, b) { return byYearN[b] - byYearN[a]; })[0];
    return {
      trips: state.own.length, days: days, thisYearN: thisYearN, thisYearD: thisYearD,
      busiest: busiest, busiestN: busiest ? byYearN[busiest] : 0, busiestD: busiest ? byYearD[busiest] : 0,
      avg: dated.length ? Math.round(days / dated.length) : 0,
      since: minYear === 9999 ? null : minYear
    };
  }

  // ---- travel history ----
  // Fifteen years of trips, which is the one thing a newly-installed rival
  // cannot show you. Everything here is computed server-side by /v1/insights —
  // assembling it in the browser would mean three calls per trip, 543 requests,
  // to draw a single screen.
  var insightsCache = null;
  async function openInsights() {
    panelRoute("#history");
    var o = overlay("wide insights", function () { shut(); });
    // Paired with panelRoute above: closing this releases #history again.
    o.back.__route = "#history";
    var back = o.back, panel = o.panel;
    panel.appendChild(el("h3", "form-title", "History"));
    var body = el("div", "insights-body");
    body.appendChild(el("div", "doc-empty", "Working out fifteen years…"));
    panel.appendChild(body);
    var btns = el("div", "form-btns");
    var close = el("button", "primary-btn small", "Done"); close.type = "button";
    btns.appendChild(close); panel.appendChild(btns);
    function shut() { back.remove(); if (insightsMap) { try { insightsMap.remove(); } catch (e) {} insightsMap = null; } }
    close.addEventListener("click", shut);

    var d = insightsCache;
    if (!d) {
      try { d = await api("/v1/insights"); insightsCache = d; }
      catch (e) { body.innerHTML = ""; body.appendChild(el("div", "form-err", "Couldn't load: " + e.message)); return; }
    }
    body.innerHTML = "";

    var n = d.totals || {};
    var s = tripStats();
    var head = el("div", "insight-tiles");
    // The five that used to sit on the dashboard come first — they answer
    // "how much do we travel" — then the ones only the server can work out.
    // "Nights away" is deliberately omitted: it is the same question as
    // "Days traveled" with a different fencepost, and showing both invites
    // the reader to spot a discrepancy that is really just a definition.
    [[String(s.trips), "Trips", s.thisYearN + " this year"],
     [s.days.toLocaleString(), "Days traveled", s.thisYearD + " this year"],
     [String(s.busiest || "—"), "Busiest year", s.busiest ? (s.busiestN + " trips · " + s.busiestD + " days") : ""],
     [s.avg + (s.avg === 1 ? " day" : " days"), "Avg length", ""],
     [String(s.since || "—"), "Traveling since", ""],
     [fmtNum(n.miles), "Miles flown", ""],
     [fmtNum(n.flights), "Flights", ""],
     [fmtNum(n.places), "Places", ""],
     // The subtitle is the honest part. A country count derived from airports
     // and addresses cannot place a domestic drive whose address ends in a zip
     // code, and saying so is better than quietly assuming those were at home.
     [String((d.countries && d.countries.count) || 0), "Countries",
      (d.countries && d.countries.unplaced_trips)
        ? d.countries.unplaced_trips + " trips unplaced" : ""],
     [fmtNum(n.timezone_legs), "Legs across a timezone", ""]
    ].forEach(function (t) {
      var b = el("div", "stat");
      b.appendChild(el("div", "stat-num", t[0]));
      b.appendChild(el("div", "stat-label", t[1]));
      if (t[2]) b.appendChild(el("div", "stat-sub", t[2]));
      head.appendChild(b);
    });
    body.appendChild(head);

    // Per-year bars. Plain divs rather than a charting library: this is one
    // series and the app has no build step to hang a dependency off.
    var years = (d.by_year || []).filter(function (r) { return r.trips; });
    if (years.length) {
      body.appendChild(el("div", "seg-label", "Trips per year"));
      var maxT = Math.max.apply(null, years.map(function (r) { return r.trips; }));
      var chart = el("div", "yr-chart");
      years.forEach(function (r) {
        var col = el("div", "yr-col");
        col.title = r.year + " · " + r.trips + " trips · " + r.nights + " nights · " + fmtNum(r.miles) + " miles";
        var bar = el("div", "yr-bar");
        bar.style.height = Math.max(3, Math.round((r.trips / maxT) * 100)) + "%";
        col.appendChild(el("div", "yr-num", String(r.trips)));
        col.appendChild(bar);
        col.appendChild(el("div", "yr-lab", r.year.slice(2)));
        chart.appendChild(col);
      });
      body.appendChild(chart);
    }

    var lists = el("div", "insight-cols");
    var listOf = function (title, rows, fmt) {
      if (!rows || !rows.length) return;
      var c = el("div", "insight-col");
      c.appendChild(el("div", "seg-label", title));
      rows.forEach(function (r) {
        var li = el("div", "insight-row");
        li.appendChild(el("span", "insight-name", fmt ? fmt(r) : r.name));
        li.appendChild(el("span", "insight-n", String(r.count != null ? r.count : r.n)));
        c.appendChild(li);
      });
      lists.appendChild(c);
    };
    // `trips` rather than `count`/`n`, so it needs the shape the others use.
    listOf("Countries", ((d.countries && d.countries.list) || []).slice(0, 12)
      .map(function (r) { return { name: r.name, count: r.trips }; }));
    listOf("Airports", (d.airports || []).slice(0, 8));
    listOf("Airlines", (d.airlines || []).slice(0, 8));
    listOf("Aircraft", (d.aircraft || []).slice(0, 6));
    body.appendChild(lists);

    // Hotels, counted both ways. Stays is how often you walked through the
    // door; nights is how much of your life you spent there — and for status
    // and points it is nights that count, which is why both are shown.
    var ho = d.hotels;
    if (ho && ho.stays) {
      body.appendChild(el("div", "seg-label",
        "Hotels · " + fmtNum(ho.stays) + " stays · " + fmtNum(ho.nights) + " nights"));
      var hcols = el("div", "insight-cols");
      var hotelList = function (title, rows, note) {
        if (!rows || !rows.length) return;
        var c = el("div", "insight-col");
        c.appendChild(el("div", "seg-label", title));
        rows.forEach(function (r) {
          var li = el("div", "insight-row");
          li.appendChild(el("span", "insight-name", r.name));
          li.appendChild(el("span", "insight-n", r.stays + " · " + r.nights + "n"));
          li.title = r.stays + (r.stays === 1 ? " stay" : " stays") + ", " +
            r.nights + (r.nights === 1 ? " night" : " nights");
          c.appendChild(li);
        });
        if (note) c.appendChild(el("div", "insight-note", note));
        hcols.appendChild(c);
      };
      hotelList("By chain", ho.chains,
        ho.independent_stays ? ho.independent_stays + " stays at independents" : "");
      hotelList("Most-stayed properties", ho.properties);
      body.appendChild(hcols);
      body.appendChild(el("div", "insight-note", "Counts read as stays · nights."));
    }

    if ((d.destinations || []).length) {
      body.appendChild(el("div", "seg-label", "Places you keep going back to"));
      var rep = el("div", "insight-repeat");
      d.destinations.slice(0, 12).forEach(function (r) {
        var b = el("button", "mini-btn", r.name + "  ×" + r.n); b.type = "button";
        b.title = "Last visit " + (r.last || "—") + " — search your trips";
        b.addEventListener("click", function () {
          shut();
          var s = $("#search"); s.value = r.name; state.q = r.name;
          state.filters.past = true; saveFilters(); paintFilterChips(); render();
        });
        rep.appendChild(b);
      });
      body.appendChild(rep);
    }

    if (d.longest) {
      body.appendChild(el("div", "insight-note",
        "Longest trip: " + d.longest.name + " — " + d.longest.nights + " nights."));
    }

    // The map last: it has to be in the DOM and sized before Leaflet will draw.
    body.appendChild(el("div", "seg-label", "Everywhere you've been"));
    var mapWrap = el("div", "insight-map");
    body.appendChild(mapWrap);
    setTimeout(function () { drawInsightsMap(mapWrap, d.places || []); }, 30);
  }

  function fmtNum(v) { return (Number(v) || 0).toLocaleString(); }

  // ---- Google Maps ----
  //
  // Loaded only when a key is configured, and Leaflet stays as the fallback so
  // the map never simply vanishes -- on a fresh deploy before the key is set,
  // on a referrer the key does not allow, or if the script fails to load.
  //
  // Only the DISPLAY and the DRIVE TIMES moved. Geocoding deliberately did not:
  // Google's terms allow caching coordinates for at most 30 consecutive days,
  // and this app stores them on every record permanently -- fifteen years of
  // them. OpenStreetMap's data is ODbL and may be kept, which is the whole
  // reason it is still there. Showing our OWN stored coordinates on a Google
  // map is fine; the restriction runs the other way.
  var mapsKey = null, gmapsPromise = null;

  // Google loaded but REFUSED. Billing lapsed, the key was rejected, the
  // referrer is not on the allow-list.
  //
  // This is the case that actually happens, and the one the loader below could
  // not see. Its `error` listener fires only when the script fails to
  // DOWNLOAD -- an offline phone. When authentication fails the script downloads
  // perfectly, window.google.maps exists, and every check says Google is fine
  // while the map renders as a grey watermarked box. gm_authFailure is the only
  // signal Google gives for it, and nothing was listening.
  //
  // The billing account is on pay-as-you-go with the free tiers, so there is no
  // expiry date driving this. What drives it is that a REFUSAL is a normal,
  // recoverable condition and always will be: the daily quota cap being reached
  // (Map loads are capped at 300/day, deliberately below the free allowance),
  // a referrer the key does not allow after a hostname changes, a rotated or
  // mistyped key, or Google simply having a bad hour.
  //
  // Every one of those downloads the script perfectly and then refuses, which is
  // exactly the case this handler exists for and the loader below could not
  // see.
  var googleDead = false;
  // How to redraw whichever maps are on screen. A map drawn before the refusal
  // is a broken map; it has to be rebuilt, not just left there.
  //
  // Two named slots rather than a list, because only two maps can ever be
  // visible -- the open trip's and the history dialog's -- and each new one
  // replaces its predecessor. A list would have grown by one closure per trip
  // opened, each holding a DOM node and a trip's data alive for a callback that
  // fires at most once, if ever.
  var mapRedraws = { trip: null, history: null };

  window.gm_authFailure = function () {
    googleDead = true;
    var slots = mapRedraws;
    mapRedraws = { trip: null, history: null };
    ["trip", "history"].forEach(function (k) {
      // One bad map must not stop the other from recovering.
      if (slots[k]) { try { slots[k](); } catch (e) { /* ignore */ } }
    });
  };

  // ---- Leaflet, on demand ----
  //
  // The fallback for when Google cannot draw the map: no key configured, a
  // referrer the key rejects, a script that will not load, the 300/day quota cap
  // reached, or Google having a bad hour. None of those is hypothetical and none
  // of them has a date -- which is the point. Google is the normal path and this
  // is what keeps a map on the screen when the normal path says no.
  //
  // But it used to load on EVERY page view: 144KB of JavaScript and 14KB of CSS
  // for a path that, when everything is working, never executes once. So it is
  // injected only at the moment something actually needs it, with the same
  // subresource-integrity hashes the markup used to carry -- lazy loading must
  // not quietly become unverified loading.
  var LEAFLET_JS = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";
  var LEAFLET_CSS = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
  var LEAFLET_JS_SRI = "sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=";
  var LEAFLET_CSS_SRI = "sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=";
  var leafletPromise = null;

  function loadLeaflet() {
    if (window.L) return Promise.resolve(true);
    if (leafletPromise) return leafletPromise;
    leafletPromise = new Promise(function (resolve) {
      var css = document.createElement("link");
      css.rel = "stylesheet"; css.href = LEAFLET_CSS;
      css.integrity = LEAFLET_CSS_SRI; css.crossOrigin = "";
      document.head.appendChild(css);
      var sc = document.createElement("script");
      sc.src = LEAFLET_JS; sc.integrity = LEAFLET_JS_SRI; sc.crossOrigin = "";
      sc.addEventListener("load", function () { resolve(!!window.L); });
      // Resolving false rather than rejecting: every caller then draws nothing
      // instead of having to catch. A missing fallback map is a shame; an
      // unhandled rejection in the middle of building a trip panel is a bug.
      sc.addEventListener("error", function () { resolve(false); });
      document.head.appendChild(sc);
    });
    return leafletPromise;
  }

  // Run something once Leaflet is there, or not at all.
  function withLeaflet(fn) { loadLeaflet().then(function (ok) { if (ok) fn(); }); }

  function loadGoogleMaps() {
    if (!mapsKey || googleDead) return Promise.resolve(null);
    if (window.google && window.google.maps) return Promise.resolve(window.google.maps);
    if (gmapsPromise) return gmapsPromise;
    gmapsPromise = new Promise(function (resolve) {
      var sc = document.createElement("script");
      sc.src = "https://maps.googleapis.com/maps/api/js?key=" + encodeURIComponent(mapsKey) +
        "&libraries=geometry&loading=async&v=weekly";
      sc.async = true;
      // Only fires when the script cannot be DOWNLOADED — an offline phone, a
      // blocked host. A rejected key or lapsed billing downloads fine and is
      // caught by gm_authFailure above instead.
      sc.addEventListener("load", function () {
        resolve(googleDead ? null : (window.google && window.google.maps));
      });
      // Resolving null rather than rejecting means every caller falls through
      // to Leaflet instead of having to catch.
      sc.addEventListener("error", function () { resolve(null); });
      document.head.appendChild(sc);
    });
    return gmapsPromise;
  }

  // Dark styling without a cloud-configured Map ID, so the only thing this
  // feature needs from Google is an API key.
  var GMAP_DARK = [
    { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
    { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
    { elementType: "labels.text.fill", stylers: [{ color: "#a9b6c9" }] },
    { featureType: "poi", stylers: [{ visibility: "off" }] },
    { featureType: "transit", stylers: [{ visibility: "off" }] },
    { featureType: "road", elementType: "geometry", stylers: [{ color: "#38414e" }] },
    { featureType: "road", elementType: "geometry.stroke", stylers: [{ color: "#212a37" }] },
    { featureType: "road", elementType: "labels.text.fill", stylers: [{ color: "#9ca5b3" }] },
    { featureType: "water", elementType: "geometry", stylers: [{ color: "#17263c" }] },
    { featureType: "water", elementType: "labels.text.fill", stylers: [{ color: "#515c6d" }] },
  ];
  var GMAP_LIGHT = [
    { featureType: "poi", stylers: [{ visibility: "off" }] },
    { featureType: "transit", stylers: [{ visibility: "off" }] },
  ];

  function gmapNew(g, node, dark) {
    return new g.Map(node, {
      mapTypeControl: true, streetViewControl: true, fullscreenControl: false,
      scrollwheel: false, gestureHandling: "cooperative",
      styles: dark ? GMAP_DARK : GMAP_LIGHT,
      mapTypeControlOptions: { mapTypeIds: ["roadmap", "hybrid", "terrain"] },
    });
  }

  // An emoji on a white disc, which is what the Leaflet divIcon pins looked
  // like. Classic Marker rather than AdvancedMarkerElement deliberately: the
  // advanced one needs a Map ID configured in the Cloud console, and the point
  // of this design is that an API key is the only setup step.
  function gmapPin(g, map, lat, lng, icon, label, colour) {
    var m = new g.Marker({
      position: { lat: lat, lng: lng }, map: map,
      title: label || "",
      label: icon ? { text: icon, fontSize: "15px" } : undefined,
      icon: {
        path: g.SymbolPath.CIRCLE, scale: 13,
        fillColor: colour || "#ffffff", fillOpacity: 1,
        strokeColor: "rgba(0,0,0,.35)", strokeWeight: 1,
      },
    });
    if (label) {
      var iw = new g.InfoWindow({ content: escapeHtml(label) });
      m.addListener("click", function () { iw.open({ anchor: m, map: map }); });
    }
    return m;
  }

  function gmapFit(g, map, pts) {
    if (!pts.length) return;
    if (pts.length === 1) { map.setCenter({ lat: pts[0][0], lng: pts[0][1] }); map.setZoom(11); return; }
    var b = new g.LatLngBounds();
    pts.forEach(function (p) { b.extend({ lat: p[0], lng: p[1] }); });
    map.fitBounds(b, 28);
  }

  var insightsMap = null;
  function drawInsightsMap(node, places) {
    if (!places.length) { node.appendChild(el("div", "doc-empty", "No mapped places yet.")); return; }
    if (mapsKey && !googleDead) {
      loadGoogleMaps().then(function (g) {
        if (!g) return withLeaflet(function () { drawInsightsMapLeaflet(node, places); });
        mapRedraws.history = function () { node.innerHTML = ""; drawInsightsMap(node, places); };
        var dark = isDarkTheme();
        var map = gmapNew(g, node, dark);
        map.setCenter({ lat: 20, lng: -60 }); map.setZoom(2);
        var pts = [];
        places.forEach(function (p) {
          if (!isFinite(p.lat) || !isFinite(p.lon)) return;
          pts.push([p.lat, p.lon]);
          // Small discs rather than pins: 680 markers as pins is unreadable,
          // and the trail of where you actually go is the point.
          new g.Marker({
            position: { lat: p.lat, lng: p.lon }, map: map, title: p.label || "",
            icon: { path: g.SymbolPath.CIRCLE, scale: 4,
              fillColor: dark ? "#6ee7a8" : "#0f9d58", fillOpacity: .8,
              strokeColor: dark ? "#0b3b22" : "#ffffff", strokeWeight: 1 },
          });
        });
        gmapFit(g, map, pts);
      });
      return;
    }
    withLeaflet(function () { drawInsightsMapLeaflet(node, places); });
  }

  function drawInsightsMapLeaflet(node, places) {
    if (!window.L) { node.appendChild(el("div", "doc-empty", "No mapped places yet.")); return; }
    try {
      insightsMap = L.map(node, { scrollWheelZoom: false }).setView([20, -60], 2);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
        { attribution: "© OpenStreetMap", maxZoom: 18 }).addTo(insightsMap);
      // 680 markers would be unreadable and slow. Circles sized small, and the
      // map fitted to them, reads as a heat trail of where you actually go.
      var pts = [];
      places.forEach(function (p) {
        if (!isFinite(p.lat) || !isFinite(p.lon)) return;
        pts.push([p.lat, p.lon]);
        L.circleMarker([p.lat, p.lon], {
          radius: p.kind === "airport" ? 3 : 4, weight: 1,
          color: p.kind === "airport" ? "#6b7683" : "#2f6df6",
          fillColor: p.kind === "airport" ? "#6b7683" : "#2f6df6", fillOpacity: 0.55
        }).addTo(insightsMap).bindPopup(
          "<strong>" + escapeHtml(p.name || "") + "</strong><br>" +
          escapeHtml([p.trip, p.year].filter(Boolean).join(" · ")));
      });
      if (pts.length) insightsMap.fitBounds(pts, { padding: [20, 20] });
    } catch (e) {
      node.appendChild(el("div", "doc-empty", "Map unavailable."));
    }
  }
  function escapeHtml(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function isPhone() {
    try { return window.matchMedia("(max-width:700px)").matches; } catch (e) { return false; }
  }

  // ---- filters + year jump ----
  function buildYearOptions() {
    var years = {}; state.own.forEach(function (t) { var d = toDate(t.starts_at); if (t.has_dates && d) years[d.getFullYear()] = true; });
    var sel = $("#year-jump"); sel.innerHTML = '<option value="">All years</option>';
    Object.keys(years).sort(function (a, b) { return b - a; }).forEach(function (y) {
      var o = el("option", null, y); o.value = y; sel.appendChild(o);
    });
  }
  $("#filters").addEventListener("click", function (e) {
    var b = e.target.closest(".chip"); if (!b) return;
    var f = b.getAttribute("data-filter"); state.filters[f] = !state.filters[f];
    b.classList.toggle("active", state.filters[f]);
    saveFilters();
    render();
  });
  // Build marker: lets us confirm which bundle a browser is actually running,
  // rather than trusting the ?v= in the script URL.
  window.__WAYFARER_BUILD = "v121.1";
  // Both sweeps live in the toolbar, in the order they are reached for: pick a
  // year, look back over all of them, then check what is coming. Appending in
  // this order puts History between the year jump and Check Trips.
  (function () {
    var bar = document.querySelector(".dash-toolbar") || document.querySelector("#filters");
    if (!bar) { window.__WAYFARER_AUDIT_BTN = "no-toolbar"; return; }

    var h = el("button", "chip audit-all chip-history", "📊 History");
    h.type = "button";
    h.title = "Every trip, mile and place across all years";
    h.addEventListener("click", function () { openInsights(); });
    bar.appendChild(h);

    var b = el("button", "chip audit-all chip-check", "🩺 Check Trips");
    b.type = "button";
    b.addEventListener("click", function () { auditAllUpcoming(); });
    bar.appendChild(b);

    // Sits after Check Trips because it answers the later question. Check Trips
    // asks whether the itinerary is sound; this asks what moved since you last
    // looked at it.
    var c = el("button", "chip audit-all chip-changes", "⟳ Changes");
    c.type = "button";
    c.title = "Every booking the importer has rewritten on your upcoming trips, with the old value beside the new one";
    c.addEventListener("click", function () { reviewChanges(); });
    bar.appendChild(c);

    var cal = el("button", "chip audit-all chip-cal", "🗓 Calendar");
    cal.type = "button";
    cal.title = "Every trip as a year of months — when you are away, rather than which trip";
    cal.addEventListener("click", function () { openYearGrid(); });
    bar.appendChild(cal);

    var bl = el("button", "chip audit-all chip-bucket", "✨ Trip Ideas");
    bl.type = "button";
    bl.title = "Places you want to go but have not booked";
    bl.addEventListener("click", function () { openBucketList(); });
    bar.appendChild(bl);

    var cg = el("button", "chip audit-all chip-cards", "💳 Card Rewards");
    cg.type = "button";
    cg.title = "Progress toward the annual spend that earns each card's reward";
    cg.addEventListener("click", function () { openCardGoals(); });
    bar.appendChild(cg);

    // These accumulated one feature at a time, and on a phone they wrapped to
    // 271px of chips before a single trip was visible — the toolbar had quietly
    // become the page. Same fix as the itinerary rows: keep the one you reach
    // for, put the rest behind a labelled sheet, and MOVE the real buttons so
    // every handler survives.
    //
    // Two of the seven are gone entirely (2026-08-23): "every flight across
    // every trip" and "every document across every trip" answered questions
    // nobody was asking. A cross-trip index earns its place only if you search
    // it; this one was only ever passed on the way to something else.
    //
    // Everything goes behind it on a phone, Check Trips included. It was kept
    // on the bar at first on the argument that it is the app's whole point —
    // but the point of the phone view is the trips themselves, and one clean
    // row of controls beats a special case. All of these are things you go
    // looking for, which a sheet serves perfectly well.
    //
    // Re-run on resize: the toolbar is built once at load, unlike the itinerary
    // which re-renders, so rotating a phone would otherwise strand it.
    var actions = [h, b, c, cal, bl, cg];
    // A hidden home for the collapsed chips rather than leaving them detached.
    // openActionSheet records each chip's parent when it opens and restores it
    // on close; with no parent it would restore nothing, and they would sit
    // orphaned in memory. With a stash they always have somewhere to go back to.
    var stash = el("div", "chip-stash");
    document.body.appendChild(stash);
    var more = el("button", "chip audit-all chip-more", "⋯ More"); more.type = "button";
    more.title = MORE_TITLE;
    more.addEventListener("click", function () { openActionSheet("Everything else", actions); });
    // Held so the two sweeps can update it from wherever they finish.
    moreChip = more;
    drawMoreBadge();

    // The order the bar reads in, left to right, at full width.
    var order = [h, b, c, cal, bl, cg];
    var collapsed = null;
    var layoutToolbar = function () {
      var want = isPhone();
      if (want === collapsed) return;
      collapsed = want;
      if (want) {
        actions.forEach(function (x) { stash.appendChild(x); });
        bar.appendChild(more);
      } else {
        if (more.parentNode) more.parentNode.removeChild(more);
        // Re-append every action chip in its original order; appending a node
        // already in the bar just moves it, so this also repairs the order.
        order.forEach(function (x) { bar.appendChild(x); });
      }
    };
    layoutToolbar();
    // Bound to the media query as well as to resize, because the query IS the
    // condition and resize is only a proxy for it. A toolbar left in the wrong
    // shape until the next reload is a poor way to fail.
    try {
      var mq = window.matchMedia("(max-width:700px)");
      if (mq.addEventListener) mq.addEventListener("change", layoutToolbar);
      else if (mq.addListener) mq.addListener(layoutToolbar);
    } catch (e) { /* the resize listener below still covers it */ }
    window.addEventListener("resize", layoutToolbar);
    window.__WAYFARER_AUDIT_BTN = "added";
  })();

  $("#year-jump").addEventListener("change", function () {
    state.year = this.value;
    // Jumping to a year is meaningless with past hidden, so turn it on — and
    // remember it, since the user asked for history by asking for a year.
    if (state.year) { state.filters.past = true; saveFilters(); paintFilterChips(); }
    render();
    if (state.year) { var h = document.getElementById("year-" + state.year); if (h) h.scrollIntoView({ behavior: "smooth", block: "start" }); }
  });
  $("#search").addEventListener("input", render);

  // Always chronological. Sorting by name or duration was a control that had to
  // be set and then set back, and search answers "where is that one trip"
  // better than any ordering does. Upcoming reads forward from today; past reads
  // backward from today, so the most recent trip is at the top of each.
  function sortList(arr, past) {
    return arr.sort(function (a, b) { var da = toDate(a.starts_at) || 0, db = toDate(b.starts_at) || 0; return past ? db - da : da - db; });
  }

  // ---- render trips ----
  // The API returns cover_gradient as a bare integer — the index of a palette it
  // does not publish — so these are our own colours for the same indices. A trip
  // with no cover photo therefore looks different here than in the iOS app, but
  // consistently so: index 5 is always this teal on the dashboard.
  var GRADIENTS = [
    ["#4f7cff", "#8a5bff"], ["#f0714a", "#f5364b"], ["#12b76a", "#0a8a5f"],
    ["#f7b32b", "#f2681f"], ["#8b5cf6", "#d946ef"], ["#0ea5e9", "#14b8a6"],
    ["#e11d48", "#7c3aed"], ["#64748b", "#1e293b"], ["#facc15", "#84cc16"],
    ["#06b6d4", "#3b82f6"], ["#f472b6", "#fb7185"], ["#22c55e", "#eab308"],
    ["#6366f1", "#0ea5e9"], ["#ef4444", "#f97316"], ["#14b8a6", "#84cc16"],
    ["#a855f7", "#6366f1"]
  ];
  function gradientCss(n) {
    var g = GRADIENTS[((Number(n) || 0) % GRADIENTS.length + GRADIENTS.length) % GRADIENTS.length];
    return "linear-gradient(135deg," + g[0] + "," + g[1] + ")";
  }
  // Which part of a cover survives the crop.
  //
  // Every cover is centre-cropped into boxes of wildly different shapes — a trip
  // card on a phone is 350x253 (1.4:1), the trip header at full width is 4.75:1.
  // A wide image loses its sides on the card; a tall one loses its top and
  // bottom on the header. Centre is right for most photographs and wrong for any
  // where the subject is not in the middle: the Mammoth banner is 1200x550 with
  // its wordmark at x=750-1050, and the card shows only x=220-980, so the word
  // is cut in half.
  //
  // Nine positions, because that is what background-position needs and what a
  // 3x3 grid of buttons offers without inventing a vocabulary.
  var COVER_POSITIONS = [
    "left top",    "center top",    "right top",
    "left center", "center center", "right center",
    "left bottom", "center bottom", "right bottom",
  ];
  // The blob is writable through the API, so the value is never trusted straight
  // into a style attribute — it is matched against the list or discarded.
  // Loads a card's photo when it comes near the viewport. One observer for
  // every card rather than one each: they all want the same threshold, and the
  // dashboard rebuilds this list on every filter change.
  var coverWatcher = null;
  function watchCover(node) {
    if (!("IntersectionObserver" in window)) {          // then just load it
      node.setAttribute("style", node.dataset.cover || "");
      return;
    }
    if (!coverWatcher) {
      coverWatcher = new IntersectionObserver(function (entries) {
        entries.forEach(function (e) {
          if (!e.isIntersecting) return;
          var n = e.target;
          coverWatcher.unobserve(n);
          if (n.dataset.cover) { n.setAttribute("style", n.dataset.cover); delete n.dataset.cover; }
        });
      }, { rootMargin: "400px" });                      // a screen or so ahead
    }
    coverWatcher.observe(node);
  }

  function coverPosition(t) {
    var p = t && t.cover_position;
    return COVER_POSITIONS.indexOf(p) >= 0 ? p : "center center";
  }

  // The gradient a trip falls back to when it has no photo. Also what sits
  // UNDER the photo while it loads, so a card is never a blank rectangle.
  function coverFallback(t) {
    if (t && t.cover_gradient && typeof t.cover_gradient === "object" && t.cover_gradient.colors)
      return "linear-gradient(135deg," + t.cover_gradient.colors.join(",") + ")";
    if (t && t.cover_gradient != null && t.cover_gradient !== "") return gradientCss(t.cover_gradient);
    return "linear-gradient(135deg,#4f7cff,#8a5bff)";
  }

  function coverStyle(t) {
    if (t.cover_image_url) {
      // Two layers: the photo, and the trip's own gradient beneath it. The
      // gradient is what you see while the image is on the wire, which on hotel
      // wifi is the difference between a card and an empty box.
      return "background-image:url('" + t.cover_image_url + "')," + coverFallback(t) +
        ";background-position:" + coverPosition(t) + ",center";
    }
    // Older payloads carried an object with explicit colours; newer ones an index.
    if (t.cover_gradient && typeof t.cover_gradient === "object" && t.cover_gradient.colors) return "background:linear-gradient(135deg," + t.cover_gradient.colors.join(",") + ")";
    if (t.cover_gradient != null && t.cover_gradient !== "") return "background:" + gradientCss(t.cover_gradient);
    return "background:linear-gradient(135deg,#4f7cff,#8a5bff)";
  }
  // ---- business or personal ----
  // Rides in the trip's `data` blob rather than a promoted column: it needs no
  // index, nothing sorts or filters on it in SQL, and a migration for one word
  // per trip would cost more than it saves.
  //
  // Absent means personal. 183 trips predate this flag and the overwhelming
  // majority of them are holidays, so the default has to be the common case —
  // and it means nothing has to be backfilled for the app to be correct.
  function tripType(t) { return (t && t.trip_type) === "business" ? "business" : "personal"; }
  function isBusiness(t) { return tripType(t) === "business"; }
  var TRIP_TYPES = {
    personal: { label: "Personal", mark: "🏖️" },
    business: { label: "Business", mark: "💼" },
  };
  // The gate for everything bought in from Expedia, Viator and TripAdvisor.
  // One function, so a surface added later cannot forget to ask.
  function wantsSuggestions(t) { return !isBusiness(t); }

  async function setTripType(t, type) {
    var was = tripType(t);
    if (was === type) return;
    t.trip_type = type;
    try {
      await api("/v1/trip/" + t.id, { method: "PATCH", body: JSON.stringify({ trip_type: type }) });
    } catch (e) {
      t.trip_type = was;
      toast("Couldn't save: " + e.message);
      throw e;
    }
  }

  function tripCard(t) {
    var card = el("div", "card"); card.setAttribute("role", "button"); card.tabIndex = 0;
    var cover = el("div", "card-cover");
    // 182 trips in card view is 182 photo requests fired at once, all but a
    // handful for cards far below the fold. The gradient goes on now and the
    // photo when it is nearly in view.
    if (t.cover_image_url) {
      cover.setAttribute("style", "background:" + coverFallback(t));
      cover.dataset.cover = coverStyle(t);
      watchCover(cover);
    } else {
      cover.setAttribute("style", coverStyle(t));
    }
    var cd = countdown(t); if (cd) { var badge = el("span", "cd-badge", cd); cover.appendChild(badge); }
    var body = el("div", "card-body");
    body.appendChild(el("div", "card-name", t.name || "Untitled trip"));
    body.appendChild(el("div", "card-dates", fmtRange(t)));
    // Both types are marked, on Alex's call. This shipped as business-only, on
    // the reasoning that personal is the default and a pill on every card is 183
    // labels saying "normal". The counter-argument won: an unmarked card is
    // ambiguous between "personal" and "nobody has set this yet", and the flag
    // now decides whether fare alerts and activity ideas appear at all — which
    // is worth being able to read without opening the trip.
    var td = TRIP_TYPES[tripType(t)];
    body.appendChild(el("span", "type-pill" + (isBusiness(t) ? " is-business" : ""),
      td.mark + " " + td.label));
    if (changedTripIds[t.id]) body.appendChild(el("span", "changed-pill", "changed"));
    cover.appendChild(body); card.appendChild(cover);
    var open = function () { openTrip(t); };
    card.addEventListener("click", open);
    card.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); open(); } });
    return card;
  }
  // "business" or "personal" filters by trip type. Deliberately a PREFIX of at
  // least four characters, unlike the name and destination matches either side
  // of it, which are substrings.
  //
  // Substring matching would be wrong here for a reason particular to this
  // field: nearly all 183 trips are personal, so "per" would return almost the
  // whole list and bury a search for Perth or Perugia. Four characters is past
  // the point where "busi" or "pers" is plausibly the start of a place.
  function matchesTripType(t, q) {
    return q.length >= 4 && TRIP_TYPES[tripType(t)].label.toLowerCase().indexOf(q) === 0;
  }
  function matchSearch(t, q) {
    if (!q) return true;
    if ((t.name || "").toLowerCase().indexOf(q) >= 0) return true;
    if (matchesTripType(t, q)) return true;
    var d = state.dest[t.id];
    return !!(d && d.indexOf(q) >= 0);
  }

  function render() {
    var q = ($("#search").value || "").trim().toLowerCase();
    var wrap = $("#dash-groups"); wrap.innerHTML = "";
    // Every card is about to be rebuilt, so stop watching the old ones. An
    // IntersectionObserver holds its targets, and below-the-fold covers never
    // fire the unobserve in the callback — so each re-render (every search
    // keystroke, every filter tap) would pin another set of detached nodes.
    // With ~180 cards in Past view that is a real leak, not a tidy-up.
    if (coverWatcher) { coverWatcher.disconnect(); }
    var today = new Date(); today.setHours(0, 0, 0, 0);
    var count = 0;

    // Upcoming + undated (owned)
    var upcoming = [], undated = [], past = [];
    state.own.forEach(function (t) {
      if (!matchSearch(t, q)) return;
      var e = t.has_dates ? toDate(t.ends_at || t.starts_at) : null;
      if (!t.has_dates || !e) undated.push(t); else if (e >= today) upcoming.push(t); else past.push(t);
    });
    sortList(upcoming, false); sortList(undated, false); sortList(past, true);

    if (state.filters.upcoming) {
      if (upcoming.length) { count += upcoming.length; wrap.appendChild(el("div", "group-title", "Upcoming · " + upcoming.length)); appendList(wrap, upcoming); }
      if (undated.length) { count += undated.length; wrap.appendChild(el("div", "group-title", "No dates · " + undated.length)); appendList(wrap, undated); }
    }
    if (state.filters.past && past.length) {
      // group by year with anchors
      var curYear = null;
      var pastFiltered = state.year ? past.filter(function (t) { return String(toDate(t.starts_at).getFullYear()) === String(state.year); }) : past;
      count += pastFiltered.length;
      if (pastFiltered.length) {
        var head = el("div", "group-title", "Past · " + pastFiltered.length + (state.year ? (" · " + state.year) : "")); wrap.appendChild(head);
        // Past trips are where the compact list earns its keep, so honour the
        // setting here too — keeping the year anchors either way.
        var asList = getDisplay().tripView === "list";
        var list = el("div", asList ? "trip-rows" : "card-list");
        var showYears = !state.year;
        pastFiltered.forEach(function (t) {
          if (showYears) {
            var y = toDate(t.starts_at).getFullYear();
            if (y !== curYear) {
              curYear = y;
              var yh = el("div", asList ? "year-head inrow" : "year-head", String(y));
              yh.id = "year-" + y; list.appendChild(yh);
            }
          }
          if (asList) {
            var r = el("button", "trip-row"); r.type = "button";
            r.appendChild(el("span", "trip-row-name", t.name || "Untitled trip"));
            r.appendChild(el("span", "trip-row-dates", fmtRange(t)));
            r.appendChild(el("span", "trip-row-days", t.has_dates ? spanDays(t) + "d" : ""));
            r.appendChild(el("span", "trip-row-cd", ""));
            r.addEventListener("click", function () { openTrip(t); });
            list.appendChild(r);
          } else {
            list.appendChild(tripCard(t));
          }
        });
        wrap.appendChild(list);
      }
    }
    $("#dash-empty").hidden = count > 0;
    // With Past off by default, "no upcoming trips" is a normal state rather
    // than an error — say what to tap instead of implying something is wrong.
    if (!count && !$("#dash-empty").hidden) {
      $("#dash-empty").textContent = q
        ? "No trips match your search."
        : (state.filters.upcoming && !state.filters.past
            ? "No upcoming trips. Tap Past to see your history."
            : "Nothing to show — turn on Upcoming or Past.");
    }
    measureSticky();
  }
  function appendList(wrap, arr) {
    // Cards are good for browsing a handful of upcoming trips; the compact list
    // is for finding one trip among nearly two hundred.
    if (getDisplay().tripView === "list") {
      var rows = el("div", "trip-rows");
      arr.forEach(function (t) {
        var r = el("button", "trip-row"); r.type = "button";
        r.appendChild(el("span", "trip-row-name", t.name || "Untitled trip"));
        r.appendChild(el("span", "trip-row-dates", fmtRange(t)));
        r.appendChild(el("span", "trip-row-days", t.has_dates ? spanDays(t) + "d" : ""));
        var cd = countdown(t);
        r.appendChild(el("span", "trip-row-cd", changedTripIds[t.id] ? "changed" : cd));
        r.addEventListener("click", function () { openTrip(t); });
        rows.appendChild(r);
      });
      wrap.appendChild(rows);
      return;
    }
    var list = el("div", "card-list");
    arr.forEach(function (t) { list.appendChild(tripCard(t)); });
    wrap.appendChild(list);
  }

  // ---- icons ----
  var ACT_ICON = { insurance: "🛡️", restaurant: "🍽️", cafe: "☕", bar: "🍸", brewery: "🍺", winery: "🍷", nightlife: "🎉", museum: "🏛️", theater: "🎭", concert: "🎵", tour: "🎟️", shopping: "🛍️", beach: "🏖️", park: "🌳", nationalPark: "🏞️", amusementPark: "🎢", zoo: "🦁", aquarium: "🐠", stadium: "🏟️", fit: "💪", fitnessCenter: "💪", relax: "🧖", kids: "🧸", note: "📝", meeting: "📅", event: "🎫", parking: "🅿️", gasStation: "⛽", evCharger: "🔌", hospital: "🏥", pharmacy: "💊", cafe2: "☕", general: "📍" };
  var TRANS_ICON = { airplane: "✈️", train: "🚆", bus: "🚌", car: "🚗", roadtrip: "🚗", cruise: "🛳️", ferry: "⛴️", walk: "🚶", bike: "🚴", motorcycle: "🏍️" };
  function actIcon(a) {
    var c = a && a.activity_type;
    var custom = catFor(c);
    if (custom) return customIcon(custom);          // API gives icon_name, not icon
    return ACT_ICON[c] || "📍";
  }
  function transIcon(s) { return TRANS_ICON[s] || "🚗"; }
  function fmtTime(utc, tz) {
    if (!utc) return "";
    // Keep the en-US locale and drive the format with hour12 explicitly — en-GB
    // is 24-hour by default, which silently strips AM/PM from 12-hour mode.
    var o = getDisplay().clock === "24"
      ? { hour: "2-digit", minute: "2-digit", hour12: false }
      : { hour: "numeric", minute: "2-digit", hour12: true };
    try { o.timeZone = tz || undefined; return new Date(utc).toLocaleTimeString("en-US", o); }
    catch (e) { delete o.timeZone; return new Date(utc).toLocaleTimeString("en-US", o); }
  }
  function dayKey(utc, tz) { if (!utc) return null; try { return new Date(utc).toLocaleDateString("en-CA", { timeZone: tz || undefined }); } catch (e) { return new Date(utc).toISOString().slice(0, 10); } }
  function dayLabel(k) {
    var d = new Date(k + "T12:00:00");
    // ISO means the actual ISO date, not a locale that happens to sort that way.
    if (getDisplay().dateFmt === "iso") {
      return d.toLocaleDateString("en-GB", { weekday: "short" }) + " " + k;
    }
    return d.toLocaleDateString(dateLocale(), { weekday: "short", month: "short", day: "numeric", year: "numeric" });
  }
  // One phone convention for the whole app.
  //
  //   North America   1-###-###-####
  //   Everywhere else <country code>-<national number, in the source's own groups>
  //
  // The temptation is "ten digits means American". It does not: 322 226 8917 is
  // Puerto Vallarta and 2286 022715 is Greece, and both would come out as
  // plausible, dialable, wrong US numbers. So a 1- prefix is only ever added on
  // positive evidence — an explicit +1, an 11-digit number starting 1, or one of
  // the punctuation styles that is overwhelmingly North American. Anything else
  // keeps its own shape and simply has its separators normalised, which is the
  // honest answer when the country is unknown.
  // Country codes seen in this data plus the common ones. Longest match wins, so
  // 1 never shadows 1-prefixed codes and 3-digit codes are tried first.
  var CC = ["1","7","20","27","30","31","32","33","34","36","39","40","41","43","44","45","46","47","48","49",
            "51","52","53","54","55","56","57","58","60","61","62","63","64","65","66","81","82","84","86","90",
            "91","92","93","94","95","98","212","213","216","218","220","233","234","238","240","242","243","244",
            "248","249","250","251","254","255","256","260","261","263","264","265","266","267","268","269","291",
            "297","298","299","350","351","352","353","354","355","356","357","358","359","370","371","372","373",
            "374","375","376","377","378","380","381","382","383","385","386","387","389","420","421","423","500",
            "501","502","503","504","505","506","507","508","509","590","591","592","593","594","595","596","597",
            "598","599","670","672","673","674","675","676","677","678","679","680","681","682","683","685","686",
            "687","688","689","690","691","692","850","852","853","855","856","880","886","960","961","962","963",
            "964","965","966","967","968","970","971","972","973","974","975","976","977","992","993","994","995",
            "996","998"];

  // Group a national number the way most countries print one: a final block of
  // four, and threes before it.
  function groups(d) {
    if (d.length <= 4) return d;
    var out = [d.slice(-4)];
    var head = d.slice(0, -4);
    while (head.length > 3) { out.unshift(head.slice(-3)); head = head.slice(0, -3); }
    if (head) out.unshift(head);
    // Never strand a single digit: an eight-digit national number came out as
    // "2-479-1600" rather than "2479-1600". Fold a leading one into its
    // neighbour, which is what every local convention does anyway.
    if (out.length > 1 && out[0].length === 1) { out[1] = out[0] + out[1]; out.shift(); }
    return out.join("-");
  }


  // True when a plus-less number begins with a country code we recognise and is
  // too long to be a ten-digit North American number. See the note above CC.
  function leadingCC(digits) {
    if (digits.length === 10 || digits.length < 11 || digits.length > 15) return "";
    for (var i = 3; i >= 1; i--) {
      var cc = digits.slice(0, i);
      if (CC.indexOf(cc) >= 0 && digits.length - i >= 6) return cc;
    }
    return "";
  }

  var PHONE_EXT = /\s*(?:x|ext\.?|extension)\s*(\d{1,6})\s*$/i;

  function fmtPhone(raw) {
    var s = String(raw == null ? "" : raw).trim();
    if (!s) return "";
    var ext = "";
    var em = s.match(PHONE_EXT);
    if (em) { ext = " x" + em[1]; s = s.slice(0, em.index).trim(); }

    var plus = s.charAt(0) === "+";
    var digits = s.replace(/\D/g, "");
    if (!digits) return String(raw).trim();

    var nanp = function (d) { return d.slice(0, 3) + "-" + d.slice(3, 6) + "-" + d.slice(6, 10); };

    // Explicit country code 1, or an 11-digit number that starts with it.
    if (digits.length === 11 && digits.charAt(0) === "1") return "1-" + nanp(digits.slice(1)) + ext;
    if (plus && digits.length === 11 && digits.charAt(0) === "1") return "1-" + nanp(digits.slice(1)) + ext;

    // Ten digits written in a North American punctuation style. A leading 0 or 1
    // on the area code rules it out — no NANP area code begins with either.
    if (!plus && digits.length === 10 && /[().]|-\d{3}-/.test(s) && !/^[01]/.test(digits)) {
      return "1-" + nanp(digits) + ext;
    }

    // A +number written as one unbroken run has no groups to preserve, but the
    // country code is still knowable, and "52-624-163-4300" beats
    // "526241634300" for a hotel in Los Cabos. Only split on a code we recognise;
    // an unknown one is left whole rather than guessed at.
    if (plus && !/[\s.\/()-]/.test(s.slice(1))) {
      for (var i = 3; i >= 1; i--) {
        var cc = digits.slice(0, i);
        if (CC.indexOf(cc) >= 0 && digits.length - i >= 6) return cc + "-" + groups(digits.slice(i)) + ext;
      }
    }

    // A plus-less number that starts with a recognised country code is regrouped
  // the same way an explicit +number is, so two numbers for the same country do
  // not sit next to each other in different shapes.
  if (!plus) {
    var lead = leadingCC(digits);
    if (lead) return lead + "-" + groups(digits.slice(lead.length)) + ext;
  }

  // Everything else keeps the grouping it arrived with; only the separators are
    // standardised. A number with no grouping and no country code stays as one
    // run, because inventing group boundaries would be inventing a country.
    var body = s.replace(/^\+/, "").trim().replace(/[()]/g, "").replace(/[\s.\/–—-]+/g, "-").replace(/^-+|-+$/g, "");
    return body + ext;
  }

  // What a dialer wants, which is not what a reader wants. E.164 where the country
  // is known, bare digits otherwise — never the display form, whose hyphens some
  // handsets read as pauses.
  //
  // The `tel:` scheme is part of the return value, and has to be. Without it a
  // browser reads "+18002527522" as a RELATIVE path, so every phone link in this
  // app navigated to trips.example.com/+18002527522 and 404'd instead of
  // dialling: it looked like a link, it had the pointer cursor, and it had never
  // once placed a call. Anything wanting the bare number calls telNumber.
  function telHref(raw) {
    var n = telNumber(raw);
    return n ? "tel:" + n : "";
  }
  function telNumber(raw) {
    var s = String(raw == null ? "" : raw).trim();
    var ext = "";
    var em = s.match(PHONE_EXT);
    if (em) { ext = ";ext=" + em[1]; s = s.slice(0, em.index).trim(); }
    var plus = s.charAt(0) === "+";
    var digits = s.replace(/\D/g, "");
    if (!digits) return "";
    if (digits.length === 11 && digits.charAt(0) === "1") return "+" + digits + ext;
    if (!plus && digits.length === 10 && !/^[01]/.test(digits) && /[().]|-\d{3}-/.test(s)) return "+1" + digits + ext;
    if (!plus) {
      var lead2 = leadingCC(digits);
      if (lead2) return "+" + digits + ext;
    }
    return (plus ? "+" : "") + digits + ext;
  }


  function money(n, c) { try { return new Intl.NumberFormat("en-US", { style: "currency", currency: c || "USD" }).format(n); } catch (e) { return (c || "") + " " + Number(n).toFixed(2); } }
  function mapsUrl(lat, lng, addr) { if (lat != null && lng != null) return "https://www.google.com/maps/search/?api=1&query=" + lat + "," + lng; if (addr) return "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(addr); return null; }
  function gmaps(lat, lng, addr, placeId, name) {
    if (placeId) return "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(name || (lat + "," + lng)) + "&query_place_id=" + encodeURIComponent(placeId);
    return mapsUrl(lat, lng, addr);
  }
  function amaps(lat, lng, addr, name) {
    if (lat != null && lng != null) return "https://maps.apple.com/?ll=" + lat + "," + lng + (name ? "&q=" + encodeURIComponent(name) : "");
    if (addr) return "https://maps.apple.com/?q=" + encodeURIComponent(addr);
    return null;
  }
  function cap(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }

  // ---- dossier ----
  //
  // The briefing you want open at the airport: every deadline, code, address and
  // phone number in one place, in the order you need them.
  //
  // The material comes from `terms`, which the importer writes onto each item
  // from the confirmation email. It is not a promoted column — it rides in the
  // `data` blob — so nothing here required a schema change. Items imported
  // before that existed simply have no terms, and every section below degrades
  // to whatever is actually present rather than showing empty scaffolding.
  function termsOf(o) { return (o && o.terms && typeof o.terms === "object") ? o.terms : null; }

  // Schedule changes the importer applied, newest first.
  //
  // A PATCH overwrites, so without this the itinerary silently becomes correct
  // and you never learn a flight moved. The importer now appends {at, field,
  // from, to, why} before each write; this reads it back.
  var CHANGE_FRESH_DAYS = 30;
  function changesOf(o) {
    var c = o && o.changes;
    if (!Array.isArray(c) || !c.length) return [];
    return c.filter(function (x) { return x && x.field; })
      .slice()
      .sort(function (a, b) { return String(b.at || "").localeCompare(String(a.at || "")); });
  }
  // A change is identified by the item it happened to, the field it touched and
  // the instant it was recorded. No part of the values goes into the key, so
  // acknowledging one departure move does not also silence the next one.
  function changeKey(o, c) {
    return "chg|" + (o && o.id) + "|" + c.field + "|" + (c.at || "");
  }
  // Only recent ones earn a marker — a change from eighteen months ago is
  // history, not news — and only ones nobody has read yet. The chip used to go
  // out by ageing rather than by being seen, so a schedule change you had
  // already read stayed lit for a month, looking identical to one you had not.
  function recentChanges(o) {
    var cut = Date.now() - CHANGE_FRESH_DAYS * 86400000;
    return changesOf(o).filter(function (x) {
      var t = Date.parse(x.at);
      return isFinite(t) && t >= cut && !checkHiddenAs(changeKey(o, x));
    });
  }
  // Times are stored as instants; a raw ISO string in "from" would be unreadable.
  function changeValue(field, v, tz) {
    if (v == null || v === "") return "—";
    if (/_at$|^starts_at$|^ends_at$/.test(field)) {
      var w = fmtWhen(v, tz);
      if (w) return w;
    }
    return String(v);
  }
  function changeLabel(field) {
    var m = {
      departure_at: "Departure", arrival_at: "Arrival", starts_at: "Start",
      ends_at: "End", seat_number: "Seat", address: "Address", name: "Name",
      departure_gate: "Gate", departure_terminal: "Terminal",
    };
    return m[field] || field.replace(/_/g, " ");
  }

  // Everything with a real cancellation instant, soonest first. This is the part
  // that earns the feature: a deadline you cannot see is one you will miss, and
  // it is otherwise buried in an email from four months ago.
  function deadlines(data) {
    var out = [];
    allItems(data).forEach(function (it) {
      var tm = termsOf(it.o);
      if (!tm || !tm.cancel_by) return;
      var when = new Date(tm.cancel_by);
      if (isNaN(when)) return;
      out.push({ when: when, name: it.name, kind: it.kind, tz: it.tz, policy: tm.cancel_policy || "", o: it.o });
    });
    return out.sort(function (a, b) { return a.when - b.when; });
  }
  // One flat list of everything on the trip, with a display name and its kind.
  // Each carries its own zone: a dossier that renders a Lisbon check-in in
  // Los Angeles time is worse than one that shows no time at all.
  function allItems(data) {
    var out = [];
    (data.transports || []).forEach(function (o) { out.push({ o: o, kind: "transport", name: transName(o), when: o.departure_at, tz: o.departure_timezone }); });
    (data.hostings || []).forEach(function (o) { out.push({ o: o, kind: "lodging", name: o.name || "Lodging", when: o.starts_at, tz: o.timezone }); });
    (data.activities || []).forEach(function (o) { out.push({ o: o, kind: "activity", name: o.name || "Activity", when: o.starts_at, tz: o.timezone }); });
    return out;
  }
  // Date and time together — fmtTime gives only the clock, and a deadline
  // without its date is useless.
  // `withYear` is opt-in rather than the default because most callers show a
  // time inside a trip whose year the surrounding page has already established.
  // A cancellation deadline has no such context — it is routinely in a
  // different year from the day you are reading it, and "Cancel by Fri, Jan 8"
  // read in August is a date you cannot act on without guessing which January.
  function fmtWhen(iso, tz, withYear) {
    if (!iso) return "";
    var d = new Date(iso);
    if (isNaN(d)) return "";
    var o = { weekday: "short", month: "short", day: "numeric" };
    if (withYear) o.year = "numeric";
    try { o.timeZone = tz || undefined; return d.toLocaleDateString(dateLocale(), o) + ", " + fmtTime(iso, tz); }
    catch (e) { delete o.timeZone; return d.toLocaleDateString(dateLocale(), o) + ", " + fmtTime(iso); }
  }
  // `carrier_name` and `flight_number` are Tripsy field names this database has
  // never used — all 369 transports store `company` and `transport_number`
  // instead. So the airplane branch quietly returned the airline on its own,
  // which is how the dossier and the change queue came to label a row
  // "Departure · Delta Air Lines" on a trip carrying two Delta flights. The old
  // names are still read first, in case anything ever starts writing them.
  // What to call a record in a dialog title or a toast: the same words the
  // itinerary row already shows, so tapping Edit on Hotel Bel-Air opens a
  // dialog that says Hotel Bel-Air.
  //
  // "Edit lodging" is equally true of every hotel on the trip and therefore
  // says nothing about which one is open. On the six-hotel trips in this
  // database that is the whole difference between a safe edit and a wrong one,
  // and the dialog is the last chance to notice before you type over something.
  //
  // Returns null rather than a placeholder when a record has no name, so the
  // caller can fall back to the generic noun instead of printing "Edit “”".
  function recordLabel(kind, o) {
    o = o || {};
    var n = kind === "transport" || kind === "transportation" ? transName(o) : (o.name || o.title || "");
    n = String(n == null ? "" : n).trim();
    return n || null;
  }

  function clipName(s, max) {
    s = String(s == null ? "" : s);
    return s.length > max ? s.slice(0, max - 1).trim() + "…" : s;
  }

  // Add has no record to name yet, so it keeps the noun.
  function formTitle(isNew, kind, noun, o) {
    if (isNew) return "Add " + noun;
    var n = recordLabel(kind, o);
    return n ? "Edit “" + clipName(n, 40) + "”" : "Edit " + noun;
  }

  function transName(o) {
    if (o.transportation_type === "airplane") {
      var n = [o.carrier_name || o.company, o.flight_number || o.transport_number]
        .filter(Boolean).join(" ");
      return n || "Flight";
    }
    return o.name || o.company || cap(o.transportation_type || "Transport");
  }
  function contactsFor(o) {
    var tm = termsOf(o) || {}, c = tm.contact || {};
    return {
      phone: c.phone || o.phone_number || o.phone || "",
      email: c.email || o.email || "",
      address: o.address || o.departure_description || "",
    };
  }

  function dossierNode(t, data) {
    var root = el("div", "dossier");
    var dl = deadlines(data);
    var items = allItems(data).filter(function (x) { return x.when; })
      .sort(function (a, b) { return new Date(a.when) - new Date(b.when); });

    // --- deadlines, first, because they are the only time-critical thing here
    if (dl.length) {
      root.appendChild(el("h3", "dossier-h", "⏳ Deadlines"));
      var dtab = el("div", "dossier-deadlines");
      dl.forEach(function (d) {
        var gone = d.when < new Date();
        var days = cancelDays(d.when);
        var row = el("div", "dl-row" + (gone ? " is-past" : days <= 7 ? " is-soon" : ""));
        row.appendChild(el("div", "dl-when", cancelCountdown(d.when)));
        var body = el("div", "dl-body");
        body.appendChild(el("div", "dl-name", d.name));
        body.appendChild(el("div", "dl-note",
          fmtWhen(d.when.toISOString(), d.tz) + (d.policy ? " · " + d.policy : "")));
        row.appendChild(body);
        dtab.appendChild(row);
      });
      root.appendChild(dtab);
    }

    // --- insurance, above everything, because it is what you reach for when a
    // trip has gone wrong rather than when it is going well
    var pols = insuranceOf(data);
    if (pols.length) {
      root.appendChild(el("h3", "dossier-h", "🛡️ Insurance"));
      var itab = el("div", "dossier-pax");
      pols.forEach(function (p) {
        var c = contactsFor(p);
        var row = el("div", "dp-row");
        row.appendChild(el("div", "dp-name", p.name || "Policy"));
        var det = el("div", "dp-detail");
        if (p.provider_reservation_code) det.appendChild(el("div", "dp-line", "Policy " + p.provider_reservation_code));
        if (p.starts_at || p.ends_at) {
          det.appendChild(el("div", "dp-line", "Covers " +
            (p.starts_at ? dayLabel(dayKey(p.starts_at, p.timezone)) : "?") + " – " +
            (p.ends_at ? dayLabel(dayKey(p.ends_at, p.timezone)) : "?")));
        }
        if (c.phone) {
          var pl = el("div", "dp-line");
          pl.appendChild(document.createTextNode("24h assistance "));
          var a = el("a", null, fmtPhone(c.phone)); a.href = telHref(c.phone);
          pl.appendChild(a);
          det.appendChild(pl);
        }
        if (!det.childNodes.length) det.appendChild(el("div", "dp-line subtle", "No policy number, dates or assistance line recorded"));
        row.appendChild(det);
        itab.appendChild(row);
      });
      root.appendChild(itab);
    }

    // --- who is coming, and whether their papers are in order
    // Placed above the itinerary because it is the one thing here you would be
    // asked at a desk before anything else. Documents are shown per person so
    // "whose passport expires first" is answerable without leaving the page.
    var going = tripTravellers(t);
    if (going.length) {
      root.appendChild(el("h3", "dossier-h", "👥 Travellers"));
      var ptab = el("div", "dossier-pax");
      going.forEach(function (p) {
        var row = el("div", "dp-row");
        row.appendChild(el("div", "dp-name", p.name));
        var det = el("div", "dp-detail");
        // Seats, so a boarding queue does not need the itinerary reopened.
        var seats = [];
        (data.transports || []).forEach(function (o) {
          paxOf(o, t).forEach(function (x) {
            if (x.id === p.id && x.seat) seats.push(transName(o) + " " + x.seat + (x.guessed ? "?" : ""));
          });
        });
        if (seats.length) det.appendChild(el("div", "dp-line", "Seats: " + seats.join(" · ")));
        var rooms = [];
        (data.hostings || []).forEach(function (o) {
          roomPaxOf(o, t).forEach(function (x) {
            if (x.id === p.id) rooms.push((o.name || "Lodging") + (x.room ? " room " + x.room : ""));
          });
        });
        if (rooms.length) det.appendChild(el("div", "dp-line", "Rooms: " + rooms.join(" · ")));
        var mine = travelDocs().filter(function (d) {
          return String(d.who || "").toLowerCase() === p.name.toLowerCase();
        });
        if (mine.length) {
          det.appendChild(el("div", "dp-line", "Documents: " + mine.map(function (d) {
            return d.kind + " to " + d.expires;
          }).join(" · ")));
        }
        if (!det.childNodes.length) det.appendChild(el("div", "dp-line subtle", "No seat, room or document recorded"));
        row.appendChild(det);
        ptab.appendChild(row);
      });
      root.appendChild(ptab);
    }

    // --- the itinerary, each entry carrying what you would otherwise dig for
    root.appendChild(el("h3", "dossier-h", "🧭 Itinerary"));
    if (!items.length) root.appendChild(el("div", "empty", "Nothing scheduled yet."));
    items.forEach(function (x) {
      var tm = termsOf(x.o) || {}, c = contactsFor(x.o);
      var card = el("div", "dossier-item");
      var head = el("div", "di-head");
      head.appendChild(el("span", "di-when", fmtWhen(x.when, x.tz)));
      head.appendChild(el("span", "di-name", x.name));
      card.appendChild(head);

      var facts = el("dl", "di-facts");
      var fact = function (k, v) {
        if (!v) return;
        facts.appendChild(el("dt", null, k));
        facts.appendChild(el("dd", null, v));
      };
      // A phone number printed as text is a number you have to retype. These are
      // the only two facts here that are actions rather than reference, so they
      // are the only two that get to be links: tel: hands off to whatever the
      // system has registered — Phone Link on Windows, the dialer on a phone.
      var factLink = function (k, v, href) {
        if (!v || !href) { fact(k, v); return; }
        facts.appendChild(el("dt", null, k));
        var dd = el("dd");
        var a = el("a", null, v); a.href = href;
        dd.appendChild(a);
        facts.appendChild(dd);
      };
      // Reference you might need to hand over or paste somewhere. The dossier is
      // the screen open at a desk, so these are the two worth making copyable.
      var factCopy = function (k, v) {
        if (!v) return;
        facts.appendChild(el("dt", null, k));
        var dd = el("dd");
        var btn = el("button", "copyable", v); btn.type = "button";
        btn.title = "Tap to copy";
        btn.addEventListener("click", function () {
          copy(v).then(function (ok) { toast(ok ? "Copied" : "Couldn't reach the clipboard."); });
        });
        dd.appendChild(btn);
        facts.appendChild(dd);
      };
      factCopy("Confirmation", x.o.provider_reservation_code || "");
      factCopy("Address", c.address);
      factLink("Phone", fmtPhone(c.phone), telHref(c.phone));
      factLink("Email", c.email, c.email ? "mailto:" + c.email : "");
      if (x.o.seat_number) fact("Seat", x.o.seat_number);
      fact("Rate", tm.rate_type ? cap(tm.rate_type.replace(/-/g, " ")) : "");
      fact("Cancel by", tm.cancel_by && !isNaN(new Date(tm.cancel_by)) ? fmtWhen(tm.cancel_by, x.tz) : "");
      fact("Cancellation", tm.cancel_policy);
      fact("Change fee", tm.change_fee);
      fact("Deposit", tm.deposit);
      fact("Baggage", tm.baggage);
      fact("Arrival", tm.arrival);
      fact("Included", Array.isArray(tm.included) ? tm.included.join(" · ") : tm.included);
      fact("Not included", Array.isArray(tm.excluded) ? tm.excluded.join(" · ") : tm.excluded);
      if (tm.loyalty && (tm.loyalty.program || tm.loyalty.number)) {
        fact("Loyalty", [tm.loyalty.program, tm.loyalty.number, tm.loyalty.status].filter(Boolean).join(" · "));
      }
      fact("Notes", tm.notes || x.o.notes || "");
      // Before-and-after, so a moved flight reads as a movement rather than a
      // time that was simply always this.
      recentChanges(x.o).slice(0, 4).forEach(function (c) {
        fact("Changed " + changeLabel(c.field).toLowerCase(),
          changeValue(c.field, c.from, x.tz) + "  →  " + changeValue(c.field, c.to, x.tz) +
          (c.at ? "   (" + fmtWhen(c.at, null) + ")" : ""));
      });
      if (facts.childNodes.length) card.appendChild(facts);
      root.appendChild(card);
    });

    // --- every number worth having when something goes wrong
    var contacts = allItems(data).map(function (x) {
      var c = contactsFor(x.o);
      return (c.phone || c.email) ? { name: x.name, phone: c.phone, email: c.email } : null;
    }).filter(Boolean);
    if (contacts.length) {
      root.appendChild(el("h3", "dossier-h", "☎ Contacts"));
      var cl = el("div", "dossier-contacts");
      contacts.forEach(function (c) {
        var row = el("div", "dc-row");
        row.appendChild(el("div", "dc-name", c.name));
        var links = el("div", "dc-links");
        if (c.phone) { var a = el("a", null, fmtPhone(c.phone)); a.href = telHref(c.phone); links.appendChild(a); }
        if (c.email) { var b = el("a", null, c.email); b.href = "mailto:" + c.email; links.appendChild(b); }
        row.appendChild(links); cl.appendChild(row);
      });
      root.appendChild(cl);
    }

    // --- documents already uploaded, so the dossier is genuinely everything
    //
    // This section has always been here and was always empty: the trip's
    // document list filtered out anything attached to a booking, and a trip
    // whose papers were all attached had, as far as this could tell, none. Now
    // that the list is complete, so is this.
    //
    // Each says what it belongs to. On a printed dossier a row reading
    // "Boarding pass" among six others is a worse answer than no row at all —
    // the question at a desk is always which flight.
    //
    // Not the Travellers block's "Documents", which is the passports and visas
    // on your account. Two different things sharing one word.
    var docs = data.documents || [];
    if (docs.length) {
      root.appendChild(el("h3", "dossier-h", "📎 Documents"));
      var dz = el("div", "dossier-docs");
      docs.forEach(function (d) {
        var p = docParent(d, data);
        var a = el("a", "dc-doc", (d.title || d.name || "Document") + (p ? "  ·  " + p.label : ""));
        a.href = d.temp_read_url || d.url || ("/api/v1/doc/" + d.id);
        a.target = "_blank"; a.rel = "noopener";
        dz.appendChild(a);
      });
      root.appendChild(dz);
    }
    return root;
  }

  function openDossier(t, data) {
    var o = overlay("wide dossier-panel");
    var back = o.back, panel = o.panel;
    panel.appendChild(el("h3", "form-title", "Dossier — " + (t.name || "Trip")));
    panel.appendChild(el("div", "form-hint", fmtRange(t)));
    panel.appendChild(dossierNode(t, data));
    var btns = el("div", "form-btns");
    var pr = el("button", "mini-btn", "🖨️ Print"); pr.type = "button";
    pr.addEventListener("click", function () { window.print(); });
    var close = el("button", "primary-btn small", "Done"); close.type = "button";
    btns.appendChild(pr); btns.appendChild(close); panel.appendChild(btns);
    close.addEventListener("click", function () { back.remove(); });
  }

  // ---- open trip (detail) ----
  var current = null, leafletMap = null, currentData = null, currentChanged = {};
  // The Google map for the open trip, and the points it was fitted to, so the
  // home leg can re-fit to include the drive once the route lands.
  var googleMap = null, googleFitPts = null;
  async function openTrip(t, opts) {
    opts = opts || {};
    current = t;
    // Opening a trip and REDRAWING the one already on screen are different
    // things that used to be identical. Every write path -- saving an item,
    // deleting one, uploading a document, reordering a day, toggling the trip
    // type -- comes back through here, and each one blanked the panel, showed
    // the skeleton again, reset the scroll to the top and refetched five
    // collections. Fixing a typo halfway down a ten-day itinerary meant
    // scrolling back down and visually re-finding the row.
    var redraw = shownTrip === t.id && !$("#detail-overlay").hidden;
    var keepScroll = 0;
    if (redraw) {
      var open = document.querySelector("#detail-overlay .detail-panel");
      keepScroll = open ? open.scrollTop : 0;
    }
    // Before the panel underneath is replaced, so coming back lands where the
    // reading left off rather than at the top.
    notePanelScroll();
    if (location.hash !== "#trip/" + t.id) {
      history.pushState(null, "", "#trip/" + t.id);
      pushedDetail = true;
    }
    var overlay = $("#detail-overlay"), content = $("#detail-content");
    content.innerHTML = "";
    var cover = el("div", "detail-cover"); cover.setAttribute("style", coverStyle(t));
    // The name sits ON the cover, as it does on a dashboard card, so opening a
    // trip looks like the card you tapped. It also gives the name the full
    // width of the panel instead of sharing a line with the dates, which is
    // what pays for the larger type.
    var cdText = countdown(t);
    if (cdText) cover.appendChild(el("span", "cd-badge", cdText));
    var coverBody = el("div", "detail-coverbody");
    var nameEl = el("h2", "detail-name", t.name || "Untitled trip");
    nameEl.title = t.name || "Untitled trip";
    coverBody.appendChild(nameEl);
    cover.appendChild(coverBody);
    content.appendChild(cover);
    var inner = el("div", "detail-inner");
    // Below the image: when the trip is, then what you can do to it. The name
    // is on the cover above; these two stay here and are the reason the dates
    // could grow -- they no longer share a line with anything.
    var when = fmtRange(t) + (t.has_dates ? " · " + spanDays(t) + " days" : "");
    if (when) inner.appendChild(el("div", "detail-when", when));

    // Three controls, not four: the countdown moved onto the cover above, which
    // is what lets these be a size bigger.
    var chipRow = el("div", "detail-chiprow");
    // Always states which it is, unlike the dashboard card which marks only the
    // exception. This is the one place the answer has to be unambiguous, because
    // it is also the control that changes it.
    var typeBtn = el("button", "type-toggle", ""); typeBtn.type = "button";
    var paintType = function () {
      var d = TRIP_TYPES[tripType(t)];
      typeBtn.textContent = d.mark + " " + d.label;
      typeBtn.classList.toggle("is-business", isBusiness(t));
      typeBtn.title = isBusiness(t)
        ? "A business trip — no suggested hotels, activities or fare alerts. Click to make it personal."
        : "A personal trip — suggestions and fare alerts are on. Click to make it business.";
    };
    paintType();
    typeBtn.addEventListener("click", async function () {
      typeBtn.disabled = true;
      try {
        await setTripType(t, isBusiness(t) ? "personal" : "business");
        paintType();
        render();
        // The suggestion blocks below are gated on this, so the trip has to be
        // redrawn rather than just the pill repainted.
        if (currentData) openTrip(t, { data: currentData });
        toast(TRIP_TYPES[tripType(t)].label + " trip");
      } catch (e) { /* setTripType has already reverted and toasted */ }
      typeBtn.disabled = false;
    });
    chipRow.appendChild(typeBtn);

    // Editing the trip itself. Everything else on this screen has an edit
    // affordance; this was the gap.
    var editBtn = el("button", "type-toggle trip-edit is-edit", "✎ Edit");
    editBtn.type = "button";
    editBtn.title = "Edit this trip's name, dates, timezone and description";
    editBtn.addEventListener("click", function () { editTripDetails(t); });
    chipRow.appendChild(editBtn);

    // Deleting the trip, as two clicks on one control rather than a confirm()
    // dialog.
    //
    // A confirm() is one reflex away from being no confirmation at all -- with
    // daily use you learn to dismiss it without reading it, which is exactly
    // the finding recorded against the item-delete path. A control that changes
    // under the cursor and has to be aimed at a second time cannot be
    // click-through'd the same way: the second click lands somewhere the first
    // one was not.
    //
    // It disarms itself after a few seconds, so a chip left armed cannot be
    // fired by a stray click minutes later, and `is-edit` keeps it away from
    // View accounts entirely.
    //
    // The server soft-deletes: the row keeps its data and gains a deleted_at,
    // and the same happens to every transport, hosting, activity, expense and
    // document on the trip. Nothing is destroyed, which is what makes a
    // two-click control an appropriate amount of ceremony rather than too
    // little.
    var delBtn = el("button", "type-toggle trip-del is-edit", "🗑 Delete");
    delBtn.type = "button";
    delBtn.title = "Delete this trip";
    var armed = false, armTimer = null;
    var disarm = function () {
      armed = false;
      clearTimeout(armTimer);
      delBtn.textContent = "🗑 Delete";
      delBtn.classList.remove("is-armed");
      delBtn.title = "Delete this trip";
    };
    delBtn.addEventListener("click", async function () {
      if (!armed) {
        armed = true;
        // Short, because this now sits in a four-chip row that must not wrap
        // on a phone. "Delete - click again" was nearly twice the width of
        // any other chip and pushed the row over on its own.
        delBtn.textContent = "🗑 Again?";
        delBtn.classList.add("is-armed");
        delBtn.title = "Click again to delete this trip. Disarms itself in a few seconds.";
        armTimer = setTimeout(disarm, 5000);
        return;
      }
      clearTimeout(armTimer);
      delBtn.disabled = true;
      delBtn.textContent = "Deleting…";
      try {
        await api("/v1/trip/" + t.id, { method: "DELETE" });
        // Drop it locally first so the dashboard is right the moment the panel
        // closes, rather than showing the deleted trip until the reload lands.
        state.own = (state.own || []).filter(function (x) { return x.id !== t.id; });
        closeDetail();
        render();
        // A trip takes its whole itinerary with it, so this is the delete that
        // most needs taking back. restoreDeleted returns exactly the children
        // that went with it -- matched on the delete's own timestamp -- not
        // everything ever removed from the trip.
        undoToast("Deleted “" + (t.name || "trip") + "”", async function () {
          await api("/v1/trip/" + t.id + "/restore", { method: "POST" });
          await loadAll();
          toast("Restored “" + (t.name || "trip") + "”");
        });
        loadAll();
      } catch (e) {
        delBtn.disabled = false;
        disarm();
        toast("Couldn't delete: " + (e && e.message ? e.message : e));
      }
    });
    // Aiming at anything else is a change of mind.
    delBtn.addEventListener("blur", function () { if (armed) disarm(); });
    chipRow.appendChild(delBtn);

    inner.appendChild(chipRow);

    var actions = el("div", "detail-actions");
    var icsBtn = el("button", "mini-btn", "📅 Calendar"); icsBtn.type = "button";
    var pdfBtn = el("button", "mini-btn", "📑 PDF"); pdfBtn.type = "button";
    var wordBtn = el("button", "mini-btn", "📄 Word"); wordBtn.type = "button";
    var printBtn = el("button", "mini-btn", "🖨️ Print"); printBtn.type = "button"; printBtn.addEventListener("click", function () { window.print(); });
    var addBtn = el("button", "mini-btn is-edit", "＋ Add"); addBtn.type = "button";
    var shiftBtn = el("button", "mini-btn is-edit", "⏱ Shift Times"); shiftBtn.type = "button";
    shiftBtn.addEventListener("click", function () { if (currentData) openShiftDialog(t, currentData); });
    var dupBtn = el("button", "mini-btn is-edit", "⧉ Duplicate"); dupBtn.type = "button";
    dupBtn.addEventListener("click", function () { duplicateTrip(t); });
    var coverBtn = el("button", "mini-btn is-edit", "🖼 Cover"); coverBtn.type = "button";
    coverBtn.addEventListener("click", function () {
      openCoverDialog(t, function (updated) { cover.setAttribute("style", coverStyle(updated)); render(); });
    });
    // Print, Calendar, PDF and Word are one idea — get this trip out of the app —
    // and each is reached for occasionally. Four permanent buttons for that
    // crowded out the two that are used constantly, so they collapse into one
    // chooser and the bar goes from eight to five.
    var exportBtn = el("button", "mini-btn", "⤓ Export"); exportBtn.type = "button";
    exportBtn.addEventListener("click", function () {
      openChooser("Export “" + String(t.name || "trip").slice(0, 40) + "”", [
        ["📅", "Calendar File (.ics)", function () { icsBtn.click(); }],
        ["📑", "PDF", function () { pdfBtn.click(); }],
        ["📄", "Word Document (.docx)", function () { wordBtn.click(); }],
        ["🖨️", "Print", function () { window.print(); }],
        ["💰", "Expense Report (.xlsx)", function () { if (currentData) exportExpensesXlsx(t, currentData, null); }],
        ["📄", "Expense Report (.csv, plain)", function () { if (currentData) exportExpenses(t, currentData); }]
      ]);
    });
    // Beside Export, not inside it: Export produces a file for you, Send hands
    // the trip to somebody else. Related enough to sit together, different
    // enough that folding one into the other would hide it.
    var sendBtn = el("button", "mini-btn", "📤 Send To"); sendBtn.type = "button";
    sendBtn.title = "Send this itinerary by message, WhatsApp or email";
    sendBtn.addEventListener("click", function () { if (currentData) openSendTo(t, currentData); });
    // Its own chip rather than an item under Export: the dossier is something you
    // open and read, not a file you take away, and burying it one level down
    // would cost it exactly the trips where you want it in a hurry.
    var dosBtn = el("button", "mini-btn", "📋 Dossier"); dosBtn.type = "button";
    dosBtn.addEventListener("click", function () { if (currentData) openDossier(t, currentData); });
    // One order for both layouts — the phone row just scrolls sideways through
    // the same sequence, so there is nothing to keep in sync.
    [addBtn, dosBtn, coverBtn, exportBtn, sendBtn, shiftBtn, dupBtn].forEach(function (b) { actions.appendChild(b); });
    inner.appendChild(actions);

    if (t.description) inner.appendChild(el("div", "detail-desc", t.description));
    var travellerBar = el("div"); inner.appendChild(travellerBar);
    // Two columns on wide screens: itinerary on the left, map and the summary
    // sections in a sticky side column. Stacks back to one column when narrow.
    var cols = el("div", "trip-cols");
    var colMain = el("div", "trip-main");
    var colSide = el("div", "trip-side");
    var mapWrap = el("div", "map-wrap"); mapWrap.hidden = true;
    var mapEl = el("div", "trip-map"); mapEl.id = "trip-map"; mapWrap.appendChild(mapEl);
    // mapWrap is NOT appended here — the sections loop places it, so hiding the
    // map in settings actually hides it.
    var itin = el("div", "itin"); itin.appendChild(itinSkeleton());
    colMain.appendChild(itin);
    // "You've been here before" is reference material: useful when you are
    // planning a return visit, noise every other time you open the trip. It
    // reads as a footnote to the itinerary, so it sits under the last day
    // rather than above the first.
    //
    // Still its own element in colMain rather than inside Trip check -- it
    // belongs to the trip as a whole, and putting it in a section meant
    // switching that section off silently took it away too.
    var recallWrap = el("div"); colMain.appendChild(recallWrap);
    renderRecall(recallWrap, t);
    cols.appendChild(colMain); cols.appendChild(colSide); inner.appendChild(cols);
    content.appendChild(inner);
    overlay.hidden = false;
    // Only a fresh open starts at the top. A redraw restores where you were
    // once the new content has been laid out -- see the end of this function.
    if (!redraw) overlay.querySelector(".detail-panel").scrollTop = 0;

    // The "Travelers" row that used to sit here read from /v1/collaborators,
    // which is a stub: it returns the signed-in user's own email prefix and
    // nothing else, so the row only ever said "alex". It has been replaced by
    // the traveller bar below, which is backed by the real roster — two rows
    // both claiming to list who was coming, one of them permanently wrong.

    try {
      // A part that FAILED must never look like a part that is EMPTY.
      //
      // Each of these used to end `.catch(() => [])`, which meant a request that
      // timed out on hotel wifi rendered as "this trip has no flights". That is
      // the worst thing this app can do: the one moment you need it is standing
      // at a desk on a bad connection, and it would quietly show you an
      // itinerary with the flights missing and no indication anything was wrong.
      //
      // Failures are collected instead of swallowed. Whatever did load is still
      // shown — three sections out of five beats a blank page — but the trip
      // says plainly what is missing and offers to fetch it again.
      var failed = [];
      var load = function (label, path) {
        return apiAll(path).catch(function (e) {
          failed.push({ label: label, message: e && e.message ? e.message : "Request failed" });
          return null;
        });
      };
      // A caller that already knows what changed hands the collections over
      // rather than making this refetch all five. The type toggle changes one
      // field and needs none of them re-read; a saved item needs exactly one.
      var data;
      if (opts.data) {
        data = opts.data;
      } else {
        var parts = await Promise.all([
          load("Flights and transport", "/v1/trip/" + t.id + "/transportations"),
          load("Lodging", "/v1/trip/" + t.id + "/hostings"),
          load("Activities", "/v1/trip/" + t.id + "/activities"),
          load("Expenses", "/v1/trip/" + t.id + "/expenses"),
          load("Documents", "/v2/trip/" + t.id + "/documents")
        ]);
        data = { transports: parts[0] || [], hostings: parts[1] || [], activities: parts[2] || [],
          expenses: parts[3] || [], documents: parts[4] || [] };
      }
      currentData = data;
      if (failed.length) colMain.insertBefore(incompleteNote(t, failed), itin);
      // Flag what the importer or the iOS app touched since this trip was last opened
      var changed = changedSince(t.id, data);
      currentChanged = {};
      changed.forEach(function (o) { currentChanged[o.id] = true; });
      if (changed.length) {
        var note = el("div", "changed-note",
          changed.length + (changed.length === 1 ? " item has" : " items have") + " changed since you last opened this trip");
        colMain.insertBefore(note, itin);
      }
      // Only a complete load counts as having seen the trip. markSeen stores a
      // timestamp that changedSince compares `updated_at` against, so marking a
      // half-loaded trip as seen would step over any change that landed in the
      // meantime — the flight moved, and you are never told.
      if (!failed.length) markSeen(t.id);
      startDestClock(inner, t, data);
      renderTravellerBar(travellerBar, t, data, itin);
      renderItinerary(itin, t, data);
      // Side sections are built separately, then appended in the configured
      // order with the switched-off ones omitted.
      // The map folds like the rest of the side column, but it is the one that
      // cannot be drawn while shut — see collapsibleSection. Built on first
      // open, which was measured: folded-then-built put its ten pins 352,000px
      // outside the frame, and the ResizeObserver did not recover it.
      var mapBox = collapsibleSection("Map", {
        onFirstOpen: function () { renderMap(mapWrap, mapEl, data); },
      });
      mapBox.body.appendChild(mapWrap);
      var mapSec = el("div");
      mapBox.mount(mapSec);
      // Asked here rather than inferred from renderMap's side effects, because
      // renderMap no longer runs until the section is opened. No coordinates
      // anywhere on the trip means no section header promising a map.
      // Coordinates decide this, and nothing else. It used to also require
      // window.L, which was true at page load back when Leaflet was eager --
      // and is now ALWAYS false here, because Leaflet is injected on demand and
      // Google is the normal path anyway. Left alone it hid the Map section on
      // every single trip, with nothing failing.
      if (!geoPoints(data).length) mapSec.hidden = true;
      var built = { map: mapSec, check: el("div"), budget: el("div"), tasks: el("div"),
        docs: el("div"), packing: el("div"), ideas: el("div"), cancel: el("div") };
      renderHealth(built.check, t, data);
      renderTasks(built.tasks, t);
      // Its own section, its own switch, its own place in the order -- for the
      // same reason Packing was pulled out of Trip check below. Mounted into
      // built.tasks it could never be moved, and turning off the to-do list
      // silently took the ideas with it. None of it is booked, which is why it
      // is not in the itinerary; that does not make it part of the to-do list.
      renderSuggested(built.ideas, t);
      // Packing is its own section, with its own switch and its own place in the
      // order. It was appended into Trip check, which meant turning that section
      // off in Settings took the packing list with it.
      renderCancellations(built.cancel, t, data);
      renderPacking(built.packing, t);
      renderBudget(built.budget, t, data);
      renderDocuments(built.docs, t, data.documents, data);
      getDisplay().sections.forEach(function (sec) {
        if (sec.on && built[sec.key]) colSide.appendChild(built[sec.key]);
      });
      icsBtn.addEventListener("click", function () { downloadIcs(t, data); });
      pdfBtn.addEventListener("click", function () { exportPdf(t, data, pdfBtn); });
      wordBtn.addEventListener("click", function () { exportWord(t, data, wordBtn); });
      addBtn.addEventListener("click", function () { openAddForm(t); });
      wireOverflowFade(content);
    } catch (e) { itin.innerHTML = ""; itin.appendChild(el("div", "empty", "Couldn't load the itinerary.")); }
    // After the content exists and has been laid out, or there is nothing to
    // scroll to yet. A redraw should look like the row you edited changing in
    // place, not like leaving the trip and coming back to the top of it.
    if (redraw && keepScroll) {
      var back = overlay.querySelector(".detail-panel");
      if (back) setTimeout(function () { back.scrollTop = keepScroll; }, 0);
    }
  }

  // ---- who is on this trip ----
  // One row, at the top of the trip. Membership is stored on the trip itself
  // rather than derived from the bookings every time, because the two genuinely
  // differ in both directions: Alex walked the Camino separately from the
  // flight his family took, so a party read off the passenger list would leave
  // him off his own trip — and Marie is joining the Mammoth drive with no
  // flight, no room and no booking bearing her name at all.
  //
  // So the stored list is the truth, and detection only ever proposes.
  //
  // Detection has two honest sources, and one thing it cannot do:
  //   · anybody already holding a seat on this trip — exact, they are on it
  //   · a roster name appearing in a booking's own text — "Jo Ski School
  //     Lesson", "Sam Rivera (room 1 of 2)", a passenger list in the notes
  //   · counting seats CANNOT name anybody. Five seats says the party was five,
  //     never which five, so a count only ever raises the question.
  // Is this name written in that text, as a whole word?
  //
  // The boundary markers are applied only where they can ever match. `\b` needs
  // a word character on the inside of the edge, so a name ending in a bracket
  // or a full stop — "A.J. (Bo)", "J.R." — can never satisfy a trailing `\b`
  // and would silently never be found. Anchoring each end independently keeps
  // "Casey" out of "Noahs Ark" without breaking those.
  function nameInText(name, text) {
    var n = String(name || "").trim();
    if (!n) return false;
    var esc = n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    var pat = (/^\w/.test(n) ? "\\b" : "") + esc + (/\w$/.test(n) ? "\\b" : "");
    try { return new RegExp(pat, "i").test(text); } catch (e) { return false; }
  }

  function detectTravellers(t, data) {
    var out = {}, all = travellers();
    if (!all.length) return [];
    // 1. Anyone already assigned a seat is on the trip by definition.
    (data.transports || []).forEach(function (o) {
      (Array.isArray(o.pax) ? o.pax : []).forEach(function (x) { if (x && x.id) out[x.id] = true; });
    });
    // 2. A roster name written into the booking itself.
    var FIELDS = ["notes", "description", "provider_reservation_description", "name", "vehicle_description", "room_type"];
    var blob = [];
    [].concat(data.transports || [], data.hostings || [], data.activities || []).forEach(function (o) {
      FIELDS.forEach(function (f) { if (typeof o[f] === "string" && o[f]) blob.push(o[f]); });
    });
    var text = blob.join("\n");
    all.forEach(function (p) {
      if (nameInText(p.name, text)) out[p.id] = true;
    });
    return all.filter(function (p) { return out[p.id]; }).map(function (p) { return p.id; });
  }

  // Policies covering this trip. `name` holds the insurer, the confirmation
  // field holds the policy number, the dates hold the coverage window, and the
  // phone is the 24-hour assistance line — the one number that matters when
  // something has gone wrong abroad, and the reason this is worth surfacing
  // separately rather than leaving as one more row in the itinerary.
  function insuranceOf(data) {
    return (data.activities || []).filter(function (a) { return a.activity_type === "insurance"; });
  }

  // The largest party any one booking on this trip implies. Used only to ask
  // whether somebody has been left off — never to guess who.
  function partySizeHint(data) {
    var n = 0;
    (data.transports || []).forEach(function (o) { n = Math.max(n, seatList(o).length); });
    return n;
  }

  // The right-edge fade in styles.css says "there is more to the right". This
  // takes it away when there is not -- otherwise it sits at the end of the row
  // promising content that does not exist, which is its own small lie.
  //
  // Also covers the case where the bar does not overflow at all: scrollWidth
  // equals clientWidth, so it is marked at-end immediately and never fades.
  function wireOverflowFade(root) {
    var bars = (root || document).querySelectorAll(".detail-actions, .pax-bar");
    [].forEach.call(bars, function (bar) {
      if (bar.__fadeWired) return;
      bar.__fadeWired = true;
      var mark = function () {
        // 2px of slack: fractional scroll positions never land exactly.
        bar.classList.toggle("at-end", bar.scrollLeft + bar.clientWidth >= bar.scrollWidth - 2);
      };
      bar.addEventListener("scroll", mark, { passive: true });
      window.addEventListener("resize", mark);
      // After layout, or clientWidth is still 0 and everything reads as at-end.
      setTimeout(mark, 0);
    });
  }

  function renderTravellerBar(host, t, data, itin) {
    host.innerHTML = "";
    var all = travellers();
    var bar = el("div", "pax-bar");
    host.appendChild(bar);
    bar.appendChild(el("span", "pax-label", "Travellers"));

    if (!all.length) {
      var hint = el("button", "pax-empty", "＋ Add travellers"); hint.type = "button";
      hint.title = "Add the people coming on this trip";
      hint.addEventListener("click", function () {
        openTripTravellers(t, data, function () { renderTravellerBar(host, t, data, itin); if (currentData) renderItinerary(itin, t, currentData); });
      });
      bar.appendChild(hint);
      return;
    }

    var ids = Array.isArray(t.travellers) ? t.travellers.slice() : [];
    var going = tripTravellers(t);
    var found = detectTravellers(t, data).filter(function (id) { return ids.indexOf(id) < 0; });

    // Only the people actually coming. The roster is a list that grows —
    // colleagues, in-laws, a babysitter for one weekend — and printing all of it
    // on every trip means the answer to "who is coming" gets longer the more
    // people you have ever travelled with. Everyone else lives one tap away.
    var manage = el("button", "pax-manage",
      found.length ? "✎ Manage · " + found.length + " found" : "✎ Manage");
    manage.type = "button";
    manage.title = found.length
      ? found.length + " on the bookings but not marked: " + found.map(travellerName).join(", ")
      : "Add or remove people on this trip";
    manage.addEventListener("click", function () {
      openTripTravellers(t, data, function () { renderTravellerBar(host, t, data, itin); if (currentData) renderItinerary(itin, t, currentData); });
    });
    // BEFORE the names, not after. On a phone this bar scrolls sideways, and
    // Manage sorted last meant the only actionable control on it was the first
    // thing pushed off-screen on a six-traveller trip -- so overflow hid the
    // button rather than hiding a name, which is the one thing overflow must
    // never do. Names are static text; losing the tail of them costs nothing.
    bar.appendChild(manage);

    if (going.length) {
      going.forEach(function (p) { bar.appendChild(el("span", "pax-chip on is-static", p.name)); });
    } else {
      bar.appendChild(el("span", "pax-none", "nobody yet"));
    }

    // A five-seat flight against three marked travellers still says somebody is
    // missing, even though nothing in the data can say who. Kept on the bar
    // rather than buried in the dialog: it is a prompt to open the dialog.
    if (!found.length && ids.length) {
      var party = partySizeHint(data);
      if (party > ids.length) {
        var gap = el("div", "pax-suggest");
        gap.appendChild(el("span", "pax-suggest-text",
          "A booking on this trip holds " + party + " seats, but " + ids.length +
          (ids.length === 1 ? " traveller is" : " travellers are") +
          " marked. Nothing records who the others were."));
        host.appendChild(gap);
      }
    }
  }


  // ---- every trip, as a year of months ----
  // The dashboard answers "which trip", chronologically. This answers "when am
  // I away", which is a different question and the one you ask when somebody
  // proposes a date.
  //
  // It first shipped as twelve months of proportional bars, on the reasoning
  // that the shape of the year mattered more than the individual days. Half of
  // that was right and half was not: the shape did read, but a bar carried the
  // trip's name inside its own width, so a four-day trip was a 20px sliver with
  // an unreadable label, and answering "am I free on the 14th?" meant counting
  // pixels against an edge. Both halves are now separate — a real day grid for
  // the dates, a full-width line per trip beneath it for the names.
  function openYearGrid() {
    panelRoute("#calendar");
    if (restorePanel("#calendar")) return;
    var dated = (state.own || []).filter(function (t) { return t.has_dates && t.starts_at && t.ends_at; });
    var years = [...new Set(dated.map(function (t) { return Number(t.starts_at.slice(0, 4)); }))].sort(function (a, b) { return b - a; });
    var thisYear = new Date().getFullYear();
    var year = years.indexOf(thisYear) >= 0 ? thisYear : (years[0] || thisYear);

    var overlay = $("#detail-overlay"), content = $("#detail-content");
    content.innerHTML = "";
    overlay.hidden = false;
    document.body.style.overflow = "hidden";
    var inner = el("div", "detail-inner");
    content.appendChild(inner);
    cachePanel("#calendar", inner);

    function paint() {
      inner.innerHTML = "";
      var h = el("h2", null, "Calendar");
      inner.appendChild(h);

      // A select, not a row of chips. Seventeen years of chips wrapped to five
      // rows on a phone and pushed January off the first screen, so you scrolled
      // past a wall of years to reach the calendar you had just opened. One
      // control, one line, at every width — and it is the same control the
      // dashboard already uses to jump to a year, so the two behave alike.
      var nav = el("div", "cal-years");
      var sel = el("select", "year-jump");
      sel.setAttribute("aria-label", "Year");
      years.forEach(function (y) {
        var o = el("option", null, String(y));
        o.value = String(y);
        if (y === year) o.selected = true;
        sel.appendChild(o);
      });
      sel.addEventListener("change", function () { year = Number(sel.value); paint(); });
      nav.appendChild(sel);
      inner.appendChild(nav);

      var mine = dated.filter(function (t) {
        return Number(t.starts_at.slice(0, 4)) === year || Number(t.ends_at.slice(0, 4)) === year;
      }).sort(function (a, b) { return a.starts_at.localeCompare(b.starts_at); });

      var status = el("div", "detail-meta",
        mine.length + (mine.length === 1 ? " trip" : " trips") + " in " + year + " · " +
        mine.reduce(function (n, t) { return n + spanDays(t); }, 0) + " days away");
      inner.appendChild(status);

      var grid = el("div", "cal-grid");
      var today = new Date().toISOString().slice(0, 10);
      // Sunday-first for US date order, Monday-first for the other two. Taken
      // from the setting that already decides date order rather than from
      // Intl.Locale.weekInfo, which is not everywhere yet and would need a
      // fallback that says the same thing anyway.
      var mondayFirst = dateLocale() !== "en-US";
      var DOW = ["S", "M", "T", "W", "T", "F", "S"];
      var order = mondayFirst ? [1, 2, 3, 4, 5, 6, 0] : [0, 1, 2, 3, 4, 5, 6];

      for (var m = 0; m < 12; m++) {
        var mm = String(m + 1).padStart(2, "0");
        var first = year + "-" + mm + "-01";
        var days = new Date(Date.UTC(year, m + 1, 0)).getUTCDate();
        var last = year + "-" + mm + "-" + String(days).padStart(2, "0");
        var cell = el("div", "cal-month");
        cell.appendChild(el("div", "cal-mname",
          new Date(Date.UTC(year, m, 1)).toLocaleDateString(dateLocale(), { month: "short", timeZone: "UTC" })));
        var inMonth = mine.filter(function (t) { return t.starts_at <= last && t.ends_at >= first; });

        var dow = el("div", "cal-dow");
        order.forEach(function (d) { dow.appendChild(el("span", null, DOW[d])); });
        cell.appendChild(dow);

        // The day grid replaced a proportional bar per trip. The bar carried the
        // trip's name inside its own width, so a four-day trip in a 150px month
        // was a 20px sliver with a name in it — the shape was right and the
        // label was unreadable. Dates belong on a date grid; the names moved
        // below, where there is a whole line each for them.
        var dgrid = el("div", "cal-days");
        var firstDow = new Date(Date.UTC(year, m, 1)).getUTCDay();
        var lead = mondayFirst ? (firstDow + 6) % 7 : firstDow;
        for (var b = 0; b < lead; b++) dgrid.appendChild(el("div", "cal-day is-blank", ""));

        for (var d = 1; d <= days; d++) {
          var key = year + "-" + mm + "-" + String(d).padStart(2, "0");
          // Every trip covering this day, not the first one. Days overlap here
          // more than you would guess — a child at camp while the rest of the
          // family is somewhere else is two trips over one week — and taking
          // [0] meant the day claimed to be one trip and opened it, with the
          // other invisible unless you read the list underneath.
          var on = inMonth.filter(function (t) { return t.starts_at <= key && t.ends_at >= key; });
          // A plain div when there is nothing to open. Everything in this app
          // that looks tappable does something, and 300-odd inert buttons a year
          // would break that and the tab order with it.
          var day = el(on.length ? "button" : "div", "cal-day", String(d));
          if (on.length) {
            day.type = "button";
            day.classList.add("is-trip");
            // Past only when everything covering the day is over, so a day
            // shared by a finished trip and a coming one still reads as ahead.
            if (on.every(function (t) { return t.ends_at < today; })) day.classList.add("is-past");
            if (on.length > 1) day.classList.add("is-multi");
            day.title = on.map(function (t) {
              return (t.name || "Trip") + " · " + fmtRange(t);
            }).join("\n");
            // Opens the earliest-starting one — `mine` is sorted by start, so
            // this is at least deterministic. The lines below name them all and
            // each opens its own, which is the unambiguous way in.
            (function (t) {
              day.addEventListener("click", function () { openTrip(t); });
            })(on[0]);
          }
          if (key === today) day.classList.add("is-today");
          dgrid.appendChild(day);
        }
        cell.appendChild(dgrid);

        var bars = el("div", "cal-bars");
        inMonth.forEach(function (t) {
          var bar = el("button", "cal-bar"); bar.type = "button";
          bar.appendChild(el("span", "cal-bar-name", t.name || "Trip"));
          // Which days of THIS month, so a trip spanning a boundary says what it
          // does here rather than repeating its full range in both cells.
          var s = t.starts_at > first ? Number(t.starts_at.slice(8, 10)) : 1;
          var e = t.ends_at < last ? Number(t.ends_at.slice(8, 10)) : days;
          bar.appendChild(el("span", "cal-bar-when", s === e ? String(s) : s + "–" + e));
          if (t.ends_at < today) bar.classList.add("is-past");
          bar.title = (t.name || "Trip") + " · " + fmtRange(t);
          bar.addEventListener("click", function () { openTrip(t); });
          bars.appendChild(bar);
        });
        cell.appendChild(bars);
        grid.appendChild(cell);
      }
      inner.appendChild(grid);
    }
    paint();
  }

  // ---- somewhere you want to go, but have not booked ----
  // Kept in settings, deliberately not as a trip with has_dates=false. An
  // undated trip is still a trip: it counts in the 183, it appears in the
  // dashboard list, the trip check has opinions about it, and the calendar feed
  // has to decide what to do with it. A wish is none of those things until it
  // becomes a booking, and promoting one is a single button when it does.
  // A readable default label for a link: the host without the www, which is
  // what somebody would call the site out loud.
  function prettyHost(u) {
    try { return new URL(u).hostname.replace(/^www\./, ""); }
    catch (e) { return String(u || "link").slice(0, 40); }
  }

  // Enough to tell "belmond.com/hotel-caruso" from "Ravello, Italy". A space
  // rules it out, and so does the absence of a dotted host with a real suffix,
  // which keeps "St. Moritz" from being mistaken for an address.
  function looksLikeUrl(v) {
    var s = String(v || "").trim();
    if (!s || /\s/.test(s)) return false;
    if (/^https?:\/\//i.test(s)) return true;
    return /^[a-z0-9][a-z0-9-]*(\.[a-z0-9-]+)*\.[a-z]{2,}([\/:?#]|$)/i.test(s);
  }

  // What to write on the link chip. A site's own name beats a hostname —
  // "Belmond" over "belmond.com" — but og:site_name is also where a site puts
  // its tagline, and "Fogo Island Inn | All-Inclusive Hospitality & Regenerative
  // Travel" is not a label. Anything long or punctuated falls back to the host.
  function linkLabel(info, url) {
    var s = String((info && info.site) || "").trim();
    if (s && s.length <= 28 && !/[|·—–]/.test(s)) return s;
    return prettyHost(url);
  }

  // ---- the planner's own vocabulary ----
  //
  // An idea is a place you have not booked. It carries three things the old
  // bucket list could not: WHERE it is, WHEN you would go, and WHEN it is worth
  // going. None is required -- an idea with only a name is still a valid idea,
  // and the list is mostly those on the day it is created.

  // A target window, not a date range. "2027" means that year, "2027-09" that
  // month, "2027-09-14" that week. One text field holds all three because they
  // are the same answer at different resolutions, and ISO-8601 sorts correctly
  // whichever one you give it.
  var MONTHS = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"];

  function targetLabel(from, to) {
    var one = function (v) {
      var t = String(v || "").trim();
      if (!t) return "";
      var m = /^(\d{4})(?:-(\d{2}))?(?:-(\d{2}))?$/.exec(t);
      if (!m) return t;
      if (m[3]) return MONTHS[Number(m[2]) - 1].slice(0, 3) + " " + Number(m[3]) + ", " + m[1];
      if (m[2]) return MONTHS[Number(m[2]) - 1] + " " + m[1];
      return m[1];
    };
    var a = one(from), b = one(to);
    if (a && b && a !== b) return a + " – " + b;
    return a || b || "";
  }

  // A season is a pair of month numbers and it may WRAP: Nantucket is 5–10,
  // but a ski property is 12–3, and December is not "after" March. Every
  // comparison here has to survive that, which is why it is a function rather
  // than a range check written out at each call site.
  function inSeason(month, from, to) {
    if (!from || !to) return true;              // nothing said, nothing to fail
    if (from <= to) return month >= from && month <= to;
    return month >= from || month <= to;        // wraps the new year
  }

  function seasonLabel(from, to) {
    if (!from || !to) return "";
    return MONTHS[from - 1].slice(0, 3) + "–" + MONTHS[to - 1].slice(0, 3);
  }

  // The months a target window actually covers, so it can be checked against a
  // season. A bare year covers all twelve -- you have not chosen yet, so there
  // is nothing to warn about.
  function targetMonths(from, to) {
    var monthOf = function (v) {
      var m = /^(\d{4})-(\d{2})/.exec(String(v || ""));
      return m ? Number(m[2]) : null;
    };
    var a = monthOf(from), b = monthOf(to);
    if (!a && !b) return [];
    if (!b || a === b) return [a || b];
    var out = [], i = a;
    for (var guard = 0; guard < 12; guard++) { out.push(i); if (i === b) break; i = i === 12 ? 1 : i + 1; }
    return out;
  }

  // Does the window fight the season? Only ever a note, never a block: going
  // somewhere out of season is a decision, not an error.
  function seasonClash(idea) {
    var months = targetMonths(idea.target_from, idea.target_to);
    if (!months.length || !idea.season_from || !idea.season_to) return null;
    var bad = months.filter(function (m) { return !inSeason(m, idea.season_from, idea.season_to); });
    if (!bad.length || bad.length === months.length) {
      return bad.length ? "Outside its season (" + seasonLabel(idea.season_from, idea.season_to) + ")" : null;
    }
    return "Partly outside its season (" + seasonLabel(idea.season_from, idea.season_to) + ")";
  }

  // ---- how far away is it, really ----
  //
  // Every airport here is one this traveller has actually used, with the
  // coordinates already on the flight record -- no dataset, no third-party API,
  // no licence. Loaded once per session and cached; it changes only when a new
  // flight is imported.
  var airportsCache = null;
  async function airports() {
    if (airportsCache) return airportsCache;
    try {
      var d = await api("/v1/airports");
      airportsCache = (d && d.results) || [];
    } catch (e) { airportsCache = []; }
    return airportsCache;
  }

  // Straight-line distance and a rough flight time. The time is an ESTIMATE and
  // is labelled as one wherever it is shown: 800 km/h cruise plus 45 minutes
  // for taxi, climb and descent. It is not a schedule and cannot be -- see the
  // note on /v1/airports for why there is no route search here.
  // Under this, an idea is a drive and the flying half of the panel is not
  // shown at all -- no airport, no routes, no fares.
  //
  // DELIBERATELY NOT HOME_MAX_KM, which is 1100 and answers a different
  // question: whether to draw a driving route on a trip that already exists.
  // Las Vegas is 435km and Mammoth 500, and both are real drives worth
  // estimating once booked. But when you are still CHOOSING, 250 miles is the
  // point past which you would look at flights, and offering an airport for
  // Terranea -- forty minutes down the coast -- is noise.
  var DRIVE_MAX_KM = 402;   // 250 miles

  function flightHours(km) {
    if (km == null) return null;
    return km / 800 + 0.75;
  }

  function nearestAirport(list, lat, lon) {
    if (lat == null || lon == null || !list || !list.length) return null;
    var best = null;
    list.forEach(function (a) {
      var d = km(lat, lon, a.latitude, a.longitude);
      if (d == null) return;
      if (!best || d < best.km) best = { code: a.code, km: d, legs: a.legs };
    });
    return best;
  }

  // What to say about getting there. Distance is exact; the flight time is an
  // estimate; "you have flown here before" is a fact worth more than either,
  // because it means the connection is known to work.
  function reachability(idea, list) {
    if (idea.latitude == null || idea.longitude == null) return null;
    var straight = km(HOME.lat, HOME.lng, idea.latitude, idea.longitude);
    if (straight == null) return null;
    var near = nearestAirport(list, idea.latitude, idea.longitude);
    var out = { km: straight, airport: near };
    // Under a long drive, a flight is the wrong frame entirely.
    out.drivable = straight <= DRIVE_MAX_KM;
    out.hours = out.drivable ? null : flightHours(straight);
    return out;
  }

  function reachLabel(r) {
    if (!r) return "";
    var miles = Math.round(r.km * 0.621371);
    if (r.drivable) return miles.toLocaleString() + " mi from home · drivable";
    var bits = [miles.toLocaleString() + " mi from home",
      "~" + (Math.round(r.hours * 10) / 10) + " h in the air"];
    if (r.airport && r.airport.km < 150) {
      bits.push(r.airport.code + (r.airport.legs ? " · flown " + r.airport.legs + "×" : ""));
    }
    return bits.join(" · ");
  }


  // ---- getting there, specifically ----
  //
  // reachability() above answers "how far is it" from geometry we own, at any
  // distance and any date. This answers "which flights, on what day, for
  // roughly what" -- which nobody can answer from geometry, so it costs a
  // metered search. Everything here exists to make that search worth spending.

  // Which day to price. A window is a wish about a month, so the 15th stands in
  // for it: mid-month, away from the month-boundary fares that would misprice
  // the whole idea. A window naming only a YEAR gets no sample date at all --
  // picking a month for you would put a specific price on a decision you have
  // not made.
  function sampleDate(idea) {
    var m = /^(\d{4})-(\d{2})(?:-(\d{2}))?$/.exec(String(idea.target_from || "").trim());
    if (!m) return null;
    return m[3] ? m[1] + "-" + m[2] + "-" + m[3] : m[1] + "-" + m[2] + "-15";
  }

  // How long you would go for. A window says WHEN, not for how long, and the
  // difference decides the return date and therefore the price. Seven is the
  // length of most of the trips already in this database; it is a default, not
  // a guess about any particular idea, and it is editable on every one.
  // Kept in step with package.json by build.js, which fails the build rather
  // than let the two drift.
  var APP_VERSION = "v121.1";

  var DEFAULT_NIGHTS = 7;
  function nightsOf(idea) {
    var n = Number(idea && idea.nights);
    return isFinite(n) && n > 0 ? Math.round(n) : DEFAULT_NIGHTS;
  }

  // The return leg's date. An explicit end to the window wins when it names a
  // real day -- that is the traveller saying so outright. Otherwise it is the
  // outbound plus the nights.
  function returnDate(idea, out) {
    if (!out) return null;
    var end = String((idea && idea.target_to) || "").trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(end) && end > out) return end;
    var d = new Date(out + "T12:00:00Z");
    if (isNaN(d)) return null;
    d.setUTCDate(d.getUTCDate() + nightsOf(idea));
    return d.toISOString().slice(0, 10);
  }

  // Airlines load schedules about eleven months out. Past that the answer is
  // "not published yet", which is not the same as "no flights" and must not be
  // shown as one.
  var FLIGHT_HORIZON_DAYS = 330;
  function flightWindow(date, nowMs) {
    if (!date) return null;
    var days = Math.round((Date.parse(date + "T12:00:00Z") - (nowMs || Date.now())) / 86400000);
    if (!isFinite(days)) return null;
    if (days < 0) return "past";
    return days > FLIGHT_HORIZON_DAYS ? "far" : "ok";
  }

  // Where you leave from: the airport nearest home in your own flight history,
  // not a hardcoded LAX. If the history ever says otherwise, the history wins.
  function homeAirport(ports) {
    var a = nearestAirport(ports, HOME.lat, HOME.lng);
    return a ? a.code : null;
  }

  // Where you land. The stored code wins: the server fills it from a real
  // airport dataset the moment an idea gains coordinates, and marks whether that
  // was automatic or a deliberate override -- either way it is the answer.
  //
  // The history fallback below is for ideas that have not been written since
  // that existed. It stays deliberately tight, because the history only knows
  // airports already used: a genuinely new destination has nothing near it, and
  // reaching 400 miles for the closest one he happens to have flown would search
  // the wrong route and spend a search doing it.
  function destAirport(idea, ports) {
    var typed = String(idea.airport || "").trim().toUpperCase();
    if (/^[A-Z]{3}$/.test(typed)) return typed;
    var near = nearestAirport(ports, idea.latitude, idea.longitude);
    return near && near.km <= 150 ? near.code : null;
  }

  // Close enough to price. Measured against the RETURN, because that is the far
  // end of the trip and the one that has to be published; a window that starts
  // inside the horizon and ends outside it has no round trip to look up.
  function bookableNow(idea, nowMs) {
    var out = sampleDate(idea);
    if (!out) return false;
    var back = returnDate(idea, out);
    return flightWindow(out, nowMs) === "ok" && flightWindow(back, nowMs) === "ok";
  }

  // "In season now" has to mean something stricter than inSeason() does.
  // inSeason answers "is there anything here that rules this month out", so it
  // says yes when no season was ever declared -- correct as a warning, useless
  // as a filter, where it would return the entire list.
  function seasonNow(idea, month) {
    if (!idea.season_from || !idea.season_to) return false;
    return inSeason(month, idea.season_from, idea.season_to);
  }

  var IDEA_SORTS = [
    { key: "target", label: "Soonest first" },
    { key: "near", label: "Nearest first" },
    { key: "added", label: "Recently added" },
    { key: "name", label: "A – Z" },
  ];
  var IDEA_FILTERS = [
    { key: "all", label: "All" },
    { key: "season", label: "In season now" },
    { key: "bookable", label: "Bookable now" },
    { key: "noplace", label: "No location yet" },
  ];

  function sortIdeas(list, mode, ports) {
    var out = list.slice();
    var byName = function (a, b) { return String(a.place).localeCompare(String(b.place)); };
    if (mode === "name") return out.sort(byName);
    if (mode === "added") {
      return out.sort(function (a, b) {
        return String(b.created_at || "").localeCompare(String(a.created_at || "")) || byName(a, b);
      });
    }
    if (mode === "near") {
      var far = Infinity;
      // Measured ONCE per idea, not once per comparison. reachability() walks
      // every airport in the history to find the nearest, so calling it from
      // inside the comparator is fifty haversines per compare -- around seventy
      // thousand of them to sort a hundred ideas, for an answer that cannot
      // change during a sort.
      var dist = new Map();
      out.forEach(function (i) {
        var r = reachability(i, ports);
        dist.set(i, r ? r.km : far);
      });
      var d = function (i) { return dist.has(i) ? dist.get(i) : far; };
      // Ideas with no location sort last rather than first: an unknown distance
      // is not a short one. Two of them give Infinity - Infinity, which is NaN
      // and not a comparator answer at all -- it only behaved because NaN is
      // falsy and fell through. Say so instead of relying on that.
      return out.sort(function (a, b) {
        var da = d(a), db = d(b);
        return da === db ? byName(a, b) : da - db;
      });
    }
    // Soonest first, and an idea with NO window sorts after every dated one --
    // "someday" is not sooner than 2027.
    return out.sort(function (a, b) {
      var A = String(a.target_from || ""), B = String(b.target_from || "");
      if (!A && !B) return byName(a, b);
      if (!A) return 1;
      if (!B) return -1;
      return A.localeCompare(B) || byName(a, b);
    });
  }

  function filterIdeas(list, mode, ports, nowMs) {
    if (mode === "season") {
      var m = new Date(nowMs || Date.now()).getMonth() + 1;
      return list.filter(function (i) { return seasonNow(i, m); });
    }
    if (mode === "bookable") return list.filter(function (i) { return bookableNow(i, nowMs); });
    if (mode === "noplace") {
      // Coordinates, not an address. A typed address looks like a finished
      // record and is still inert: the map, the distance, the drive time and
      // the airport all need a pin, and none of them can read prose.
      return list.filter(function (i) { return i.latitude == null && !i.no_location; });
    }
    return list;
  }

  function durLabel(min) {
    if (!isFinite(min) || min == null) return "";
    var h = Math.floor(min / 60), m = Math.round(min % 60);
    return (h ? h + "h" : "") + (h && m ? " " : "") + (m ? m + "m" : (h ? "" : "0m"));
  }

  // Airfares are whole dollars everywhere they are quoted, including on Google
  // Flights itself. money() renders cents because an expense genuinely has
  // them; "$202.00" here just adds two characters of noise to every line.
  function fare(n) {
    if (n == null || !isFinite(n)) return "—";
    try {
      return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD",
        maximumFractionDigits: 0 }).format(n);
    } catch (e) { return "$" + Math.round(n); }
  }

  function stopsLabel(n) { return n === 0 ? "nonstop" : n + (n === 1 ? " stop" : " stops"); }

  async function searchFlights(from, to, date, back, refresh) {
    return api("/v1/flightsearch?from=" + from + "&to=" + to + "&date=" + date +
      (back ? "&return=" + back : "") + (refresh ? "&refresh=1" : ""));
  }

  // The whole result, drawn into a box that is already on screen. Kept separate
  // from the fetch so a cached answer and a fresh one render identically.
  function paintFlights(box, data, onRefresh) {
    box.innerHTML = "";
    if (!data || !data.results || !data.results.length) {
      // Four different silences. "Nothing came back" for a spent allowance
      // would send you looking at the route, and for a rejected key would send
      // you looking at the date -- so each says which one it is, in the words
      // the upstream used where there are any.
      var why = data && data.reason;
      var said = data && data.message;
      var text = why === "too_far" ? "Schedules for that date are not published yet."
        : why === "past" ? "That date has gone."
        : why === "unconfigured" ? "Flight search is not set up yet."
        : (why === "upstream" || why === "timeout" || why === "unreadable")
          ? (said || "The flight service could not answer.")
          : "No flights came back for that date.";
      var line = el("div", "fl-empty", text);
      if (why === "upstream" || why === "timeout") line.classList.add("is-bad");
      box.appendChild(line);
      return;
    }
    var head = el("div", "fl-head");
    // Said plainly and every time. These are one day's fares for a date nobody
    // picked, and reading them as a quote is the only real way to be misled here.
    // A one-way fare is roughly half of what going somewhere costs, so which
    // of the two this is has to be on the line with the money.
    var when = data.round_trip && data.return_date
      ? targetLabel(data.date, "") + " – " + targetLabel(data.return_date, "")
      : targetLabel(data.date, "");
    var bits = [(data.round_trip ? "Round trip " : "One way ") + when];
    if (data.typical) bits.push("typically " + fare(data.typical.low) + "–" + fare(data.typical.high));
    head.appendChild(el("span", "fl-note", bits.join("  ·  ") + "  ·  indicative, not a quote"));
    var again = el("button", "bucket-addlink", data.cached ? "Refresh" : "Refresh");
    again.type = "button";
    again.title = "Ask again — this spends one of the 250 monthly searches";
    again.addEventListener("click", onRefresh);
    head.appendChild(again);
    box.appendChild(head);

    data.results.forEach(function (r) {
      var card = el("div", "fl-card");
      var top = el("div", "fl-top");
      top.appendChild(el("span", "fl-price", fare(r.price)));
      top.appendChild(el("span", "fl-meta",
        [durLabel(r.minutes), stopsLabel(r.stops)].filter(Boolean).join("  ·  ")));
      card.appendChild(top);

      r.legs.forEach(function (L, i) {
        var line = el("div", "fl-leg");
        line.appendChild(el("span", "fl-code",
          [L.airline, L.flight].filter(Boolean).join(" ")));
        line.appendChild(el("span", "fl-path",
          (L.from || "?") + " " + (L.depart ? L.depart.split(" ").slice(1).join(" ") : "") +
          " → " + (L.to || "?") + " " + (L.arrive ? L.arrive.split(" ").slice(1).join(" ") : "")));
        card.appendChild(line);
        var lay = r.layovers[i];
        if (lay) {
          card.appendChild(el("div", "fl-lay",
            durLabel(lay.minutes) + " in " + (lay.code || lay.name || "?") +
            (lay.overnight ? " · overnight" : "")));
        }
      });
      box.appendChild(card);
    });
  }


  // ---- card spend thresholds ----
  //
  // Some cards pay a reward for reaching an annual spend figure. Knowing where
  // you stand is only half of it -- the question this answers is whether to
  // keep steering spend at a card or stop, which needs the PACE, not just the
  // total. So every goal shows three things: where you are, what the current
  // rate gets you by December, and what rate would be enough.
  //
  // The arithmetic lives on the server (see cardsPayload in _core.js) because
  // the classification behind it is subtle enough to have been wrong twice.
  // This paints what it returns and nothing more.
  function openCardGoals() {
    panelRoute("#cards");

    var overlay = $("#detail-overlay"), content = $("#detail-content");
    content.innerHTML = "";
    overlay.hidden = false;
    document.body.style.overflow = "hidden";
    var inner = el("div", "detail-inner");
    content.appendChild(inner);

    // Whole dollars. Cents on a $250,000 threshold are noise, and the columns
    // line up without them.
    function usd(n) {
      return (n < 0 ? "-$" : "$") + Math.round(Math.abs(n)).toLocaleString("en-US");
    }
    function dayLabel(iso) {
      var d = toDate(iso);
      return d ? fmtMD(d) : iso;
    }
    function sinceLabel(iso) {
      var t = Date.parse(iso || "");
      if (!t) return "never";
      var mins = Math.round((Date.now() - t) / 60000);
      if (mins < 2) return "just now";
      if (mins < 60) return mins + " minutes ago";
      var hrs = Math.round(mins / 60);
      if (hrs < 24) return hrs + (hrs === 1 ? " hour ago" : " hours ago");
      var days = Math.round(hrs / 24);
      return days + (days === 1 ? " day ago" : " days ago");
    }

    // The stays, and whether each one counts.
    //
    // This is not a detail view -- it is the correction mechanism, and it has
    // to be here because no brand match can be right on its own. "Hotel Seville
    // NoMad" is a Hyatt and says nothing of the sort; three nights would have
    // gone quietly missing. A number you cannot check is a number you cannot
    // use, so every stay of the year is listed with the answer the match gave
    // and a tick to overrule it.
    function stayList(r) {
      var box = el("details", "goal-stays");
      // Tagged with the goal, so a repaint reopens THIS list and not whichever
      // .goal-stays happens to come first in the document. One nights goal
      // today; the querySelector version was a wrong-goal bug waiting on the
      // second.
      box.dataset.goal = String(r.goal_id);
      if (openStays[String(r.goal_id)]) box.open = true;
      var sum = el("summary", null,
        r.stays.filter(function (x) { return x.counts && x.nights > 0; }).length +
        " of " + r.stays.length + " stays counted");
      box.appendChild(sum);

      r.stays.forEach(function (st) {
        var row = el("label", "stay-row" + (st.counts ? " is-on" : ""));
        var box2 = el("input");
        box2.type = "checkbox";
        box2.checked = !!st.counts;
        box2.addEventListener("change", function () {
          box2.disabled = true;
          // Through the write queue: two ticks in quick succession used to
          // race, and whichever RESPONSE landed last painted the screen --
          // which could be the one that never saw the other's change. Queued,
          // each request departs after the previous response, so the last
          // payload always contains every prior write and repainting from it
          // unconditionally is correct.
          enqueueWrite(function () {
            return api("/v1/cards/stays", {
              method: "POST",
              body: JSON.stringify({ goal_id: r.goal_id, hosting_id: st.hosting_id, counts: box2.checked }),
            });
          }).then(function (d) {
            shown = d;
            // Repainting the whole panel keeps the total and the list in step;
            // paint itself preserves which stay lists were open.
            paint(d, false);
          }).catch(function (e) {
            box2.checked = !box2.checked;
            box2.disabled = false;
            try { toast("Could not save that: " + (e && e.message ? e.message : "unknown error")); } catch (err) {}
          });
        });
        row.appendChild(box2);

        var body = el("span", "stay-body");
        body.appendChild(el("span", "stay-name", st.name || "(unnamed)"));
        var meta = st.from + " → " + st.to + " · " + st.nights + (st.nights === 1 ? " night" : " nights");
        if (st.room > 1) meta += " · second room";
        if (st.future) meta += " · not stayed yet";
        if (st.overridden) meta += " · set by you";
        body.appendChild(el("span", "stay-meta", meta));
        // A stay whose dates are the same day earns nothing, which is almost
        // always a missing check-out rather than a real day trip. Silence here
        // is how a night disappears.
        if (st.suspect) body.appendChild(el("span", "stay-warn", "No check-out date, so this counts as zero nights."));
        row.appendChild(body);
        box.appendChild(row);
      });

      if (r.extra_room_nights && !r.count_extra_rooms) {
        box.appendChild(el("div", "stay-note",
          r.extra_room_nights + " further nights are second rooms on those same stays, and are not " +
          "counted. Hyatt credits qualifying nights on up to three rooms when you pay for all of " +
          "them, so they may well qualify."));
      }
      return box;
    }

    // The anchor line: American's own figure, and how stale it is.
    //
    // The panel cannot see flying, so this number IS the flying. Left
    // unrefreshed it silently understates progress -- which is why the age is
    // stated in plain words rather than tucked away, and why moving it is one
    // tap from here.
    function anchorLine(r) {
      var box = el("div", "goal-anchor");
      var head = el("div", "anchor-head");

      if (r.anchor_stale) {
        // The balance on record was read in the PREVIOUS qualification year,
        // and loyalty balances reset when the year rolls over. Counting it
        // would OVERSTATE progress by last year's entire total -- the opposite
        // direction from the usual staleness warning -- so the server has
        // already dropped it and this explains the smaller number.
        head.appendChild(el("span", "anchor-warn",
          "The balance on record was read " + r.baseline_at + ", in the previous qualification year. " +
          "It no longer applies, so this counts card spend only — update it from American."));
      } else if (!r.baseline_at) {
        head.appendChild(el("span", "anchor-warn",
          "No balance recorded yet, so this counts card spend only and is missing every flight."));
      } else {
        var age = Math.floor((Date.now() - Date.parse(r.baseline_at + "T00:00:00Z")) / 86400000);
        var txt = Math.round(r.baseline_units).toLocaleString() + " points read from American on " +
          r.baseline_at + ", plus " + usd(r.spend_since_anchor || 0) + " charged since.";
        head.appendChild(el("span", age > 45 ? "anchor-warn" : "anchor-ok", txt));
        if (age > 45) {
          head.appendChild(el("span", "anchor-sub",
            "That was " + age + " days ago. Any flying since then is not in the total."));
        }
      }
      box.appendChild(head);

      var btn = el("button", "chip", r.baseline_at && !r.anchor_stale ? "Update from American" : "Record the balance");
      btn.type = "button";
      btn.addEventListener("click", function () {
        // A prompt rather than a form: it is two values, typed rarely, and a
        // dialog for it would be more chrome than the job deserves.
        var raw = window.prompt(
          "Loyalty Points balance shown by American:",
          r.baseline_units ? String(Math.round(r.baseline_units)) : "");
        if (raw === null) return;
        // The stripper turns "abc" into "" and Number("") is 0 -- which passed
        // the old guard and silently zeroed the baseline. Digit-free input is
        // a refusal, not a zero.
        if (!/[0-9]/.test(String(raw))) { try { toast("That is not a number of points."); } catch (e) {} return; }
        var units = Number(String(raw).replace(/[^0-9.]/g, ""));
        if (!isFinite(units) || units < 0) { try { toast("That is not a number of points."); } catch (e) {} return; }
        var when = window.prompt(
          "Date you read it (YYYY-MM-DD):", new Date().toISOString().slice(0, 10));
        if (when === null) return;
        var asOf = String(when).trim();
        // Shape, then reality: "2026-13-05" is shaped like a date and is not
        // one, and stored it would freeze accrual -- every real transaction
        // date compares below the impossible month.
        var rt = new Date(asOf + "T00:00:00Z");
        if (!/^\d{4}-\d{2}-\d{2}$/.test(asOf) || isNaN(rt.getTime()) ||
            rt.toISOString().slice(0, 10) !== asOf) {
          try { toast("That is not a real date in YYYY-MM-DD form."); } catch (e) {}
          return;
        }
        if (asOf > new Date().toISOString().slice(0, 10)) {
          try { toast("That date has not happened yet."); } catch (e) {}
          return;
        }
        btn.disabled = true;
        enqueueWrite(function () {
          return api("/v1/cards/anchor", {
            method: "POST",
            body: JSON.stringify({ goal_id: r.goal_id, units: units, as_of: asOf }),
          });
        }).then(function (d) {
          shown = d;
          paint(d, false);
        }).catch(function (e) {
          btn.disabled = false;
          try { toast("Could not save that: " + (e && e.message ? e.message : "unknown error")); } catch (err) {}
        });
      });
      box.appendChild(btn);
      return box;
    }

    function paint(data, busy) {
      // Which stay lists are open, BEFORE the wipe -- so a refresh or a saved
      // toggle repaints with the reading position intact. Keyed by goal id.
      openStays = {};
      inner.querySelectorAll(".goal-stays[open]").forEach(function (d) {
        if (d.dataset.goal) openStays[d.dataset.goal] = true;
      });
      inner.innerHTML = "";
      inner.appendChild(el("h2", null, "Card Rewards"));

      var rows = (data && data.results) || [];
      var synced = rows.reduce(function (a, r) {
        return (!a || (r.last_sync_at || "") > a) ? (r.last_sync_at || a) : a;
      }, null);

      var meta = el("div", "detail-meta",
        (data ? data.year + " spend" : "") + (synced ? " · synced " + sinceLabel(synced) : ""));
      inner.appendChild(meta);

      var bar = el("div", "goal-actions");
      var refresh = el("button", "chip", busy ? "Checking…" : "⟳ Check now");
      refresh.type = "button";
      refresh.disabled = !!busy;
      refresh.addEventListener("click", function () { load(true); });
      bar.appendChild(refresh);
      inner.appendChild(bar);

      // A failed sync must never render as a smaller number. Showing stale
      // totals under a silent failure is the same lie as an upstream outage
      // rendering as "nothing found" -- it looks like an answer.
      ((data && data.problems) || []).forEach(function (msg) {
        inner.appendChild(el("div", "goal-problem", "⚠ " + msg +
          " The figures below are from the last successful check."));
      });

      if (!rows.length) {
        inner.appendChild(el("div", "empty",
          "No spend goals yet. Link a card and set its annual threshold to track progress here."));
        return;
      }

      rows.forEach(function (r) {
        var nights = r.unit === "nights", points = r.unit === "points";
        // Three units now, and they read differently. "53 of 60 nights",
        // "58,826 of 125,000 points" and "$52,207 of $60,000" want their own
        // formatting rather than one compromise that suits none of them.
        var amount = function (n) {
          if (nights) return Math.round(n) + (Math.round(n) === 1 ? " night" : " nights");
          if (points) return Math.round(n).toLocaleString();
          return usd(n);
        };
        var pct = r.target ? Math.min(999, (r.progress / r.target) * 100) : 0;
        var card = el("div", "goal-card");

        var head = el("div", "goal-head");
        head.appendChild(el("span", "goal-name", r.card));
        head.appendChild(el("span", "goal-pct" + (r.met ? " is-done" : ""), Math.floor(pct) + "%"));
        card.appendChild(head);

        // The mask rides with the reward rather than the name. Beside the name
        // it was the fragment that wrapped -- "Business Platinum Card(R)" fills
        // a phone line on its own, and the four digits landed alone underneath.
        // The window, whenever it is not the calendar year. An AAdvantage year
        // sits beside a calendar card in this panel, and a reader who assumes
        // January will misread every figure on the row.
        var sub2 = r.label + (r.mask ? " · ····" + r.mask : "");
        if (r.window_label && r.window_label !== String(r.year)) sub2 += " · " + r.window_label + " year";
        card.appendChild(el("div", "goal-reward", sub2));

        var track = el("div", "goal-track");
        var fill = el("span", "goal-fill" + (r.met ? " is-done" : ""));
        fill.style.width = Math.min(100, pct) + "%";
        track.appendChild(fill);
        card.appendChild(track);

        card.appendChild(el("div", "goal-nums",
          amount(r.progress) + " of " + amount(r.target) + (points ? " points" : "")));

        if (points) card.appendChild(anchorLine(r));

        // Where the nights came from. A single number hides the fact that two
        // of the three sources are things you can still act on.
        if (nights) {
          var parts = [];
          if (r.from_held) parts.push(r.from_held + " for holding the card");
          if (r.from_spend) parts.push(r.from_spend + " from " + usd(r.spend) + " of spend");
          if (r.from_stays) parts.push(r.from_stays + " from nights stayed");
          card.appendChild(el("div", "goal-sources", parts.join("  ·  ")));
        }

        // Three states, and each says what to DO rather than only where you are.
        if (r.met) {
          // progress minus target, in the goal's OWN unit. spend is always
          // dollars, and on a nights goal "spend - target" was $75,970 - 60.
          var done = "Earned" + (r.crossed_on ? " — crossed " + dayLabel(r.crossed_on) : "") +
            ", " + amount(r.progress - r.target) + " beyond it.";
          card.appendChild(el("div", "goal-note is-done", done));
          if (r.paid_next_year) {
            card.appendChild(el("div", "goal-sub",
              "The reward is paid against the following year — expect it in early " + (Number(r.year) + 1) + "."));
          }
        } else if (r.days_left <= 0) {
          card.appendChild(el("div", "goal-note is-miss",
            "The year closed " + amount(r.remaining) + " short."));
        } else {
          var onTrack = r.projected >= r.target;
          card.appendChild(el("div", "goal-note" + (onTrack ? " is-ok" : " is-warn"),
            (onTrack ? "On track" : "Behind") + " — " + amount(r.remaining) + " to go, " +
            r.days_left + " days left."));

          if (points) {
            // Only the card half is actionable here -- flying lands through the
            // anchor -- so the honest advice is what more spend would buy.
            var rate = (r.spend_step && r.units_per_step) ? (r.units_per_step / r.spend_step) : 1;
            card.appendChild(el("div", "goal-sub",
              usd(Math.ceil(r.remaining / rate)) + " more on the card would cover it, " +
              "or the flying you have not yet counted."));
          } else if (nights) {
            // The useful answer for a nights goal is not a daily rate -- nobody
            // spends evenly toward a step of $5,000 -- it is the two levers:
            // how much more spend buys the gap, and how many nights would.
            var sub = [];
            if (r.spend_step && r.units_per_step) {
              var steps = Math.ceil(r.remaining / r.units_per_step);
              sub.push(usd(steps * r.spend_step) + " more on the card would cover it");
            }
            sub.push("or " + Math.round(r.remaining) + " more nights stayed");
            card.appendChild(el("div", "goal-sub", sub.join(", ") + "."));
            if (r.stays_ahead) {
              card.appendChild(el("div", "goal-sub",
                r.stays_ahead + (r.stays_ahead === 1 ? " night is" : " nights are") +
                " already booked for later this year, which would leave " +
                Math.max(0, Math.round(r.remaining - r.stays_ahead)) + " to find."));
            }
          } else {
            var pace = "Running at " + usd(r.per_day) + "/day; at that pace the year ends at " +
              usd(r.projected) + ".";
            if (onTrack && r.per_day > 0) {
              var lands = new Date(Date.now() + (r.remaining / r.per_day) * 86400000);
              pace += " Lands around " + fmtMD(lands) + ".";
            } else {
              pace += " Needs " + usd(r.needed_per_day) + "/day (" +
                usd(r.needed_per_day * 30.4) + "/month) from here.";
            }
            card.appendChild(el("div", "goal-sub", pace));
          }
        }

        if (nights && r.stays && r.stays.length) card.appendChild(stayList(r));

        // What went into the number, because a threshold total that cannot be
        // checked against a statement is not worth much.
        card.appendChild(el("div", "goal-split",
          usd(r.charges) + " charged" +
          (r.refunds ? ", " + usd(-r.refunds) + " refunded" : "") +
          (r.credits ? " · " + usd(-r.credits) + " of statement credits, which still count" : "") +
          (r.pending_spend ? " · " + usd(r.pending_spend) + " of it still pending" : "") +
          " · " + r.txn_count + " transactions"));

        inner.appendChild(card);
      });
    }

    async function load(force) {
      try {
        if (force) paint(shown, true);
        var d = await api("/v1/cards" + (force ? "/sync" : ""), force ? { method: "POST" } : undefined);
        shown = d;
        paint(d, false);
      } catch (e) {
        var msg = "⚠ Could not reach the card data: " + (e && e.message ? e.message : "unknown error");
        if (shown) {
          // The figures already on screen came from a request that SUCCEEDED.
          // Wiping them for a failed refresh -- taking the retry button with
          // them -- replaced a good answer with a dead end, the exact lie the
          // problems strip exists to prevent. Repaint the last good payload
          // and put the failure above it.
          paint(shown, false);
          var bar = inner.querySelector(".goal-actions");
          var strip = el("div", "goal-problem", msg + " The figures below are from the last successful check.");
          if (bar && bar.nextSibling) inner.insertBefore(strip, bar.nextSibling);
          else inner.appendChild(strip);
        } else {
          // Nothing good to fall back to -- but paint(null) would render
          // "No spend goals yet", an outage dressed as an empty account. Say
          // what happened and offer the plain retry.
          inner.innerHTML = "";
          inner.appendChild(el("h2", null, "Card Rewards"));
          inner.appendChild(el("div", "goal-problem", msg));
          var again = el("button", "chip", "Try again");
          again.type = "button";
          again.addEventListener("click", function () { load(false); });
          inner.appendChild(again);
        }
      }
    }

    var shown = null;
    var openStays = {};
    // One write on the wire at a time. Concurrent POSTs raced, and the last
    // RESPONSE to land won the screen -- which could be the one issued before,
    // and therefore missing, the other's change.
    var writeChain = Promise.resolve();
    function enqueueWrite(fn) {
      var next = writeChain.then(fn, fn);
      writeChain = next.catch(function () {});
      return next;
    }
    inner.appendChild(el("div", "empty", "Checking your cards…"));
    load(false);
  }

  async function openBucketList() {
    panelRoute("#ideas");
    var o = overlay("wide");
    // Paired with panelRoute above: closing this releases #ideas again.
    o.back.__route = "#ideas";
    var back = o.back, panel = o.panel;

    // The list is a table now, not a field on /v1/me, so each edit is a row
    // write rather than a rewrite of the whole array. Held in memory between
    // paints and re-read after every change, because the server decides the
    // order and the ids.
    var ideas = [], ports = [];
    // Kept on the panel rather than persisted: which way you sorted last week
    // is not a fact about the list, and restoring it would answer a question
    // you did not ask this time.
    var sortMode = "target", filterMode = "all";

    async function reload() {
      var d = await api("/v1/ideas");
      ideas = (d && d.results) || [];
    }

    // ---- keeping the list in step without re-reading all of it ----
    //
    // Every write here used to end in reload(): a fresh GET of the whole list
    // to learn about one changed row. The response already carried it. Both the
    // POST and the PATCH handlers read the row back after writing and return it
    // hydrated, so the reply IS the authoritative version -- including the
    // airport that withAutoAirport fills in server-side, which is precisely why
    // these apply the RESPONSE and never the request body. Applying the body
    // would leave the row looking edited and missing what the server added.
    //
    // Sorting and filtering are already client-side (see sortIdeas above), so
    // position is not something the server decides here; paint() re-derives it.
    //
    // Each returns whether it could do the splice. False means the list is not
    // in the shape assumed -- a second tab wrote, or the row went -- and the
    // caller falls back to a full reload. Slow beats quietly wrong.
    function replaceIdea(fresh) {
      if (!fresh || fresh.id == null) return false;
      for (var i = 0; i < ideas.length; i++) {
        if (ideas[i].id === fresh.id) { ideas[i] = fresh; return true; }
      }
      return false;
    }

    function addIdea(fresh) {
      if (!fresh || fresh.id == null) return false;
      // A row already present is an update, not a duplicate: the panel can sit
      // open while another device writes the same idea.
      if (replaceIdea(fresh)) return true;
      ideas.push(fresh);
      return true;
    }

    function dropIdea(id) {
      var before = ideas.length;
      ideas = ideas.filter(function (x) { return x.id !== id; });
      return ideas.length < before;
    }

    function paint() {
      panel.innerHTML = "";
      panel.appendChild(el("h3", "form-title", "Trip Ideas"));
      panel.appendChild(el("div", "place-hint",
        "Places you want to go, and roughly when. Kept out of your trips — no counts, no trip check, no calendar — until you turn one into a real trip."));

      // ---- what is worth doing something about right now ----
      //
      // An idea whose window has come inside the schedule horizon is the moment
      // it stops being a daydream, and it is the one thing here that changes on
      // its own, silently, while you are not looking. Computed from data
      // already loaded; it costs nothing and asks for nothing.
      var nowMs = Date.now();
      var ripe = ideas.filter(function (i) { return bookableNow(i, nowMs); });
      if (ripe.length && filterMode !== "bookable") {
        var nudge = el("div", "bucket-ripe");
        nudge.appendChild(el("span", null,
          ripe.length === 1
            ? "1 idea is close enough to price now."
            : ripe.length + " ideas are close enough to price now."));
        var see = el("button", "bucket-addlink", "Show them"); see.type = "button";
        see.addEventListener("click", function () { filterMode = "bookable"; paint(); });
        nudge.appendChild(see);
        panel.appendChild(nudge);
      }

      // ---- sort and filter ----
      //
      // Seventeen ideas fit on a screen. This list is meant to grow, and a flat
      // scroll of a hundred is a list you stop opening.
      var tools = el("div", "bucket-tools");
      var sortSel = el("select", "form-input bucket-sort");
      IDEA_SORTS.forEach(function (o) {
        var op = el("option", null, o.label); op.value = o.key;
        sortSel.appendChild(op);
      });
      sortSel.value = sortMode;
      sortSel.title = "Order the list";
      sortSel.addEventListener("change", function () { sortMode = sortSel.value; paint(); });
      tools.appendChild(sortSel);

      var chips = el("div", "bucket-filters");
      IDEA_FILTERS.forEach(function (f) {
        // The count goes on the chip. A filter that turns out to be empty is
        // worth knowing BEFORE you press it and stare at a blank list.
        var n = filterIdeas(ideas, f.key, ports, nowMs).length;
        var c = el("button", "chip bucket-filter", f.label + (f.key === "all" ? "" : " · " + n));
        c.type = "button";
        if (f.key === filterMode) c.classList.add("is-on");
        if (!n && f.key !== "all") c.disabled = true;
        c.addEventListener("click", function () { filterMode = f.key; paint(); });
        chips.appendChild(c);
      });
      tools.appendChild(chips);
      panel.appendChild(tools);

      // ---- the one-time chore ----
      //
      // Every row here is inert until it knows where it is, and most of these
      // are named properties a geocoder resolves from the name alone. Doing
      // seventeen by hand is the whole distance between built and useful.
      // An idea deliberately marked as having no address yet is not a gap to
      // be filled -- it is a decision already made.
      var placeless = ideas.filter(function (i) { return i.latitude == null && !i.no_location; });
      if (placeless.length) {
        var fill = el("div", "bucket-fill");
        var typed = placeless.filter(function (i) { return hasText(i.address); }).length;
        fill.appendChild(el("span", "fl-hint",
          placeless.length + (placeless.length === 1 ? " idea has" : " ideas have") +
          " no coordinates, so they cannot be mapped, priced, or matched to an airport" +
          (typed ? " — " + typed + " already " + (typed === 1 ? "has an address" : "have addresses") +
            " to look up, which is the accurate kind." : ".")));
        var go = el("button", "mini-btn is-edit", "Find locations"); go.type = "button";
        go.title = "Look each one up and show you what it found — nothing is saved until you approve it";
        go.addEventListener("click", function () {
          openFindLocations(placeless, async function () { await reload(); paint(); });
        });
        fill.appendChild(go);
        panel.appendChild(fill);
      }

      var view = sortIdeas(filterIdeas(ideas, filterMode, ports, nowMs), sortMode, ports);

      var list = el("div", "sheet-list pax-list bucket-list");
      if (!ideas.length) list.appendChild(el("div", "doc-empty", "Nothing on the list yet."));
      else if (!view.length) {
        // Distinguish "you have nothing" from "this filter has nothing", which
        // look identical and mean opposite things.
        var none = el("div", "doc-empty", "No ideas match that filter.");
        var clear = el("button", "bucket-addlink", "Show all"); clear.type = "button";
        clear.addEventListener("click", function () { filterMode = "all"; paint(); });
        none.appendChild(clear);
        list.appendChild(none);
      }

      view.forEach(function (item) {
        var row = el("div", "bucket-row");
        var body = el("div", "bucket-body");

        var edit = function () {
          openBucketEdit(item, async function (patch) {
            var fresh = await api("/v1/ideas/" + item.id, { method: "PATCH", body: JSON.stringify(patch) });
            if (!replaceIdea(fresh)) await reload();
            paint();
          });
        };

        var nm = el("button", "bucket-place", item.place); nm.type = "button";
        nm.title = "Edit this idea";
        nm.addEventListener("click", edit);
        body.appendChild(nm);

        // The three facts a planner adds, on one line under the name. Each is
        // omitted when unset rather than shown empty: a list of "—" teaches you
        // to stop reading the line.
        var facts = [];
        var when = targetLabel(item.target_from, item.target_to);
        if (when) facts.push(when);
        var season = seasonLabel(item.season_from, item.season_to);
        if (season) facts.push("best " + season);
        var reach = reachLabel(reachability(item, ports));
        if (reach) facts.push(reach);
        if (facts.length) body.appendChild(el("div", "bucket-facts", facts.join("  ·  ")));

        // Only ever a note. Going somewhere out of season is a decision, not a
        // mistake, and the app has no business refusing it.
        var clash = seasonClash(item);
        if (clash) body.appendChild(el("div", "bucket-warn", "⚠ " + clash));

        // ---- how you would get there ----
        //
        // Nothing is fetched here. The strip is drawn from what we already know
        // and the search happens only on a press, because painting this list
        // would otherwise spend one search per idea per open and empty a
        // monthly allowance in a week.
        var reachNow = reachability(item, ports);
        if (ports.length && reachNow && !reachNow.drivable) {
          var dep = homeAirport(ports), arr = destAirport(item, ports);
          var day = sampleDate(item), ret = returnDate(item, day);
          // Measured on the RETURN: that is the far end of the trip and the one
          // that has to be published for there to be anything to price.
          var win = flightWindow(ret || day);
          var strip = el("div", "bucket-flights");
          if (!arr) {
            // The history only knows airports already flown. Somewhere new has
            // none nearby, and that is a question, not a failure.
            strip.appendChild(el("span", "fl-hint", "Add the airport you'd fly into to check flights."));
          } else if (!day) {
            strip.appendChild(el("span", "fl-hint", "Narrow the window to a month to check flights."));
          } else if (win === "far") {
            strip.appendChild(el("span", "fl-hint",
              "Too far out — airlines publish schedules about 11 months ahead."));
          } else if (win === "ok" && dep) {
            var box = el("div", "fl-box");
            var go = el("button", "mini-btn", "✈ Flights " + dep + " → " + arr); go.type = "button";
            go.title = "Round trip " + targetLabel(day, "") + " – " + targetLabel(ret, "") +
              " (" + nightsOf(item) + " nights) — one search of your monthly 250";
            var run = async function (refresh) {
              go.disabled = true;
              var was = go.textContent; go.textContent = "Looking…";
              try {
                var d = await searchFlights(dep, arr, day, ret, refresh);
                paintFlights(box, d, function () { run(true); });
              } catch (e) { toast("Couldn't check flights: " + e.message); }
              finally { go.disabled = false; go.textContent = was; }
            };
            go.addEventListener("click", function () { run(false); });
            strip.appendChild(go); strip.appendChild(box);
          }
          if (strip.childNodes.length) body.appendChild(strip);
        }

        var noteBtn = el("button", "bucket-note", item.note || "Add a note"); noteBtn.type = "button";
        if (!item.note) noteBtn.classList.add("is-empty");
        noteBtn.addEventListener("click", edit);
        body.appendChild(noteBtn);

        var linksWrap = el("div", "bucket-links");
        (Array.isArray(item.links) ? item.links : []).forEach(function (L) {
          var a = el("a", "bucket-link", L.title || prettyHost(L.url));
          a.href = L.url; a.target = "_blank"; a.rel = "noopener";
          a.title = L.url;
          linksWrap.appendChild(a);
        });
        var editLinks = el("button", "bucket-addlink",
          linksWrap.childNodes.length ? "Edit" : "＋ Details");
        editLinks.type = "button";
        editLinks.title = "Edit the name, place, dates, season, note and links";
        editLinks.addEventListener("click", edit);
        linksWrap.appendChild(editLinks);
        body.appendChild(linksWrap);
        row.appendChild(body);

        var mk = el("button", "mini-btn is-edit", "Make a trip"); mk.type = "button";
        mk.title = item.address || item.latitude != null
          ? "Create the trip with this booked in as its lodging"
          : "Create a real trip from this and take it off the list";
        mk.addEventListener("click", async function () {
          var willLodge = !!(item.address || item.latitude != null);
          if (!confirm("Create a trip called “" + item.place + "”?" +
              (willLodge ? "\n\n" + item.place + " goes in as the lodging." : "") +
              "\n\nIt comes off this list.")) return;
          mk.disabled = true;
          try {
            // The note and the links go into the description. Dropping them on
            // promotion would lose exactly the research that made it worth
            // keeping, at the moment it finally becomes a real trip.
            var desc = [item.note || ""].concat(
              (Array.isArray(item.links) ? item.links : []).map(function (L) {
                return (L.title ? L.title + " — " : "") + L.url;
              })
            ).filter(Boolean).join("\n");
            // No dates: it becomes an undated trip, which is what the
            // dashboard's "No dates" group is for, and the trip check leaves
            // undated trips alone. The target window was never a date -- it is
            // a wish about a month -- so inventing dates from it would be
            // writing a guess into the database.
            var made = await api("/v1/trips", { method: "POST", body: JSON.stringify({
              name: item.place, has_dates: false, description: desc,
            }) });
            if (!made || !made.id) throw new Error("The trip was not created.");

            // THE POINT OF ALL THIS. 16 of the first 17 ideas were properties,
            // and the old conversion produced a trip NAMED after a hotel with
            // no hotel in it. If we know where it is, it goes in as lodging --
            // so the map, the drive times and the No-location rule all work
            // before anything else is typed.
            if (willLodge) {
              try {
                var lodging = { name: item.place, address: item.address || null };
                if (item.latitude != null && item.longitude != null) {
                  lodging.latitude = item.latitude; lodging.longitude = item.longitude;
                }
                await api("/v1/trip/" + made.id + "/hostings",
                  { method: "POST", body: JSON.stringify(lodging) });
              } catch (e) {
                // The trip exists and is the thing that matters; a failed
                // lodging write must not strand it half-created.
                toast("Trip created, but the lodging did not save: " + e.message);
              }
            }

            await api("/v1/ideas/" + item.id, { method: "DELETE" });
            state.own = [made].concat(state.own || []);
            back.remove();
            render();
            toast("Created “" + item.place + "”");
            openTrip(made);
          } catch (e) { toast("Couldn't create it: " + e.message); mk.disabled = false; }
        });
        row.appendChild(mk);

        var rm = el("button", "cover-libdel", "✕"); rm.type = "button"; rm.title = "Remove";
        rm.addEventListener("click", async function () {
          if (!confirm("Take “" + item.place + "” off the list?")) return;
          try {
            await api("/v1/ideas/" + item.id, { method: "DELETE" });
            // The delete replies {ok:true} rather than a row, so this drops it
            // by id instead of splicing one in.
            if (!dropIdea(item.id)) await reload();
            paint();
          } catch (e) { toast("Couldn't remove it: " + e.message); }
        });
        row.appendChild(rm);
        list.appendChild(row);
      });
      panel.appendChild(list);

      // One box for both ways of adding something. A place you already know the
      // name of gets typed; a place somebody sent you gets pasted. Which one
      // this is can be read off the text, so asking would be a question with an
      // obvious answer.
      var addRow = el("div", "doc-add");
      var inp = el("input", "form-input");
      inp.placeholder = "Paste a link, or type somewhere you want to go";
      var add = el("button", "mini-btn is-edit", "＋ Add"); add.type = "button";
      var create = async function (entry) {
        var fresh = await api("/v1/ideas", { method: "POST", body: JSON.stringify(entry) });
        if (!addIdea(fresh)) await reload();
        paint();
      };
      var doAdd = async function () {
        var v = inp.value.trim(); if (!v) return;
        if (looksLikeUrl(v)) {
          openBucketLink(v, ideas, function (entry) {
            return create(entry).then(function () { inp.value = ""; });
          });
          return;
        }
        add.disabled = true;
        try { await create({ place: v, note: "", links: [] }); inp.value = ""; }
        catch (e) { toast("Couldn't save: " + e.message); }
        finally { add.disabled = false; }
      };
      add.addEventListener("click", doAdd);
      inp.addEventListener("keydown", function (ev) { if (ev.key === "Enter") { ev.preventDefault(); doAdd(); } });
      addRow.appendChild(inp); addRow.appendChild(add);
      panel.appendChild(addRow);

      var btns = el("div", "form-btns");
      var done = el("button", "primary-btn small", "Done"); done.type = "button";
      done.addEventListener("click", function () { back.remove(); });
      btns.appendChild(done); panel.appendChild(btns);
    }

    panel.appendChild(el("div", "loading", "Loading…"));
    try { await reload(); } catch (e) {
      panel.innerHTML = "";
      panel.appendChild(el("div", "empty", "Couldn't load your ideas: " + e.message));
      return;
    }
    paint();
    // The airport list only decorates -- distance and flight time -- so it is
    // fetched after the first paint and the rows are redrawn when it lands.
    // Waiting for it would delay the list for a line of secondary text.
    airports().then(function (a) { if (a && a.length && document.body.contains(panel)) { ports = a; paint(); } });
  }

  // ---- the one bucket-list form ----
  //
  // Used by both "add from a link" and "edit", so what you review when a page is
  // read is exactly what you get back when you change your mind about it. Every
  // field is a real input: the note the server guessed is a first draft, and an
  // address with a typo in it needs correcting rather than deleting.
  //
  // Returns a read() that validates and assembles the entry, or null and a toast
  // if something is wrong, so the two callers cannot disagree about what counts
  // as a valid one.
  // ---- filling in where these places actually are ----
  //
  // Sixteen of the first seventeen ideas were named PROPERTIES -- Airelles Le
  // Grand Controle, Alisal Ranch, Biltmore -- and a geocoder resolves those
  // from the name alone. Doing them one at a time through the edit form is the
  // whole distance between a feature that exists and a feature that is used.
  //
  // It proposes; it never decides. Every match is shown with the full address
  // the geocoder returned, every one can be unticked, and nothing is written
  // until Save. A geocoder is confidently wrong often enough that accepting its
  // answer unseen would quietly put the wrong coordinates on a real trip.
  var GEOCODE_GAP_MS = 1100;

  // What to search for, coarsest last.
  //
  // OpenStreetMap's coverage of rural street addresses is thin: "1471 W Millers
  // Cove Rd, Walland, TN 37886" returns nothing at all, while "Walland, TN"
  // resolves immediately. For most of what a pin is used for here -- which
  // airport serves this, how far is it, roughly where on the map -- a town is
  // precise enough: TYS is eighteen kilometres from Walland whether you stand
  // at the driveway or in the village.
  //
  // So the street line is dropped one component at a time. The last two
  // components are always kept, because "TN 37886" alone is not a place.
  function geoQueries(item) {
    var qs = [], addr = hasText(item.address) ? String(item.address).trim() : "";
    if (addr) {
      qs.push(addr);
      var parts = addr.split(",").map(function (x) { return x.trim(); }).filter(Boolean);
      for (var drop = 1; drop <= 2 && parts.length - drop >= 2; drop++) {
        qs.push(parts.slice(drop).join(", "));
      }
    }
    var name = hasText(item.place) ? String(item.place).trim() : "";
    if (name && qs.indexOf(name) < 0) qs.push(name);
    return qs;
  }

  // ---- one triage screen, two callers ----
  //
  // Trip Ideas look things up by name; trip items look them up inside their own
  // trip's bounding box. The careful parts are identical and must stay
  // identical: nothing is preselected, the run stops when the geocoder starts
  // refusing, and a coarser match than what was asked for is coloured rather
  // than quietly accepted. Those were learned the hard way and are not worth
  // reimplementing twice, slightly differently.
  //
  // entry: { key, title, note, queries: [string], box: "lon,lat,lon,lat"|null,
  //          exact: string|null, apply: async (hit) => void }
  async function openLocationTriage(opts) {
    var entries = opts.entries || [];
    var o = overlay("wide", false);
    var back = o.back, panel = o.panel;

    panel.appendChild(el("h3", "form-title", opts.title || "Find locations"));
    // Measured on the real list: of the first seven ideas, the geocoder put
    // Blackberry Farm in south London, Atlantis in Palm Beach County and
    // Biltmore in Raleigh. A bare name is simply not enough for it. So nothing
    // is chosen for you -- an unread Save writes nothing rather than writing
    // three wrong places into trips you would later build on.
    panel.appendChild(el("div", "place-hint", opts.hint ||
      "Nothing is selected — pick the right match, or leave it for later. Only what you pick gets saved."));

    var rows = el("div", "sheet-list pax-list");
    panel.appendChild(rows);

    var status = el("div", "fl-hint", "Searching 1 of " + entries.length + "…");
    panel.appendChild(status);

    var btns = el("div", "form-btns");
    var save = el("button", "primary-btn small", "Save"); save.type = "button";
    save.disabled = true;
    var cancel = el("button", "mini-btn", "Cancel"); cancel.type = "button";
    cancel.addEventListener("click", function () { back.remove(); });
    btns.appendChild(cancel); btns.appendChild(save);
    panel.appendChild(btns);

    var picks = [];
    function retally() {
      var n = picks.filter(function (p) { return p.chosen; }).length;
      save.disabled = !n;
      save.textContent = n ? "Save " + n : "Save";
    }

    // Consecutive upstream failures. Nominatim rate-limits, and
    // /api/ext/geocode reports that as a 200 carrying
    // {results: [], error: "geocoder 429"} -- indistinguishable from "this place
    // does not exist" unless it is read.
    var blocked = 0;

    for (var i = 0; i < entries.length; i++) {
      // Closing the dialog stops the run rather than hammering a public
      // geocoder for a list nobody is looking at.
      if (!document.body.contains(panel)) return;
      var entry = entries[i];
      status.textContent = "Searching " + (i + 1) + " of " + entries.length + "…";

      var row = el("div", "find-row");
      row.appendChild(el("div", "bucket-place", entry.title));
      if (hasText(entry.note)) row.appendChild(el("div", "find-note", entry.note));
      var searched = el("div", "find-note", "searching…");
      row.appendChild(searched);
      var optsBox = el("div", "find-opts");
      row.appendChild(optsBox);
      rows.appendChild(row);

      var hits = [], upstream = null, usedQuery = null;
      var qs = entry.queries || [];
      for (var qi = 0; qi < qs.length; qi++) {
        if (qi) await new Promise(function (r) { setTimeout(r, GEOCODE_GAP_MS); });
        try {
          var d = await ext("geocode?q=" + encodeURIComponent(qs[qi]) +
            (entry.box ? "&viewbox=" + encodeURIComponent(entry.box) : ""));
          if (d && d.error) { upstream = String(d.error); break; }
          hits = (d && d.results) || [];
        } catch (e) { upstream = (e && e.message) || "lookup failed"; break; }
        if (hits.length) { usedQuery = qs[qi]; break; }
      }

      searched.textContent = usedQuery
        ? (entry.exact && usedQuery === entry.exact ? "matched the full address" : "matched: " + usedQuery)
        : (qs.length ? "no match for: " + qs[0] : "nothing to search");
      // A hit on the town is a genuinely different pin from a hit on the front
      // door. Saving it silently would move the place a few kilometres.
      if (usedQuery && entry.exact && usedQuery !== entry.exact) searched.classList.add("is-coarse");

      if (upstream) {
        blocked++;
        optsBox.appendChild(el("div", "find-none is-bad",
          "Lookup unavailable (" + upstream + ") — not the same as no match."));
        // Three in a row is a service saying stop, and the courteous answer is
        // to stop rather than finish the list at one request a second.
        if (blocked >= 3) {
          status.textContent = "The geocoder stopped answering (" + upstream + "). " +
            (picks.length
              ? "The " + picks.length + " already found are still yours to save; the rest can wait a few minutes."
              : "Nothing was found — try again in a few minutes.");
          retally();
          return;
        }
      } else if (!hits.length) {
        blocked = 0;
        optsBox.appendChild(el("div", "find-none", "No match — add this one by hand."));
      } else {
        blocked = 0;
        (function (entry, optsBox) {
          var slot = { key: entry.key, title: entry.title, apply: entry.apply, chosen: null };
          picks.push(slot);
          var group = "find-" + entry.key;
          // Four is as many as can be compared without the list becoming its
          // own reading task.
          hits.slice(0, 4).forEach(function (h) {
            var lab = el("label", "find-opt");
            var r = el("input", null);
            r.type = "radio"; r.name = group;
            r.addEventListener("change", function () { if (r.checked) { slot.chosen = h; retally(); } });
            lab.appendChild(r);
            lab.appendChild(el("span", "find-label", h.label));
            optsBox.appendChild(lab);
          });
          var skip = el("label", "find-opt");
          var sr = el("input", null);
          sr.type = "radio"; sr.name = group; sr.checked = true;
          sr.addEventListener("change", function () { if (sr.checked) { slot.chosen = null; retally(); } });
          skip.appendChild(sr);
          skip.appendChild(el("span", "find-label is-skip", "Leave this one"));
          optsBox.appendChild(skip);
        })(entry, optsBox);
      }

      if (i < entries.length - 1) await new Promise(function (r) { setTimeout(r, GEOCODE_GAP_MS); });
    }

    status.textContent = picks.length
      ? "Found matches for " + picks.length + " of " + entries.length +
        ". Check each one — the geocoder is often confident and wrong about a bare name."
      : "Nothing was found. These need adding by hand.";
    retally();

    save.addEventListener("click", async function () {
      var take = picks.filter(function (p) { return p.chosen; });
      if (!take.length) { back.remove(); return; }
      save.disabled = true; save.textContent = "Saving…";
      var wrote = 0, failed = [];
      for (var j = 0; j < take.length; j++) {
        try { await take[j].apply(take[j].chosen); wrote++; }
        catch (e) { failed.push(take[j].title); }
      }
      back.remove();
      toast(failed.length
        ? "Saved " + wrote + "; " + failed.length + " failed (" + failed[0] + (failed.length > 1 ? ", …" : "") + ")"
        : "Saved " + wrote + " location" + (wrote === 1 ? "" : "s"));
      if (opts.onDone) await opts.onDone();
    });
  }

  // ---- caller 1: trip ideas, looked up by name and address ----
  async function openFindLocations(items, onDone) {
    return openLocationTriage({
      title: "Find locations",
      hint: "Looking each one up by name. Nothing is selected — pick the right match, or leave it for later. Only what you pick gets saved.",
      onDone: onDone,
      entries: items.map(function (item) {
        return {
          key: item.id,
          title: item.place,
          note: hasText(item.address)
            ? item.address
            : (hasText(item.note) ? String(item.note).slice(0, 140) : ""),
          exact: hasText(item.address) ? String(item.address).trim() : null,
          queries: geoQueries(item),
          box: null,
          apply: function (hit) {
            return api("/v1/ideas/" + item.id, { method: "PATCH", body: JSON.stringify({
              address: hit.label, latitude: hit.lat, longitude: hit.lon,
            }) });
          },
        };
      }),
    });
  }

  // ---- caller 2: trip items, looked up inside the trip's own area ----
  //
  // "Bath Bomb Workshop" and "Ski Day" are unfindable alone and dangerous to
  // guess at. But the trip already knows where it is: its other items have
  // coordinates. Searching inside that box turns the question into an easy one.
  var TRIP_BOX_PAD = 0.35;   // degrees, roughly 35km — a comfortable day's radius

  function tripBox(data) {
    var pts = geoPoints(data);
    if (!pts.length) return null;
    var lat1 = Infinity, lat2 = -Infinity, lon1 = Infinity, lon2 = -Infinity;
    pts.forEach(function (p) {
      lat1 = Math.min(lat1, p.lat); lat2 = Math.max(lat2, p.lat);
      lon1 = Math.min(lon1, p.lng); lon2 = Math.max(lon2, p.lng);
    });
    // Nominatim wants lon,lat,lon,lat.
    return [(lon1 - TRIP_BOX_PAD).toFixed(4), (lat1 - TRIP_BOX_PAD).toFixed(4),
      (lon2 + TRIP_BOX_PAD).toFixed(4), (lat2 + TRIP_BOX_PAD).toFixed(4)].join(",");
  }

  // What is worth looking up. Notes are scraps of text, not places, and the
  // backfill script has always skipped them for the same reason. Parking is at
  // an airport the flight already pins, so a second marker on top of it adds
  // nothing. Anything already exempted with "No location" was a deliberate
  // decision and is not second-guessed here.
  var NO_LOOKUP_TYPES = { note: 1, parking: 1 };

  function tripPlaceless(data) {
    var out = [];
    (data.hostings || []).forEach(function (h) {
      if (!hasPlace(h, "hosting") && !h.no_location) out.push({ kind: "hosting", x: h });
    });
    (data.activities || []).forEach(function (a) {
      if (NO_LOOKUP_TYPES[a.activity_type]) return;
      if (!hasPlace(a, "activity") && !a.no_location) out.push({ kind: "activity", x: a });
    });
    return out.filter(function (c) { return hasText(c.x.name); });
  }

  async function openFindTripLocations(t, data, onDone) {
    var box = tripBox(data);
    var cands = tripPlaceless(data);
    if (!cands.length) { toast("Nothing here needs a location."); return; }
    return openLocationTriage({
      title: "Find locations",
      hint: box
        ? "Searched inside this trip's own area, so a result cannot land on the wrong continent. Nothing is selected — pick the right match, or leave it."
        : "This trip has no located item to search around, so these are looked up by name alone. Check each one carefully.",
      onDone: onDone,
      entries: cands.map(function (c) {
        return {
          key: c.kind + "-" + c.x.id,
          title: c.x.name,
          note: c.kind === "hosting" ? "Lodging" : (c.x.activity_type || "Activity"),
          exact: null,
          queries: [String(c.x.name).trim()],
          box: box,
          apply: function (hit) {
            return api("/v1/trip/" + t.id + "/" + c.kind + "/" + c.x.id, {
              method: "PATCH",
              body: JSON.stringify({ address: hit.label, latitude: hit.lat, longitude: hit.lon }),
            });
          },
        };
      }),
    });
  }

  function bucketFields(panel, item) {
    var wrap = el("div", "peek-form");

    wrap.appendChild(el("label", "peek-label", "Place"));
    var nameIn = el("input", "form-input");
    nameIn.value = item.place || "";
    nameIn.placeholder = "The hotel, and where it is";
    wrap.appendChild(nameIn);

    wrap.appendChild(el("label", "peek-label", "Note"));
    var noteIn = el("textarea", "form-input peek-note");
    noteIn.rows = 3;
    noteIn.value = item.note || "";
    noteIn.placeholder = "Why it is worth going";
    wrap.appendChild(noteIn);

    // ---- where it is ----
    //
    // 16 of the first 17 entries were PROPERTIES -- Blackberry Farm, Sea
    // Island, Terranea -- not destinations. That is what makes an address worth
    // asking for here: on conversion it becomes the trip's first lodging
    // record, so the map, the drive times and the No-location rule all work
    // from the first minute rather than after a round of re-typing.
    wrap.appendChild(el("label", "peek-label", "Address"));
    // In a row of its own so the place search has a row to anchor to. Handed
    // the bare input, attachPlaceSearch resolves the host to `wrap` itself and
    // then reaches for wrap.parentNode, which does not exist until this whole
    // panel is mounted.
    var addrRow = el("div", null);
    var addrIn = el("input", "form-input");
    addrIn.value = item.address || "";
    addrIn.placeholder = "Where it is — becomes the lodging when this turns into a trip";
    addrRow.appendChild(addrIn);
    wrap.appendChild(addrRow);

    var coordRow = el("div", "peek-coords");
    var latIn = el("input", "form-input peek-coord");
    latIn.placeholder = "Latitude";
    latIn.value = item.latitude != null ? item.latitude : "";
    var lonIn = el("input", "form-input peek-coord");
    lonIn.placeholder = "Longitude";
    lonIn.value = item.longitude != null ? item.longitude : "";
    coordRow.appendChild(latIn); coordRow.appendChild(lonIn);
    wrap.appendChild(coordRow);

    // AFTER both rows are in the tree. The same geocoder every booking form
    // uses, so an address typed here resolves exactly as it would on the trip.
    attachPlaceSearch(wrap,
      { name: nameIn, address: addrIn, latitude: latIn, longitude: lonIn },
      { placeholder: "Search the property name or address…" });

    // ---- when you would go ----
    //
    // A WINDOW, not dates: "2027", "September 2027", or a specific week. All
    // three are the same answer at different resolutions, so all three are one
    // text field, and ISO-8601 sorts correctly whichever you give.
    wrap.appendChild(el("label", "peek-label", "When you'd go"));
    var targetRow = el("div", "peek-coords");
    var tFrom = el("input", "form-input peek-coord");
    tFrom.placeholder = "10/15/27,  10/2027  or  2027";
    tFrom.value = item.target_from || "";
    var tTo = el("input", "form-input peek-coord");
    tTo.placeholder = "through (optional)";
    tTo.value = item.target_to || "";
    targetRow.appendChild(tFrom); targetRow.appendChild(tTo);
    wrap.appendChild(targetRow);

    wrap.appendChild(el("label", "peek-label", "Nights"));
    var nightsIn = el("input", "form-input");
    nightsIn.type = "number"; nightsIn.min = "1"; nightsIn.max = "365";
    nightsIn.value = item.nights != null ? item.nights : "";
    nightsIn.placeholder = String(DEFAULT_NIGHTS) + " — how long you would stay";
    wrap.appendChild(nightsIn);
    wrap.appendChild(el("div", "form-hint",
      "Sets the return date the flight price is based on. Blank means " +
      DEFAULT_NIGHTS + "."));

    // ---- when it is worth going ----
    //
    // Two month pickers rather than free text, because the pair is compared
    // against the target window and a typo would silently stop that working.
    // The pair may wrap the year: a ski property is December to March.
    wrap.appendChild(el("label", "peek-label", "Best season"));
    var seasonRow = el("div", "peek-coords");
    var mkMonth = function (val) {
      var sel = el("select", "form-input peek-coord");
      sel.appendChild(el("option", null, "—"));
      MONTHS.forEach(function (m, i) {
        var o = el("option", null, m); o.value = String(i + 1);
        sel.appendChild(o);
      });
      sel.value = val != null && val !== "" ? String(val) : "";
      return sel;
    };
    var sFrom = mkMonth(item.season_from), sTo = mkMonth(item.season_to);
    seasonRow.appendChild(sFrom); seasonRow.appendChild(sTo);
    wrap.appendChild(seasonRow);
    wrap.appendChild(el("div", "form-hint",
      "December to March is a season that wraps the year — that works."));

    // Which airport to fly into. Filled in automatically from the coordinates
    // against a real airport dataset -- clearing it fills it in again, and
    // typing a different code overrides it for good.
    // Within a drive of home there is nothing to fly into, so the whole
    // block goes rather than sitting there empty inviting an answer.
    var driveOnly = (function () {
      if (item.latitude == null || item.longitude == null) return false;
      var d = km(HOME.lat, HOME.lng, item.latitude, item.longitude);
      return d != null && d <= DRIVE_MAX_KM;
    })();
    if (driveOnly) {
      wrap.appendChild(el("div", "form-hint",
        Math.round(km(HOME.lat, HOME.lng, item.latitude, item.longitude) * 0.621371)
          .toLocaleString() + " miles from home — near enough to drive, so no airport or flights."));
    }
    if (!driveOnly) wrap.appendChild(el("label", "peek-label", "Fly into"));
    var apIn = el("input", "form-input");
    var apLoaded = item.airport || "";
    apIn.value = apLoaded;
    apIn.placeholder = "Airport code — filled in from the location";
    apIn.maxLength = 4;
    if (!driveOnly) wrap.appendChild(apIn);

    // Some ideas have no address YET -- a rafting trip nobody has booked, a
    // place recommended by name. Ticking this says so, and the location prompt
    // stops counting it. Exactly the "No location" tick the itinerary already
    // has, and for the same reason: a prompt that cannot be satisfied is a
    // prompt you learn to ignore, which costs you the ones that CAN be.
    var noLoc = el("label", "idea-noloc");
    var noLocBox = el("input", null);
    noLocBox.type = "checkbox"; noLocBox.checked = !!item.no_location;
    noLoc.appendChild(noLocBox);
    noLoc.appendChild(el("span", null, "No address yet — stop asking"));
    wrap.appendChild(noLoc);

    var apNote = el("div", "form-hint",
      item.airport
        ? (item.airport_auto === false
            ? "You chose this one. Clear the box to go back to the nearest airport."
            : "Filled in from the location. Type another code to fly in somewhere else.")
        : "Fills in from the location once this idea has one.");
    if (!driveOnly) wrap.appendChild(apNote);

    // The neighbours, so an override is a click rather than a memory test.
    // Straight-line distance does not know about mountains -- Zermatt's nearest
    // airport is across the Alps -- which is exactly why the alternatives are
    // shown rather than the best one being presented as the only answer.
    var apAlts = el("div", "ap-alts");
    if (!driveOnly) wrap.appendChild(apAlts);
    if (!driveOnly && item.latitude != null && item.longitude != null) {
      // Two sources, and they answer different questions. The endpoint knows
      // what is NEAR; airports() knows where you have actually flown, which is
      // your own trip history and therefore the only thing here that cannot be
      // stale or wrong. It is cached, so this costs one request the first time
      // and nothing after.
      Promise.all([
        api("/v1/nearest-airport?lat=" + item.latitude + "&lon=" + item.longitude),
        airports().catch(function () { return []; }),
      ])
        .then(function (both) {
          var d = both[0], flown = both[1] || [];
          if (!d || !d.results || !d.results.length || !document.body.contains(apAlts)) return;
          var legsOf = {};
          flown.forEach(function (f) { if (f && f.code) legsOf[f.code] = f.legs || 0; });
          apAlts.appendChild(el("span", "ap-alts-label", "Nearby:"));
          d.results.forEach(function (a) {
            var b = el("button", "chip ap-alt", a.code + " · " + a.km + " km");
            b.type = "button";
            // Only two tiers exist in the dataset by construction: it holds
            // large_airport and corroborated medium_airport and nothing else,
            // so every airport here is one or the other. Saying which, for both,
            // beats labelling one and leaving the other to be inferred from
            // silence.
            var bits = [a.city + (a.country ? ", " + a.country : "")];
            bits.push(a.large ? "major airport" : "regional airport");
            var n = legsOf[a.code];
            if (n) bits.push("you have flown here " + n + "×");
            b.title = bits.join(" — ");
            if (a.code === apIn.value.trim().toUpperCase()) b.classList.add("is-on");
            b.addEventListener("click", function () {
              apIn.value = a.code;
              [].forEach.call(apAlts.querySelectorAll(".ap-alt"), function (x) { x.classList.remove("is-on"); });
              b.classList.add("is-on");
            });
            apAlts.appendChild(b);
          });
        })
        .catch(function () { /* the field still works typed by hand */ });
    }

    wrap.appendChild(el("label", "peek-label", "Links"));
    var linksBox = el("div", "peek-links");
    wrap.appendChild(linksBox);
    var rows = [];

    function addLinkRow(L) {
      var r = el("div", "peek-linkrow");
      var lab = el("input", "form-input peek-linklabel");
      lab.value = (L && L.title) || "";
      lab.placeholder = "Label";
      var u = el("input", "form-input peek-linkurl");
      u.value = (L && L.url) || "";
      u.placeholder = "https://…";
      // A live anchor rather than a button: the point of the link is that you
      // can check it goes where you think before saving, and after editing it.
      var go = el("a", "peek-go", "↗");
      go.target = "_blank"; go.rel = "noopener"; go.title = "Open this page";
      var sync = function () {
        var v = u.value.trim();
        if (v && !/^https?:\/\//i.test(v)) v = "https://" + v;
        go.href = v || "#";
        go.classList.toggle("is-off", !v);
      };
      u.addEventListener("input", sync); sync();
      var x = el("button", "bucket-linkx", "✕"); x.type = "button";
      x.title = "Remove this link";
      x.addEventListener("click", function () {
        r.remove();
        rows = rows.filter(function (o) { return o.row !== r; });
      });
      r.appendChild(lab); r.appendChild(u); r.appendChild(go); r.appendChild(x);
      linksBox.appendChild(r);
      rows.push({ row: r, lab: lab, url: u });
      return u;
    }
    (Array.isArray(item.links) ? item.links : []).forEach(addLinkRow);

    var more = el("button", "bucket-addlink peek-more", "＋ Another link"); more.type = "button";
    more.addEventListener("click", function () { addLinkRow(null).focus(); });
    wrap.appendChild(more);
    panel.appendChild(wrap);

    return {
      focus: function () { nameIn.focus(); nameIn.select(); },
      read: function () {
        var place = nameIn.value.trim();
        if (!place) { toast("Give it a name first."); nameIn.focus(); return null; }
        var links = [], bad = null;
        rows.forEach(function (o) {
          // An emptied address means the link was removed, which is the same
          // gesture as clearing any other field and needs no separate button.
          var raw = o.url.value.trim();
          if (!raw) return;
          var u = /^https?:\/\//i.test(raw) ? raw : "https://" + raw;
          var ok = false;
          try { ok = !!new URL(u).hostname; } catch (e) { ok = false; }
          if (!ok) { if (!bad) bad = raw; return; }
          links.push({ url: u, title: o.lab.value.trim() || prettyHost(u) });
        });
        if (bad) { toast("“" + bad + "” is not a web address."); return null; }
        // A window that is not a year, a month or a day is a typo, and a typo
        // here silently disables the season check rather than failing loudly.
        var win = null, targets = {};
        [[tFrom, "when you'd go", "target_from"], [tTo, "the end of the window", "target_to"]]
          .forEach(function (pair) {
            if (win) return;
            var got = normalizeTarget(pair[0].value);
            if (!("value" in got)) {
              win = pair[1] + ": " + (got.error ||
                "write it as 10/15/27, 10/2027, 2027-09-14 or just 2027");
              return;
            }
            targets[pair[2]] = got.value;
            // Show what was stored, so the normalisation is visible rather than
            // something that silently happened to the box you just typed in.
            if (got.value) pair[0].value = got.value;
          });
        if (win) { toast(win); return null; }
        var nightsRaw = nightsIn.value.trim();
        var nights = nightsRaw === "" ? null : Number(nightsRaw);
        if (nights != null && (!isFinite(nights) || nights < 1 || nights > 365)) {
          toast("Nights has to be a number between 1 and 365."); return null;
        }
        var ap = apIn.value.trim().toUpperCase();
        if (ap && !/^[A-Z]{3}$/.test(ap)) {
          toast("An airport code is three letters, like OGG."); return null;
        }
        // Sent ONLY when it changed. Sending the auto-filled code back unchanged
        // would tell the server a person had chosen it, freezing a value nobody
        // picked and stopping it following the location ever again.
        var apChanged = ap !== apLoaded.trim().toUpperCase();
        var seasonA = sFrom.value ? Number(sFrom.value) : null;
        var seasonB = sTo.value ? Number(sTo.value) : null;
        if ((seasonA && !seasonB) || (seasonB && !seasonA)) {
          toast("A season needs both months, or neither."); return null;
        }
        return {
          place: place, note: noteIn.value.trim(), links: links,
          address: addrIn.value.trim() || null,
          no_location: !!noLocBox.checked,
          nights: nights,
          target_from: targets.target_from || null,
          target_to: targets.target_to || null,
          season_from: seasonA, season_to: seasonB,
          // Both or neither, the same rule every booking form uses: half a
          // coordinate puts a pin in the sea.
          ...coordPair(latIn.value, lonIn.value),
          ...(apChanged ? { airport: ap || null } : {}),
        };
      },
    };
  }

  // What counts as a date in the "when you'd go" boxes.
  //
  // It used to be ISO only -- 2027, 2027-09, 2027-09-14 -- and everything else
  // was refused. Typing 10/15/27, which is how a date is written on every US
  // form and how this app DISPLAYS dates, produced "write a year, 2027-09, or
  // 2027-09-14" and no saved trip. The box was stricter than the person using
  // it, which is the wrong way round.
  //
  // Accepted now, all normalised to ISO so everything downstream still parses
  // one shape:
  //     2027           a whole year
  //     2027-09        a month
  //     2027-09-14     a day
  //     10/15/27       US order, two-digit year
  //     10/15/2027     US order, four-digit year
  //     10/2027        a month, written the American way round
  // Separators may be / or -. A two-digit year is 2000+yy without a pivot:
  // these are trips being planned, so 27 is 2027 and can never be 1927.
  function normalizeTarget(raw) {
    var v = String(raw == null ? "" : raw).trim();
    if (!v) return { value: null };
    v = v.replace(/\s+/g, "");

    // Already ISO, in one of its three lengths.
    var iso = /^(\d{4})(?:-(\d{2})(?:-(\d{2}))?)?$/.exec(v);
    if (iso) {
      var y = Number(iso[1]), mo = iso[2] ? Number(iso[2]) : null, da = iso[3] ? Number(iso[3]) : null;
      if (mo != null && (mo < 1 || mo > 12)) return { error: "there is no month " + iso[2] };
      if (da != null && !realDate(y, mo, da)) return { error: v + " is not a real date" };
      return { value: v };
    }

    var parts = v.split(/[\/\-.]/);
    var pad = function (n) { return (n < 10 ? "0" : "") + n; };
    var year = function (t) { return t.length === 2 ? 2000 + Number(t) : Number(t); };

    // 10/2027 or 10/27 -- month and year, no day.
    if (parts.length === 2 && /^\d{1,2}$/.test(parts[0]) && /^(\d{2}|\d{4})$/.test(parts[1])) {
      var m2 = Number(parts[0]), y2 = year(parts[1]);
      if (m2 < 1 || m2 > 12) return { error: "there is no month " + parts[0] };
      return { value: y2 + "-" + pad(m2) };
    }

    // 10/15/27 or 10/15/2027 -- the ordinary US order.
    if (parts.length === 3 && parts.every(function (x) { return /^\d{1,4}$/.test(x); })) {
      var m3 = Number(parts[0]), d3 = Number(parts[1]), y3 = year(parts[2]);
      if (m3 < 1 || m3 > 12) return { error: "there is no month " + parts[0] };
      if (!realDate(y3, m3, d3)) {
        return { error: v + " is not a real date" };
      }
      return { value: y3 + "-" + pad(m3) + "-" + pad(d3) };
    }

    return { error: null };   // unrecognised: the caller gives the general hint
  }

  // Rejects 2027-02-30 and 2027-11-31, which pass a range check and are still
  // not days. Date rolls them into the next month, so a round trip catches it.
  function realDate(y, m, d) {
    if (!(y >= 1000 && y <= 9999) || m < 1 || m > 12 || d < 1 || d > 31) return false;
    var dt = new Date(Date.UTC(y, m - 1, d));
    return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
  }

  // Reading the form can throw, and for a long time that was invisible.
  //
  // Both Save buttons called f.read() OUTSIDE their try, in an async handler.
  // Anything it threw rejected that handler and vanished -- no request, no
  // message, not even a console entry, because an unhandled rejection in a
  // listener is not reported anywhere a person would look. The button did
  // nothing at all, which is the one failure a user cannot describe and I
  // cannot debug. Reported on 2026-08-23 as "trouble saving edits".
  //
  // read() still returns null for the ordinary refusals -- an empty name, half
  // a season, a malformed airport code -- and each of those toasts its own
  // reason first. This only catches the unplanned kind, and makes it say so.
  function readForm(f, ok) {
    try { return { value: f.read() }; }
    catch (e) {
      console.error("[form] read failed:", e);
      // coordPair throws ApiError with a sentence already written for the
      // person reading it -- "Give both a latitude and a longitude, or leave
      // both blank." Wrapping that in "Couldn't read the form:" would bury the
      // instruction. Anything else is a real fault and says so.
      var msg = (e && e.message) ? e.message : String(e);
      toast(e instanceof ApiError ? msg : "Couldn't read the form: " + msg);
      if (ok) ok.disabled = false;
      return null;
    }
  }

  // Everything about one entry, after it exists. Reached by clicking the name,
  // the note, or the Edit chip — three ways into one place, rather than a
  // different prompt per field and no way at all to reach the link.
  function openBucketEdit(item, onSave) {
    var o = overlay();
    var back = o.back, panel = o.panel;

    // U14's rule, in the one dialog U14 did not reach: a bare "Edit" is true of
    // every idea on the list and names none of them.
    panel.appendChild(el("h3", "form-title",
      item && item.place ? "Edit “" + clipName(item.place, 40) + "”" : "Edit idea"));
    panel.appendChild(el("div", "place-hint",
      "Clearing a link's address removes it. Nothing is saved until you press Save."));
    var f = bucketFields(panel, item);

    var btns = el("div", "form-btns");
    var cancel = el("button", "mini-btn", "Cancel"); cancel.type = "button";
    cancel.addEventListener("click", function () { back.remove(); });
    var ok = el("button", "primary-btn small", "Save"); ok.type = "button";
    ok.addEventListener("click", async function () {
      var got = readForm(f, ok); if (!got) return;
      var v = got.value; if (!v) return;
      ok.disabled = true;
      try {
        // Spread over the original so `added` and anything a later version puts
        // on an entry survive an edit made by a form that never knew about it.
        await onSave(Object.assign({}, item, v));
        back.remove();
        toast("Saved");
      } catch (e) { toast("Couldn't save: " + e.message); ok.disabled = false; }
    });
    btns.appendChild(cancel); btns.appendChild(ok);
    panel.appendChild(btns);
    f.focus();
  }

  // ---- paste a page, get a bucket-list entry ----
  //
  // Opens straight into reading the address rather than asking whether to,
  // because the answer to "shall I read the page you just pasted?" is always
  // yes. What comes back is shown as ordinary editable fields: the server is
  // guessing which part of a page title is the hotel and which is the marketing,
  // and it will sometimes be wrong. A wrong guess should cost a keystroke, not
  // a retype, so nothing is written until Add is pressed.
  function openBucketLink(rawUrl, existing, onSave) {
    var url = /^https?:\/\//i.test(rawUrl) ? rawUrl : "https://" + rawUrl;
    var o = overlay();
    var back = o.back, panel = o.panel;

    function shut() { back.remove(); }
    function closeBtns(label) {
      var btns = el("div", "form-btns");
      var b = el("button", "primary-btn small", label || "OK"); b.type = "button";
      b.addEventListener("click", shut);
      btns.appendChild(b);
      return btns;
    }

    // Already saved? Say so before spending a fetch and a dialog on it. Matching
    // on the link rather than the name catches the same hotel pasted twice under
    // two different titles, which is the case that actually happens.
    var already = (existing || []).filter(function (it) {
      return (Array.isArray(it.links) ? it.links : []).some(function (L) {
        return L && String(L.url || "").replace(/\/+$/, "") === url.replace(/\/+$/, "");
      });
    })[0];
    if (already) {
      panel.appendChild(el("h3", "form-title", "Already on the list"));
      panel.appendChild(el("div", "place-hint", "“" + already.place + "” already links to that page."));
      panel.appendChild(closeBtns());
      return;
    }

    panel.appendChild(el("h3", "form-title", "Add from a link"));
    panel.appendChild(el("div", "place-hint", "Reading " + prettyHost(url) + "…"));

    function form(info, trouble) {
      panel.innerHTML = "";
      panel.appendChild(el("h3", "form-title", "Add from a link"));
      panel.appendChild(el("div", "place-hint",
        trouble ? trouble + " You can still save it — fill in whatever you know."
        : info.thin ? "That page says little about itself, so this is mostly its title. Edit anything that is wrong."
        : info.geo_source === "page"
          ? "Taken from the page, including its coordinates — the property published them itself, so the pin is exact. Edit anything that is wrong."
        : info.address
          ? "Taken from the page, with its address. The pin fills in when you press 🔎 Find, or from the Trip Ideas list later."
        : "Taken from the page. Edit anything that is wrong — nothing is saved until you press Add."));

      var f = bucketFields(panel, {
        place: info.place || prettyHost(url),
        note: info.note || "",
        // Straight from the page's own structured data. Coordinates published
        // by the property beat any geocoder, because it is the place saying
        // where it is rather than a third party guessing from its name.
        address: info.address || "",
        latitude: info.latitude != null ? info.latitude : null,
        longitude: info.longitude != null ? info.longitude : null,
        links: [{ url: info.url || url, title: linkLabel(info, info.url || url) }],
      });

      var btns = el("div", "form-btns");
      var cancel = el("button", "mini-btn", "Cancel"); cancel.type = "button";
      cancel.addEventListener("click", shut);
      var ok = el("button", "primary-btn small", "Add to list"); ok.type = "button";
      ok.addEventListener("click", async function () {
        var got = readForm(f, ok); if (!got) return;
        var v = got.value; if (!v) return;
        ok.disabled = true;
        try {
          await onSave(Object.assign({ added: new Date().toISOString() }, v));
          shut();
          toast("Added “" + v.place + "”");
        } catch (e) { toast("Couldn't save: " + e.message); ok.disabled = false; }
      });
      btns.appendChild(cancel); btns.appendChild(ok);
      panel.appendChild(btns);
      f.focus();
    }

    api("/v1/linkpeek", { method: "POST", body: JSON.stringify({ url: url }) })
      .then(function (info) { form(info || {}, null); })
      // A page that will not be read is not a reason to lose the address. Fall
      // through to the same form with the fields empty.
      .catch(function (e) { form({ url: url }, "Couldn't read that page: " + e.message); });
  }

  // ---- manage who is on this trip ----
  // Everything about a trip's party in one dialog: tick people on and off, rename
  // one, add somebody who is not on the roster yet, and take the suggestions the
  // bookings imply. The roster can run to dozens, so the people already coming
  // sort to the top and a filter appears once the list is long enough to scroll.
  function openTripTravellers(trip, data, onSaved) {
    var o = overlay("sheet");
    var back = o.back, panel = o.panel;

    var ids = Array.isArray(trip.travellers) ? trip.travellers.slice() : [];
    var filter = "";

    var saveTrip = async function (next) {
      await replaceValue("/v1/trip/" + trip.id, "travellers", next,
        Array.isArray(trip.travellers) ? trip.travellers : []);
      ids = next; trip.travellers = next;
      onSaved();
    };
    var saveRoster = async function (arr) {
      await replaceValue("/v1/me", "travellers", arr,
        (state.me && Array.isArray(state.me.travellers)) ? state.me.travellers : []);
      if (state.me) state.me.travellers = arr;
    };

    function paint() {
      panel.innerHTML = "";
      panel.appendChild(el("h3", "form-title", "Travellers on this trip"));
      var all = travellers();

      var found = detectTravellers(trip, data).filter(function (id) { return ids.indexOf(id) < 0; });
      if (found.length) {
        var sug = el("div", "pax-suggest");
        sug.appendChild(el("span", "pax-suggest-text",
          "On the bookings but not marked: " + found.map(travellerName).join(", ")));
        var addAll = el("button", "mini-btn is-edit",
          found.length === 1 ? "＋ Add" : "＋ Add all " + found.length);
        addAll.type = "button";
        addAll.addEventListener("click", async function () {
          addAll.disabled = true;
          try { await saveTrip(ids.concat(found)); paint(); }
          catch (e) { toast("Couldn't save: " + e.message); addAll.disabled = false; }
        });
        sug.appendChild(addAll);
        panel.appendChild(sug);
      }

      // The filter earns its place only once the list is too long to scan.
      if (all.length > 8) {
        var fw = el("div", "form-field");
        var fi = el("input", "form-input");
        fi.placeholder = "Filter by name"; fi.value = filter;
        fi.addEventListener("input", function () { filter = fi.value; paint();
          var again = panel.querySelector(".form-input"); if (again) { again.focus(); again.setSelectionRange(filter.length, filter.length); } });
        fw.appendChild(fi); panel.appendChild(fw);
      }

      // On the trip first, so the answer to "who is coming" is always at the top.
      var q = filter.trim().toLowerCase();
      var shown = all.filter(function (p) { return !q || p.name.toLowerCase().indexOf(q) >= 0; });
      shown.sort(function (a, b) {
        var ao = ids.indexOf(a.id) >= 0 ? 0 : 1, bo = ids.indexOf(b.id) >= 0 ? 0 : 1;
        return ao - bo || all.indexOf(a) - all.indexOf(b);
      });

      var list = el("div", "sheet-list pax-list");
      if (!all.length) list.appendChild(el("div", "doc-empty", "No travellers yet. Add the first one below."));
      else if (!shown.length) list.appendChild(el("div", "doc-empty", "Nobody matches “" + filter + "”."));
      shown.forEach(function (person) {
        var on = ids.indexOf(person.id) >= 0;
        var row = el("div", "seat-row");
        var pick = el("button", "room-pick" + (on ? " on" : "")); pick.type = "button";
        pick.appendChild(el("span", "room-tick", on ? "✓" : "○"));
        pick.appendChild(el("span", "seat-who", person.name));
        pick.addEventListener("click", async function () {
          pick.disabled = true;
          try {
            await saveTrip(on ? ids.filter(function (x) { return x !== person.id; }) : ids.concat([person.id]));
            paint();
          } catch (e) { toast("Couldn't save: " + e.message); pick.disabled = false; }
        });
        row.appendChild(pick);
        var ren = el("button", "mini-btn is-edit", "✎"); ren.type = "button";
        ren.title = "Rename " + person.name;
        ren.addEventListener("click", async function () {
          var nm = prompt("Rename traveller", person.name);
          if (nm === null) return;
          nm = nm.trim();
          if (!nm || nm === person.name) return;
          // The id never changes, so every seat and room already assigned to
          // this person follows the rename rather than being orphaned.
          var arr = travellers().map(function (x) {
            return x.id === person.id ? { id: x.id, name: nm } : x;
          });
          try { await saveRoster(arr); onSaved(); paint(); toast("Renamed"); }
          catch (e) { toast("Couldn't save: " + e.message); }
        });
        row.appendChild(ren);
        list.appendChild(row);
      });
      panel.appendChild(list);

      // Somebody new, added to the roster and to this trip in one go — which is
      // the only reason you would be adding them from here.
      var addRow = el("div", "doc-add");
      var nameIn = el("input", "form-input"); nameIn.placeholder = "Add someone new";
      var addBtn = el("button", "mini-btn is-edit", "＋ Add"); addBtn.type = "button";
      var doAdd = async function () {
        var nm = nameIn.value.trim();
        if (!nm) return;
        var arr = travellers().slice();
        var existing = arr.filter(function (x) { return x.name.toLowerCase() === nm.toLowerCase(); })[0];
        addBtn.disabled = true;
        try {
          var id;
          if (existing) { id = existing.id; }
          else { id = newTravellerId(nm, arr); arr.push({ id: id, name: nm }); await saveRoster(arr); }
          if (ids.indexOf(id) < 0) await saveTrip(ids.concat([id]));
          nameIn.value = ""; filter = ""; paint();
          toast(existing ? nm + " added to this trip" : nm + " added");
        } catch (e) { toast("Couldn't save: " + e.message); }
        finally { addBtn.disabled = false; }
      };
      addBtn.addEventListener("click", doAdd);
      nameIn.addEventListener("keydown", function (ev) { if (ev.key === "Enter") { ev.preventDefault(); doAdd(); } });
      addRow.appendChild(nameIn); addRow.appendChild(addBtn);
      panel.appendChild(addRow);

      panel.appendChild(el("div", "place-hint",
        "Removing somebody here takes them off this trip only. To delete them from your travellers altogether, use Settings."));

      var btns = el("div", "form-btns");
      var done = el("button", "primary-btn small", "Done"); done.type = "button";
      done.addEventListener("click", function () { back.remove(); });
      btns.appendChild(done); panel.appendChild(btns);
    }
    paint();
  }

  // ---- map ----
  // Where the trip IS, as opposed to where it starts.
  //
  // geoPoints lists transports first, so its first entry is the DEPARTURE point
  // -- home, or the airport you left from. Anything anchored on it describes the
  // place you are leaving. That is how the weather line came to report Los
  // Angeles for a trip to Spain: the Camino's first coordinate is LAX.
  //
  // Lodging first, because where you sleep is where you are. Then an activity,
  // then a transport ARRIVAL, and only then a departure -- by which point the
  // trip has no destination recorded anywhere and the departure is the only
  // coordinate there is.
  //
  // One anchor per trip is a simplification, and it shows on a trip that
  // crosses a border. Everything built on it -- weather, typical weather,
  // public holidays, the practicalities line -- is a heads-up rather than an
  // authority, and the wording says so.
  function destPoint(data) {
    // Undated rows sort under a HIGH sentinel, not an empty string. "" compares
    // before every real date, so one lodging saved without a check-in date
    // outranked every dated stay and became "the destination".
    var dated = function (v) { return String(v || "9999-99-99"); };
    var host = (data.hostings || []).filter(function (h) { return h.latitude != null; })
      .sort(function (a, b) { return dated(a.starts_at).localeCompare(dated(b.starts_at)); });
    if (host.length) return { lat: host[0].latitude, lng: host[0].longitude };

    var act = (data.activities || []).filter(function (a) { return a.latitude != null; })
      .sort(function (a, b) { return dated(a.starts_at).localeCompare(dated(b.starts_at)); });
    if (act.length) return { lat: act[0].latitude, lng: act[0].longitude };

    var arr = (data.transports || []).filter(function (tr) { return tr.arrival_latitude != null; })
      .sort(function (a, b) { return dated(a.arrival_at).localeCompare(dated(b.arrival_at)); });
    // A LAYOVER is an arrival you leave again from within a day: some other leg
    // departs from (about) the same coordinates shortly after you land. On
    // LAX -> JFK -> MAD the earliest arrival is JFK, and anchoring there put
    // the whole trip's weather in the wrong hemisphere. Round trips are safe
    // either way: the return departs days later, so the real destination
    // survives this filter and remains the earliest.
    var isLayover = function (a) {
      if (!a.arrival_at) return false;
      var t0 = Date.parse(a.arrival_at);
      return (data.transports || []).some(function (o) {
        if (o === a || o.departure_latitude == null || !o.departure_at) return false;
        var dt = Date.parse(o.departure_at) - t0;
        return dt > 0 && dt < 86400000 &&
          Math.abs(o.departure_latitude - a.arrival_latitude) < 0.1 &&
          Math.abs(o.departure_longitude - a.arrival_longitude) < 0.1;
      });
    };
    var real = arr.filter(function (a) { return !isLayover(a); });
    if (real.length) return { lat: real[0].arrival_latitude, lng: real[0].arrival_longitude };
    if (arr.length) return { lat: arr[0].arrival_latitude, lng: arr[0].arrival_longitude };

    var any = geoPoints(data)[0];
    return any ? { lat: any.lat, lng: any.lng } : null;
  }

  function geoPoints(data) {
    var pts = [];
    (data.transports || []).forEach(function (tr) {
      if (tr.departure_latitude != null) pts.push({ lat: tr.departure_latitude, lng: tr.departure_longitude, icon: transIcon(tr.transportation_type), label: (tr.departure_description || "Departure"), when: tr.departure_at });
      if (tr.arrival_latitude != null) pts.push({ lat: tr.arrival_latitude, lng: tr.arrival_longitude, icon: transIcon(tr.transportation_type), label: (tr.arrival_description || "Arrival"), when: tr.arrival_at });
    });
    (data.hostings || []).forEach(function (h) { if (h.latitude != null) pts.push({ lat: h.latitude, lng: h.longitude, icon: "🏨", label: h.name || "Lodging", when: h.starts_at }); });
    (data.activities || []).forEach(function (a) { if (a.latitude != null) pts.push({ lat: a.latitude, lng: a.longitude, icon: actIcon(a), label: a.name || "Activity", when: a.starts_at }); });
    return pts;
  }
  // ---- driving trips ----
  //
  // A trip with no flights inside California, Pinecrest or Las Vegas is one we
  // drove to, so the map should show the road from home rather than a lone pin
  // at the far end.
  //
  // The list is exactly those three: no other destination qualifies, by
  // instruction. Fifteen years of history happens to agree — every flightless
  // trip on record lands in California, Pinecrest, or Las Vegas — but the rule is
  // the rule, not the inference. A flightless trip anywhere else gets the
  // ordinary map.
  // The actual front door, geocoded to a house match rather than the middle of
  // the city — a mile and a half of error is the difference between a useful
  // drive time and a decorative one. Private repo; see the note in README.
  // CONFIGURE ME. Your home, geocoded to the building rather than the city
  // centre -- a mile of error is the difference between a useful drive time
  // and a decorative one. Right-click a point in Google Maps to copy exact
  // coordinates. Until you change this, drive times are measured from a
  // placeholder at Los Angeles City Hall, a public building. The shipped
  // test suite asserts drive-distance relationships that hold from there
  // (see SETUP.md) -- change this first, then those fixtures.
  var HOME = { lat: 34.0537, lng: -118.2427, label: "Home" };

  // California, traced coarsely. A bounding box will not do: the box that holds
  // California also holds Reno and Carson City, which are neither California nor
  // a drive we make. The eastern edge here follows the real border — straight
  // down the 120th meridian, then the diagonal to the Colorado — so Nevada falls
  // outside it. The western edge is deliberately slack; it runs offshore, where
  // being generous costs nothing because there is nothing there to match.
  var CA_POLY = [
    [-124.60, 42.00], [-120.00, 42.00],  // Oregon border
    [-120.00, 39.00],                     // straight down the Nevada line
    [-114.63, 35.00], [-114.13, 34.30],  // the diagonal, then the Colorado River
    [-114.72, 32.71], [-117.30, 32.50],  // Mexico border, west to the Pacific
    [-118.60, 33.60], [-120.70, 34.30],  // up the coast, held offshore
    [-122.10, 36.50], [-122.70, 37.80],
    [-124.00, 38.90],
  ];
  function inPoly(lat, lon, poly) {
    // Ray casting. A point is inside when a ray drawn east of it crosses the
    // outline an odd number of times.
    var inside = false;
    for (var i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      var xi = poly[i][0], yi = poly[i][1], xj = poly[j][0], yj = poly[j][1];
      if ((yi > lat) !== (yj > lat) && lon < ((xj - xi) * (lat - yi)) / (yj - yi) + xi) inside = !inside;
    }
    return inside;
  }
  function inBox(lat, lon, b) { return lat >= b[0] && lat <= b[1] && lon >= b[2] && lon <= b[3]; }
  // CONFIGURE ME (optional). Extra boxes counting as drivable, beyond the
  // state outline above: [minLat, maxLat, minLon, maxLon]. A trip whose
  // every point falls in a drivable region gets the road drawn from home
  // instead of a lone pin. Empty boxes simply never match.
  var SECOND_REGION = [0, 0, 0, 0];
  var LAS_VEGAS = [0, 0, 0, 0];
  function inDrivingRange(lat, lon) {
    return inPoly(lat, lon, CA_POLY) || inBox(lat, lon, SECOND_REGION) || inBox(lat, lon, LAS_VEGAS);
  }
  // Modes that mean somebody else did the driving. A rental car or a taxi on the
  // trip proves nothing either way, so those do not disqualify it.
  var NOT_DRIVEN = { airplane: 1, train: 1, ferry: 1, boat: 1, bus: 1 };
  function drivingRoute(data) {
    var trans = data.transports || [];
    for (var i = 0; i < trans.length; i++) if (NOT_DRIVEN[trans[i].transportation_type]) return null;
    var pts = geoPoints(data);
    if (!pts.length) return null;
    for (var k = 0; k < pts.length; k++) if (!inDrivingRange(+pts[k].lat, +pts[k].lng)) return null;
    // Where we were going: the first lodging booked, or failing that the point
    // furthest from home — on a there-and-back drive that is the destination.
    var dest;
    var beds = (data.hostings || []).filter(function (h) { return h.latitude != null; })
      .sort(function (a, b) { return String(a.starts_at || "").localeCompare(String(b.starts_at || "")); });
    if (beds.length) {
      dest = { lat: +beds[0].latitude, lng: +beds[0].longitude, label: beds[0].name || "Destination" };
    } else {
      var far = null, best = -1;
      pts.forEach(function (p) {
        var d = milesFromHome(+p.lat, +p.lng);
        if (d > best) { best = d; far = p; }
      });
      dest = { lat: +far.lat, lng: +far.lng, label: far.label };
    }
    // A hotel down the road is a staycation, not a drive. Five trips on record
    // are your home city itself, and drawing a two-mile route across them tells
    // you nothing you did not already know.
    return milesFromHome(dest.lat, dest.lng) >= 10 ? dest : null;
  }
  function milesFromHome(lat, lng) {
    // Equirectangular is plenty at this range and avoids a haversine for what is
    // only ever a near-or-far question.
    var y = (lat - HOME.lat) * 69.1;
    var x = (lng - HOME.lng) * 69.1 * Math.cos((HOME.lat * Math.PI) / 180);
    return Math.sqrt(x * x + y * y);
  }
  async function drawDriving(dest, dark, refit) {
    var line = null, note = "";
    try {
      var r = await ext("route?from=" + HOME.lat + "," + HOME.lng + "&to=" + dest.lat + "," + dest.lng);
      if (r && r.line && r.line.length) {
        line = r.line;
        note = (r.distance_m / 1609.344).toFixed(0) + " mi · " +
          (r.duration_s >= 3600 ? Math.floor(r.duration_s / 3600) + "h " + Math.round((r.duration_s % 3600) / 60) + "m"
                                : Math.round(r.duration_s / 60) + "m") + " drive";
      }
    } catch (e) { /* fall through to the straight line */ }
    // The panel may have closed while the route was being fetched.
    if (!leafletMap && !googleMap) return null;
    // No router, no road — but still show that the trip started at home.
    if (!line) { line = [[HOME.lat, HOME.lng], [dest.lat, dest.lng]]; note = "Driving from " + HOME.label; }
    if (googleMap && window.google && window.google.maps) {
      var g = window.google.maps;
      new g.Polyline({
        path: line.map(function (c) { return { lat: c[0], lng: c[1] }; }),
        map: googleMap, strokeColor: dark ? "#6ee7a8" : "#0f9d58",
        strokeWeight: 4, strokeOpacity: .75,
      });
      gmapPin(g, googleMap, HOME.lat, HOME.lng, "🏠", HOME.label, dark ? "#e8edf5" : "#ffffff");
      gmapFit(g, googleMap, (googleFitPts || []).concat(line, [[HOME.lat, HOME.lng]]));
      return note;
    }
    L.polyline(line, { color: dark ? "#6ee7a8" : "#0f9d58", weight: 4, opacity: .75 }).addTo(leafletMap);
    L.marker([HOME.lat, HOME.lng], {
      icon: L.divIcon({ className: "map-pin", html: "<span>🏠</span>", iconSize: [30, 30], iconAnchor: [15, 15] }),
    }).addTo(leafletMap).bindPopup(escapeHtml(HOME.label));
    refit(line.concat([[HOME.lat, HOME.lng]]));
    return note;
  }

  function renderMap(wrap, mapEl, data) {
    var pts0 = geoPoints(data); if (!pts0.length) return;
    if (mapsKey && !googleDead) {
      wrap.hidden = false;
      loadGoogleMaps().then(function (g) {
        if (!g) return withLeaflet(function () { renderMapLeaflet(wrap, mapEl, data); });
        var dark = isDarkTheme();
        try { if (leafletMap) { leafletMap.remove(); leafletMap = null; } } catch (e) {}
        googleMap = gmapNew(g, mapEl, dark);
        // If Google refuses after this point, this map is already on screen and
        // broken. Say how to rebuild it without Google. Replaces any previous
        // trip map rather than accumulating.
        mapRedraws.trip = function () { mapEl.innerHTML = ""; renderMap(wrap, mapEl, data); };
        var latlngs = [];
        pts0.forEach(function (p) {
          gmapPin(g, googleMap, p.lat, p.lng, p.icon, p.label, dark ? "#e8edf5" : "#ffffff");
          latlngs.push([p.lat, p.lng]);
        });
        var ordered = pts0.filter(function (p) { return p.when; })
          .sort(function (a, b) { return new Date(a.when) - new Date(b.when); })
          .map(function (p) { return { lat: p.lat, lng: p.lng }; });
        if (ordered.length > 1) {
          new g.Polyline({
            path: ordered, map: googleMap, strokeOpacity: 0,
            // strokeOpacity 0 plus a repeating dash is how Google draws a dashed
            // line; there is no dashArray.
            icons: [{ icon: { path: "M 0,-1 0,1", strokeOpacity: .6, strokeWeight: 2,
              strokeColor: dark ? "#5b8bff" : "#2f6df6", scale: 3 },
              offset: "0", repeat: "9px" }],
          });
        }
        gmapFit(g, googleMap, latlngs);
        // Google re-fits on its own when the container resizes, so the
        // three-pass Leaflet dance below is not needed here.
        googleFitPts = latlngs;

        // The road from home, same as the Leaflet path. Easy to leave out and
        // it would have silently dropped the drive line and the "3h 40m drive"
        // note from every road trip the moment the key was set.
        var dest = drivingRoute(data);
        if (dest) {
          // drawDriving re-fits the Google map itself, so the refit callback
          // here has nothing to do.
          drawDriving(dest, dark, function () {}).then(function (note) {
            if (!note || !wrap.isConnected) return;
            var n = wrap.querySelector(".map-note");
            if (!n) { n = el("div", "map-note"); wrap.appendChild(n); }
            n.textContent = "🚗 " + note + " from " + HOME.label;
          });
        }
      });
      return;
    }
    withLeaflet(function () { renderMapLeaflet(wrap, mapEl, data); });
  }

  function renderMapLeaflet(wrap, mapEl, data) {
    if (!window.L) return;
    var pts = geoPoints(data); if (!pts.length) return;
    wrap.hidden = false;
    try { if (leafletMap) { leafletMap.remove(); leafletMap = null; } } catch (e) {}
    googleMap = null; googleFitPts = null;
    var dark = isDarkTheme();
    leafletMap = L.map(mapEl, { scrollWheelZoom: false, attributionControl: false });
    var url = dark ? "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png" : "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png";
    L.tileLayer(url, { maxZoom: 19 }).addTo(leafletMap);
    var latlngs = [];
    pts.forEach(function (p) {
      var m = L.marker([p.lat, p.lng], { icon: L.divIcon({ className: "map-pin", html: '<span>' + p.icon + '</span>', iconSize: [30, 30], iconAnchor: [15, 15] }) });
      m.addTo(leafletMap).bindPopup(escapeHtml(p.label));
      latlngs.push([p.lat, p.lng]);
    });
    var ordered = pts.filter(function (p) { return p.when; }).sort(function (a, b) { return new Date(a.when) - new Date(b.when); }).map(function (p) { return [p.lat, p.lng]; });
    if (ordered.length > 1) L.polyline(ordered, { color: dark ? "#5b8bff" : "#2f6df6", weight: 2, opacity: .6, dashArray: "4 5" }).addTo(leafletMap);

    // Fit AFTER the container has a size, and fit again whenever it changes.
    //
    // The panel is still being assembled when this runs, so the map element is
    // effectively 0x0 and Leaflet computes the zoom for a viewport that does not
    // exist yet. invalidateSize() later corrected the size but never re-fitted,
    // which left Costa Rica — LAX to Liberia to San José — zoomed so far in that
    // all ten pins sat off-screen, ±99,000 pixels from the middle. A map you must
    // zoom out of by hand every time to see where you went.
    var fit = function () {
      if (!leafletMap) return;
      try {
        leafletMap.invalidateSize({ animate: false });
        leafletMap.fitBounds(latlngs, { padding: [28, 28], maxZoom: 13, animate: false });
      } catch (e) {
        try { leafletMap.setView(latlngs[0], 11); } catch (e2) {}
      }
    };
    fit();
    // Once for the first layout pass, once after fonts and the side column have
    // settled. Cheap, and the alternative is a map that is right only sometimes.
    requestAnimationFrame(fit);
    setTimeout(fit, 250);
    // A width change — rotating the phone, or the settings that resize the
    // content column — re-fits rather than leaving the old zoom behind.
    if (window.ResizeObserver) {
      try {
        var ro = new ResizeObserver(function () { fit(); });
        ro.observe(mapEl);
        leafletMap.on("unload", function () { try { ro.disconnect(); } catch (e) {} });
      } catch (e) {}
    }

    // On a driving trip, lay the road from home over the top. This runs after
    // the map is already drawn and fitted, so a slow or dead router delays
    // nothing — the map is usable either way, and widens when the route lands.
    var dest = drivingRoute(data);
    if (dest) {
      drawDriving(dest, dark, function (extra) { latlngs = latlngs.concat(extra); fit(); }).then(function (note) {
        if (!note || !wrap.isConnected) return;
        var n = wrap.querySelector(".map-note");
        if (!n) { n = el("div", "map-note"); wrap.appendChild(n); }
        n.textContent = "🚗 " + note + " from " + HOME.label;
      });
    }
  }

  // ---- a check-in or check-out time you set yourself ----
  //
  // Hotel status buys early check-in and late check-out, and those are the times
  // that matter on the day. They are not what the confirmation says, and the
  // confirmation is what the importer trusts: it matches a stay by confirmation
  // number, compares field by field, and PATCHes anything that differs. So a
  // 4pm check-out typed in here survived exactly until the hotel re-sent its
  // standard 11am — at which point it was silently overwritten and logged as a
  // schedule change, as though the property had moved it.
  //
  // Locking is per field, not per booking. Locking both would also suppress a
  // genuine change to the OTHER end, which is a real thing that happens: a
  // property moves a check-in date while the late check-out stands.
  function lockedTimes(o) {
    var l = o && o.locked_times;
    return Array.isArray(l) ? l : [];
  }
  function isLocked(o, field) { return lockedTimes(o).indexOf(field) >= 0; }

  // ---- every future item has to say where it is ----
  //
  // An itinerary item with no address and no coordinates cannot be put on the
  // map, and — more to the point — breaks the chain of drives either side of
  // it, silently: a missing leg looks exactly like a short walk.
  //
  // An address OR coordinates satisfies this. They do different jobs — only
  // coordinates draw the pin and the route — but an address is a real answer
  // to "where is this", and one that can be geocoded later.
  //
  // `no_location` is the deliberate exemption. Plenty of an itinerary genuinely
  // has no place: "find a coffee place", a rest day, a call to make. Ticking
  // the box is you saying so, which is different from nobody having filled it
  // in, and the whole reason the check can be strict about the rest.
  function hasText(v) { return v != null && String(v).trim() !== ""; }

  function hasPlace(o, kind) {
    if (!o) return true;                                   // nothing to judge
    if (o.no_location) return true;                        // exempted on purpose
    // A note is a thought, not a place. Its form has no address or coordinate
    // fields at all, so flagging one would be a warning with no way to act on
    // it short of ticking a box on every note ever written.
    if (kind === "activity" && o.activity_type === "note") return true;
    if (kind === "transport") {
      // Both ends, because a leg is drawn between them and one located end
      // draws nothing. All thirteen upcoming transportations already have both.
      var from = hasText(o.departure_address) || o.departure_latitude != null;
      var to = hasText(o.arrival_address) || o.arrival_latitude != null;
      return from && to;
    }
    return hasText(o.address) || o.latitude != null;
  }

  // The same idea as locked_times, for things that are not times.
  //
  // Kept as a separate list rather than folded into locked_times because the
  // importer reads that one as "leave these instants alone" and an amount is
  // not an instant. An expense whose amount you have corrected -- a resort fee
  // the confirmation omitted, a split you settled differently -- must survive
  // the next time that booking is re-sent, or the correction lasts exactly
  // until the vendor emails again.
  function lockedFields(o) {
    var l = o && o.locked_fields;
    return Array.isArray(l) ? l : [];
  }
  function isFieldLocked(o, field) { return lockedFields(o).indexOf(field) >= 0; }
  // Two stored instants, compared as instants. The database holds what the
  // importer wrote, which carries milliseconds; the form round-trips through
  // fromLocalInput, which does not. They are the same moment and must compare
  // equal, or every save looks like an edit.
  function sameInstant(a, b) {
    if (!a && !b) return true;
    if (!a || !b) return false;
    var x = Date.parse(a), y = Date.parse(b);
    return isFinite(x) && isFinite(y) ? x === y : String(a) === String(b);
  }


  // ---- live flight status ----
  //
  // Written by the flight-status Worker into `live_status`, beside the booking
  // rather than over it: the ticket still says 13:00 and the aeroplane now
  // leaves at 14:20, and those are two different facts. The row keeps showing
  // the booked time; this says what is actually happening to it.
  //
  // Stale status is worse than none. A "on time" read six hours ago says
  // nothing about now, so anything older than the window in which it could
  // still be true is simply not shown.
  var STATUS_STALE_H = 3;

  function liveStatusOf(o) {
    var ls = o && o.live_status;
    if (!ls || typeof ls !== "object") return null;
    var t = Date.parse(ls.checked_at);
    if (!isFinite(t) || (Date.now() - t) / MS_H > STATUS_STALE_H) return null;
    return ls;
  }

  // The one-line verdict, or null when there is nothing worth saying. "On time"
  // is deliberately included: before a flight you want to know it was CHECKED,
  // and silence cannot distinguish "fine" from "we never asked".
  function statusPill(o) {
    var ls = liveStatusOf(o);
    if (!ls) return null;
    if (ls.cancelled) return el("span", "status-pill is-bad", "Cancelled");
    if (ls.diverted) return el("span", "status-pill is-bad", "Diverted");
    var d = Number(ls.delay_minutes);
    if (isFinite(d) && d >= 15) {
      var txt = d >= 60 ? (Math.round(d / 6) / 10) + " h late" : d + " min late";
      return el("span", "status-pill is-warn", txt);
    }
    if (isFinite(d) && d <= -15) return el("span", "status-pill is-ok", Math.abs(d) + " min early");
    return el("span", "status-pill is-ok", "On time");
  }

  // ---- getting from one place to the next ----
  //
  // feasibility.js already works out ground travel time between two points —
  // that is how it decides a connection is impossible. The number was only ever
  // used to complain. Shown instead, between a landing and the hotel, it answers
  // the question you actually have standing at the carousel.
  //
  // Straight-line distance with a winding factor and a distance-dependent speed;
  // no routing API and no key. Deliberately optimistic, for the same reason the
  // check is: better to say nothing than to be wrong in the alarming direction.

  // Where an entry leaves you. A flight's row is its departure, but it puts you
  // at the far end, which is the point the next item is reached from.
  // Modes where you are the driver. A hire car's two ends are a pick-up desk and
  // a drop-off desk, which is a different thing from a departure and an arrival.
  var SELF_DRIVEN = { car: 1, roadtrip: 1, bike: 1, motorcycle: 1 };

  // When the previous thing finished — the mirror of endPoint, and wrong in the
  // same ways if written carelessly.
  //
  // A hire car's pick-up row carries arrival_at, which is the DROP-OFF eight
  // days later; a hotel's check-in row carries ends_at, which is check-out. Both
  // read as "this ended in the future", the gap test sees a negative interval
  // and rejects a leg that is really twenty minutes long. That is why the drive
  // from the rental counter to the hotel stayed missing after endPoint was fixed.
  function endTimeOf(e) {
    var o = (e && e.obj) || {};
    if (!e) return null;
    if (e.kind === "transport") {
      var fromPickup = SELF_DRIVEN[o.transportation_type] && !e.isCheckout;
      return fromPickup ? (o.departure_at || e.when) : (o.arrival_at || e.when);
    }
    if (e.kind === "hosting") return e.isCheckout ? (o.ends_at || e.when) : e.when;
    return o.ends_at || e.when;
  }

  function endPoint(e) {
    var o = e && e.obj; if (!o) return null;
    if (e.kind === "transport") {
      // A flight leaves you where it lands. A hire car's PICK-UP row leaves you
      // standing at the pick-up desk holding the keys — its arrival coordinates
      // are the drop-off, eight days later and a hundred miles away, which is
      // why the drive from the rental counter to the hotel went unmentioned.
      var fromPickup = SELF_DRIVEN[o.transportation_type] && !e.isCheckout;
      var lat = fromPickup ? o.departure_latitude : o.arrival_latitude;
      var lon = fromPickup ? o.departure_longitude : o.arrival_longitude;
      return lat != null ? { lat: +lat, lon: +lon } : null;
    }
    return o.latitude != null ? { lat: +o.latitude, lon: +o.longitude } : null;
  }
  // Where an entry begins.
  function startPoint(e) {
    var o = e && e.obj; if (!o) return null;
    if (e.kind === "transport") {
      return o.departure_latitude != null ? { lat: +o.departure_latitude, lon: +o.departure_longitude } : null;
    }
    return o.latitude != null ? { lat: +o.latitude, lon: +o.longitude } : null;
  }

  // Under this you are already there: a hotel restaurant, two entrances of one
  // building, the same campus recorded twice.
  //
  // It was 1.5 km, which is a fifteen-minute walk and quietly swallowed most of
  // a city day — the old apartment to Parnassus is 870 m and Parnassus to the
  // Academy of Sciences 1.07 km, and neither said anything at all.
  var TRANSFER_MIN_KM = 0.25;

  // Up to about this, in a city, you walk. Saying "3 min" for a 900 m drive is
  // true of the driving and false of the trip: it ignores parking, which is the
  // part that actually costs you. A walking time is the honest answer and the
  // one you would act on.
  //
  // 1.2 km, not 2. At 2 km the airport transfers came out as walks: SFO's
  // terminal to its rental centre is 1.8 km and nobody walks it, there is a
  // train. The cases this is for are a few blocks — 870 m from the old
  // apartment to Parnassus, 640 m along the wharf — and 1.2 km covers those
  // while leaving anything airport-sized as a drive.
  var WALK_MAX_KM = 1.2;
  // Pavements wind like roads do, and 4.5 km/h is a purposeful city walk.
  function walkMinutes(distKm) { return ((distKm * 1.4) / 4.5) * 60; }
  // Over this it is a journey, not a transfer, and almost always means a leg is
  // missing from the itinerary. The trip check reports that; repeating it here
  // as a cheerful "6 h drive" would be worse than silence.
  var TRANSFER_MAX_KM = 300;
  // A gap this long is not a transfer either. You are doing something else in
  // between, and the itinerary simply does not say what.
  var TRANSFER_MAX_GAP_H = 12;

  // ---- the drive from home, on a trip you drive to ----
  //
  // A flight makes the journey obvious: you go to the airport. A trip you drive
  // to has a first leg nobody has written down — your home city to Mammoth is
  // five hours and the itinerary used to begin at the lodge, as though you had
  // arrived by magic.
  //
  // Only when there is no flight on the trip. With one, the first leg is the
  // drive to the airport and that is already covered by the ordinary
  // item-to-item rule.
  function tripHasFlight(data) {
    return (data.transports || []).some(function (x) { return x && x.transportation_type === "airplane"; });
  }

  // Far enough from home to be a journey. Five trips on record are Beverly
  // Hills itself; "20 min from home" on a staycation is noise, and the map's
  // driving route already uses this same ten-mile test.
  var HOME_MIN_KM = 16;
  // A drive rather than a relocation. Las Vegas is 435 km and Mammoth about
  // 500; beyond about a thousand nobody is driving it for a long weekend, and a
  // trip that far with no flight recorded is a gap in the data rather than an
  // epic road trip worth estimating.
  var HOME_MAX_KM = 1100;


  // ---- where you are based on a given day ----
  //
  // Until now a hint only appeared between two items that happened to sit next
  // to each other. That misses the shape of an actual day: you wake in a hotel,
  // go out to one or more places, and come back to it. The hotel is three days
  // earlier on the itinerary, so nothing connected it to this morning's tour and
  // the longest drive of the day went unmentioned.
  //
  // A stay covers the NIGHTS between check-in and check-out. On the night of day
  // k you sleep wherever check-in <= k < check-out; on the morning of day k you
  // wake wherever you slept on k-1. Those two are different on a check-out day,
  // which is the whole reason to model them separately: you leave the hotel and
  // do not come back to it.
  function lodgingForNight(k, data) {
    if (!k) return null;
    var best = null;
    (data.hostings || []).forEach(function (h) {
      if (h.latitude == null || !h.starts_at) return;
      var inK = dayKey(h.starts_at, h.timezone);
      var outK = h.ends_at ? dayKey(h.ends_at, h.timezone) : null;
      // No check-out recorded means an open-ended stay; treat the night of
      // check-in as covered and no more, rather than every night thereafter.
      if (!inK) return;
      if (k < inK) return;
      if (outK && k >= outK) return;
      if (!outK && k !== inK) return;
      // The latest qualifying stay wins, for the night two bookings overlap.
      if (!best || inK > best.k) best = { k: inK, h: h };
    });
    return best ? best.h : null;
  }
  function prevDayKey(k) {
    var d = new Date(k + "T12:00:00Z");
    d.setUTCDate(d.getUTCDate() - 1);
    return d.toISOString().slice(0, 10);
  }
  // Where you woke on day k: whoever's roof you were under the night before.
  function lodgingWokeIn(k, data) { return lodgingForNight(prevDayKey(k), data); }

  function lodgingPoint(h) {
    if (!h || h.latitude == null) return null;
    var p = { lat: +h.latitude, lon: +h.longitude };
    return (!p.lat && !p.lon) ? null : p;
  }
  function lodgingName(h) { return (h && h.name) || "the hotel"; }

  // An entry that IS the base itself — its own check-in or check-out row. The
  // drive from the hotel to the hotel is not a drive.
  function isSameLodging(e, h) {
    return !!(e && h && e.kind === "hosting" && e.obj && String(e.obj.id) === String(h.id));
  }

  // ---- places you go back to ----
  //
  // Somewhere the family owns or returns to so often that the destination is
  // known before the itinerary is. Pinecrest is the case: ten trips on record, all
  // to the same house, so the drive is the same 250 km every time and worth
  // saying whether or not anyone wrote down a booking.
  //
  // Which matters more than it sounds. NINE of those ten trips have no
  // itinerary items at all — a name and two dates — so a rule keyed off the
  // first located item finds nothing and says nothing. Those are precisely the
  // trips where the drive is the only fact there is.
  // CONFIGURE ME (optional). Places you return to that have no booking --
  // a family cabin, a second home. A trip matching the name or landing
  // near the coordinates gets its drive drawn even when the itinerary is
  // empty. The entry below is an example; replace or delete it.
  var KNOWN_PLACES = [
    {
      key: "pinecrest",
      label: "The Ranch",
      lat: 33.2504,
      lng: -115.6012,
      // Matched on the trip NAME as well as on coordinates, because most of
      // these trips have no coordinates to match. The word boundary keeps it
      // from firing on a longer word that merely contains it.
      name: /\bpinecrest\b/i,
    },
  ];

  // Within this of a known place, an item IS that place — the same house
  // geocoded twice slightly differently should not read as two destinations.
  var PLACE_RADIUS_KM = 8;

  // The known place a trip is going to, or null. Coordinates first: an item
  // sitting on the house is proof, where a name is only a strong hint.
  function knownPlaceFor(t, data) {
    var F = window.WayfarerFeasibility;
    var pts = [];
    if (F && F.km && data) {
      (data.hostings || []).forEach(function (h) { if (h.latitude != null) pts.push([+h.latitude, +h.longitude]); });
      (data.activities || []).forEach(function (a) { if (a.latitude != null) pts.push([+a.latitude, +a.longitude]); });
    }
    for (var i = 0; i < KNOWN_PLACES.length; i++) {
      var pl = KNOWN_PLACES[i];
      for (var j = 0; j < pts.length; j++) {
        var d = F.km(pts[j][0], pts[j][1], pl.lat, pl.lng);
        if (d != null && d <= PLACE_RADIUS_KM) return pl;
      }
      if (pl.name && pl.name.test(String((t && t.name) || ""))) return pl;
    }
    return null;
  }

  function homeHint(point) {
    var F = window.WayfarerFeasibility;
    if (!F || !F.km || !F.driveMinutes || !point) return null;
    if (!point.lat && !point.lon) return null;
    var home = { lat: HOME.lat, lon: HOME.lng };
    var d = F.km(home.lat, home.lon, point.lat, point.lon);
    if (d == null || d < HOME_MIN_KM || d > HOME_MAX_KM) return null;
    var mins = F.driveMinutes(d);
    if (mins == null) return null;
    return { km: d, minutes: mins, from: home, to: point };
  }
  function homeHintBack(point) {
    var h = homeHint(point);
    if (!h) return null;
    return { km: h.km, minutes: h.minutes, from: h.to, to: h.from };
  }

  function transferHint(prev, next) {
    if (!prev || !next) return null;
    var F = window.WayfarerFeasibility;
    if (!F || !F.km || !F.driveMinutes) return null;
    var a = endPoint(prev), b = startPoint(next);
    if (!a || !b) return null;
    // 0,0 is what a failed geocode leaves behind, not a place in the Atlantic.
    if (!a.lat && !a.lon) return null;
    if (!b.lat && !b.lon) return null;
    var d = F.km(a.lat, a.lon, b.lat, b.lon);
    if (d == null || d < TRANSFER_MIN_KM || d > TRANSFER_MAX_KM) return null;
    // Nothing is suppressed for being a flight any more. Checking out of a hotel
    // and driving to the airport is one of the two cases this exists for, and
    // the next item there IS a flight — the earlier rule hid exactly the hint
    // that was wanted. The degenerate cases it was guarding against, a
    // connection or a return leg from the same airport, are zero kilometres
    // apart and the distance floor already drops them.
    var prevEnd = endTimeOf(prev);
    var nextStart = next.when;
    if (prevEnd && nextStart) {
      var gap = (Date.parse(nextStart) - Date.parse(prevEnd)) / MS_H;
      if (!isFinite(gap) || gap < 0 || gap > TRANSFER_MAX_GAP_H) return null;
    }
    if (d <= WALK_MAX_KM) {
      return { km: d, minutes: walkMinutes(d), from: a, to: b, mode: "walk" };
    }
    var mins = F.driveMinutes(d);
    if (mins == null || mins < 5) return null;
    return { km: d, minutes: mins, from: a, to: b, mode: "drive" };
  }

  function fmtDrive(mins) {
    var m = Math.max(1, Math.round(mins));
    if (m < 60) return m + " min";
    var h = Math.floor(m / 60), r = m % 60;
    return r ? h + " h " + r + " min" : h + " h";
  }

  // One route lookup per pair per session. The proxy caches for a day server
  // side, but a trip re-renders on every save and there is no reason to ask
  // again about a road that has not moved.
  var routeCache = {};
  function routeKey(a, b) {
    return a.lat.toFixed(4) + "," + a.lon.toFixed(4) + ";" + b.lat.toFixed(4) + "," + b.lon.toFixed(4);
  }

  // The estimate is drawn immediately; the real route replaces it when it lands.
  //
  // Both halves earn their place. The estimate is instant, needs no network, and
  // is what an offline itinerary on a plane will show. The route is real roads
  // and real driving time — your home city to Mammoth is 500 km of straight line
  // and closer to five hours of actual mountain road, and no winding factor
  // recovers that. Showing the estimate and correcting it beats showing nothing
  // while a request is in flight.
  function upgradeWithRoute(row, textNode, prefix, from, to) {
    if (!from || !to) return;
    var k = routeKey(from, to);
    var paint = function (r) {
      if (!r || !isFinite(r.duration_s) || !isFinite(r.distance_m)) return;
      textNode.textContent = prefix + fmtDrive(r.duration_s / 60) + "  ·  " + fmtDistance(r.distance_m / 1000);
      row.classList.add("is-routed");
      row.title = "By road, via OSRM. No live traffic. " +
        (r.attribution || "© OpenStreetMap contributors");
    };
    if (routeCache[k]) { paint(routeCache[k]); return; }
    ext("route?from=" + from.lat + "," + from.lon + "&to=" + to.lat + "," + to.lon)
      .then(function (r) { if (r && r.duration_s) { routeCache[k] = r; paint(r); } })
      // A missing route is not a problem: the estimate is already on screen.
      .catch(function () {});
  }

  function transferRow(hint, opts) {
    opts = opts || {};
    var walk = hint.mode === "walk";
    var row = el("div", "itin-transfer" + (opts.home ? " is-home" : "") + (walk ? " is-walk" : ""));
    row.appendChild(el("span", "itin-transfer-icon",
      opts.home ? "🏠" : walk ? "🚶" : "🚗"));
    var mins = Math.round(hint.minutes / 5) * 5;
    var time = mins >= 60 ? (Math.round(mins / 6) / 10) + " h" : Math.max(5, mins) + " min";
    var prefix = opts.label ? opts.label + "  ·  " : "";
    var txt = el("span", null,
      prefix + "about " + time + (walk ? " on foot" : "") + "  ·  " + fmtDistance(hint.km));
    row.appendChild(txt);
    // Said once, quietly: the estimate has no traffic in it and no routing.
    row.title = walk
      ? "A short hop — walking pace over a straight line with a winding allowance."
      : "Straight-line distance with a winding allowance — no traffic, no route. Treat it as a floor.";
    // Driving directions are not fetched for a walk: OSRM would answer with a
    // three-minute drive, which is true of the car and false of the errand.
    if (!walk) upgradeWithRoute(row, txt, prefix, hint.from, hint.to);
    return row;
  }

  // ---- itinerary ----
  function buildEntries(t, data) {
    var entries = [];
    (data.transports || []).forEach(function (tr) {
      var meta = [tr.departure_at ? "Dep " + fmtTime(tr.departure_at, tr.departure_timezone) : "", tr.arrival_at ? "Arr " + fmtTime(tr.arrival_at, tr.arrival_timezone) : ""].filter(Boolean).join(" · ");
      var label = [tr.company, tr.transport_number].filter(Boolean).join(" ").trim() || cap(tr.transportation_type) || "Transport";
      // A hire car spans days: without a second entry the drop-off never appears
      // on the day it actually happens. Same treatment lodging already gets.
      var spans = tr.departure_at && tr.arrival_at &&
        dayKey(tr.departure_at, tr.departure_timezone) !== dayKey(tr.arrival_at, tr.arrival_timezone) &&
        /^(car|bike|motorcycle)$/.test(tr.transportation_type || "");
      // A time you set yourself is marked, the same as a locked check-out: a
      // drop-off at 9:30 PM reads as the rental company's unless something says
      // it is yours.
      var depLock = isLocked(tr, "departure_at") ? "  🔒" : "";
      var arrLock = isLocked(tr, "arrival_at") ? "  🔒" : "";
      entries.push({ kind: "transport", when: tr.departure_at, tz: tr.departure_timezone, icon: transIcon(tr.transportation_type),
        title: label + (spans ? " · Pick-up" : ""),
        sub: [tr.departure_description, tr.arrival_description].filter(Boolean).join("  →  "),
        meta: (spans ? "Pick-up " + fmtTime(tr.departure_at, tr.departure_timezone) : meta) +
          (spans ? depLock : (depLock || arrLock)), obj: tr });
      if (spans) {
        entries.push({ kind: "transport", when: tr.arrival_at, tz: tr.arrival_timezone, icon: transIcon(tr.transportation_type),
          title: label + " · Drop-off", sub: tr.arrival_description || tr.arrival_address || "",
          meta: "Drop-off " + fmtTime(tr.arrival_at, tr.arrival_timezone) + arrLock, obj: tr, isCheckout: true });
      }
    });
    (data.hostings || []).forEach(function (h) {
      // The confirmation code used to ride here, beside the check-in time, while
      // flights and hire cars carried theirs on the detail line under the title.
      // One fact, two places, depending on what you had booked. It is on the
      // detail line for every kind now, so there is only one place to look.
      // A locked time is marked, because "check-out 4:00 PM" reads as the
      // hotel's policy unless something says otherwise, and the difference
      // matters at the desk.
      var ciMeta = h.starts_at ? fmtTime(h.starts_at, h.timezone) + (isLocked(h, "starts_at") ? "  🔒" : "") : "";
      var coMeta = h.ends_at ? fmtTime(h.ends_at, h.timezone) + (isLocked(h, "ends_at") ? "  🔒" : "") : "";
      entries.push({ kind: "hosting", when: h.starts_at, tz: h.timezone, icon: "🏨", title: (h.name || "Lodging") + " · Check-in", sub: h.address || "", meta: ciMeta, obj: h });
      if (h.ends_at) entries.push({ kind: "hosting", when: h.ends_at, tz: h.timezone, icon: "🏨", title: (h.name || "Lodging") + " · Check-out", sub: h.address || "", meta: coMeta, obj: h, isCheckout: true });
    });
    (data.activities || []).forEach(function (a) {
      // Airport parking (and anything else spanning days) needs a closing entry
      // too, otherwise "collect the car" never shows on the day you land.
      var spans = a.starts_at && a.ends_at &&
        dayKey(a.starts_at, a.timezone) !== dayKey(a.ends_at, a.timezone);
      var name = a.name || (a.activity_type === "note" ? "Note" : "Activity");
      var isPark = a.activity_type === "parking";
      entries.push({ kind: "activity", when: a.starts_at, tz: a.timezone, icon: actIcon(a),
        title: name + (spans ? (isPark ? " · Drop off car" : " · Starts") : ""),
        sub: a.address || "", meta: a.all_day ? "All day" : (a.starts_at ? fmtTime(a.starts_at, a.timezone) : ""), obj: a });
      if (spans) {
        entries.push({ kind: "activity", when: a.ends_at, tz: a.timezone, icon: actIcon(a),
          title: name + (isPark ? " · Collect car" : " · Ends"),
          sub: a.address || "", meta: fmtTime(a.ends_at, a.timezone), obj: a, isCheckout: true });
      }
    });
    return entries;
  }
  // Today, as the trip reckons it. A trip in Lisbon is a day ahead of the phone
  // that booked it from California, and every "is this today" question in the
  // itinerary has to be asked in the trip's zone or it answers for the wrong
  // hemisphere.
  // Date.now() rather than new Date(): the argless constructor reads the system
  // clock directly and ignores a stubbed Date.now, so a test that freezes time
  // has no effect on it. Three tests here "passed" against the real wall clock
  // before this was written that way.
  function todayKey(t) {
    return dayKey(new Date(Date.now()).toISOString(), (t && t.timezone) || null);
  }

  // Is the trip happening now? Dates only — a trip is "on" for the whole of its
  // last day, not until some hour of it.
  function tripInProgress(t) {
    if (!t || !t.has_dates || !t.starts_at || !t.ends_at) return false;
    var k = todayKey(t);
    return k >= String(t.starts_at).slice(0, 10) && k <= String(t.ends_at).slice(0, 10);
  }

  // The next thing still ahead of you, or the one happening now.
  //
  // "Now" wins over "next": mid-flight, the flight is the answer, and the
  // connection two hours out is not. Only entries with an end time can be
  // current — an activity with a start and nothing else is a moment, and a
  // moment is past as soon as it passes.
  //
  // Lodging is never the answer to either question. A stay is true for days at
  // a stretch, so it wins "happening now" from the moment you check in and
  // holds it through every meal, tour and flight of the trip — crowding out the
  // one thing the card exists to tell you. The hotel is on the itinerary and in
  // the day's own rows; it does not need the top of the screen as well.
  function nextEntry(entries, nowMs) {
    var current = null, upcoming = null;
    entries.forEach(function (e) {
      if (!e.when || e.kind === "hosting") return;
      var start = Date.parse(e.when);
      if (!isFinite(start)) return;
      var endIso = e.obj && (e.obj.arrival_at || e.obj.ends_at);
      var end = endIso ? Date.parse(endIso) : NaN;
      if (isFinite(end) && start <= nowMs && nowMs < end) {
        if (!current || end < current.end) current = { entry: e, end: end };
      } else if (start > nowMs) {
        if (!upcoming || start < upcoming.start) upcoming = { entry: e, start: start };
      }
    });
    if (current) return { entry: current.entry, now: true };
    return upcoming ? { entry: upcoming.entry, now: false } : null;
  }

  // Two stays that genuinely clash: overlapping in time AND at different
  // hotels. The same hotel twice over the same nights is a second room, not a
  // mistake -- see the overlap check for the measurement that established that.
  function clashingStays(first, second) {
    if (!first || !second || !first.ends_at || !second.starts_at) return false;
    if (!(new Date(second.starts_at) < new Date(first.ends_at))) return false;
    var a = String(first.name || "").trim().toLowerCase();
    var b = String(second.name || "").trim().toLowerCase();
    // A missing name on either side means we cannot establish they are
    // different places, and silence beats a warning we cannot stand behind.
    if (!a || !b || a === b) return false;
    return true;
  }

  // Which day sections the user has collapsed, per trip, for this session.
  var collapsedDays = {};
  // The live day-strip observer, if any. Replaced on each render.
  var dayWatcher = null;
  // The trip whose itinerary is currently on screen. Distinguishes opening a
  // trip from redrawing one: openTrip runs after every save, and treating that
  // as an open would re-fade the list and jump you back to today each time you
  // corrected a time.
  var shownTrip = null;
  function renderItinerary(root, t, data, budgetRoot) {
    root.innerHTML = "";
    var entries = buildEntries(t, data);
    var show = getDisplay().showKinds;
    entries = entries.filter(function (e) { return show[e.kind === "transport" ? "transport" : e.kind === "hosting" ? "hosting" : "activity"] !== false; });
    // sort_order wins when set (all zeros by default => pure chronological order).
    var scheduled = entries.filter(function (e) { return e.when; }).sort(function (a, b) {
      var d = dayKey(a.when, a.tz).localeCompare(dayKey(b.when, b.tz));
      if (d) return d;
      var sa = (a.obj && a.obj.sort_order) || 0, sb = (b.obj && b.obj.sort_order) || 0;
      if (sa !== sb) return sa - sb;
      return new Date(a.when) - new Date(b.when);
    });
    var unscheduled = entries.filter(function (e) { return !e.when; });

    // A trip with nothing on it may still have a drive worth showing: nine of the
    // ten Pinecrest weekends are a name and two dates, and the journey is the only
    // fact there is. Worked out before the empty-handed exit below, or that exit
    // takes the drive with it.
    var placeLegs = (!tripHasFlight(data) && !scheduled.length && t.has_dates && t.starts_at)
      ? knownPlaceFor(t, data) : null;
    if (!scheduled.length && !unscheduled.length && !(data.expenses || []).length && !placeLegs) {
      root.appendChild(el("div", "empty", "No itinerary items for this trip yet."));
      return;
    }

    // Each day becomes a section: a sticky heading plus its own rows container,
    // so a day can be collapsed and so reordering stays scoped to one day.
    var dayHeads = {}, groups = {}, order = [], lastInDay = {}, rowEls = [];
    // Extracted so a day can also be created for a trip that has no items at
    // all — a Pinecrest weekend is a name and two dates, and the drive is the only
    // thing there is to say about it.
    var ensureDay = function (k) {
      if (groups[k]) return groups[k];
      var sec = el("div", "day-sec"); sec.dataset.day = k;
      var dh = el("div", "day-head");
      var caret = el("span", "day-caret", "▾");
      var label = el("span", "day-label", dayLabel(k));
      dh.appendChild(caret); dh.appendChild(label);
      var rows = el("div", "day-rows");
      dh.addEventListener("click", function (ev) {
        if (ev.target.closest(".linkchip,.mini-btn")) return;
        var key = t.id + "|" + k;
        var now = !collapsedDays[key];
        collapsedDays[key] = now;
        sec.classList.toggle("collapsed", now);
        caret.textContent = now ? "▸" : "▾";
      });
      // Marked in the trip's own zone. Reading "today" off the browser means a
      // traveller nine hours ahead is told the wrong day by their own itinerary
      // — precisely the reader this is for.
      if (k === todayKey(t)) sec.classList.add("is-today");
      var pastDay = getDisplay().autoCollapsePast && k < new Date().toISOString().slice(0, 10);
      var startCollapsed = collapsedDays[t.id + "|" + k];
      if (startCollapsed === undefined) startCollapsed = pastDay && k !== todayKey(t);
      if (startCollapsed) { sec.classList.add("collapsed"); caret.textContent = "▸"; }
      sec.appendChild(dh); sec.appendChild(rows);
      root.appendChild(sec);
      groups[k] = rows; dayHeads[k] = dh; order.push(k);
      return rows;
    };
    scheduled.forEach(function (e) {
      var k = dayKey(e.when, e.tz);
      ensureDay(k);
      // How you get there from the last thing, when both ends are located and
      // the gap looks like a transfer rather than an afternoon.
      var hint = transferHint(lastInDay[k], e);
      if (hint) groups[k].appendChild(transferRow(hint));
      lastInDay[k] = e;
      var rowEl = itinRow(e, t);
      rowEls.push({ entry: e, row: rowEl, day: k });
      groups[k].appendChild(rowEl);
    });

    // The drive from home, and the drive back, when nothing flies.
    if (!tripHasFlight(data) && rowEls.length) {
      var firstLocated = null, lastLocated = null;
      rowEls.forEach(function (r) {
        if (!firstLocated && startPoint(r.entry)) firstLocated = r;
        if (endPoint(r.entry)) lastLocated = r;
      });
      if (firstLocated) {
        var out = homeHint(startPoint(firstLocated.entry));
        if (out) {
          firstLocated.row.parentNode.insertBefore(
            transferRow(out, { home: true, label: "From home" }), firstLocated.row);
        }
      }
      // Only worth saying if you actually end up somewhere else; on a there and
      // back trip the last item is often the same place as the first.
      if (lastLocated) {
        var back = homeHintBack(endPoint(lastLocated.entry));
        if (back) {
          var after = lastLocated.row.nextSibling;
          var backRow = transferRow(back, { home: true, label: "Home" });
          if (after) lastLocated.row.parentNode.insertBefore(backRow, after);
          else lastLocated.row.parentNode.appendChild(backRow);
        }
      }
    }
    // The shape of a day: out from where you slept, round the places you are
    // going, and back to where you sleep tonight.
    //
    // The middle of that is already handled — consecutive items on the same day
    // have been getting a hint all along. What was missing is the two ends,
    // because the hotel sits days earlier on the itinerary and nothing joined it
    // to this morning.
    //
    // A check-out day gets no return leg: you left, and the onward drive is
    // whatever comes next, which the consecutive rule already covers.
    order.forEach(function (k) {
      var mine = rowEls.filter(function (r) { return r.day === k; });
      if (!mine.length) return;
      var first = mine[0], last = mine[mine.length - 1];

      var woke = lodgingWokeIn(k, data);
      var wokePt = lodgingPoint(woke);
      // Nothing to add if the first thing you did was leave that very hotel —
      // its check-out row IS the departure, and the leg onward from it is
      // already drawn.
      if (wokePt && !isSameLodging(first.entry, woke)) {
        // Coordinates only. Handing over the whole booking would let its
        // check-out datetime — days later — be read as "when the previous thing
        // ended", and the gap test would reject every morning of the stay.
        var outHint = transferHint(
          { kind: "hosting", obj: { latitude: wokePt.lat, longitude: wokePt.lon }, when: null },
          first.entry);
        if (outHint) {
          first.row.parentNode.insertBefore(
            transferRow(outHint, { label: "From " + lodgingName(woke) }), first.row);
        }
      }

      var night = lodgingForNight(k, data);
      var nightPt = lodgingPoint(night);
      // No return leg when you are not sleeping there — a check-out day, a
      // night in the air, the last day of the trip.
      if (nightPt && !isSameLodging(last.entry, night)) {
        var backHint = transferHint(last.entry,
          { kind: "hosting", obj: { latitude: nightPt.lat, longitude: nightPt.lon }, when: null });
        if (backHint) {
          var after = last.row.nextSibling;
          var backRow = transferRow(backHint, { label: "Back to " + lodgingName(night) });
          if (after) last.row.parentNode.insertBefore(backRow, after);
          else last.row.parentNode.appendChild(backRow);
        }
      }
    });

    // A trip with nothing on it, to a place already known. Nine of the ten
    // Pinecrest weekends are exactly this: a name, two dates, and a drive nobody
    // wrote down. The day sections are created for the sole purpose of holding
    // it, which is why ensureDay was pulled out of the loop above.
    if (placeLegs && !rowEls.length) {
      var place = placeLegs;
      if (place) {
        var dest = { lat: place.lat, lon: place.lng };
        var outHint = homeHint(dest);
        if (outHint) {
          ensureDay(t.starts_at).appendChild(
            transferRow(outHint, { home: true, label: "Home to " + place.label }));
        }
        var backHint = homeHintBack(dest);
        if (backHint) {
          ensureDay(t.ends_at || t.starts_at).appendChild(
            transferRow(backHint, { home: true, label: place.label + " to home" }));
        }
      }
    }

    // Count badge per day, added after the rows exist. Counts ROWS, not
    // children: a transfer hint is a note between two items, not a third item.
    order.forEach(function (k) {
      var n = groups[k].querySelectorAll(".itin-row").length;
      dayHeads[k].appendChild(el("span", "day-count", n + (n === 1 ? " item" : " items")));
    });
    decorateWeather(dayHeads, data);
    decorateTypical(dayHeads, data);
    decorateHolidays(dayHeads, data);
    renderLocalInfo(root, t, data);

    // A day strip for long trips. Fifteen days on the Camino and twenty-nine at
    // Camp Stone are one continuous scroll otherwise, with no way to reach the
    // middle of the trip except by dragging past everything before it.
    //
    // Only appears when there is enough trip to get lost in — on a three-day
    // weekend it would be a row of chrome above content you can already see.
    if (order.length > 4) {
      var strip = el("div", "day-strip");
      // A bare row of numbers reads as anything — page numbers, item counts.
      // One word in front makes it a day picker.
      strip.appendChild(el("span", "day-strip-label", "Day:"));
      var pips = {};
      order.forEach(function (k, i) {
        var b = el("button", "day-pip", String(i + 1)); b.type = "button";
        pips[k] = b;
        var dn = groups[k].children.length;
        b.title = dayLabel(k) + " · " + dn + (dn === 1 ? " item" : " items");
        b.addEventListener("click", function () {
          var sec = root.querySelector('.day-sec[data-day="' + k + '"]');
          if (!sec) return;
          // Jumping to a day you had collapsed should show it, not scroll to a
          // closed header and look broken.
          if (sec.classList.contains("collapsed")) {
            sec.classList.remove("collapsed");
            collapsedDays[t.id + "|" + k] = false;
            var c = sec.querySelector(".day-caret"); if (c) c.textContent = "▾";
          }
          sec.scrollIntoView({ behavior: "smooth", block: "start" });
          strip.querySelectorAll(".day-pip").forEach(function (p) { p.classList.remove("on"); });
          b.classList.add("on");
        });
        strip.appendChild(b);
      });

      // One chip, and its label is the action it will perform — not a state you
      // then have to reason about. If anything is open it offers to close
      // everything; once everything is closed it offers to open it again.
      var toggleAll = el("button", "day-pip day-toggle-all", "Collapse All");
      toggleAll.type = "button";
      var sections = function () { return [].slice.call(root.querySelectorAll(".day-sec")); };
      var anyOpen = function () {
        return sections().some(function (s) { return !s.classList.contains("collapsed"); });
      };
      var paintToggle = function () { toggleAll.textContent = anyOpen() ? "Collapse All" : "Expand All"; };
      toggleAll.addEventListener("click", function () {
        var collapse = anyOpen();
        sections().forEach(function (s) {
          s.classList.toggle("collapsed", collapse);
          var c = s.querySelector(".day-caret"); if (c) c.textContent = collapse ? "▸" : "▾";
          // Remember it per day, the same way a single header click does, so the
          // choice survives reopening the trip in this session.
          if (s.dataset.day) collapsedDays[t.id + "|" + s.dataset.day] = collapse;
        });
        paintToggle();
      });
      // A day toggled from its own header changes what this chip should offer,
      // so repaint after any click inside the itinerary rather than letting the
      // label drift out of step with what is actually open.
      root.addEventListener("click", function () { setTimeout(paintToggle, 0); });
      strip.appendChild(toggleAll);
      paintToggle();

      root.insertBefore(strip, root.firstChild);

      // ---- the strip follows you ----
      //
      // Clicking a pip lit it; scrolling did not, so on a fifteen-day trip the
      // marker sat on day 1 while you read day 9. An observer rather than a
      // scroll handler: scroll fires per frame and would do this work on every
      // one of them.
      //
      // The band is the top of the panel, not its middle. What you are reading
      // on a long page is what has just come up under the header, and a middle
      // band on a day taller than the viewport matches nothing at all.
      if ("IntersectionObserver" in window) {
        if (dayWatcher) dayWatcher.disconnect();
        var panel = root.closest(".detail-panel") || null;
        var lit = null;
        dayWatcher = new IntersectionObserver(function (entries) {
          // Whichever observed day is nearest the top of the band wins. Taking
          // the last entry to fire instead would depend on callback order,
          // which is not the order things appear on the page.
          var best = null;
          Object.keys(pips).forEach(function (k) {
            var sec = root.querySelector('.day-sec[data-day="' + CSS.escape(k) + '"]');
            if (!sec) return;
            var top = sec.getBoundingClientRect().top;
            var edge = panel ? panel.getBoundingClientRect().top : 0;
            if (top - edge <= 80 && (!best || top > best.top)) best = { key: k, top: top };
          });
          var key = best ? best.key : order[0];
          if (key === lit) return;
          lit = key;
          Object.keys(pips).forEach(function (k) { pips[k].classList.toggle("on", k === key); });
        }, { root: panel, rootMargin: "-70px 0px -70% 0px", threshold: 0 });
        order.forEach(function (k) {
          var sec = root.querySelector('.day-sec[data-day="' + CSS.escape(k) + '"]');
          if (sec) dayWatcher.observe(sec);
        });
      }
    }

    if (unscheduled.length) {
      var usec = el("div", "day-sec");
      var uh = el("div", "day-head");
      uh.appendChild(el("span", "day-caret", "▾"));
      uh.appendChild(el("span", "day-label", "Unscheduled"));
      var urows = el("div", "day-rows");
      uh.addEventListener("click", function () {
        var on = !usec.classList.contains("collapsed");
        usec.classList.toggle("collapsed", on);
        uh.querySelector(".day-caret").textContent = on ? "▸" : "▾";
      });
      usec.appendChild(uh); usec.appendChild(urows);
      unscheduled.forEach(function (e) { urows.appendChild(itinRow(e, t)); });
      root.appendChild(usec);
    }

    // ---- where you are meant to be next ----
    //
    // Only while the trip is actually happening. Before it starts the answer is
    // the countdown at the top, and afterwards there is no next thing at all --
    // on a trip you took in 2015 a card saying "next up" would be nonsense.
    if (tripInProgress(t)) {
      var up = nextEntry(scheduled, Date.now());
      if (up) {
        var card = el("div", "nextup");
        card.appendChild(el("div", "nextup-icon", up.entry.icon || "•"));
        var nb = el("div", "nextup-body");
        // The label and the time share a line, and the title gets the full
        // width beneath them. The time used to be a third column of its own,
        // fixed width and never wrapping, which on a 375px phone left the body
        // 186px of the card's 335 -- so a flight title wrapped to two lines and
        // its airports to two more, for a 141px-tall card saying one thing.
        var head = el("div", "nextup-head");
        head.appendChild(el("span", "nextup-label", up.now ? "Happening now" : "Next up"));
        if (up.entry.meta) head.appendChild(el("span", "nextup-when", up.entry.meta));
        nb.appendChild(head);
        nb.appendChild(el("div", "nextup-title", up.entry.title || ""));
        if (up.entry.sub) nb.appendChild(el("div", "nextup-sub", up.entry.sub));
        // The tracker, on the card that is already saying you are on this
        // flight. Same window as the row chip, so the two agree.
        var trackHref = trackable(up.entry.obj, Date.now()) ? fr24Url(up.entry.obj) : null;
        if (trackHref) {
          var tl = alink("📡 Track", trackHref);
          tl.className = "linkchip nextup-track";
          // The card itself scrolls to the row; without this the tap would do
          // both, and the page would jump out from under the new tab.
          tl.addEventListener("click", function (ev) { ev.stopPropagation(); });
          nb.appendChild(tl);
        }
        card.appendChild(nb);
        // Takes you to the row rather than opening anything: the card is a
        // pointer into the itinerary, and the itinerary is where the detail is.
        card.addEventListener("click", function () {
          var hit = rowEls.filter(function (r) { return r.entry === up.entry; })[0];
          if (!hit) return;
          var sec = hit.row.closest(".day-sec");
          if (sec && sec.classList.contains("collapsed")) {
            sec.classList.remove("collapsed");
            collapsedDays[t.id + "|" + hit.day] = false;
            var c = sec.querySelector(".day-caret"); if (c) c.textContent = "▾";
          }
          hit.row.scrollIntoView({ behavior: "smooth", block: "center" });
        });
        root.insertBefore(card, root.firstChild);
      }
    }

    // A fresh open fades in and lands on today. A redraw does neither -- see
    // shownTrip. Both are deliberately cheap: one opacity animation on the
    // container, and one scroll.
    if (shownTrip !== t.id) {
      shownTrip = t.id;
      root.classList.add("itin-loaded");
      var todaySec = root.querySelector(".day-sec.is-today");
      // Left alone when today is already the first thing on screen, or the
      // scroll is a jump to nowhere. Also skipped when the trip has not begun:
      // there is no today section to find.
      if (todaySec && todaySec !== root.querySelector(".day-sec")) {
        // Not smooth: this fires as the panel appears, and a smooth scroll
        // racing the opening animation reads as the page sliding about on its
        // own. Instant means it is simply already in the right place.
        try { todaySec.scrollIntoView({ block: "start" }); } catch (e) {}
      }
    }

    if (budgetRoot) renderBudget(budgetRoot, t, data);
  }
  // The detail line under a row's title, built from parts so that some of them
  // can be tapped to copy. A confirmation code is read OUT at a desk far more
  // often than it is read for pleasure, and retyping "10868SG140143" off a
  // phone screen is exactly the kind of small misery an app should absorb.
  //
  // Returns null when every part is empty, so callers can append blindly.
  function detailLine(parts) {
    var live = parts.filter(function (p) { return p && p.text; });
    if (!live.length) return null;
    var wrap = el("div", "itin-sub subtle");
    live.forEach(function (p, i) {
      if (i) wrap.appendChild(document.createTextNode(" · "));
      if (!p.copy) { wrap.appendChild(document.createTextNode(p.text)); return; }
      var b = el("button", "copyable", p.text); b.type = "button";
      b.title = "Tap to copy " + p.copy;
      // stopPropagation because the row itself opens the item; copying a code
      // should not also throw you into an edit form.
      b.addEventListener("click", function (ev) {
        ev.stopPropagation();
        copy(p.copy).then(function (ok) {
          toast(ok ? "Copied " + p.copy : "Couldn't reach the clipboard.");
        });
      });
      wrap.appendChild(b);
    });
    return wrap;
  }

  // The name-and-label chips shared by flights (seat) and lodging (room).
  // Returns null when there is nothing to draw, so callers can append blindly.
  function paxLineNode(list, key, guessTitle, onOpen) {
    if (!list || !list.length) return null;
    var pl = el("div", "itin-pax");
    list.forEach(function (x) {
      var chip = el("span", "pax-seat" + (x.guessed ? " guessed" : ""));
      chip.appendChild(el("span", "pax-seat-who", x.name));
      if (x[key]) chip.appendChild(el("span", "pax-seat-no", x[key]));
      pl.appendChild(chip);
    });
    if (list.some(function (x) { return x.guessed; })) {
      var g = el("span", "pax-guess", "unconfirmed");
      g.title = guessTitle;
      pl.appendChild(g);
    }
    pl.addEventListener("click", function (ev) { ev.stopPropagation(); onOpen(); });
    return pl;
  }

  function itinRow(e, trip) {
    var o = e.obj || {};
    var row = el("div", "itin-row");
    // checklist for activities
    if (e.kind === "activity") {
      var box = el("button", "check" + (o.checked ? " on" : ""), o.checked ? "✓" : ""); box.type = "button"; box.title = "Toggle done";
      box.addEventListener("click", function (ev) { ev.stopPropagation(); toggleChecked(trip, o, box); });
      row.appendChild(box);
    } else { row.appendChild(el("div", "itin-icon", e.icon)); }
    var b = el("div", "itin-body");
    var title = el("div", "itin-title"); title.textContent = (e.kind === "activity" ? e.icon + " " : "") + e.title;
    if (e.meta) b.appendChild(el("span", "itin-time", e.meta));
    b.appendChild(title);
    if (e.sub) b.appendChild(el("div", "itin-sub", e.sub));
    // rich transport line
    if (e.kind === "transport") {
      var pax = paxOf(o, trip);
      // Once each seat has a name against it, the bare seat list is noise —
      // "Seat 6D, 6A, 6F" says strictly less than "Alex 6D · Sam 6A".
      var tline = detailLine([
        { text: (o.seat_number && !pax.length) ? "Seat " + o.seat_number : "", copy: o.seat_number },
        { text: o.seat_class || "" },
        { text: o.departure_terminal ? "Term " + o.departure_terminal : "" },
        { text: o.departure_gate ? "Gate " + o.departure_gate : "" },
        { text: o.vehicle_description || "" },
        { text: o.provider_reservation_code ? "Conf " + o.provider_reservation_code : "", copy: o.provider_reservation_code },
      ]);
      if (tline) b.appendChild(tline);
      var pl = paxLineNode(pax, "seat",
        "Paired in the order the airline listed the seats, which is usually passenger order. Tap to confirm or correct.",
        function () { openSeatEditor(trip, o); });
      if (pl) b.appendChild(pl);
    }
    // Lodging's own detail line, in the same slot and the same style the
    // transport branch above uses: room first because it is what you are told at
    // the desk, then the confirmation code.
    if (e.kind === "hosting") {
      var hline = detailLine([
        { text: o.room_type || "" },
        { text: o.provider_reservation_code ? "Conf " + o.provider_reservation_code : "", copy: o.provider_reservation_code },
      ]);
      if (hline) b.appendChild(hline);
    }
    // Activities never showed a confirmation code at all, though tours and
    // parking bookings have one and it is exactly what gets asked for on arrival.
    if (e.kind === "activity" && o.provider_reservation_code) {
      b.appendChild(detailLine([
        { text: "Conf " + o.provider_reservation_code, copy: o.provider_reservation_code },
      ]));
    }
    // Who is in this room. Only on the check-in row: the same booking appears
    // again at check-out, and saying it twice on one stay is noise.
    if (e.kind === "hosting" && !e.isCheckout) {
      var rl = paxLineNode(roomPaxOf(o, trip), "room",
        "Read from the names written on this booking. Tap to confirm or change who is in this room.",
        function () { openRoomEditor(trip, o); });
      if (rl) b.appendChild(rl);
    }
    // Custom category badge, in the category's own colour
    if (e.kind === "activity") {
      var cat = catFor(o.activity_type);
      if (cat) {
        var badge = el("span", "cat-badge", cat.name || "Category");
        if (cat.color) { badge.style.borderColor = cat.color; badge.style.color = cat.color; }
        b.appendChild(badge);
      }
    }
    // Notes hold the long detail — bed type, cancellation policy, rate
    // breakdowns, driver instructions. Useful when you want it, noise the rest
    // of the time, so it collapses behind a summary. The genuinely at-a-glance
    // facts (name, time, address, seat/confirmation) are already above.
    if (o.notes) {
      var noteText = String(o.notes).replace(/\n{3,}/g, "\n\n").trim();
      if (noteText) {
        var noteWrap = el("div", "itin-notewrap");
        var firstLine = noteText.split("\n")[0].trim();
        var tog = el("button", "note-toggle"); tog.type = "button";
        var body = el("div", "itin-note", noteText); body.hidden = true;
        var openN = false;
        function paintNote() {
          tog.innerHTML = "";
          tog.appendChild(el("span", "note-caret", openN ? "▾" : "▸"));
          tog.appendChild(el("span", "note-peek", openN
            ? "Hide details"
            : (firstLine.length > 46 ? firstLine.slice(0, 46).trim() + "…" : firstLine || "Details")));
          body.hidden = !openN;
          tog.setAttribute("aria-expanded", String(openN));
        }
        tog.addEventListener("click", function (ev) { ev.stopPropagation(); openN = !openN; paintNote(); });
        paintNote();
        noteWrap.appendChild(tog); noteWrap.appendChild(body);
        b.appendChild(noteWrap);
      }
    }
    // What guests say. Collapsed like the notes above and for the same reason:
    // it is worth reading once before you go and is noise every other time.
    // Suppressed on a business trip — you did not choose the hotel and the
    // review digest cannot change anything.
    if (o.rating && o.review_summary && wantsSuggestions(trip)) {
      var revWrap = el("div", "itin-notewrap");
      var rTog = el("button", "note-toggle"); rTog.type = "button";
      var rBody = el("div", "itin-note stay-info"); rBody.hidden = true;
      rBody.appendChild(el("div", "stay-summary", o.review_summary));
      var subs = o.subratings || {};
      var SUB_LABELS = { cleanliness: "Clean", location: "Location", rooms: "Rooms",
                         service: "Service", sleepQuality: "Sleep", value: "Value" };
      var subKeys = Object.keys(SUB_LABELS).filter(function (k) { return subs[k] != null; });
      if (subKeys.length) {
        var subRow = el("div", "stay-subs");
        subKeys.forEach(function (k) {
          var s = el("span", "stay-sub");
          s.appendChild(el("span", "stay-sub-n", String(subs[k])));
          s.appendChild(el("span", "stay-sub-l", SUB_LABELS[k]));
          subRow.appendChild(s);
        });
        rBody.appendChild(subRow);
      }
      if (Array.isArray(o.amenities) && o.amenities.length) {
        var amWrap = el("div", "stay-amenities");
        o.amenities.forEach(function (a) { amWrap.appendChild(el("span", "stay-amenity", a)); });
        rBody.appendChild(amWrap);
      }
      // Says where it came from and when. A rating is somebody else's opinion at
      // a point in time, not a fact about the booking, and it should not be able
      // to pass for one.
      rBody.appendChild(el("div", "stay-src", "TripAdvisor" +
        (o.enriched_at ? " · read " + dayLabel(String(o.enriched_at).slice(0, 10)) : "")));
      var openR = false;
      var paintRev = function () {
        rTog.innerHTML = "";
        rTog.appendChild(el("span", "note-caret", openR ? "▾" : "▸"));
        rTog.appendChild(el("span", "note-peek", openR ? "Hide what guests say"
          : "★ " + o.rating + " · what guests say"));
        rBody.hidden = !openR;
        rTog.setAttribute("aria-expanded", String(openR));
      };
      rTog.addEventListener("click", function (ev) { ev.stopPropagation(); openR = !openR; paintRev(); });
      paintRev();
      revWrap.appendChild(rTog); revWrap.appendChild(rBody);
      b.appendChild(revWrap);
    }
    // A changed item says so on the row. Without it the only way to discover a
    // schedule change is to have memorised the old time.
    var rc = recentChanges(o);
    if (rc.length) {
      var ch = el("span", "itin-changed", "⟳ Changed");
      ch.title = rc.slice(0, 4).map(function (c) {
        return changeLabel(c.field) + ": " + changeValue(c.field, c.from, e.tz) +
               " → " + changeValue(c.field, c.to, e.tz);
      }).join("\n");
      b.appendChild(ch);
    }

    // action links
    var links = el("div", "itin-links");
    var lat = o.latitude != null ? o.latitude : o.arrival_latitude, lng = o.longitude != null ? o.longitude : o.arrival_longitude, addr = o.address || o.arrival_description || o.departure_description;
    var gl = gmaps(lat, lng, addr, o.google_places_id, e.title), al = amaps(lat, lng, addr, e.title);
    // One Maps chip rather than two. Which map app you want is a per-tap
    // decision, not something worth two permanent chips on every single row.
    if (gl || al) {
      var mapChip = el("button", "linkchip", "📍 Maps"); mapChip.type = "button";
      mapChip.addEventListener("click", function (ev) {
        ev.stopPropagation();
        openMapPicker(e.title, gl, al);
      });
      links.appendChild(mapChip);
    }
    // Website, phone and email are one question — "how do I reach this place" —
    // and as three chips they crowded out the ones you act on. The phone chip
    // was the worst of it: it printed the whole number, so a Madrid hotel spent
    // half the row on "📞 912 10 88 00".
    var contacts = contactsOf(o, e.kind);
    if (contacts.length) {
      var cc = el("button", "linkchip", "☎ Contact"); cc.type = "button";
      cc.title = contacts.map(function (x) { return x.label; }).join(" · ");
      cc.dataset.sheetLabel = "☎  Contact";
      cc.addEventListener("click", function (ev) {
        ev.stopPropagation();
        openChooser("Contact " + String(e.title || "this").slice(0, 40),
          contacts.map(function (x) {
            return [x.icon, x.label, function () { openContactHref(x.href); }];
          }));
      });
      links.appendChild(cc);
    }
    // Live tracking, but only while it means anything. The always-on version of
    // this chip was removed once for spending a slot on every flight row
    // forever; gated to the flight's own window it costs nothing on the other
    // 270 and is there on the one you are about to board.
    if (trackable(o, Date.now())) {
      links.appendChild(alink("📡 Track", fr24Url(o)));
    }
    // No confirmation-code chip. The code is already on the row's detail line,
    // and in every export — spending a chip on a string you read rather than
    // press pushed the actions you do press into the overflow.
    // Scannable ticket codes the importer pulled out of the confirmation
    ticketCodes(o).forEach(function (tc) {
      var tb = el("button", "linkchip", "▦ " + tc.label); tb.type = "button";
      tb.addEventListener("click", function (ev) { ev.stopPropagation(); openTicketCode(e.title, tc); });
      links.appendChild(tb);
    });
    if (o.provider_url) links.appendChild(alink("🎟 Ticket", o.provider_url));
    // Which parent_type a document attached here carries. Declared before
    // docLinks so the unlink control has its context.
    var attachKind = e.kind === "activity" ? "activity"
      : e.kind === "transport" ? "transportation"
      : e.kind === "hosting" ? "hosting" : null;
    // One booking, one set of document chips. A hotel stay and a hire car each
    // produce two rows from a single record — check-in and check-out, pick-up
    // and drop-off — and both read the same object, so a rate confirmation
    // rendered on both and looked like two documents. It goes on the first row,
    // where Attach already is.
    if (!e.isCheckout) {
      docLinks(o, trip, attachKind, currentData).forEach(function (d) { links.appendChild(d); });
    }
    if (attachKind && !e.isCheckout) {
      var att = el("button", "linkchip", "📎 Attach"); att.type = "button";
      att.addEventListener("click", function (ev) { ev.stopPropagation(); attachItemDocument(trip, attachKind, o, e.title); });
      links.appendChild(att);
    }
    // No "Nearby" chip. Finding things around a hotel is what a maps app is
    // for, and this one sat on every lodging and activity row to earn it.
    // edit/delete — every itinerary object type is editable, each writing to our API
    var edits = {
      activity: { open: function () { editActivity(trip, o); }, kind: "activity" },
      transport: { open: function () { editTransport(trip, o); }, kind: "transportation" },
      hosting: { open: function () { editHosting(trip, o); }, kind: "hosting" }
    };
    var cfg = edits[e.kind];
    if (cfg && !e.isCheckout) {
      var ed = el("button", "linkchip is-edit", "✎ Edit"); ed.type = "button";
      // Pinned like Delete, and appended before it, so the pair always sits
      // together at the end of the row. Only Delete was pinned before, which
      // let a busy row push Edit into the overflow and leave a lone bin
      // behind — the one arrangement neither of them should ever be in.
      ed.dataset.alwaysShow = "1";
      ed.addEventListener("click", function (ev) { ev.stopPropagation(); cfg.open(); });
      var del = el("button", "linkchip danger is-edit", "🗑"); del.type = "button";
      // Stays on the row at every width. Buried in the overflow it took two taps
      // and a read to find, which is the wrong shape for the one action you
      // reach for when something is plainly wrong on the itinerary.
      del.dataset.alwaysShow = "1";
      del.dataset.sheetLabel = "🗑  Delete";
      del.title = "Delete this item";
      del.addEventListener("click", function (ev) { ev.stopPropagation(); deleteItem(trip, cfg.kind, o); });
      links.appendChild(ed); links.appendChild(del);
    }
    if (currentChanged && currentChanged[o.id]) {
      var chPill = el("span", "changed-pill", "changed");
      b.insertBefore(chPill, b.firstChild);
    }
    // Live flight status, when the status Worker has left some. Placed before
    // everything else on the row because a cancellation is the only thing on an
    // itinerary that makes the rest of the day irrelevant.
    var lsPill = statusPill(o);
    if (lsPill && !e.isCheckout) b.insertBefore(lsPill, b.firstChild);
    // A row can carry thirteen chips — maps, website, phone, flight tracking,
    // confirmation, ticket, QR, documents, attach, nearby, edit, delete. That is
    // fine with a mouse and unusable with a thumb. On a phone keep the two you
    // actually use standing at a gate, and put the rest behind one overflow that
    // opens a labelled sheet. The buttons are MOVED, not rebuilt, so every
    // handler, closure and document link keeps working untouched.
    // A wide screen is roomier, not infinite: thirteen chips on a row is a wall
    // of icons to read past on any device, and the rows you care about are the
    // ones with the most attached. Same overflow everywhere, just a higher cap
    // where there is room — three chips on a phone, five on a desktop.
    var all = [].slice.call(links.children);
    // Anything flagged alwaysShow is pinned to the row whatever the width —
    // Edit and Delete.
    var pinned = all.filter(function (c) { return c.dataset && c.dataset.alwaysShow === "1"; });
    var loose = all.filter(function (c) { return !(c.dataset && c.dataset.alwaysShow === "1"); });
    var moreChip = function (rest) {
      var more = el("button", "linkchip more-chip", "⋯ More"); more.type = "button";
      more.addEventListener("click", function (ev) {
        ev.stopPropagation();
        openActionSheet(e.title, rest);
      });
      return more;
    };

    if (isPhone()) {
      // Exactly three chips on a phone — More, Edit, Delete — and everything
      // else behind More: Maps, Contact, reviews, tickets, documents.
      //
      // Maps used to be promoted onto the row, and the capping step only ran
      // once a row exceeded three chips, so a quiet row kept its Maps chip
      // while a busy one did not. Two layouts for the same kind of row is worse
      // than either one. The buttons are MOVED rather than rebuilt, so every
      // handler and closure survives the trip into the sheet.
      if (loose.length) {
        links.innerHTML = "";
        links.appendChild(moreChip(loose));
        pinned.forEach(function (c) { links.appendChild(c); });
      }
    } else if (links.children.length > 5) {
      // A mouse gets the first few in the order they were built. Reordering a
      // layout that already works would be a worse trade than the clutter.
      var room = Math.max(1, 5 - pinned.length);
      var keep = loose.slice(0, room), rest = loose.slice(room);
      links.innerHTML = "";
      keep.concat(pinned).forEach(function (c) { links.appendChild(c); });
      if (rest.length) links.appendChild(moreChip(rest));
    }
    if (links.children.length) b.appendChild(links);
    row.appendChild(b);

    // ---- drag to reorder within a day ----
    // Order persists via each object's sort_order. Everything defaults to 0, so
    // the list stays purely chronological until you actually drag something.
    if (cfg && !e.isCheckout) {
      row.setAttribute("draggable", "true");
      row.dataset.itemId = String(o.id);
      row.dataset.itemKind = cfg.kind;
      row.addEventListener("dragstart", function (ev) {
        row.classList.add("dragging");
        ev.dataTransfer.setData("text/plain", cfg.kind + ":" + o.id);
        ev.dataTransfer.effectAllowed = "move";
      });
      row.addEventListener("dragend", function () {
        row.classList.remove("dragging");
        $$(".itin-row.dragover").forEach(function (n) { n.classList.remove("dragover"); });
      });
      row.addEventListener("dragover", function (ev) { ev.preventDefault(); row.classList.add("dragover"); });
      row.addEventListener("dragleave", function () { row.classList.remove("dragover"); });
      row.addEventListener("drop", function (ev) {
        ev.preventDefault(); row.classList.remove("dragover");
        var payload = ev.dataTransfer.getData("text/plain");
        if (payload && payload !== cfg.kind + ":" + o.id) reorderWithin(trip, row, payload);
      });
    }

    // ---- the whole row opens the item ----
    //
    // Every control on this row already calls stopPropagation. They were all
    // written to guard a row handler that did not exist -- so the row was built
    // as though it were tappable, looked tappable, and did nothing. The only
    // way in was a 22px pencil pinned to the end of a chip row that scrolls
    // sideways on a phone.
    //
    // Check-out rows are the sharp end of it: they deliberately carry no Edit
    // chip, to avoid a second copy of the same controls on the same booking,
    // which left half the lodging rows on a trip with no way to open them at
    // all. Those are exactly the rows this fixes.
    //
    // No role or tabindex on the row. It contains real buttons, and a container
    // with role=button wrapping buttons is invalid -- screen readers flatten it
    // and you lose the controls inside. This is a pointer convenience layered
    // over the Edit chip, which stays the keyboard path and is already
    // focusable. On a check-out row the keyboard route is the check-in row for
    // the same booking, a few lines up.
    if (cfg) {
      row.classList.add("is-tappable");
      row.addEventListener("click", function () {
        // Dragging across a confirmation code to copy it is not a tap. Without
        // this, letting go of the mouse opens the editor over the text you were
        // trying to select.
        var sel = window.getSelection && window.getSelection();
        if (sel && String(sel).replace(/\s/g, "").length > 2) return;
        cfg.open();
      });
    }
    return row;
  }

  // Renumber every draggable row in the dropped-on row's day, then persist.
  async function reorderWithin(trip, targetRow, payload) {
    // Rows live inside their day's .day-rows container, so the day is the scope.
    var parent = targetRow.parentNode;
    var block = Array.prototype.slice.call(parent.children)
      .filter(function (n) { return n.dataset && n.dataset.itemId; });
    var srcIdx = block.findIndex(function (n) { return n.dataset.itemKind + ":" + n.dataset.itemId === payload; });
    var tgtIdx = block.indexOf(targetRow);
    if (srcIdx < 0 || tgtIdx < 0) return;
    var moved = block.splice(srcIdx, 1)[0];
    block.splice(tgtIdx, 0, moved);

    // One request for the whole day, not one per row.
    //
    // This awaited a PATCH per row, in sequence: eight items on a day meant
    // eight round trips one after another, with "Saving order..." on screen for
    // all of them, and a failure at row five left the day half-renumbered with
    // nothing to undo it. The server does the batch in a single transaction, so
    // it either all lands or none of it does.
    //
    // Still every row in the day, not just the two that swapped: the positions
    // are 1..n and moving one row shifts every row after it. That is cheap now
    // that it is one request.
    var order = block.map(function (n, i) {
      return { kind: n.dataset.itemKind, id: Number(n.dataset.itemId), sort_order: i + 1 };
    });
    toast("Saving order…");
    try {
      var res = await api("/v1/trip/" + trip.id + "/reorder",
        { method: "POST", body: JSON.stringify({ items: order }) });
      // The server reports what it actually changed. Fewer means a row went
      // while the drag was in flight -- the reorder that landed is still right,
      // and the redraw below shows what is really there.
      if (res && res.updated != null && res.updated < order.length) {
        toast("Order saved, but " + (order.length - res.updated) +
          " item" + (order.length - res.updated === 1 ? " was" : "s were") + " no longer there.");
      } else {
        toast("Order saved");
      }
      openTrip(trip);
    } catch (e) { toast("Couldn't save order: " + e.message); }
  }
  // ---- trip health check ----
  // Audits a trip against its own data: open-ended bookings, uncovered nights,
  // impossible or tight connections, overlaps, and missing details. Every finding
  // carries a suggested resolution, and most carry a button that opens the right
  // pre-filled form so the fix is one click away.
  var MS_H = 3600000;
  function km(aLat, aLon, bLat, bLon) {
    if (aLat == null || bLat == null) return null;
    var R = 6371, p = Math.PI / 180;
    var dLat = (bLat - aLat) * p, dLon = (bLon - aLon) * p;
    var s = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(aLat * p) * Math.cos(bLat * p) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    return R * 2 * Math.atan2(Math.sqrt(s), Math.sqrt(1 - s));
  }
  function tLabel(x) { return [x.company, x.transport_number].filter(Boolean).join(" ") || cap(x.transportation_type) || "Transport"; }
  function hrs(ms) { var h = ms / MS_H; return (h < 1 ? Math.round(h * 60) + " min" : (Math.round(h * 10) / 10) + " h"); }

  // ---- travel documents ----
  // Passport and visa expiry, kept in the account settings rather than against a
  // trip: the document outlives any one journey, and the whole point is that
  // recording it once checks every trip after it.
  //
  // Deliberately no field for the document NUMBER. The expiry date is all a date
  // comparison needs, and a passport number is the one piece of data here worth
  // stealing. Recording less means a leak of this database costs less.
  function travelDocs() {
    var d = state.me && state.me.travel_documents;
    return Array.isArray(d) ? d.filter(function (x) { return x && x.expires; }) : [];
  }
  // ---- travellers ----
  // Who you travel with, kept in account settings beside the documents so one
  // roster serves every trip.
  //
  // Deliberately NOT the `users` table. That is a list of logins and roles, and
  // three of the five people on a family trip have no reason to hold an account
  // — Jo, Robin and Casey have none today. "Who is this booking for" and "who
  // may sign in" are different questions, and conflating them would force an
  // email address onto a child just to record which seat is hers.
  //
  // `assigned_users` is left alone. It sits on all 571 bookings as an empty
  // array, a field the old app shipped and never populated; writing to it would
  // make a real assignment indistinguishable from Tripsy's leftover.
  function travellers() {
    var t = state.me && state.me.travellers;
    return Array.isArray(t) ? t.filter(function (x) { return x && x.id && x.name; }) : [];
  }
  function travellerById(id) {
    var all = travellers();
    for (var i = 0; i < all.length; i++) if (all[i].id === id) return all[i];
    return null;
  }
  function travellerName(id) { var p = travellerById(id); return p ? p.name : null; }
  // Derived from the name once, at creation, and never again — so renaming
  // "Jo" to "Jo S." keeps every seat she is already assigned to.
  function newTravellerId(name, existing) {
    var base = String(name || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "traveller";
    var id = base, n = 2;
    while (existing.some(function (x) { return x.id === id; })) id = base + "-" + (n++);
    return id;
  }
  // Who is on this trip, in roster order so a row never reshuffles between
  // renders. Unknown ids are dropped rather than drawn as ghosts.
  function tripTravellers(t) {
    var ids = (t && Array.isArray(t.travellers)) ? t.travellers : [];
    return travellers().filter(function (p) { return ids.indexOf(p.id) >= 0; });
  }

  // "6D, 6A, 6F" — one field holding a whole party, which is how 65 of the 124
  // seated flights already store it. Nothing in the data says whose is whose.
  function seatList(o) {
    return String((o && o.seat_number) || "")
      .split(/[,;\/]|\band\b/i)
      .map(function (s) { return s.trim(); })
      .filter(Boolean);
  }
  // Pairs travellers with seats: [{id, name, seat, guessed}].
  //
  // A stored assignment always wins. Failing that the seats are paired in listed
  // order, because airlines print them in passenger order — but ONLY when the
  // counts match exactly. Five seats against three travellers means the party
  // included people who are not on your roster, which is precisely what the
  // Camino flights are (Sam plus three Rosaleses), and pairing the first
  // three would put a confident wrong name beside a seat. Showing the seats
  // unassigned is the honest answer, and one tap fixes it.
  function paxOf(o, trip) {
    var stored = (o && Array.isArray(o.pax)) ? o.pax : null;
    if (stored) {
      return stored.filter(function (x) { return x && x.id; }).map(function (x) {
        return { id: x.id, name: travellerName(x.id) || x.id, seat: x.seat || "", guessed: false };
      });
    }
    var people = tripTravellers(trip), seats = seatList(o);
    if (!people.length || !seats.length || people.length !== seats.length) return [];
    return people.map(function (p, i) {
      return { id: p.id, name: p.name, seat: seats[i], guessed: true };
    });
  }

  // Who is in this room: [{id, name, room, guessed}].
  //
  // Lodging works the other way round from a flight. There is no list of room
  // numbers to pair against — a second room is a whole second booking, which is
  // how all 42 same-property same-night pairs in this database are stored — so
  // the only question is which people belong to THIS record.
  //
  // room_number was removed on 2026-08-19: empty on all 216 lodging records,
  // never going to be used, and it had two editors for one field nobody filled.
  // `x.room` is still read where stored data might carry one, and is otherwise
  // always empty.
  //
  // The guess comes from the booking's own words. Where the importer wrote
  // "Room 1 - Sam Rivera (Alex's room)" it has already answered the
  // question and reading it back beats asking again. Anything inferred stays
  // dashed and unwritten until confirmed, exactly as seats do.
  function roomPaxOf(o, trip) {
    var stored = (o && Array.isArray(o.pax)) ? o.pax : null;
    if (stored) {
      return stored.filter(function (x) { return x && x.id; }).map(function (x) {
        return { id: x.id, name: travellerName(x.id) || x.id, room: x.room || "", guessed: false };
      });
    }
    var people = tripTravellers(trip);
    if (!people.length) return [];
    var text = ["description", "provider_reservation_description", "notes", "room_type"]
      .map(function (f) { return typeof o[f] === "string" ? o[f] : ""; }).join("\n");
    if (!text.trim()) return [];
    var hit = people.filter(function (p) { return nameInText(p.name, text); });
    // Everybody named is not a room split — it is a booking that happens to
    // mention the whole party, which tells you nothing worth drawing.
    if (!hit.length || hit.length === people.length) return [];
    return hit.map(function (p) {
      return { id: p.id, name: p.name, room: "", guessed: true };
    });
  }

  // The soonest trip that has not finished — the one an expired document is
  // most urgent for. Ties break on id so two trips starting the same day always
  // pick the same winner and the finding cannot flicker between them.
  function isNextUpcomingTrip(t) {
    if (!t || !t.has_dates || !t.ends_at) return false;
    var today = new Date().toISOString().slice(0, 10);
    var soonest = null;
    (state.own || []).forEach(function (x) {
      if (!x.has_dates || !x.starts_at || !x.ends_at || x.ends_at < today) return;
      if (!soonest || x.starts_at < soonest.starts_at ||
          (x.starts_at === soonest.starts_at && x.id < soonest.id)) soonest = x;
    });
    return !!soonest && soonest.id === t.id;
  }
  function addDays(ymd, n) {
    var d = new Date(ymd + "T12:00:00Z");
    d.setUTCDate(d.getUTCDate() + n);
    return d.toISOString().slice(0, 10);
  }
  // Does this trip leave the United States? Decided from coordinates, because
  // they are the one location field almost every booking carries — addresses are
  // free text and airport codes would need a table of every airport on earth.
  //
  // Three boxes rather than a polygon: the error cases are a trip to the very
  // edge of a border, and being asked about a passport you already hold is a
  // far cheaper mistake than being told nothing before a flight to Madrid.
  // Checked against all 183 trips — 26 international, 137 domestic, and every
  // Hawaii trip correctly domestic.
  var US_BOXES = [
    [24.4, 49.4, -125.0, -66.9],      // contiguous 48
    [51.0, 71.5, -179.9, -129.0],     // Alaska
    [18.8, 22.3, -160.3, -154.7]      // Hawaii
  ];
  function tripLeavesCountry(data) {
    var pts = [];
    var put = function (la, lo) {
      if (la == null || lo == null) return;
      la = +la; lo = +lo;
      if (!isFinite(la) || !isFinite(lo)) return;
      // (0,0) is null island — what an ungeocoded booking stores, not a place in
      // the Atlantic. One taxi with no coordinates was enough to label a Kauai
      // trip international before this guard existed.
      if (Math.abs(la) < 0.01 && Math.abs(lo) < 0.01) return;
      pts.push([la, lo]);
    };
    (data.transports || []).forEach(function (x) {
      put(x.departure_latitude, x.departure_longitude);
      put(x.arrival_latitude, x.arrival_longitude);
    });
    (data.hostings || []).forEach(function (x) { put(x.latitude, x.longitude); });
    (data.activities || []).forEach(function (x) { put(x.latitude, x.longitude); });
    return pts.some(function (p) {
      return !US_BOXES.some(function (b) {
        return p[0] >= b[0] && p[0] <= b[1] && p[1] >= b[2] && p[1] <= b[3];
      });
    });
  }

  // A trip whose last day has passed. Matches how the dashboard splits Upcoming
  // from Past, so "it's in Past" and "the check went quiet" always agree.
  // Undated trips are neither, and keep every check.
  function tripIsPast(t) {
    if (!t.has_dates) return false;
    var e = toDate(t.ends_at || t.starts_at);
    if (!e) return false;
    var today = new Date(); today.setHours(0, 0, 0, 0);
    return e < today;
  }

  function auditTrip(t, data) {
    var out = [];
    var trans = (data.transports || []).slice();
    var host = (data.hostings || []).slice();
    var acts = (data.activities || []).slice();
    // Once a trip is over, findings about MISSING data are noise: no
    // confirmation number can be added to a flight already flown, and no
    // coordinate will put a past dinner back on the map. Those are marked soft
    // below and dropped here. Findings that say a record is DUPLICATED or
    // factually WRONG survive — those are worth correcting whenever you see
    // them, because they distort history, totals and the map.
    var past = tripIsPast(t);
    // Findings get a stable key so a snooze or dismissal survives a re-render.
    // Numbers are normalised out of the title, so "12 min before" and "1.2 h
    // before" are the same finding — but a genuinely different problem, or the
    // same problem on another trip, still gets its own key and reappears.
    var keyOf = function (level, title) {
      return t.id + "|" + level + "|" + String(title).toLowerCase()
        .replace(/[0-9]+(\.[0-9]+)?/g, "#").replace(/\s+/g, " ").trim();
    };
    var add = function (level, title, detail, fix, soft) {
      if (past && soft) return;
      out.push({ level: level, title: title, detail: detail, fix: fix, key: keyOf(level, title) });
    };

    // ---- A. open-ended bookings ----
    trans.forEach(function (x) {
      var isRental = /^(car|roadtrip)$/.test(x.transportation_type || "") && x.company;
      if (x.departure_at && !x.arrival_at) {
        add(isRental ? "issue" : "warn",
          (isRental ? "Car rental has no drop-off time" : tLabel(x) + " has no arrival time"),
          isRental
            ? tLabel(x) + " picks up " + fmtTime(x.departure_at, x.departure_timezone) + " but has no return date/time, so it never ends on your itinerary."
            : "Set an arrival time so the itinerary and map order correctly.",
          { label: "Set it", run: function () { editTransport(t, x); } }, true);
      }
      if (!x.departure_at) {
        add("warn", tLabel(x) + " is unscheduled", "No departure time, so it won't appear on any day.",
          { label: "Add times", run: function () { editTransport(t, x); } }, true);
      }
    });
    host.forEach(function (h) {
      if (h.starts_at && !h.ends_at) {
        add("issue", (h.name || "Lodging") + " has no check-out",
          "Open-ended stay — nothing tells you when you leave, and later nights look covered when they may not be.",
          { label: "Set check-out", run: function () { editHosting(t, h); } }, true);
      }
      // A stay that checks out on the day it checks in is worth zero nights,
      // and it says so nowhere. Found across 15 stays of 218, and the shape is
      // consistent enough to name: the check-IN carries the check-OUT's date,
      // so a one-night stay collapses to none. Alila Marea sat on 28 February
      // inside a trip running 27–28 February; Hyatt Place Peña Station on
      // 27 March inside 26–27 March; the same for Kimpton La Peer and the
      // Courtyard in Pasadena.
      //
      // NOT soft, so it survives on past trips — the rule the older findings
      // already follow. A missing confirmation number on a flown flight is
      // noise, but this one distorts totals that are still being read: it
      // leaves the night out of every count, makes the lodging-gap check below
      // report the night as uncovered when a hotel was in fact booked, and it
      // silently withheld night credit from a loyalty goal. Two of the fifteen
      // are in this calendar year and did exactly that.
      if (h.starts_at && h.ends_at &&
          dayKey(h.starts_at, h.timezone) === dayKey(h.ends_at, h.timezone)) {
        add("issue", (h.name || "Lodging") + " checks out the day it checks in",
          "Zero nights, so this stay counts for nothing — it is missing from night totals, " +
          "the night before may be reported as having no lodging, and loyalty night credit " +
          "does not see it. If it was a one-night stay, the check-in belongs a day earlier.",
          { label: "Fix the dates", run: function () { editHosting(t, h); } });
      }
    });

    // ---- B. nights with no lodging ----
    if (t.has_dates && t.starts_at && t.ends_at) {
      var nights = [];
      var d0 = new Date(t.starts_at + "T12:00:00Z"), d1 = new Date(t.ends_at + "T12:00:00Z");
      for (var d = new Date(d0); d < d1; d.setUTCDate(d.getUTCDate() + 1)) nights.push(d.toISOString().slice(0, 10));
      var covered = {};
      host.forEach(function (h) {
        if (!h.starts_at) return;
        var s = dayKey(h.starts_at, h.timezone);
        var e = h.ends_at ? dayKey(h.ends_at, h.timezone) : s;
        for (var x = new Date(s + "T12:00:00Z"); x.toISOString().slice(0, 10) < e; x.setUTCDate(x.getUTCDate() + 1)) {
          covered[x.toISOString().slice(0, 10)] = true;
        }
      });
      // A night spent in the air on a red-eye is legitimately uncovered — don't
      // report it. Treat a night as "travelled through" if any transport is en
      // route across the middle of it.
      var overnight = function (n) {
        var mid = Date.parse(n + "T00:00:00Z") + 26 * MS_H;      // ~02:00 the following night
        var lo = mid - 5 * MS_H, hi = mid + 5 * MS_H;
        return trans.some(function (x) {
          if (!x.departure_at || !x.arrival_at) return false;
          var s = Date.parse(x.departure_at), e = Date.parse(x.arrival_at);
          return s < hi && e > lo;
        });
      };
      var gaps = nights.filter(function (n) { return !covered[n] && !overnight(n); });
      if (gaps.length && host.length) {
        add("issue", gaps.length === 1 ? "One night with no lodging" : gaps.length + " nights with no lodging",
          "No booking covers " + gaps.slice(0, 4).map(function (g) { return dayLabel(g); }).join(", ") +
          (gaps.length > 4 ? " and " + (gaps.length - 4) + " more" : "") + ".",
          { label: "Add lodging", run: function () { openItemForm(t, "hosting", null); } }, true);
      }
    }

    // ---- C. flight connections & routing ----
    var flights = trans.filter(function (x) { return x.transportation_type === "airplane" && x.departure_at; })
      .sort(function (a, b) { return new Date(a.departure_at) - new Date(b.departure_at); });
    for (var i = 0; i < flights.length - 1; i++) {
      var a = flights[i], b = flights[i + 1];
      if (!a.arrival_at || !b.departure_at) continue;
      var gap = new Date(b.departure_at) - new Date(a.arrival_at);
      if (gap < 0) {
        add("issue", "Impossible connection: " + tLabel(a) + " → " + tLabel(b),
          tLabel(b) + " departs before " + tLabel(a) + " lands. One of these times or dates is wrong.",
          { label: "Check times", run: function () { editTransport(t, b); } });
      } else if (gap < 24 * MS_H) {
        var sameAirport = (a.arrival_description || "") === (b.departure_description || "");
        if (sameAirport && gap < 60 * 60000) {
          add("warn", "Tight connection at " + (a.arrival_description || "the airport"),
            "Only " + hrs(gap) + " between landing and your next departure. International connections usually need 90 minutes or more.",
            null, true);
        }
        if (!sameAirport && a.arrival_description && b.departure_description) {
          var dist = km(a.arrival_latitude, a.arrival_longitude, b.departure_latitude, b.departure_longitude);
          var hasTransfer = trans.some(function (x) {
            return x.transportation_type !== "airplane" && x.departure_at &&
              new Date(x.departure_at) >= new Date(a.arrival_at) && new Date(x.departure_at) <= new Date(b.departure_at);
          });
          if (dist != null && dist > 5 && !hasTransfer) {
            add("warn", "Airport change with no transfer booked",
              "You land at " + a.arrival_description + " but depart from " + b.departure_description +
              " (~" + fmtDistance(dist) + " apart), with " + hrs(gap) + " in between and no ground transport on the itinerary.",
              { label: "Add transfer", run: function () { openItemForm(t, "transport", null); } }, true);
          }
        }
      }
    }
    // return-leg check: does the last flight land where the first one departed?
    if (flights.length && t.has_dates) {
      var first = flights[0], last = flights[flights.length - 1];
      if (first.departure_description && last.arrival_description &&
          first.departure_description !== last.arrival_description && flights.length < 6) {
        add("info", "No return to " + first.departure_description,
          "Your trip starts at " + first.departure_description + " but the last flight lands at " +
          last.arrival_description + ". If you're flying home, that leg isn't booked yet.",
          { label: "Add flight", run: function () { openItemForm(t, "transport", null); } }, true);
      }
    }

    // ---- C2. hire car / parking vs the flight you're catching ----
    // Dropping a rental at the terminal still takes shuttle + counter time, so a
    // return that lands almost on top of departure isn't achievable.
    trans.filter(function (x) { return /^(car|bike|motorcycle)$/.test(x.transportation_type || "") && x.arrival_at; })
      .forEach(function (car) {
        var ret = new Date(car.arrival_at);
        var next = flights.filter(function (f) { return new Date(f.departure_at) >= ret; })
          .sort(function (a, b) { return new Date(a.departure_at) - new Date(b.departure_at); })[0];
        if (!next) {
          // Nothing departs after the return — so the car is still out after the
          // final flight has gone. Almost always an off-by-one on the return date.
          var lastF = flights[flights.length - 1];
          if (lastF && lastF.departure_at && ret > new Date(lastF.departure_at)) {
            add("issue", (car.company || "Hire car") + " is returned after you've flown home",
              "The car is booked back at " + fmtTime(car.arrival_at, car.arrival_timezone) + " on " +
              dayLabel(dayKey(car.arrival_at, car.arrival_timezone)) + ", but " + tLabel(lastF) + " leaves " +
              dayLabel(dayKey(lastF.departure_at, lastF.departure_timezone)) + " at " +
              fmtTime(lastF.departure_at, lastF.departure_timezone) +
              " — you'd already be home. Check the rental agreement: the return is usually a day earlier than this.",
              { label: "Fix return", run: function () { editTransport(t, car); } });
          }
          return;
        }
        var lead = new Date(next.departure_at) - ret;
        if (lead <= 90 * 60000) {
          add(lead < 30 * 60000 ? "issue" : "warn",
            (car.company || "Hire car") + " drop-off is only " + hrs(lead) + " before " + tLabel(next) + " departs",
            "You return the car at " + fmtTime(car.arrival_at, car.arrival_timezone) + " and " + tLabel(next) +
            " leaves at " + fmtTime(next.departure_at, next.departure_timezone) +
            ". Returning a rental means the drop-off lot, a shuttle and bag drop — move the return about two hours earlier, or check what the rental agreement actually says.",
            { label: "Adjust return", run: function () { editTransport(t, car); } }, true);
        }
      });
    // The other direction: collecting a hire car before the flight bringing you
    // there has landed. Found on a real trip by the importer's reconciliation
    // pass while this check only looked at returns.
    trans.filter(function (x) { return /^(car|bike|motorcycle)$/.test(x.transportation_type || "") && x.departure_at; })
      .forEach(function (car) {
        var pick = new Date(car.departure_at);
        var inbound = flights.filter(function (f) {
          return f.arrival_at && new Date(f.departure_at) < pick;
        }).sort(function (a, b) { return new Date(b.arrival_at) - new Date(a.arrival_at); })[0];
        if (!inbound) return;
        var lead = pick - new Date(inbound.arrival_at);
        if (lead < 0) {
          add("issue", (car.company || "Hire car") + " is collected before you land",
            "Pick-up is " + fmtTime(car.departure_at, car.departure_timezone) + " but " + tLabel(inbound) +
            " doesn't land until " + fmtTime(inbound.arrival_at, inbound.arrival_timezone) +
            " — you'd still be in the air. Move it to roughly 45 minutes after landing to allow for deplaning, bags and the counter.",
            { label: "Fix pick-up", run: function () { editTransport(t, car); } });
        } else if (lead < 30 * 60000) {
          add("warn", (car.company || "Hire car") + " pick-up is only " + hrs(lead) + " after landing",
            "That leaves no room for deplaning, bags or the rental shuttle.",
            { label: "Adjust pick-up", run: function () { editTransport(t, car); } }, true);
        }
      });

    // Airport parking that ends before you land — you'd have no car to collect.
    acts.filter(function (x) { return x.activity_type === "parking" && x.ends_at; }).forEach(function (p) {
      var back = flights.filter(function (f) { return f.arrival_at; })
        .sort(function (a, b) { return new Date(b.arrival_at) - new Date(a.arrival_at); })[0];
      if (!back) return;
      if (new Date(p.ends_at) < new Date(back.arrival_at)) {
        add("warn", (p.name || "Parking") + " ends before you land",
          "Parking runs out at " + fmtTime(p.ends_at, p.timezone) + " but " + tLabel(back) +
          " doesn't land until " + fmtTime(back.arrival_at, back.arrival_timezone) + ". Extend it or you'll overrun the booking.",
          { label: "Extend parking", run: function () { editActivity(t, p); } }, true);
      }
    });

    // ---- D. overlaps ----
    //
    // Two stays running at once is only a mistake when they are two DIFFERENT
    // hotels. The same hotel twice over the same nights is a second room, which
    // in this house is ordinary: measured across all 182 trips, this rule fired
    // 40 times and every single one was a second room -- 27 with identical
    // dates, 13 differing by an hour or a day because the two confirmations
    // were typed up separately. Different hotels genuinely overlapping: zero,
    // ever.
    //
    // So the old wording -- "one may be a duplicate" -- was wrong 40 times out
    // of 40, and it was wrong twice on a trip that was being travelled at the
    // time. A rule that is usually wrong does not ship. The check is kept for
    // the case it was written for, which has simply never happened yet.
    //
    // Names are compared normalised. A missing name on either side means we
    // cannot establish they are different places, and silence beats a warning
    // we cannot stand behind.
    var stays = host.filter(function (h) { return h.starts_at && h.ends_at; })
      .sort(function (x, y) { return new Date(x.starts_at) - new Date(y.starts_at); });
    stays.forEach(function (first, i) {
      var second = stays[i + 1];
      if (!clashingStays(first, second)) return;
      add("warn", "Two hotels booked at once",
        (first.name || "A stay") + " and " + (second.name || "another") +
        " overlap. If you moved hotels, shorten the first one.",
        // forEach rather than a C-style loop on purpose: `var s2` was shared by
        // every closure here, so each Review button opened whichever stay the
        // loop happened to stop on rather than the one it was reporting.
        { label: "Review", run: function () { editHosting(t, first); } });
    });
    // Activities during a flight used to be checked here against departure and
    // arrival times alone. That rule now lives in feasibility.js, which decides
    // the same question from a position model and so also catches the case this
    // one could not see: a HOTEL whose check-in falls while you are airborne.

    // ---- D2. the same cost entered twice ----
    //
    // Costs live on expenses. The nine bookings that predated that decision
    // were moved into linked expenses on 2026-08-19 and the forms no longer
    // offer a price, so nothing should carry one -- but nothing enforces that
    // at the API, and the way a price turns into a wrong total is an expense
    // added for the very same charge: the hotel folio logged as an expense
    // while the room rate still sits on the stay.
    //
    // The signal is the AMOUNT, not the link. A linked expense is usually an
    // extra: a baggage fee belongs to a flight and a resort fee to a room, and
    // both are real money on top of the fare. Two figures that match to the
    // penny, on the same booking, are one charge written down twice.
    //
    // Measured before shipping: across all 182 trips this fires zero times,
    // and after the migration there is nothing left for it to fire on. It is a
    // guard on a real future mistake, not a rule that disagrees with the data.
    (function () {
      var priced = {};
      host.forEach(function (h) { if (Number(h.price)) priced["hosting:" + h.id] = h; });
      trans.forEach(function (x) { if (Number(x.price)) priced["transport:" + x.id] = x; });
      acts.forEach(function (a) { if (Number(a.price)) priced["activity:" + a.id] = a; });
      (data.expenses || []).forEach(function (x) {
        if (!x || !x.linked_kind || x.linked_id == null) return;
        // A credit matching the booking's price is a full refund -- the exact
        // opposite of one charge written twice -- and must not trip this.
        if (x.category === CREDIT_CAT) return;
        var b = priced[x.linked_kind + ":" + x.linked_id];
        if (!b) return;
        var amt = Number(x.price != null ? x.price : x.amount) || 0;
        if (!amt || Number(b.price) !== amt) return;
        add("warn", "This cost may be counted twice",
          (x.title || x.name || "An expense") + " and the booking it is linked to both say " +
          money(amt, x.currency || priceCurrency(b) || "USD") +
          ". If they are the same charge, clear the price on the booking — the expense is the one that keeps the receipt.",
          { label: "Open the expense", run: function () { editExpense(t, x); } });
      });
    })();

    // ---- E. items outside the trip's own dates ----
    if (t.has_dates && t.starts_at && t.ends_at) {
      var strays = [];
      var check = function (when, tz, name) {
        if (!when) return;
        var k = dayKey(when, tz);
        if (k < t.starts_at || k > t.ends_at) strays.push(name + " (" + dayLabel(k) + ")");
      };
      trans.forEach(function (x) { check(x.departure_at, x.departure_timezone, tLabel(x)); });
      host.forEach(function (h) { check(h.starts_at, h.timezone, h.name || "Lodging"); });
      acts.forEach(function (x) { check(x.starts_at, x.timezone, x.name || "Activity"); });
      if (strays.length) {
        add("info", strays.length + (strays.length === 1 ? " item falls" : " items fall") + " outside the trip dates",
          strays.slice(0, 3).join(", ") + (strays.length > 3 ? "…" : "") +
          ". Either the trip's dates need widening or an item is on the wrong day.",
          { label: "Edit trip dates", run: function () { editTripDetails(t); } });
      }
    }

    // ---- F. missing details ----
    var noConf = [].concat(
      flights.filter(function (x) { return !x.provider_reservation_code; }).map(tLabel),
      host.filter(function (h) { return !h.provider_reservation_code; }).map(function (h) { return h.name || "Lodging"; })
    );
    if (noConf.length) {
      add("info", noConf.length + " booking" + (noConf.length === 1 ? "" : "s") + " without a confirmation number",
        noConf.slice(0, 4).join(", ") + (noConf.length > 4 ? "…" : "") + ". Worth adding before you travel — it's what you need at the desk.",
        null, true);
    }
    // ---- items that do not say where they are ----
    //
    // The rule, set 2026-08-19: every item on a trip that has not happened yet
    // carries an address, or coordinates, or the "No location" box ticked.
    //
    // It is a warning rather than a note because it is a standing requirement
    // with an action attached, and soft so it disappears once the trip is over
    // — no coordinate will put a past dinner back on the map, and a panel that
    // nags about history teaches you to close it.
    //
    // Measured before shipping, across every upcoming trip: 41 activities and
    // stays, of which 2 lack both — and both are notes, which are exempt by
    // nature. All 13 transportations already carry both ends. So this starts at
    // zero and exists to catch the next thing added, which is the point.
    var placeless = [].concat(
      acts.filter(function (x) { return !hasPlace(x, "activity"); })
        .map(function (x) { return x.name || "Activity"; }),
      host.filter(function (x) { return !hasPlace(x, "hosting"); })
        .map(function (x) { return x.name || "Lodging"; }),
      trans.filter(function (x) { return !hasPlace(x, "transport"); })
        .map(tLabel)
    );
    if (placeless.length) {
      add("warn", placeless.length + " item" + (placeless.length === 1 ? "" : "s") + " with no location",
        placeless.slice(0, 4).join(", ") + (placeless.length > 4 ? "…" : "") +
        (placeless.length === 1 ? " has" : " have") + " no address and no coordinates, so " +
        (placeless.length === 1 ? "it cannot be" : "they cannot be") +
        " mapped and the drives either side cannot be worked out. " +
        "Add an address or use “🔎 Find” — or tick “No location” in the edit form if there genuinely isn't one.",
        // Offered only when something here is worth looking up.
        // tripPlaceless excludes notes and parking, so a trip whose only
        // placeless items are those still gets the warning but not a
        // button that would open an empty dialog.
        (function () {
          var can = tripPlaceless(data);
          if (!can.length) return null;
          return {
            label: "Find " + can.length + (can.length === 1 ? " location" : " locations"),
            run: function () {
              openFindTripLocations(t, data, function () { loadAll(); openTrip(t); });
            },
          };
        })(),
        true);
    }

    // A separate, softer point: an address is enough to satisfy the rule above,
    // but only coordinates draw the pin and the route. Nothing geocodes at
    // render, so an address on its own leaves the item off the map.
    //
    // Deliberately narrowed to items that HAVE an address, or it would repeat
    // everything the check above just said in a quieter voice.
    var addressOnly = [].concat(
      acts.filter(function (x) {
        return x.activity_type !== "note" && x.latitude == null && hasText(x.address) && !x.no_location;
      }).map(function (x) { return x.name || "Activity"; }),
      host.filter(function (x) {
        return x.latitude == null && hasText(x.address) && !x.no_location;
      }).map(function (x) { return x.name || "Lodging"; })
    );
    if (addressOnly.length) {
      add("info", addressOnly.length + " item" + (addressOnly.length === 1 ? "" : "s") + " not on the map",
        addressOnly.slice(0, 4).join(", ") + (addressOnly.length > 4 ? "…" : "") +
        (addressOnly.length === 1 ? " has an address but no coordinates" : " have addresses but no coordinates") +
        ", so nothing marks the spot and no drive is drawn to " +
        (addressOnly.length === 1 ? "it" : "them") + ". Use “🔎 Find” in the edit form to fill them in.",
        null, true);
    }

    // ---- days whose journey cannot be worked out ----
    //
    // The itinerary now draws the drive between one place and the next: out from
    // the hotel in the morning, between the places you are going, back at the
    // end. One item without coordinates breaks the chain either side of it, and
    // the failure is SILENT — a missing line looks exactly like a short walk.
    //
    // So the days it happens on are named. This is the one check that exists to
    // make you fill something in, which is why it says which day as well as
    // which item: "Walking tour" is easier to place when you know it is Tuesday.
    var journeyGaps = {};
    (function () {
      var byDay = {};
      [].concat(
        acts.filter(function (x) { return x.activity_type !== "note" && x.starts_at; })
          .map(function (x) { return { o: x, when: x.starts_at, tz: x.timezone, name: x.name || "Activity" }; }),
        host.filter(function (x) { return x.starts_at; })
          .map(function (x) { return { o: x, when: x.starts_at, tz: x.timezone, name: x.name || "Lodging" }; })
      ).forEach(function (i) {
        var k = dayKey(i.when, i.tz);
        if (!k) return;
        (byDay[k] = byDay[k] || []).push(i);
      });
      Object.keys(byDay).forEach(function (k) {
        // A day with one located thing and nothing else has no journey to lose.
        if (byDay[k].length < 2 && !lodgingWokeIn(k, data)) return;
        byDay[k].forEach(function (i) {
          if (i.o.latitude == null) (journeyGaps[i.name] = journeyGaps[i.name] || []).push(k);
        });
      });
    })();
    // NOT CHECKED: an activity sharing a lodging's coordinates.
    //
    // Built, measured, deleted the same day. The theory was that a geocode
    // which fell back to the booking's own address reads as valid data and
    // fails silently — the distance is zero, no leg is drawn, and the day looks
    // like you never left. The Arenal safari float looked exactly like that.
    //
    // Across all 183 trips it fires 43 times, and every one of them is a hotel
    // restaurant or spa correctly recorded at its hotel: 8100 Mountainside at
    // the Park Hyatt Beaver Creek thirteen times over, Teppan Grill at the
    // Hyatt Regency Mexico City, Pur' at the Park Hyatt Paris, SPA TIME at the
    // Waldorf Los Cabos. The premise was simply wrong — a hotel restaurant IS
    // at the hotel's coordinates, to the metre, legitimately.
    //
    // The float turned out to be a hotel pickup too, so the case that motivated
    // it was not a fault either. A rule that is wrong every time it fires
    // teaches you to ignore the panel it lives in.

    var gapNames = Object.keys(journeyGaps);
    if (gapNames.length) {
      var when = gapNames.slice(0, 3).map(function (n) {
        return n + " (" + dayLabel(journeyGaps[n][0]) + ")";
      }).join(", ");
      add("info", "No drive times on " + gapNames.length + " " + (gapNames.length === 1 ? "day" : "days"),
        when + (gapNames.length > 3 ? " and " + (gapNames.length - 3) + " more" : "") +
        (gapNames.length === 1 ? " has" : " have") + " no coordinates, so the itinerary cannot say how " +
        "long it takes to get there or back. Add an address and it will fill itself in.",
        null, true);
    }
    // A seat you haven't picked five months out is not a defect. Airlines
    // often haven't released the map that far ahead, and award tickets
    // frequently assign only at check-in — Alaska AS1412 to Liberia sat
    // unassigned for five of the five and a half months before departure, and
    // the confirmation itself shows the seat field blank for all five
    // travellers. Asking then is noise; asking near departure is useful.
    //
    // Bounding it by time rather than dismissing it means the question puts
    // itself away now and comes back on its own once it can be acted on. No
    // saved dismissal to remember, and nothing device-specific — a dismissal in
    // the browser would not have followed him to the phone anyway.
    var SEAT_WINDOW_DAYS = 30;
    var seatCutoff = Date.now() + SEAT_WINDOW_DAYS * 86400000;
    var noSeat = flights.filter(function (x) {
      return !x.seat_number && x.departure_at && Date.parse(x.departure_at) <= seatCutoff;
    }).map(tLabel);
    if (noSeat.length && flights.length) {
      add("info", noSeat.length + " flight" + (noSeat.length === 1 ? "" : "s") + " without a seat",
        noSeat.slice(0, 4).join(", ") + (noSeat.length > 4 ? "…" : "") +
        " — inside " + SEAT_WINDOW_DAYS + " days of departure and still unassigned.",
        null, true);
    }
    var priceNoCur = [].concat(trans, host, acts).filter(function (x) { return x.price && !x.currency; });
    if (priceNoCur.length) {
      add("info", priceNoCur.length + " priced item" + (priceNoCur.length === 1 ? "" : "s") + " without a currency",
        "These are left out of the converted budget total.",
        null, true);
    }

    // ---- F2. travel documents ----
    // The one failure this app could not warn about that ends a trip at the
    // check-in desk rather than inconveniencing it. Everything else here is
    // recoverable on the day; an expired passport is not.
    //
    // Only fires on trips that leave the country, and only against documents you
    // have actually recorded — an empty list stays quiet apart from one soft
    // nudge, because a check that fires on all 26 international trips at once
    // teaches you to stop reading the panel.
    if (t.has_dates && t.ends_at && !past) {
      var intl = tripLeavesCountry({ transports: trans, hostings: host, activities: acts });
      // Only the people actually going. Jo's passport is not this trip's
      // problem if Jo is not on it.
      //
      // The fallback matters as much as the rule: when nobody has been marked,
      // every document is still checked. Membership is opt-in and most trips
      // have none yet, so filtering on an empty list would silence the whole
      // check on exactly the trips nobody has curated — the ones most likely to
      // be forgotten. A document whose name matches nobody on the roster is
      // kept too, since it cannot be attributed either way.
      var going = tripTravellers(t);
      var docs = travelDocs();
      if (going.length) {
        var names = {};
        going.forEach(function (p) { names[p.name.toLowerCase()] = true; });
        var known = {};
        travellers().forEach(function (p) { known[p.name.toLowerCase()] = true; });
        docs = docs.filter(function (d) {
          var who = String(d.who || "").trim().toLowerCase();
          return !who || names[who] || !known[who];
        });
      }
      var ends = t.ends_at;
      if (intl && !docs.length) {
        add("info", "No travel documents on file",
          "This trip leaves the country and nothing records when your passport expires. Add it once in Settings and every future international trip gets checked automatically.",
          null, true);
      }
      docs.forEach(function (d) {
        if (!d.expires) return;
        var who = d.who ? d.who + "'s " : "";
        var kind = d.kind || "document";
        var isPassport = /passport/i.test(kind);
        // Six months of validity beyond the date you leave is the common
        // entry requirement — not universal, which is why it warns rather
        // than blocks, but it is refused at the gate often enough to matter.
        var sixMonthsOut = addDays(ends, 182);
        if (d.expires < t.starts_at) {
          // An already-expired document is a fact about the document, not about
          // any one trip — saying it on all seven upcoming trips says the same
          // thing seven times and buries the findings that ARE trip-specific.
          // It belongs on the trip you are about to take, which is also where
          // you would act on it. The two rules below stay per-trip because they
          // genuinely depend on the dates.
          if (!isNextUpcomingTrip(t)) return;
          add(isPassport && intl ? "issue" : "warn",
            who + kind + " has expired",
            "It expired " + dayLabel(d.expires) + ", before this trip even starts." +
            (isPassport && intl ? " You will not be allowed to board." : "") +
            " Shown on your next trip only, so it isn't repeated on every one.",
            null, true);
        } else if (d.expires <= ends) {
          add(intl ? "issue" : "warn",
            who + kind + " expires during this trip",
            "It runs out " + dayLabel(d.expires) + " and the trip ends " + dayLabel(ends) +
            (intl ? ". You would be abroad with an expired document and unable to fly home on it." : "."),
            null, true);
        } else if (isPassport && intl && d.expires < sixMonthsOut) {
          add("warn",
            who + "passport expires within six months of this trip",
            "It runs out " + dayLabel(d.expires) + ", which is less than six months after you return on " +
            dayLabel(ends) + ". Many countries refuse entry on a passport with under six months left — check the rule for where you're going, and renew if it applies.",
            null, true);
        }
      });
    }

    // ---- F3. travel insurance ----
    // A policy that lapses mid-trip is worth as much as no policy at all, and
    // the date it lapses is buried in a PDF nobody opens. Same reasoning as the
    // passport check above, and the same restraint: it only speaks about
    // policies you have actually recorded, except for one soft nudge abroad.
    if (t.has_dates && t.starts_at && t.ends_at && !past) {
      var pols = insuranceOf({ activities: acts });
      var abroad = tripLeavesCountry({ transports: trans, hostings: host, activities: acts });
      pols.forEach(function (p) {
        var who = p.name || "Travel insurance";
        var cvEnd = p.ends_at ? dayKey(p.ends_at, p.timezone) : "";
        var cvStart = p.starts_at ? dayKey(p.starts_at, p.timezone) : "";
        if (cvEnd && cvEnd < t.ends_at) {
          add("issue", who + " runs out before the trip ends",
            "Cover ends " + dayLabel(cvEnd) + " but the trip runs to " + dayLabel(t.ends_at) +
            ". The last " + Math.round((Date.parse(t.ends_at) - Date.parse(cvEnd)) / 86400000) +
            " day(s) are uninsured.",
            { label: "Open policy", run: function () { editActivity(t, p); } });
        }
        if (cvStart && cvStart > t.starts_at) {
          add("issue", who + " does not start until after the trip does",
            "Cover begins " + dayLabel(cvStart) + " but you leave " + dayLabel(t.starts_at) + ".",
            { label: "Open policy", run: function () { editActivity(t, p); } });
        }
        if (!contactsFor(p).phone) {
          add("info", who + " has no assistance number",
            "The 24-hour line is the one number worth having on a policy, and it is not recorded.",
            { label: "Add it", run: function () { editActivity(t, p); } }, true);
        }
      });
      if (abroad && !pols.length) {
        add("info", "No travel insurance recorded",
          "This trip leaves the country and no policy is on file. If you are covered — by a card, a plan or a standalone policy — adding it here puts the policy number and assistance line in the dossier.",
          { label: "Add one", run: function () { openItemForm(t, "activity", null); } }, true);
      }
    }

    // ---- G. physical feasibility ----
    // Everything above compares two bookings of the same kind. feasibility.js
    // instead works out where you ARE at each moment and asks whether the next
    // thing is possible from there — which is the only way to catch a hotel
    // check-in recorded at the property's 3pm policy time when your flight
    // doesn't land until 6:25pm. Shared verbatim with tools/audit-feasibility.js
    // so a sweep of the whole database and this panel can never disagree.
    if (window.WayfarerFeasibility) {
      var byRef = {};
      trans.forEach(function (x) { byRef["transport:" + x.id] = x; });
      host.forEach(function (x) { byRef["hosting:" + x.id] = x; });
      acts.forEach(function (x) { byRef["activity:" + x.id] = x; });
      window.WayfarerFeasibility
        .audit({ trip: t, transports: trans, hostings: host, activities: acts })
        .forEach(function (f) {
          var item = f.ref ? byRef[f.ref.kind + ":" + f.ref.id] : null;
          var fixes = [];
          if (item) {
            fixes.push({
              label: "Open",
              run: function () {
                if (f.ref.kind === "hosting") editHosting(t, item);
                else if (f.ref.kind === "activity") editActivity(t, item);
                else editTransport(t, item);
              }
            });
          }
          // A computed arrival time is only offered where it was derived from
          // real legs — never as a blind default.
          if (item && f.suggest && f.suggest.at && f.ref.kind === "hosting") {
            fixes.push({
              label: "Set to " + f.suggest.local,
              run: function () { applySuggestedTime(t, f.ref.kind, item, f.suggest); }
            });
          }
          add(f.level, f.title, f.detail, fixes.length ? fixes : null, f.soft);
        });
    }

    var rank = { issue: 0, warn: 1, info: 2 };
    out.sort(function (x, y) { return rank[x.level] - rank[y.level]; });
    return out;
  }

  // Write back a time the feasibility check worked out from the itinerary. The
  // original is left in the notes, because "the hotel says 3pm" is still true
  // and worth keeping even though it isn't when you'll arrive.
  async function applySuggestedTime(t, kind, item, suggest) {
    var was = fmtTime(item[suggest.field], item.timezone);
    if (!window.confirm("Change " + (item.name || "this item") + " to " + suggest.local + "?\n\n" +
      "Currently " + was + ". The original time will be noted on the booking.")) return;
    try {
      var body = {};
      body[suggest.field] = suggest.at;
      var note = "Property check-in from confirmation: " + was + ".";
      body.notes = item.notes ? item.notes + "\n" + note : note;
      await api("/v1/trip/" + t.id + "/" + kind + "/" + item.id,
        { method: "PATCH", body: JSON.stringify(body) });
      toast("Updated to " + suggest.local); loadAll(); openTrip(t);
    } catch (e) { toast("Couldn't update: " + e.message); }
  }

  // The trip's own details -- the one thing on this screen that could not be
  // edited.
  //
  // Every child object has a pinned edit control, the type is a one-click
  // toggle and the cover has its own chip, but the trip's name, dates, timezone
  // and description were fixed at creation. The only way to change a date was
  // to deliberately break the trip -- add an item outside the range so the trip
  // check would offer "Edit trip dates" -- which is an absurd route to a
  // routine correction. The importer names most trips and infers their dates,
  // so fixing one is ordinary: a two-night stay that turns out to be one night
  // is a Tuesday, not an exception.
  //
  // Same fields and same rules as creating a trip, so the two cannot drift.
  function editTripDetails(t) {
    var dated = !!t.has_dates;
    formDialog("Edit “" + clipName(t.name || "trip", 40) + "”", [
      { name: "name", label: "Trip name", value: t.name || "" },
      { name: "timezone", label: "Main timezone", type: "select", value: t.timezone || "", options: tzOptions() },
      { name: "starts_at", label: "Starts", type: "date", value: dated ? (t.starts_at || "") : "" },
      { name: "ends_at", label: "Ends", type: "date", value: dated ? (t.ends_at || "") : "" },
      { name: "number_of_days", label: "Or, days (leave dates blank)", type: "number",
        value: dated ? "" : (t.number_of_days || "") },
      { name: "description", label: "Description", type: "textarea", value: t.description || "" }
    ], async function (v) {
      if (!v.name.trim()) throw new ApiError("A trip needs a name.", 0);
      var hasBoth = !!(v.starts_at && v.ends_at);
      if (hasBoth && v.ends_at < v.starts_at) throw new ApiError("The end date is before the start date.", 0);
      if (!hasBoth && !v.number_of_days) throw new ApiError("Give either both dates or a number of days.", 0);
      var body = {
        name: v.name.trim(),
        timezone: v.timezone,
        description: v.description || "",
        has_dates: hasBoth
      };
      if (hasBoth) { body.starts_at = v.starts_at; body.ends_at = v.ends_at; }
      else { body.number_of_days = Number(v.number_of_days); }
      var saved = await api("/v1/trip/" + t.id, { method: "PATCH", body: JSON.stringify(body) });
      // The dashboard card and the open panel have to end up on the SAME
      // object, or the card keeps showing the old dates until the next full
      // load. The PATCH returns the hydrated row; the merge is the fallback.
      var fresh = (saved && saved.id) ? saved : Object.assign({}, t, body);
      state.own = (state.own || []).map(function (x) { return x.id === t.id ? fresh : x; });
      current = fresh;
      render();
      toast("Trip updated");
      // Deliberately a full reload rather than a data-reusing redraw: changing
      // the dates changes which day every item falls under, so the itinerary
      // has to be rebuilt from scratch.
      openTrip(fresh);
    }, true);
  }

  // ---- snoozed / dismissed trip checks ----
  // Server-backed, so a dismissal on the desktop is already gone on the phone.
  //
  // Three layers, and the order matters:
  //   1. `checkMap` in memory — the only thing reads touch, because
  //      renderHealth() is synchronous and cannot await a fetch mid-render.
  //   2. localStorage — an offline cache, so the first paint after a cold start
  //      (or on a plane) shows the right thing before the network answers.
  //   3. D1 via /v1/checkstate — the truth, one row per finding.
  //
  // Writes are optimistic: memory and cache update immediately so the UI never
  // waits, then the request goes out. A failed write is queued rather than lost,
  // which is the case that matters — the panel is most useful in an airport,
  // which is exactly where the connection is worst.
  var CHECK_STATE_KEY = "wayfarer_check_state_v1";
  var CHECK_QUEUE_KEY = "wayfarer_check_queue_v1";
  var SNOOZE_DAYS = 14;
  var checkMap = {};

  function readCache(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key) || "null") || fallback; } catch (e) { return fallback; }
  }
  function writeCache(key, v) {
    try { localStorage.setItem(key, JSON.stringify(v)); } catch (e) {}
  }
  function cacheCheckMap() { writeCache(CHECK_STATE_KEY, checkMap); }

  // Pull the server's rows and adopt them, then replay anything that failed to
  // send earlier so a queued write still wins over the state it was made from.
  var CHECK_MIGRATED_KEY = "wayfarer_check_migrated_v1";

  async function loadCheckState() {
    var local = readCache(CHECK_STATE_KEY, {});
    checkMap = local;
    try {
      // One-time hand-up of whatever this device already had. Without it the
      // first load after the change would fetch an empty server list, overwrite
      // the local map with it, and silently throw away every snooze and
      // dismissal made before today — on each device, the first time it opens.
      if (!localStorage.getItem(CHECK_MIGRATED_KEY)) {
        var keys = Object.keys(local);
        for (var i = 0; i < keys.length; i++) {
          var e = local[keys[i]];
          await api("/v1/checkstate", {
            method: "PUT",
            body: JSON.stringify({ key: keys[i], mode: e.mode, until: e.until || null })
          });
        }
        try { localStorage.setItem(CHECK_MIGRATED_KEY, String(Date.now())); } catch (e2) {}
      }

      var res = await api("/v1/checkstate");
      var next = {};
      (res.results || []).forEach(function (r) {
        next[r.key] = r.mode === "snoozed" ? { mode: "snoozed", until: r.until } : { mode: "dismissed" };
      });
      checkMap = next;
      cacheCheckMap();
    } catch (e) {
      // Offline, or the endpoint is not deployed yet. The cache stands in, and
      // the migration flag stays unset so it is retried on the next load.
    }
    await flushCheckQueue();
  }

  async function flushCheckQueue() {
    var q = readCache(CHECK_QUEUE_KEY, []);
    if (!q.length) return;
    var left = [];
    for (var i = 0; i < q.length; i++) {
      try {
        await api("/v1/checkstate", { method: "PUT", body: JSON.stringify(q[i]) });
        // Re-apply locally: the GET above may have overwritten this entry with
        // the older server value.
        if (q[i].mode) checkMap[q[i].key] = { mode: q[i].mode, until: q[i].until || null };
        else delete checkMap[q[i].key];
      } catch (e) { left.push(q[i]); }
    }
    writeCache(CHECK_QUEUE_KEY, left);
    cacheCheckMap();
  }

  function pushCheck(body) {
    api("/v1/checkstate", { method: "PUT", body: JSON.stringify(body) }).catch(function (e) {
      // A View/Read account cannot write check state at all, so its 403 is a
      // permanent answer, not a blip. Queuing it meant retrying on every load
      // forever and never draining. Offline failures still queue.
      if (e && /\b403\b/.test(String(e.message || e))) return;
      var q = readCache(CHECK_QUEUE_KEY, []);
      // One pending write per key; the latest intent is the only one worth
      // sending, and replaying a stale snooze after a dismiss would undo it.
      q = q.filter(function (x) { return x.key !== body.key; });
      q.push(body);
      writeCache(CHECK_QUEUE_KEY, q);
    });
  }

  // Returns "snoozed" | "dismissed" | null. Expired snoozes clear themselves,
  // on the server as well, so they do not accumulate across devices forever.
  function checkHiddenAs(key) {
    var e = checkMap[key];
    if (!e) return null;
    if (e.mode === "snoozed") {
      if (!e.until || e.until <= new Date().toISOString()) {
        delete checkMap[key]; cacheCheckMap();
        pushCheck({ key: key, mode: null });
        return null;
      }
      return "snoozed";
    }
    return "dismissed";
  }
  function hideCheck(key, mode) {
    var entry = mode === "snoozed"
      ? { mode: "snoozed", until: new Date(Date.now() + SNOOZE_DAYS * 86400000).toISOString() }
      : { mode: "dismissed", until: null };
    checkMap[key] = entry; cacheCheckMap();
    pushCheck({ key: key, mode: entry.mode, until: entry.until });
  }
  function unhideCheck(key) {
    delete checkMap[key]; cacheCheckMap();
    pushCheck({ key: key, mode: null });
  }

  function renderHealth(root, t, data) {
    var findings = auditTrip(t, data);
    // Threshold keeps the panel quiet on well-formed trips.
    var lvl = getDisplay().checkLevel;
    if (lvl === "issue") findings = findings.filter(function (f) { return f.level === "issue"; });
    else if (lvl === "warn") findings = findings.filter(function (f) { return f.level !== "info"; });
    // Split out anything snoozed or dismissed; it stays reachable below.
    var hidden = [];
    findings = findings.filter(function (f) {
      var st = checkHiddenAs(f.key);
      if (st) { f.hiddenAs = st; hidden.push(f); return false; }
      return true;
    });

    var counts = { issue: 0, warn: 0, info: 0 };
    findings.forEach(function (f) { counts[f.level]++; });
    var box = collapsibleSection("Trip check");
    var sec = box.body;
    // The pills are why this can be shut. "2 to fix" on the header says whether
    // opening it is worth doing, which is the only thing a closed section owes.
    if (counts.issue) box.badge(el("span", "health-pill issue", counts.issue + " to fix"));
    if (counts.warn) box.badge(el("span", "health-pill warn", counts.warn + " to check"));
    if (counts.info) box.badge(el("span", "health-pill info", counts.info + " suggestion" + (counts.info === 1 ? "" : "s")));
    if (!findings.length) box.badge(el("span", "health-pill ok", "All clear"));

    if (!findings.length) {
      sec.appendChild(el("div", "doc-empty", hidden.length
        ? "Nothing outstanding. " + hidden.length + " item" + (hidden.length === 1 ? " is" : "s are") + " snoozed or dismissed."
        : "No conflicts or gaps found in this itinerary."));
    }

    findings.forEach(function (f) {
      var row = el("div", "health-row " + f.level);
      row.appendChild(el("div", "health-icon", f.level === "issue" ? "🔴" : f.level === "warn" ? "🟠" : "🔵"));
      var b = el("div", "health-body");
      b.appendChild(el("div", "health-title", f.title));
      b.appendChild(el("div", "health-detail", f.detail));
      var acts = el("div", "health-acts");
      // One fix or several — a feasibility finding can offer both "open the
      // form" and "use the time I worked out for you".
      (f.fix ? (Array.isArray(f.fix) ? f.fix : [f.fix]) : []).forEach(function (fx) {
        var btn = el("button", "mini-btn health-fix", fx.label); btn.type = "button";
        btn.addEventListener("click", fx.run);
        acts.appendChild(btn);
      });
      var sn = el("button", "mini-btn is-edit", "Snooze " + SNOOZE_DAYS + "d"); sn.type = "button";
      // Keeps the concrete date — the useful part — and adds the reach, which is
      // the part you cannot infer from the button.
      sn.title = "Hide until " + fmtShortDate(new Date(Date.now() + SNOOZE_DAYS * 86400000)) +
        ". Snoozes are yours alone; other people still see this.";
      sn.addEventListener("click", function () { hideCheck(f.key, "snoozed"); redrawChecks(t, data, root); });
      var dm = el("button", "mini-btn is-edit", "Dismiss"); dm.type = "button";
      dm.title = "Hide permanently, for everyone — dismissals apply to the whole household.";
      dm.addEventListener("click", function () { hideCheck(f.key, "dismissed"); redrawChecks(t, data, root); });
      acts.appendChild(sn); acts.appendChild(dm);
      b.appendChild(acts);
      row.appendChild(b);
      sec.appendChild(row);
    });

    if (hidden.length) {
      var tog = el("button", "mini-btn health-hidden-toggle",
        "Hidden (" + hidden.length + ")");
      tog.type = "button";
      var list = el("div", "health-hidden"); list.hidden = true;
      tog.addEventListener("click", function () { list.hidden = !list.hidden; });
      hidden.forEach(function (f) {
        var r = el("div", "health-hidden-row");
        var lbl = el("span", "health-hidden-name",
          f.title + (f.hiddenAs === "snoozed" ? " · snoozed" : " · dismissed"));
        var un = el("button", "mini-btn is-edit", "Restore"); un.type = "button";
        un.addEventListener("click", function () { unhideCheck(f.key); redrawChecks(t, data, root); });
        r.appendChild(lbl); r.appendChild(un);
        list.appendChild(r);
      });
      sec.appendChild(tog); sec.appendChild(list);
    }
    box.mount(root);
  }
  // ---- packing ----
  // Five people, three of them children. The question is never "are the boots
  // packed" but "are JO's boots packed", so every line carries a person.
  // Templates exist because a ski week packs nothing like Cabo, but you pack
  // the same ski week every January.
  // CONFIGURE ME. Who a packing item can be assigned to. Put the people who
  // travel with you here; "" is "Anyone" and is what the dropdown opens on.
  var PACK_WHO = ["", "Me", "Shared"];

  // ---- things to do before you go ----
  // Separate from packing because they are different questions — packing is
  // "what goes in the bag", this is "what must happen first" — and because the
  // deadlines already extracted into `terms` belong here rather than nowhere.
  //
  // Those deadlines are shown but not editable: they come from a confirmation
  // email and are the provider's fact, not a note you wrote. Ticking one off
  // would only make the app disagree with the booking.
  // ---- a section that folds away ----
  //
  // Every section in the side column: Map, Trip check, Packing, Budget,
  // Documents, To do and Ideas for free days. What they have in common is that
  // none of them is the itinerary, and the itinerary is what a trip is for.
  //
  // Extracted rather than written seven times, because the details that make it
  // work are easy to drop on the fifth copy: aria-expanded has to track the
  // state, the gap under the heading has to belong to the body or a shut
  // section leaves dead space above nothing, and a badge has to sit outside the
  // button so a closed section can still say what is in it.
  //
  // `sub: true` gives the same control at the size of a group label, for a
  // block that lives inside another section rather than beside it.
  // Placeholder shapes for an itinerary still on the wire. Shaped like the rows
  // that will replace them so the page does not jump when they land, which on a
  // hotel connection is the difference between "slow" and "broken".
  //
  // It is a placeholder for a request IN FLIGHT and nothing else. Every exit
  // from the load — success, partial failure, total failure — clears it, and
  // the incomplete banner says what is missing. A skeleton left standing after
  // an error tells the same lie the old `.catch(() => [])` told: that the data
  // is coming.
  //
  // aria-hidden because a screen reader has nothing to gain from a description
  // of grey boxes; the status line beside it is what gets announced, and it is
  // the announcement the old "Loading itinerary…" text used to make.
  function itinSkeleton() {
    var wrap = el("div", "skel-wrap");
    var say = el("div", "loading", "Loading itinerary…");
    say.setAttribute("role", "status");
    // Off-screen rather than display:none — a hidden node is not announced.
    say.setAttribute("style", "position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap;padding:0;");
    wrap.appendChild(say);
    var skel = el("div", "skel"); skel.setAttribute("aria-hidden", "true");
    // Two days of three and two rows. Enough to read as an itinerary, few
    // enough that a short trip does not flash a wall of grey and then shrink.
    [3, 2].forEach(function (rows) {
      var day = el("div", "skel-day");
      day.appendChild(el("div", "skel-bar skel-head"));
      for (var i = 0; i < rows; i++) {
        var r = el("div", "skel-row");
        r.appendChild(el("div", "skel-dot"));
        var lines = el("div", "skel-lines");
        lines.appendChild(el("div", "skel-bar " + (i % 2 ? "skel-w55" : "skel-w70")));
        lines.appendChild(el("div", "skel-bar " + (i % 2 ? "skel-w30" : "skel-w45")));
        r.appendChild(lines);
        day.appendChild(r);
      }
      skel.appendChild(day);
    });
    wrap.appendChild(skel);
    return wrap;
  }

  function collapsibleSection(title, opts) {
    opts = opts || {};
    var sec = el("div", opts.sub ? "sug-sub" : "detail-section");
    var head = el(opts.sub ? "div" : "h3", "sug-head" + (opts.sub ? " seg-label" : ""));
    var tog = el("button", "sug-toggle"); tog.type = "button";
    var caret = el("span", "note-caret", "▸");
    tog.appendChild(caret);
    tog.appendChild(el("span", null, title));
    head.appendChild(tog);
    var body = el("div", "sug-body");
    var open = !!opts.open;
    function paint() {
      caret.textContent = open ? "▾" : "▸";
      body.hidden = !open;
      tog.setAttribute("aria-expanded", String(open));
    }

    // Some content cannot be built inside a hidden box. Leaflet measures its
    // container to pick a zoom, and a container with no box measures 0x0 — the
    // map then centres on nothing and its pins land hundreds of thousands of
    // pixels outside the frame, which is exactly what happened the first time
    // the map was folded. Anything of that kind is built on first open instead,
    // which also means a section nobody opens costs nothing to have.
    var pending = typeof opts.onFirstOpen === "function" ? opts.onFirstOpen : null;
    tog.addEventListener("click", function () {
      open = !open;
      paint();
      if (open && pending) { var run = pending; pending = null; run(); }
    });
    return {
      section: sec,
      body: body,
      // Badges sit on the header, outside the button, so they stay readable
      // while the section is shut — which is the whole point of shutting it.
      badge: function (node) { if (node) head.appendChild(node); return node; },
      mount: function (root) {
        sec.appendChild(head); sec.appendChild(body); paint();
        root.appendChild(sec); return sec;
      },
    };
  }

  // ---- telling two tours apart ----
  //
  // A destination search returns the same day out several times over. Las Vegas
  // is the worked example: "Grand Canyon West, Hoover Dam Stop, Wi-Fi, Optional
  // Lunch & Skywalk" and "Grand Canyon West, Hoover Dam Stop, Breakfast, Lunch &
  // Skywalk" are the same coach to the same rim, sold by two operators and
  // separated only by which meal is thrown in.
  //
  // The words that differ are exactly the ones that do not matter, so they are
  // stripped — meals, time of day, group size, "private", "guided", "combo",
  // "optional" — and what is left is the places and the activity: grand, canyon,
  // west, hoover, dam, skywalk. On those, that pair is word-for-word identical —
  // it scores 1.00, because "Wi-Fi" leaves nothing behind either once its
  // sub-three-letter fragments are dropped.
  var TOUR_NOISE = {};
  ("tour tours trip trips day days half full private small large group groups " +
   "from with and the an of in to for optional option experience experiences " +
   "guided guide excursion ticket tickets admission entry pass combo shared " +
   "morning afternoon evening night sunset sunrise early late hour hours " +
   "lunch breakfast dinner meal meals drinks tasting included includes including " +
   "transfer transfers transport transportation pickup hotel wifi free skip line " +
   "best top popular new exclusive deluxe premium ultimate vip").split(" ")
    .forEach(function (w) { TOUR_NOISE[w] = 1; });

  function tourTokens(title) {
    var out = {}, n = 0;
    String(title || "").toLowerCase()
      // Letters and digits only. "Wi-Fi" and "8D/7N" must not survive as
      // punctuation-glued tokens that look distinctive when they are not.
      .replace(/[^a-z0-9]+/g, " ").split(" ")
      .forEach(function (w) {
        if (w.length < 3 || TOUR_NOISE[w] || /^\d+$/.test(w)) return;
        if (!out[w]) { out[w] = 1; n++; }
      });
    return { set: out, size: n };
  }

  // Jaccard — shared words over total distinct words. Chosen over "does one
  // title contain the other" because these titles are comma-salad, not prefixes.
  function tourLikeness(a, b) {
    var A = tourTokens(a), B = tourTokens(b);
    if (!A.size || !B.size) return 0;
    var shared = 0;
    Object.keys(A.set).forEach(function (w) { if (B.set[w]) shared++; });
    return shared / (A.size + B.size - shared);
  }

  // A Viator code is supplier-then-product: 132218P75 and 132218P76 are two
  // departures of one thing — the morning-versus-afternoon case, which no amount
  // of title comparison would catch because the titles are identical.
  function tourFamily(code) {
    var m = String(code || "").match(/^([A-Za-z0-9]+?)P\d+$/);
    return m ? m[1] : null;
  }

  // 0.6 was set against the real data, not by feel. The two Grand Canyon coaches
  // score 0.88 and collapse. The two La Fortuna combos score 0.50 and both
  // survive, which is correct — one is waterfall plus hot springs, the other
  // waterfall plus hanging bridges, and they are genuinely different days out.
  var TOUR_SAME = 0.6;

  // A shared product family is strong evidence but not proof, so it has to clear
  // a low title bar too. Plenty of suppliers sell several unrelated day trips
  // under one code: Transporte Baja out of Ensenada sells 31612P1 "Guadalupe
  // Valley Wine Route Tour" and 31612P3 "La Bufadora Tour", a wine day and a
  // blowhole-plus-handicrafts half day. On family alone the Bufadora trip was
  // collapsed into the wine tour and vanished — and it was the only non-wine idea
  // in a Pinecrest set of ten, so the panel read as six near-identical wine tours
  // and the footer called the casualty a near-duplicate, which it was not.
  //
  // 0.35 keeps the case this rule exists for. Morning-versus-afternoon departures
  // have identical or near-identical titles and score at or near 1.00, so they
  // still collapse; the Bufadora pair scores 0.29 and both now survive.
  var TOUR_FAMILY_FLOOR = 0.35;

  // Viator's duration means two different things and the payload does not say
  // which. For a tour it is how long you are out; for a rental it is how long
  // you keep the kit. The Mammoth ski rental reports 7200 minutes, so the panel
  // advertised a $131 hire as a 120-hour outing.
  //
  // A day is the honest ceiling: this section fills a free day, and the importer
  // already drops multi-day packages, so anything longer is a hire period rather
  // than a long tour. We cannot tell the two apart from what is stored, and an
  // absent chip is better than a confident wrong one — the same call as leaving
  // a coordinate unset rather than writing 0,0.
  var TOUR_MAX_MINUTES = 24 * 60;

  // Returns the label, or null when there is nothing honest to say.
  function tourDurationLabel(minutes) {
    if (!minutes || minutes > TOUR_MAX_MINUTES) return null;
    return Math.round(minutes / 60) + "h";
  }

  // Keeps the best of each cluster, so the caller's ordering decides which
  // survives rather than whatever the search happened to return first.
  function dedupeIdeas(items, limit) {
    var kept = [];
    (items || []).forEach(function (it) {
      if (kept.length >= (limit || 6)) return;
      var fam = tourFamily(it.code);
      var dupe = kept.some(function (k) {
        var like = tourLikeness(k.title, it.title);
        if (fam && tourFamily(k.code) === fam && like >= TOUR_FAMILY_FLOOR) return true;
        return like >= TOUR_SAME;
      });
      if (!dupe) kept.push(it);
    });
    return kept;
  }

  // ---- what the outside world is offering ----
  //
  // Activity ideas from Viator. Two rules hold this together and both matter
  // more than the layout:
  //
  //   1. It is appended, never inserted into the itinerary. Nothing here is
  //      booked, and the itinerary is the record of what is.
  //   2. It states its source and the date it was read. A price from three
  //      weeks ago is a fact about three weeks ago.
  //
  // Suppressed entirely on a business trip — same gate as everything else.
  //
  // This also carried a fare watch — Expedia's price for the booked route,
  // tracked against a baseline. Removed on 2026-08-16: it was never able to say
  // whether Alex had overpaid, only that the market had moved since the watch
  // began, and that is not a thing anyone acts on. See the commit if it is ever
  // wanted back.
  function renderSuggested(root, t) {
    if (!wantsSuggestions(t)) return;
    var sg = t.suggestions;
    if (!(sg && sg.items && sg.items.length)) return;
    var money = function (n, cur) {
      return (cur === "USD" ? "$" : "") + Number(n).toFixed(2).replace(/\.00$/, "") + (cur === "USD" ? "" : " " + cur);
    };

    {
      // Rank before de-duplicating, so the survivor of each cluster is the
      // best-reviewed rather than whichever the search returned first. Rating
      // leads; review count breaks ties, because 4.9 from 24,000 people is a
      // firmer number than 5.0 from two.
      var ranked = sg.items.slice().sort(function (a, b) {
        return (b.rating || 0) - (a.rating || 0) || (b.reviews || 0) - (a.reviews || 0);
      });
      // De-duplicate first, THEN trim. Doing both at once and subtracting would
      // report "3 near-duplicates hidden" when two were duplicates and the third
      // was simply the seventh-best — two different reasons wearing one label,
      // and only one of them is a claim about the results themselves.
      var unique = dedupeIdeas(ranked, ranked.length);
      var shown = unique.slice(0, 6);
      var dupes = ranked.length - unique.length;
      var trimmed = unique.length - shown.length;

      var s2box = collapsibleSection("Ideas for free days");
      s2box.badge(el("span", "health-pill info", String(shown.length)));
      var body = s2box.body;
      var list = el("div", "sug-list");
      shown.forEach(function (it) {
        var card = el("div", "sug-row");
        var a = el("a", "sug-title", it.title);
        a.href = it.url; a.target = "_blank"; a.rel = "noopener";
        card.appendChild(a);
        var meta = el("div", "sug-meta");
        if (it.rating) meta.appendChild(el("span", "sug-rating", "★ " + it.rating + " (" + (it.reviews || 0) + ")"));
        if (it.price) meta.appendChild(el("span", null, "from " + money(it.price, it.currency) + " pp"));
        var dur = tourDurationLabel(it.minutes);
        if (dur) meta.appendChild(el("span", null, dur));
        if (it.kid) meta.appendChild(el("span", "sug-tag", "kid friendly"));
        if (it.free_cancel) meta.appendChild(el("span", "sug-tag", "free cancellation"));
        card.appendChild(meta);
        // Adds a line to the to-do list, not a booking to the itinerary. The
        // decision stays yours; this only stops you losing the link.
        var add = el("button", "mini-btn is-edit", "＋ To do"); add.type = "button";
        add.title = "Add this to the trip's to-do list";
        add.addEventListener("click", async function () {
          add.disabled = true;
          var entry = { text: it.title + " — " + it.url, done: false, added: new Date().toISOString() };
          try {
            await updateTasks(t, function (cur) { return cur.concat([entry]); });
            toast("Added to the to-do list"); openTrip(t);
          } catch (e) { toast("Couldn't add: " + e.message); add.disabled = false; }
        });
        card.appendChild(add);
        list.appendChild(card);
      });
      body.appendChild(list);
      // Says what was hidden and why. A list that silently drops half its
      // results looks like a thin search rather than a filtered one.
      body.appendChild(el("div", "watch-foot", "Viator · read " + dayLabel(sg.fetched_at) +
        (sg.window ? " · for " + dayLabel(sg.window.from) + " – " + dayLabel(sg.window.to) : "") +
        (dupes ? " · " + dupes + " near-duplicate" + (dupes === 1 ? "" : "s") + " hidden" : "") +
        (trimmed ? " · " + trimmed + " more not shown" : "")));
      s2box.mount(root);
    }
  }

  // ---- cancellation policies ----
  //
  // These used to live at the bottom of the to-do list, which was the wrong
  // place twice over. A to-do is something you intend to do; a cancellation
  // deadline is the opposite — it is the date by which you must act if you
  // change your mind, and most of them pass without you doing anything. Mixed
  // in, they made a list of five real tasks look like eleven, and the count on
  // the header stopped meaning anything.
  //
  // They were also read-only. The importer fills these in from confirmation
  // emails when it can, but plenty of bookings never state a policy in a form
  // it can parse, and a few state it in a phone call. So every one of them is
  // editable here, and one can be written for a booking that has none.

  // Kind as allItems names it, to the singular the API routes on.
  //
  // Neither half is free to guess. allItems calls lodging "lodging" while the
  // route is /hosting, and a transport's route is /transportation — "transport"
  // is not an alias, it is a 404. See KINDS in functions/api/_core.js; the test
  // suite reads that file rather than trusting this table.
  var CANCEL_PATH = { transport: "transportation", lodging: "hosting", activity: "activity" };

  // Every booking, with whatever cancellation terms it carries. Callers filter
  // on `has` — the ones without are what the "add" picker offers.
  function cancelRows(data) {
    return allItems(data).map(function (it) {
      var tm = termsOf(it.o) || {};
      var when = tm.cancel_by ? new Date(tm.cancel_by) : null;
      if (when && isNaN(when)) when = null;
      var policy = tm.cancel_policy || "";
      return { item: it, when: when, policy: policy, has: !!(when || policy) };
    });
  }

  // Soonest deadline first; a policy with no date sits after the dated ones,
  // because "free until 48h before" is a standing fact and a date is a warning.
  function cancelSort(rows) {
    return rows.slice().sort(function (a, b) {
      if (a.when && b.when) return a.when - b.when;
      if (a.when) return -1;
      if (b.when) return 1;
      return String(a.item.name).localeCompare(String(b.item.name));
    });
  }

  // Whole days between today and the deadline's day, in the viewer's own zone.
  //
  // Calendar days, not 24-hour blocks. Ceiling a fractional day — which is what
  // this did — makes a deadline twenty minutes away read "tomorrow", because
  // any positive fraction ceilings to 1; by the same arithmetic "today" was
  // reachable only at the exact millisecond. That is the one thing a deadline
  // countdown must never do, so it counts dates instead. Rounding a
  // midnight-to-midnight difference also survives the 23- and 25-hour days that
  // daylight saving produces.
  function cancelDays(when) {
    var floorDay = function (d) { var x = new Date(d.getTime()); x.setHours(0, 0, 0, 0); return x; };
    return Math.round((floorDay(when) - floorDay(new Date())) / 86400000);
  }
  // "in 5 days" / "today" / "passed". Deliberately relative: an absolute date
  // makes you do the arithmetic, and the arithmetic is the whole question.
  // "passed" is decided on the instant, not the day — a 6pm deadline read at
  // 8pm has gone, even though both are today.
  function cancelCountdown(when) {
    if (!when) return "";
    if (when < new Date()) return "passed";
    var days = cancelDays(when);
    return days === 0 ? "today" : days === 1 ? "tomorrow" : "in " + days + " days";
  }

  function renderCancellations(root, t, data) {
    root.innerHTML = "";
    var rows = cancelSort(cancelRows(data).filter(function (r) { return r.has; }));
    var missing = cancelRows(data).filter(function (r) { return !r.has; });

    var box = collapsibleSection("Cancellation policies");
    var sec = box.body;
    // The header carries the next live deadline, because the section is shut by
    // default and a deadline you cannot see is one you will miss — which is the
    // only reason these are surfaced at all.
    var next = rows.filter(function (r) { return r.when && r.when >= new Date(Date.now() - 86400000); })[0];
    if (next) {
      box.badge(el("span", "health-pill " + (cancelDays(next.when) <= 7 ? "warn" : "info"),
        "next " + cancelCountdown(next.when)));
    } else if (rows.length) {
      box.badge(el("span", "health-pill ok", rows.length + (rows.length === 1 ? " policy" : " policies")));
    }

    // Two nights at the same camp are two bookings with identical names, and a
    // list of deadlines that cannot tell them apart is a list you cannot act
    // on. Only the ambiguous ones get the extra date; adding it to everything
    // would be noise on the trips that do not need it.
    var nameCount = {};
    rows.forEach(function (r) { nameCount[r.item.name] = (nameCount[r.item.name] || 0) + 1; });

    var list = el("div", "pol-rows");
    rows.forEach(function (r) {
      var row = el("div", "pol-row");
      var past = r.when && r.when < new Date();
      var days = r.when ? cancelDays(r.when) : null;
      row.appendChild(el("div", "pol-when" + (past ? " is-past" : days != null && days <= 7 ? " is-soon" : ""),
        r.when ? cancelCountdown(r.when) : "—"));
      var body = el("div", "pol-body");
      var name = r.item.name;
      if (nameCount[name] > 1 && r.item.when) {
        var k = dayKey(r.item.when, r.item.tz);
        if (k) name += "  ·  " + new Date(k + "T12:00:00").toLocaleDateString(dateLocale(),
          { month: "short", day: "numeric" });
      }
      body.appendChild(el("div", "pol-name", name));
      if (r.when) body.appendChild(el("div", "pol-by", "Cancel by " + fmtWhen(r.when.toISOString(), r.item.tz, true)));
      if (r.policy) body.appendChild(el("div", "pol-text", r.policy));
      row.appendChild(body);
      var ed = el("button", "linkchip is-edit", "✎"); ed.type = "button";
      ed.title = "Edit this policy";
      ed.addEventListener("click", function () { editCancellation(t, r.item); });
      row.appendChild(ed);
      list.appendChild(row);
    });
    sec.appendChild(list);

    if (!rows.length) {
      sec.appendChild(el("div", "doc-empty",
        "No cancellation terms recorded. The importer fills these in when a confirmation states them; " +
        "add the rest yourself — including the ones you were told over the phone."));
    }

    if (missing.length) {
      var addRow = el("div", "doc-actions");
      var addBtn = el("button", "mini-btn is-edit", "＋ Add a policy"); addBtn.type = "button";
      addBtn.addEventListener("click", function () { pickForCancellation(t, data, missing); });
      addRow.appendChild(addBtn);
      sec.appendChild(addRow);
    }
    box.mount(root);
  }

  // Which booking are we writing a policy for. Only offered for bookings that
  // have none — the ones that do are edited from their own row.
  function pickForCancellation(trip, data, missing) {
    var opts = missing.map(function (r) {
      var k = r.item.when ? dayKey(r.item.when, r.item.tz) : null;
      return { value: CANCEL_PATH[r.item.kind] + ":" + r.item.o.id,
        label: (r.item.kind === "lodging" ? "🏨  " : r.item.kind === "transport" ? "✈️  " : "🍽️  ") + r.item.name +
          (k ? "  ·  " + fmtMD(new Date(k + "T12:00:00")) : "") };
    });
    formDialog("Add a cancellation policy", [
      { name: "which", label: "Booking", type: "select", value: opts[0].value, options: opts },
    ], async function (v) {
      var pick = missing.filter(function (r) {
        return CANCEL_PATH[r.item.kind] + ":" + r.item.o.id === v.which;
      })[0];
      if (!pick) throw new ApiError("Pick a booking.", 0);
      // Closes this dialog, then opens the editor on the chosen booking.
      setTimeout(function () { editCancellation(trip, pick.item); }, 0);
    });
  }

  function editCancellation(trip, it) {
    var tm = termsOf(it.o) || {};
    var tz = it.tz || tripTz(trip, null) || "UTC";
    formDialog("Cancellation — " + it.name, [
      { name: "cancel_by", label: "Free cancellation until", type: "datetime-local",
        value: toLocalInput(tm.cancel_by, tz) },
      { name: "timezone", label: "Timezone (IANA)", value: tz },
      { name: "cancel_policy", label: "Policy", type: "textarea", value: tm.cancel_policy || "",
        placeholder: "Free until 48h before · then one night" },
    ], async function (v) {
      var tzv = v.timezone || tz;
      // The whole terms object goes back, not just these two fields: the PATCH
      // spreads the body over the stored blob one level deep, so sending a
      // bare {cancel_by} would replace terms entirely and take the rate type,
      // deposit and baggage allowance with it.
      var terms = Object.assign({}, tm, {
        cancel_by: fromLocalInput(v.cancel_by, tzv) || null,
        cancel_policy: v.cancel_policy || null,
      });
      await api("/v1/trip/" + trip.id + "/" + CANCEL_PATH[it.kind] + "/" + it.o.id,
        { method: "PATCH", body: JSON.stringify({ terms: terms }) });
      toast("Saved");
      openTrip(trip);
    });
  }

  function renderTasks(root, t) {
    root.innerHTML = "";
    var tasks = Array.isArray(t.tasks) ? t.tasks.slice() : [];

    var box = collapsibleSection("To do");
    var sec = box.body;
    var open = tasks.filter(function (x) { return !x.done; }).length;
    if (tasks.length) {
      box.badge(el("span", "health-pill " + (open ? "info" : "ok"),
        open ? open + " open" : "all done"));
    }

    // Every change below is expressed as an intent over whatever the server
    // currently holds, not as a finished array. Two people with the trip open
    // is ordinary, and a precomputed array silently discards the other one's
    // task; "tick THIS one" re-applies cleanly to a list that has moved on.
    //
    // Identity is by content, because a task has no id: after a re-read the
    // indexes have shifted, so an index is the one thing that cannot be trusted.
    var apply = async function (mutate) {
      await updateTasks(t, mutate);
      renderTasks(root, t);
    };

    if (!tasks.length) {
      sec.appendChild(el("div", "doc-empty",
        "Nothing to do yet. Add what has to happen before you leave — order currency, arrange the dog sitter, check in."));
    }

    tasks.forEach(function (x, i) {
      var row = el("div", "task-row");
      var box = el("button", "check" + (x.done ? " on" : ""), x.done ? "✓" : ""); box.type = "button";
      box.title = x.done ? "Mark as still to do" : "Mark as done";
      box.addEventListener("click", async function () {
        box.disabled = true;
        // The target is absolute, not a flip: you meant "mark this done", so
        // that is what gets re-applied even if the list changed underneath.
        var want = !x.done;
        try {
          await apply(function (cur) {
            var at = taskIndex(cur, x);
            if (at < 0) return null;                 // removed on another device
            if (!!cur[at].done === want) return null; // someone already did it
            var next = cur.slice();
            next[at] = Object.assign({}, cur[at], { done: want });
            return next;
          });
        } catch (e) { toast("Couldn't save: " + e.message); box.disabled = false; }
      });
      row.appendChild(box);
      var txt = el("div", "task-text" + (x.done ? " is-done" : ""), x.text);
      row.appendChild(txt);
      var rm = el("button", "cover-libdel", "✕"); rm.type = "button"; rm.title = "Remove";
      rm.addEventListener("click", async function () {
        try {
          await apply(function (cur) {
            var at = taskIndex(cur, x);
            if (at < 0) return null;                 // already gone
            return cur.slice(0, at).concat(cur.slice(at + 1));
          });
        } catch (e) { toast("Couldn't save: " + e.message); }
      });
      row.appendChild(rm);
      sec.appendChild(row);
    });


    var addRow = el("div", "doc-add");
    var inp = el("input", "form-input"); inp.placeholder = "Add something to do";
    var add = el("button", "mini-btn is-edit", "＋ Add"); add.type = "button";
    var doAdd = async function () {
      var v = inp.value.trim(); if (!v) return;
      add.disabled = true;
      var entry = { text: v, done: false, added: new Date().toISOString() };
      try { await apply(function (cur) { return cur.concat([entry]); }); }
      catch (e) { toast("Couldn't save: " + e.message); }
      finally { add.disabled = false; }
    };
    add.addEventListener("click", doAdd);
    inp.addEventListener("keydown", function (ev) { if (ev.key === "Enter") { ev.preventDefault(); doAdd(); } });
    addRow.appendChild(inp); addRow.appendChild(add);
    sec.appendChild(addRow);
    box.mount(root);
  }

  async function renderPacking(root, t) {
    root.innerHTML = "";
    var lists;
    try { lists = (await api("/v1/packing?trip_id=" + t.id)).results || []; }
    catch (e) { return; }

    var box = collapsibleSection("Packing");
    var sec = box.body;
    var done = 0, total = 0;
    lists.forEach(function (l) { (l.items || []).forEach(function (i) { total++; if (i.done) done++; }); });
    if (total) box.badge(el("span", "health-pill " + (done === total ? "ok" : "info"), done + " / " + total + " packed"));

    if (!lists.length) {
      sec.appendChild(el("div", "doc-empty", "Nothing to pack yet."));
    }

    lists.forEach(function (l) { sec.appendChild(packingList(l, t, root)); });

    var acts = el("div", "cal-feed-acts");
    var add = el("button", "mini-btn is-edit", "＋ Packing List"); add.type = "button";
    add.addEventListener("click", async function () {
      var templates = [];
      try { templates = (await api("/v1/packing")).results || []; } catch (e) {}
      var opts = [{ value: "", label: "Empty list" }].concat(templates.map(function (x) {
        return { value: String(x.id), label: "From: " + x.name + " (" + (x.items || []).length + " items)" };
      }));
      formDialog("New packing list", [
        { name: "name", label: "List name", value: "Packing" },
        { name: "from", label: "Start from", type: "select", options: opts, value: "" }
      ], async function (v) {
        await api("/v1/packing", { method: "POST", body: JSON.stringify({
          trip_id: t.id, name: v.name || "Packing", from_template: v.from ? Number(v.from) : null }) });
        renderPacking(root, t);
      });
    });
    acts.appendChild(add);
    sec.appendChild(acts);
    box.mount(root);
  }

  function packingList(l, t, root) {
    var wrap = el("div", "pack-list");
    var h = el("div", "pack-head");
    h.appendChild(el("strong", null, l.name || "Packing"));
    var tools = el("div", "pack-tools");

    var save = el("button", "mini-btn is-edit", "Save As Template"); save.type = "button";
    save.addEventListener("click", async function () {
      formDialog("Save As Template", [{ name: "name", label: "Template name", value: l.name || "Packing" }],
        async function (v) {
          await api("/v1/packing/" + l.id + "/save-template", { method: "POST", body: JSON.stringify({ name: v.name }) });
          toast("Template saved — reusable on any trip");
        });
    });
    var del = el("button", "mini-btn danger is-edit", "Delete"); del.type = "button";
    del.addEventListener("click", async function () {
      if (!window.confirm("Delete “" + (l.name || "this list") + "”?")) return;
      await api("/v1/packing/" + l.id, { method: "DELETE" });
      renderPacking(root, t);
    });
    tools.appendChild(save); tools.appendChild(del);
    h.appendChild(tools); wrap.appendChild(h);

    var items = (l.items || []).slice();
    // The one list two people genuinely edit at the same moment, standing over
    // the same suitcase. Each change is an intent re-applied to whatever the
    // server holds, so ticking "passports" cannot erase the "chargers" the other
    // phone added ten seconds ago.
    var apply = function (mutate) {
      return updatePacking(l, mutate)
        .then(function () { renderPacking(root, t); })
        .catch(function (e) { toast("Couldn't save: " + e.message); renderPacking(root, t); });
    };

    var body = el("div", "pack-items");
    items.forEach(function (it, idx) {
      var row = el("div", "pack-row" + (it.done ? " done" : ""));
      var box = el("button", "check" + (it.done ? " on" : ""), it.done ? "✓" : ""); box.type = "button";
      box.addEventListener("click", function () {
        // Painted immediately so the tick feels instant; the re-render that
        // follows the save is what makes it true.
        var want = !it.done;
        box.classList.toggle("on", want); box.textContent = want ? "✓" : "";
        row.classList.toggle("done", want);
        apply(function (cur) {
          var at = packIndex(cur, it);
          if (at < 0) return null;                  // removed on another device
          if (!!cur[at].done === want) return null; // someone already ticked it
          var next = cur.slice();
          next[at] = Object.assign({}, cur[at], { done: want });
          return next;
        });
      });
      row.appendChild(box);
      row.appendChild(el("span", "pack-text", it.text || ""));
      if (it.who) row.appendChild(el("span", "pack-who", it.who));
      var x = el("button", "mini-btn pack-x", "✕"); x.type = "button";
      x.addEventListener("click", function () {
        apply(function (cur) {
          var at = packIndex(cur, it);
          if (at < 0) return null;
          return cur.slice(0, at).concat(cur.slice(at + 1));
        });
      });
      row.appendChild(x);
      body.appendChild(row);
    });
    wrap.appendChild(body);

    // Add straight from the list rather than through a dialog — packing is done
    // in bursts, standing over a suitcase, and a modal per sock is intolerable.
    var addRow = el("form", "pack-add");
    var inp = document.createElement("input");
    inp.className = "form-input"; inp.placeholder = "Add an item…"; inp.type = "text";
    var who = document.createElement("select"); who.className = "form-input pack-sel";
    PACK_WHO.forEach(function (p) { var o = el("option", null, p || "Anyone"); o.value = p; who.appendChild(o); });
    var go = el("button", "mini-btn", "Add"); go.type = "submit";
    addRow.appendChild(inp); addRow.appendChild(who); addRow.appendChild(go);
    addRow.addEventListener("submit", function (e) {
      e.preventDefault();
      var text = inp.value.trim();
      if (!text) return;
      var entry = { text: text, who: who.value, done: false };
      inp.value = "";
      apply(function (cur) { return cur.concat([entry]); });
    });
    wrap.appendChild(addRow);
    return wrap;
  }

  // ---- been here before ----
  // Las Vegas fifteen times, Pinecrest ten, Phoenix nine. Where a planning app
  // researches somewhere new, the more useful question for this itinerary is
  // "what did we do last time" — and the answer was already in the database,
  // written down over fifteen years and never once read back.
  var ACT_EMOJI = { restaurant: "🍽", parking: "🅿", tour: "🚌", museum: "🖼",
    theater: "🎭", concert: "🎵", zoo: "🦁", general: "•", note: "📝" };

  // One line on the trip, and everything else behind it. This is reference
  // material — useful when planning a return visit, noise on every other open —
  // so it earns a link, not a permanent panel.
  // ---- the five things you look up on arrival ---------------------------
  //
  // Plug, voltage, which side they drive on, the emergency number, the dialling
  // code. Shipped as data rather than fetched from REST Countries, because the
  // moment this is wanted is the moment there is no signal: it cannot fail, it
  // cannot rate-limit, and it works on a plane.
  //
  // Only the countries Alex actually travels to, plus the obvious neighbours.
  // An unknown country renders nothing at all rather than a row of blanks.
  var LOCAL_INFO = {
    US: "A/B|120V|right|911", CA: "A/B|120V|right|911", MX: "A/B|127V|right|911",
    GB: "G|230V|left|999", IE: "G|230V|left|112", PT: "C/F|230V|right|112",
    ES: "C/F|230V|right|112", FR: "C/E|230V|right|112", DE: "C/F|230V|right|112",
    IT: "C/F/L|230V|right|112", NL: "C/F|230V|right|112", BE: "C/E|230V|right|112",
    CH: "C/J|230V|right|112", AT: "C/F|230V|right|112", GR: "C/F|230V|right|112",
    DK: "C/E/F/K|230V|right|112", SE: "C/F|230V|right|112", NO: "C/F|230V|right|112",
    FI: "C/F|230V|right|112", IS: "C/F|230V|right|112", PL: "C/E|230V|right|112",
    CZ: "C/E|230V|right|112", HU: "C/F|230V|right|112", HR: "C/F|230V|right|112",
    IL: "C/H/M|230V|right|100", AE: "G|230V|right|999", TR: "C/F|230V|right|112",
    MA: "C/E|127V/220V|right|19", ZA: "C/D/M/N|230V|left|10111",
    JP: "A/B|100V|left|110", CN: "A/C/I|220V|right|110", HK: "G|220V|left|999",
    SG: "G|230V|left|999", TH: "A/B/C/O|230V|left|191", KR: "C/F|220V|right|112",
    IN: "C/D/M|230V|left|112", AU: "I|230V|left|000", NZ: "I|230V|left|111",
    AR: "C/I|220V|right|911", BR: "C/N|127V/220V|right|190", CL: "C/L|220V|right|133",
    PE: "A/B/C|220V|right|105", CO: "A/B|110V|right|123", CR: "A/B|120V|right|911",
    PA: "A/B|120V|right|911", DO: "A/B|110V|right|911", JM: "A/B|110V|left|119",
    BS: "A/B|120V|left|911", KY: "A/B|120V|left|911", BB: "A/B|115V|left|211",
    AW: "A/B/F|127V|right|911", TC: "A/B|120V|left|911", VI: "A/B|110V|left|911",
    PR: "A/B|120V|right|911", FJ: "I|240V|left|911", ID: "C/F|230V|left|112",
    VN: "A/C/F|220V|right|113", PH: "A/B/C|220V|right|911", MY: "G|240V|left|999",
    TW: "A/B|110V|right|110", EG: "C/F|220V|right|122", KE: "G|240V|left|999",
    TZ: "D/G|230V|left|112", GE: "C/F|220V|right|112", RS: "C/F|230V|right|192",
    SI: "C/F|230V|right|112", SK: "C/E|230V|right|112", RO: "C/F|230V|right|112",
    BG: "C/F|230V|right|112", EE: "C/F|230V|right|112", LV: "C/F|230V|right|112",
    LT: "C/F|230V|right|112", LU: "C/E/F|230V|right|112", MT: "G|230V|left|112",
    CY: "G|230V|left|112", MC: "C/E/F|230V|right|112",
  };

  // One quiet line at the foot of the itinerary, beside the recall link --
  // the part of the screen that is already for things you might want rather
  // than things you need. Nothing renders for a country not in the table, and
  // nothing renders at home.
  async function renderLocalInfo(root, t, data) {
    var pt = destPoint(data);
    if (!pt) return;
    try {
      var c = await ext("country?lat=" + pt.lat + "&lon=" + pt.lng);
      if (!c || !c.cc) return;
      // Home needs no telling which side of the road it drives on.
      if (c.cc === "US") return;
      var row = LOCAL_INFO[c.cc];
      if (!row) return;
      var bits = row.split("|");
      // The itinerary re-renders while this await was in flight, and the root
      // survives those re-renders -- so two overlapping calls appended two
      // lines. Idempotent beats clever here: one practicalities line, always.
      var prev = root.querySelector(".local-info");
      if (prev) prev.remove();
      var line = el("div", "local-info",
        (c.name || c.cc) + ": type " + bits[0] + " plugs, " + bits[1] + ", drives on the " +
        bits[2] + ", emergency " + bits[3] + ".");
      root.appendChild(line);
    } catch (e) { /* a nicety, and silent when it cannot answer */ }
  }

  async function renderRecall(root, t) {
    var d;
    try { d = await api("/v1/recall/" + t.id); } catch (e) { return; }
    if (!d || !(d.prior || []).length) return;

    var n = d.prior.length;
    var wrap = el("div", "recall-link-wrap");
    var b = el("button", "recall-link",
      "↩ You've been to " + (t.name || "here") + " " + n + " time" + (n === 1 ? "" : "s") + " before");
    b.type = "button";
    b.title = "See where you stayed and what you did";
    b.addEventListener("click", function () { openRecall(t, d); });
    wrap.appendChild(b);
    root.appendChild(wrap);
  }

  function openRecall(t, d) {
    var n = d.prior.length;
    var o = overlay("wide");
    var back = o.back, panel = o.panel;
    panel.appendChild(el("h3", "form-title", (t.name || "Here") + " — previous visits"));
    var body = el("div", "insights-body");

    var last = d.prior[0];
    body.appendChild(el("div", "recall-sub",
      "This is visit " + (n + 1) + ". The last was " + (last.starts_at || "—") + "."));

    var block = function (title, rows, fmt) {
      if (!rows || !rows.length) return;
      body.appendChild(el("div", "seg-label", title));
      var list = el("div", "recall-list");
      rows.slice(0, 20).forEach(function (r) {
        var row = el("div", "recall-row");
        row.appendChild(el("span", "recall-name", fmt(r)));
        var meta = [];
        if (r.times > 1) meta.push(r.times + "×");
        if (r.last) meta.push(String(r.last).slice(0, 7));
        row.appendChild(el("span", "recall-meta", meta.join(" · ")));
        if (r.address) row.title = r.address;
        list.appendChild(row);
      });
      body.appendChild(list);
    };

    block("Where you stayed", d.lodging, function (r) { return "🏨 " + r.name; });
    // Parking is not a memory worth surfacing; it is the same barn every time.
    var acts = (d.activities || []).filter(function (r) { return r.activity_type !== "parking" && r.activity_type !== "note"; });
    block("What you did", acts, function (r) { return (ACT_EMOJI[r.activity_type] || "•") + " " + r.name; });

    body.appendChild(el("div", "seg-label", "The trips themselves"));
    var trips = el("div", "recall-list");
    d.prior.forEach(function (p) {
      var row = el("button", "recall-row recall-trip"); row.type = "button";
      row.appendChild(el("span", "recall-name", p.starts_at + (p.ends_at && p.ends_at !== p.starts_at ? " → " + p.ends_at : "")));
      row.appendChild(el("span", "recall-meta", "open →"));
      row.addEventListener("click", function () {
        back.remove();
        var prev = state.own.filter(function (x) { return x.id === p.id; })[0];
        if (prev) openTrip(prev); else toast("That trip isn't in the current list — turn on Past.");
      });
      trips.appendChild(row);
    });
    body.appendChild(trips);

    panel.appendChild(body);
    var btns = el("div", "form-btns");
    var close = el("button", "primary-btn small", "Done"); close.type = "button";
    close.addEventListener("click", function () { back.remove(); });
    btns.appendChild(close); panel.appendChild(btns);
  }

  // renderHealth owns its wrapper element outright, so a redraw is just a swap.
  function redrawChecks(t, data, root) {
    root.innerHTML = "";
    renderHealth(root, t, data);
  }
  function fmtShortDate(d) {
    try { return fmtMD(d); }
    catch (e) { return d.toISOString().slice(0, 10); }
  }

  // ---- bulk time shift ----
  // Nearly every itinerary error we see is a time or date offset — a whole day
  // entered an hour out, or a booking landing on the wrong date. Fixing those one
  // item at a time on a phone is miserable; this shifts a whole selection at once.
  function openShiftDialog(trip, data) {
    var items = [];
    (data.transports || []).forEach(function (x) { items.push({ kind: "transportation", o: x, label: tLabel(x), when: x.departure_at, tz: x.departure_timezone }); });
    (data.hostings || []).forEach(function (x) { items.push({ kind: "hosting", o: x, label: x.name || "Lodging", when: x.starts_at, tz: x.timezone }); });
    (data.activities || []).forEach(function (x) { items.push({ kind: "activity", o: x, label: x.name || "Activity", when: x.starts_at, tz: x.timezone }); });
    items = items.filter(function (i) { return i.when; })
      .sort(function (a, b) { return new Date(a.when) - new Date(b.when); });
    if (!items.length) { toast("Nothing with a time to shift."); return; }

    var o = overlay("wide", function () { close(); });
    var back = o.back, panel = o.panel;
    panel.appendChild(el("h3", "form-title", "Shift times — " + (trip.name || "trip")));
    var ctl = el("div", "shift-controls");
    var amount = el("input", "form-input"); amount.type = "number"; amount.value = "1"; amount.style.maxWidth = "90px";
    var unit = el("select", "form-input"); unit.style.maxWidth = "130px";
    [["hours", "hours"], ["days", "days"], ["minutes", "minutes"]].forEach(function (u) {
      var op = el("option", null, u[1]); op.value = u[0]; unit.appendChild(op);
    });
    var dir = el("select", "form-input"); dir.style.maxWidth = "120px";
    [["1", "later (+)"], ["-1", "earlier (−)"]].forEach(function (d) { var op = el("option", null, d[1]); op.value = d[0]; dir.appendChild(op); });
    ctl.appendChild(el("span", "form-label", "Move selected by")); ctl.appendChild(amount); ctl.appendChild(unit); ctl.appendChild(dir);
    panel.appendChild(ctl);

    var selAll = el("button", "mini-btn", "Select all"); selAll.type = "button";
    var selNone = el("button", "mini-btn", "Clear"); selNone.type = "button";
    var quick = el("div", "shift-controls"); quick.appendChild(selAll); quick.appendChild(selNone);
    panel.appendChild(quick);

    var list = el("div", "shift-list");
    var boxes = [];
    var lastDay = null;
    items.forEach(function (it, idx) {
      var k = dayKey(it.when, it.tz);
      if (k !== lastDay) { list.appendChild(el("div", "shift-day", dayLabel(k))); lastDay = k; }
      var row = el("label", "shift-row");
      var cb = el("input"); cb.type = "checkbox"; cb.checked = false; cb.dataset.idx = String(idx);
      boxes.push(cb);
      row.appendChild(cb);
      row.appendChild(el("span", "shift-time", fmtTime(it.when, it.tz)));
      row.appendChild(el("span", "shift-name", it.label));
      list.appendChild(row);
    });
    panel.appendChild(list);
    var err = el("div", "form-err"); err.hidden = true; panel.appendChild(err);

    var foot = el("div", "form-btns");
    var cancel = el("button", "mini-btn", "Cancel"); cancel.type = "button";
    var go = el("button", "primary-btn small", "Shift"); go.type = "button";
    foot.appendChild(cancel); foot.appendChild(go); panel.appendChild(foot);

    var close = function () { back.remove(); };
    cancel.addEventListener("click", close);
    selAll.addEventListener("click", function () { boxes.forEach(function (b) { b.checked = true; }); });
    selNone.addEventListener("click", function () { boxes.forEach(function (b) { b.checked = false; }); });

    go.addEventListener("click", async function () {
      var chosen = boxes.filter(function (b) { return b.checked; }).map(function (b) { return items[+b.dataset.idx]; });
      if (!chosen.length) { err.textContent = "Tick at least one item."; err.hidden = false; return; }
      var n = Number(amount.value) * Number(dir.value);
      if (!n) { err.textContent = "Enter an amount."; err.hidden = false; return; }
      go.disabled = true; go.textContent = "Shifting…";
      var unitName = unit.value;
      var moved = function (iso, tz) { return shiftIso(iso, tz, n, unitName); };
      // A bulk edit that stops half-way has left the trip in a state neither the
      // user nor a re-run can reason about: some items moved, some did not, and
      // shifting again would move the first group twice. So the count that
      // actually landed is reported, and the itinerary is reloaded either way.
      var okCount = 0;
      try {
        for (var i = 0; i < chosen.length; i++) {
          var c = chosen[i], body = {};
          if (c.kind === "transportation") {
            // Each end carries its own zone — a red-eye departs and lands in
            // different ones, and shifting by days has to keep both clocks.
            if (c.o.departure_at) body.departure_at = moved(c.o.departure_at, c.o.departure_timezone);
            if (c.o.arrival_at) body.arrival_at = moved(c.o.arrival_at, c.o.arrival_timezone || c.o.departure_timezone);
          } else {
            if (c.o.starts_at) body.starts_at = moved(c.o.starts_at, c.o.timezone);
            if (c.o.ends_at) body.ends_at = moved(c.o.ends_at, c.o.timezone);
          }
          await api("/v1/trip/" + trip.id + "/" + c.kind + "/" + c.o.id, { method: "PATCH", body: JSON.stringify(body) });
          okCount++;
        }
        close(); toast("Shifted " + chosen.length + " item" + (chosen.length === 1 ? "" : "s")); openTrip(trip);
      } catch (e) {
        err.textContent = okCount
          ? "Stopped after " + okCount + " of " + chosen.length + " — " + e.message +
            ". The first " + okCount + " have already moved; shifting again would move them twice."
          : "Failed: " + e.message;
        err.hidden = false;
        go.disabled = false; go.textContent = "Shift";
        if (okCount) openTrip(trip);
      }
    });
  }

  // ---- "changed since you last looked" ----
  var SEEN_KEY = "wayfarer_seen_v1";
  function getSeen() { try { return JSON.parse(localStorage.getItem(SEEN_KEY) || "{}"); } catch (e) { return {}; } }
  // The banner shown when part of a trip could not be fetched.
  //
  // Deliberately loud and deliberately specific. "Something went wrong" would
  // leave you guessing whether the empty Flights section is a failure or the
  // truth; naming the section answers that, which is the entire point.
  function incompleteNote(t, failed) {
    var box = el("div", "load-warn");
    box.appendChild(el("div", "load-warn-title",
      failed.length === 1 ? "Couldn't load " + failed[0].label.toLowerCase()
        : "Couldn't load " + failed.length + " parts of this trip"));
    box.appendChild(el("div", "load-warn-body",
      failed.map(function (f) { return f.label; }).join(", ") +
      (failed.length === 1 ? " is" : " are") +
      " missing below — what you can see is incomplete, not empty. " +
      "Nothing has been deleted; this device just could not reach the server."));
    var detail = failed.map(function (f) { return f.label + ": " + f.message; }).join(" · ");
    if (detail) { var d = el("div", "load-warn-detail", detail); box.appendChild(d); }
    var again = el("button", "mini-btn is-edit", "↻ Try again"); again.type = "button";
    again.addEventListener("click", function () { openTrip(t); });
    var row = el("div", "doc-actions"); row.appendChild(again);
    box.appendChild(row);
    return box;
  }

  function markSeen(tripId) {
    try { var s = getSeen(); s[tripId] = new Date().toISOString(); localStorage.setItem(SEEN_KEY, JSON.stringify(s)); } catch (e) {}
  }
  function changedSince(tripId, data) {
    var seen = getSeen()[tripId];
    if (!seen) return [];              // first visit: everything is "new", so say nothing
    var out = [];
    [].concat(data.transports || [], data.hostings || [], data.activities || []).forEach(function (o) {
      if (o.updated_at && o.updated_at > seen) out.push(o);
    });
    return out;
  }

  // ---- audit every upcoming trip at once ----
  // Reuses auditTrip so this can never drift from the per-trip check.
  async function auditAllUpcoming() {
    panelRoute("#check");
    if (restorePanel("#check")) return;
    var today = new Date().toISOString().slice(0, 10);
    var horizon = new Date(Date.now() + 180 * 86400000).toISOString().slice(0, 10);
    var trips = (state.own || []).filter(function (t) {
      return t.has_dates && t.ends_at && t.ends_at >= today && t.starts_at <= horizon;
    }).sort(function (a, b) { return String(a.starts_at).localeCompare(String(b.starts_at)); });

    var overlay = $("#detail-overlay"), content = $("#detail-content");
    content.innerHTML = "";
    overlay.hidden = false;
    document.body.style.overflow = "hidden";
    var inner = el("div", "detail-inner");
    inner.appendChild(el("h2", null, "Check all upcoming trips"));
    var status = el("div", "detail-meta", "Checking " + trips.length + " trip" + (trips.length === 1 ? "" : "s") + "…");
    inner.appendChild(status);
    var results = el("div"); inner.appendChild(results);
    content.appendChild(inner);
    cachePanel("#check", inner);

    if (!trips.length) { status.textContent = "No upcoming trips with dates in the next six months."; return; }

    var done = 0, totals = { issue: 0, warn: 0, info: 0 }, clean = 0, hiddenTotal = 0;
    // Kept so the cross-trip pass below can compare trips against each other.
    // Every check in auditTrip is blind outside its own trip, which is exactly
    // where a misfiled booking hides: both trips look internally consistent.
    var loaded = [], unread = [];
    var i = 0;
    async function worker() {
      while (i < trips.length) {
        var t = trips[i++];
        try {
          // Not `.catch(() => [])`. An empty trip passes every check, so a
          // trip that merely failed to LOAD was counted among the clean ones —
          // a green all-clear from the feature whose whole job is to find what
          // is wrong before you travel. A part that will not load fails the
          // trip out of the sweep and is reported at the bottom.
          var parts = await Promise.all([
            apiAll("/v1/trip/" + t.id + "/transportations"),
            apiAll("/v1/trip/" + t.id + "/hostings"),
            apiAll("/v1/trip/" + t.id + "/activities")
          ]);
          var data = { transports: parts[0], hostings: parts[1], activities: parts[2], expenses: [] };
          loaded.push({ trip: t, data: data });
          var findings = auditTrip(t, data);
          // Only the actionable levels are worth a cross-trip sweep; the
          // "missing seat / no coordinates" noise stays on the trip itself.
          // Snoozes and dismissals made on the trip page apply here too.
          var real = findings.filter(function (f) { return f.level !== "info" && !checkHiddenAs(f.key); });
          hiddenTotal += findings.filter(function (f) { return f.level !== "info" && checkHiddenAs(f.key); }).length;
          if (!real.length) { clean++; }
          else {
            var card = el("div", "detail-section");
            var h = el("h3", null, t.name || "Untitled trip");
            h.appendChild(el("span", "audit-when", fmtRange(t)));
            card.appendChild(h);
            real.forEach(function (f) {
              totals[f.level]++;
              var row = el("div", "health-row " + f.level);
              row.appendChild(el("div", "health-icon", f.level === "issue" ? "🔴" : "🟠"));
              var b = el("div", "health-body");
              b.appendChild(el("div", "health-title", f.title));
              b.appendChild(el("div", "health-detail", f.detail));
              var acts = el("div", "health-acts");
              var open = el("button", "mini-btn health-fix", "Open trip"); open.type = "button";
              open.addEventListener("click", function () { openTrip(t); });
              var sn = el("button", "mini-btn is-edit", "Snooze " + SNOOZE_DAYS + "d"); sn.type = "button"; sn.title = "Hide this for 14 days. Snoozes are yours alone - other people still see it.";
              sn.addEventListener("click", function () { hideCheck(f.key, "snoozed"); row.remove(); });
              var dm = el("button", "mini-btn is-edit", "Dismiss"); dm.type = "button"; dm.title = "Hide this for everyone. Dismissals apply to the whole household.";
              dm.addEventListener("click", function () { hideCheck(f.key, "dismissed"); row.remove(); });
              acts.appendChild(open); acts.appendChild(sn); acts.appendChild(dm);
              b.appendChild(acts);
              row.appendChild(b); card.appendChild(row);
            });
            results.appendChild(card);
          }
        } catch (e) {
          // One unreachable trip must not abort the sweep, but it must not pass
          // for a healthy one either.
          unread.push(t);
        }
        done++;
        status.textContent = "Checked " + done + " of " + trips.length + "…";
      }
    }
    await Promise.all([worker(), worker(), worker()]);

    // Now the checks that need more than one trip in hand at once.
    var cross = crossTripFindings(loaded).filter(function (f) { return !checkHiddenAs(f.key); });
    hiddenTotal += crossTripFindings(loaded).length - cross.length;
    if (cross.length) {
      var xcard = el("div", "detail-section");
      xcard.appendChild(el("h3", null, "Across trips"));
      cross.forEach(function (f) {
        totals[f.level]++;
        var row = el("div", "health-row " + f.level);
        row.appendChild(el("div", "health-icon", f.level === "issue" ? "🔴" : "🟠"));
        var b = el("div", "health-body");
        b.appendChild(el("div", "health-title", f.title));
        b.appendChild(el("div", "health-detail", f.detail));
        var acts = el("div", "health-acts");
        (f.trips || []).forEach(function (t) {
          var o = el("button", "mini-btn health-fix", "Open " + (t.name || "trip")); o.type = "button";
          o.addEventListener("click", function () { openTrip(t); });
          acts.appendChild(o);
        });
        var dm = el("button", "mini-btn is-edit", "Dismiss"); dm.type = "button";
        dm.title = "Hide this for everyone. Dismissals apply to the whole household.";
        dm.addEventListener("click", function () { hideCheck(f.key, "dismissed"); row.remove(); });
        acts.appendChild(dm);
        b.appendChild(acts);
        row.appendChild(b); xcard.appendChild(row);
      });
      results.appendChild(xcard);
    }

    // A trip that could not be read is reported first and separately. It is not
    // a finding — nothing is known to be wrong with it — but it is the reason
    // the all-clear below cannot be trusted, and saying so is the difference
    // between "checked" and "tried to check".
    if (unread.length) {
      var ucard = el("div", "detail-section");
      ucard.appendChild(el("h3", null, "Couldn't be checked"));
      var urow = el("div", "health-row warn");
      urow.appendChild(el("div", "health-icon", "🟠"));
      var ub = el("div", "health-body");
      ub.appendChild(el("div", "health-title",
        unread.length + " trip" + (unread.length === 1 ? "" : "s") + " could not be read"));
      ub.appendChild(el("div", "health-detail",
        unread.map(function (x) { return x.name || "Untitled trip"; }).join(", ") +
        " — the connection failed part-way. Nothing is wrong with " +
        (unread.length === 1 ? "it" : "them") + " as far as anyone knows; " +
        (unread.length === 1 ? "it was" : "they were") + " simply not checked. Run this again."));
      var uacts = el("div", "health-acts");
      var uagain = el("button", "mini-btn health-fix", "↻ Check again"); uagain.type = "button";
      uagain.addEventListener("click", function () { auditAllUpcoming(); });
      uacts.appendChild(uagain);
      ub.appendChild(uacts);
      urow.appendChild(ub); ucard.appendChild(urow);
      results.insertBefore(ucard, results.firstChild);
    }

    var checked = trips.length - unread.length;
    var summary = totals.issue || totals.warn
      ? totals.issue + " to fix · " + totals.warn + " to check · " + clean + " trip" + (clean === 1 ? "" : "s") + " clean"
      : "All " + checked + " upcoming trip" + (checked === 1 ? "" : "s") + " checked look clean.";
    if (unread.length) summary += " · " + unread.length + " couldn't be read";
    if (hiddenTotal) summary += " · " + hiddenTotal + " snoozed or dismissed";
    status.textContent = summary;
    // Only the things to FIX. A warn is "worth a look", and a badge that fires
    // on those would be lit permanently, which is the same as being off.
    noteAttention("check", totals.issue, !unread.length);
    if (!totals.issue && !totals.warn && !unread.length) {
      results.appendChild(el("div", "doc-empty", "No conflicts, gaps or open-ended bookings found."));
    }
  }

  // ---- conflicts that only show up between trips ----
  // auditTrip cannot see any of these, because each takes two trips to notice
  // and it is only ever handed one. A booking filed under the wrong trip is the
  // motivating case: the importer picks a trip by date proximity, and when it
  // guesses wrong BOTH trips still audit clean — the booking is simply somewhere
  // it does not belong, and nothing on either trip page can tell.
  //
  // Deliberately NOT checked: trips whose dates overlap. Tested against all 181
  // dated trips and it found two pairs, both entirely legitimate — a family
  // member's month at camp spanning a weekend away, and a 2011 same-day handoff.
  // A rule that is wrong every time it fires teaches you to ignore the panel.
  function crossTripFindings(loaded) {
    var out = [];
    var add = function (level, key, title, detail, trips) {
      out.push({ level: level, key: "x|" + key, title: title, detail: detail, trips: trips });
    };
    // One flat list of every booking on every trip, tagged with its trip.
    var all = [];
    loaded.forEach(function (L) {
      allItems(L.data).forEach(function (it) { all.push({ trip: L.trip, it: it }); });
    });

    // ---- 1. one confirmation code, two trips ----
    // Proven against live data: Air France AF22 under VPUI2K sat on two trips a
    // year apart. Either one is a duplicate, or a code was typed onto the wrong
    // booking — both are worth knowing, and neither is visible from one trip.
    var byCode = {};
    all.forEach(function (r) {
      var c = String(r.it.o.provider_reservation_code || "").trim().toUpperCase();
      if (c.length < 5) return;                       // short codes collide by chance
      (byCode[c] = byCode[c] || []).push(r);
    });
    Object.keys(byCode).forEach(function (c) {
      var rs = byCode[c];
      var tripIds = {}; rs.forEach(function (r) { tripIds[r.trip.id] = r.trip; });
      var ts = Object.keys(tripIds).map(function (k) { return tripIds[k]; });
      if (ts.length < 2) return;
      add("warn", "code|" + c,
        "Confirmation " + c + " is on " + ts.length + " different trips",
        rs.map(function (r) { return r.it.name + " on " + (r.trip.name || "a trip"); }).join(", ") +
        ". The same reference cannot belong to two separate bookings — one is a duplicate, or the code was copied onto the wrong item.",
        ts);
    });

    // ---- 2. a booking filed under the wrong trip ----
    // Only fires when the date sits outside its own trip AND squarely inside
    // exactly one other. Both halves matter: "outside its own trip" alone is
    // already reported per-trip and is often just a trip whose dates need
    // widening, and naming two candidate trips would be a guess.
    loaded.forEach(function (L) {
      if (!L.trip.has_dates || !L.trip.starts_at || !L.trip.ends_at) return;
      allItems(L.data).forEach(function (it) {
        if (!it.when) return;
        var k = dayKey(it.when, it.tz);
        if (k >= L.trip.starts_at && k <= L.trip.ends_at) return;      // where it should be
        var homes = loaded.filter(function (M) {
          return M.trip.id !== L.trip.id && M.trip.has_dates &&
            M.trip.starts_at && M.trip.ends_at && k >= M.trip.starts_at && k <= M.trip.ends_at;
        });
        if (homes.length !== 1) return;
        add("issue", "misfiled|" + it.o.id,
          it.name + " looks filed under the wrong trip",
          "It is dated " + dayLabel(k) + ", which falls inside " + (homes[0].trip.name || "another trip") +
          " (" + fmtRange(homes[0].trip) + ") but it is filed under " + (L.trip.name || "this trip") +
          " (" + fmtRange(L.trip) + "). The importer picks a trip by date, so a booking that arrived early or late can land on its neighbour.",
          [L.trip, homes[0].trip]);
      });
    });

    // ---- 3. the same journey entered twice, under different trips ----
    // Catches the duplicate that check 1 cannot: a booking with no confirmation
    // code, or two copies that were given different ones.
    var byLeg = {};
    all.forEach(function (r) {
      var o = r.it.o;
      if (r.it.kind !== "transport" || !o.departure_at) return;
      var sig = String(o.company || "").trim().toLowerCase() + "|" +
        String(o.transport_number || "").trim().toLowerCase() + "|" + o.departure_at;
      if (sig.indexOf("||") === 0) return;             // no company and no number: nothing to match on
      (byLeg[sig] = byLeg[sig] || []).push(r);
    });
    Object.keys(byLeg).forEach(function (sig) {
      var rs = byLeg[sig];
      var tripIds = {}; rs.forEach(function (r) { tripIds[r.trip.id] = r.trip; });
      var ts = Object.keys(tripIds).map(function (k) { return tripIds[k]; });
      if (ts.length < 2) return;
      add("warn", "dupleg|" + sig,
        rs[0].it.name + " is on two trips at the same time",
        "The same departure appears on " + ts.map(function (t) { return t.name || "a trip"; }).join(" and ") +
        ". One is almost certainly a duplicate — delete it from whichever trip it does not belong to.",
        ts);
    });

    return out;
  }

  // ---- change review ----
  // The importer records every field it rewrites on a booking it already knew
  // about, and the itinerary paints a "⟳ Changed" chip on the row. That told you
  // something had moved but never what it moved FROM, and finding it meant
  // opening each trip in turn and reading down the itinerary looking for chips.
  //
  // This is the other half. Every recorded change across the upcoming trips in
  // one list, newest first, with the old value beside the new one and the
  // importer's reason for the rewrite. Acknowledging puts the chip out, and it
  // rides the same household-wide store as a dismissal: a schedule change Alex
  // has read is not one Sam should be asked about again.
  //
  // The window is wider than the chip's. A change from six weeks ago no longer
  // deserves a marker on the itinerary, but if nobody ever acknowledged it, it
  // still belongs in the queue — that is the whole point of a queue.
  // ---- what is waiting behind "More" ----
  //
  // On a phone, five features collapse behind one unmarked "⋯ More" chip:
  // History, Check Trips, Changes, Calendar and Trip Ideas. Two of them can
  // actually want something -- a flight the importer rewrote, a booking that
  // conflicts with another -- and behind an unmarked chip the only way to find
  // out is to go and look, which nobody does on a Tuesday. The feature was
  // effectively off on the device it matters most on.
  //
  // Neither count is cheap. Both sweeps read every item on every upcoming trip,
  // which is precisely the traffic P1 and P2 went to some trouble to remove, so
  // this does not run one in order to draw a badge. It remembers what the last
  // sweep found and shows that -- the way a mail app shows the count it had at
  // its last sync. Opening the panel runs the real thing and corrects it.
  //
  // Which makes the badge a claim about the past, and it is labelled as one:
  // the tooltip says "when you last looked". It expires after two weeks,
  // because a count from a month ago is describing a trip you have taken.
  function readAttention() {
    var out = {};
    try {
      var raw = JSON.parse(localStorage.getItem(ATTN_KEY) || "{}");
      var cut = Date.now() - ATTN_MAX_DAYS * 86400000;
      Object.keys(raw).forEach(function (k) {
        var v = raw[k];
        if (v && isFinite(v.n) && v.n > 0 && v.at > cut) out[k] = v;
      });
    } catch (e) { /* corrupt or unavailable store: no badge, no error */ }
    return out;
  }

  // `complete` is false when the sweep could not read every trip. A partial
  // sweep that found nothing has not established that there is nothing, so it
  // must not clear a badge it never earned the right to clear -- otherwise one
  // failed request silently marks everything as handled.
  function noteAttention(which, n, complete) {
    try {
      var all = {};
      try { all = JSON.parse(localStorage.getItem(ATTN_KEY) || "{}") || {}; } catch (e2) { all = {}; }
      if (!n && !complete && all[which] && all[which].n) { drawMoreBadge(); return; }
      all[which] = { n: n || 0, at: Date.now() };
      localStorage.setItem(ATTN_KEY, JSON.stringify(all));
    } catch (e) { /* private mode or quota -- a badge is not worth an error */ }
    drawMoreBadge();
  }

  var moreChip = null;
  function drawMoreBadge() {
    if (!moreChip) return;
    var all = readAttention(), n = 0;
    Object.keys(all).forEach(function (k) { n += all[k].n || 0; });
    var dot = moreChip.querySelector(".chip-badge");
    if (!n) { if (dot) dot.remove(); moreChip.title = MORE_TITLE; return; }
    if (!dot) { dot = el("span", "chip-badge"); moreChip.appendChild(dot); }
    // Past nine the exact number stops changing the decision, and three digits
    // stop fitting the chip.
    dot.textContent = n > 9 ? "9+" : String(n);
    var parts = [];
    if (all.check && all.check.n) parts.push(all.check.n + " to fix in Check Trips");
    if (all.changes && all.changes.n) parts.push(all.changes.n + " to review in Changes");
    moreChip.title = parts.join("  ·  ") + " — as of when you last looked";
    // The chip reads as "More" to a screen reader without this; the badge is a
    // number with no stated subject.
    moreChip.setAttribute("aria-label", "More — " + parts.join(", "));
  }

  var CHANGE_REVIEW_DAYS = 120;

  async function reviewChanges() {
    panelRoute("#changes");
    if (restorePanel("#changes")) return;
    var today = new Date().toISOString().slice(0, 10);
    var trips = (state.own || []).filter(function (t) {
      return t.has_dates && t.ends_at && t.ends_at >= today;
    }).sort(function (a, b) { return String(a.starts_at).localeCompare(String(b.starts_at)); });

    var overlay = $("#detail-overlay"), content = $("#detail-content");
    content.innerHTML = "";
    overlay.hidden = false;
    document.body.style.overflow = "hidden";
    var inner = el("div", "detail-inner");
    inner.appendChild(el("h2", null, "What changed"));
    var status = el("div", "detail-meta", "Reading " + trips.length + " upcoming trip" + (trips.length === 1 ? "" : "s") + "…");
    inner.appendChild(status);
    var actions = el("div", "doc-actions"); inner.appendChild(actions);
    var results = el("div"); inner.appendChild(results);
    content.appendChild(inner);
    cachePanel("#changes", inner);

    if (!trips.length) { status.textContent = "No upcoming trips with dates."; return; }

    var cut = Date.now() - CHANGE_REVIEW_DAYS * 86400000;
    var rows = [], acked = 0, i = 0, unread = [];
    async function worker() {
      while (i < trips.length) {
        var t = trips[i++];
        try {
          var parts = await Promise.all([
            apiAll("/v1/trip/" + t.id + "/transportations"),
            apiAll("/v1/trip/" + t.id + "/hostings"),
            apiAll("/v1/trip/" + t.id + "/activities")
          ]);
          allItems({ transports: parts[0], hostings: parts[1], activities: parts[2] }).forEach(function (it) {
            changesOf(it.o).forEach(function (c) {
              var when = Date.parse(c.at);
              if (!isFinite(when) || when < cut) return;
              if (checkHiddenAs(changeKey(it.o, c))) { acked++; return; }
              rows.push({ trip: t, it: it, c: c, when: when });
            });
          });
        } catch (e) {
          // One unreachable trip must not abort the sweep, but "no changes" and
          // "could not look" are opposite answers and must not print the same.
          unread.push(t);
        }
      }
    }
    await Promise.all([worker(), worker(), worker()]);

    rows.sort(function (a, b) { return b.when - a.when; });

    // Sits above the list either way: it qualifies a "nothing new" and it
    // qualifies a count, because in both cases some trips were never read.
    var unreadNote = function () {
      if (!unread.length) return null;
      var n = el("div", "load-warn");
      n.appendChild(el("div", "load-warn-title",
        unread.length + " trip" + (unread.length === 1 ? "" : "s") + " couldn't be read"));
      n.appendChild(el("div", "load-warn-body",
        unread.map(function (x) { return x.name || "Untitled trip"; }).join(", ") +
        " — the connection failed, so any changes on " +
        (unread.length === 1 ? "it are" : "them are") + " not listed below."));
      var again = el("button", "mini-btn is-edit", "↻ Read again"); again.type = "button";
      again.addEventListener("click", function () { reviewChanges(); });
      var row = el("div", "doc-actions"); row.appendChild(again);
      n.appendChild(row);
      return n;
    };

    if (!rows.length) {
      noteAttention("changes", 0, !unread.length);
      var un = unreadNote();
      if (un) results.appendChild(un);
      status.textContent = unread.length
        ? "Read " + (trips.length - unread.length) + " of " + trips.length + " trips — nothing new in those."
        : (acked
          ? "Nothing new. " + acked + " change" + (acked === 1 ? " has" : "s have") + " already been acknowledged."
          : "No changes recorded on your upcoming trips.");
      results.appendChild(el("div", "doc-empty",
        "When the importer rewrites a booking you already had — a flight moved, a gate reassigned, a room changed — it lands here with the old value beside the new one."));
      return;
    }

    var un2 = unreadNote();
    if (un2) results.appendChild(un2);
    status.textContent = rows.length + " change" + (rows.length === 1 ? "" : "s") + " to review" +
      (acked ? " · " + acked + " already acknowledged" : "") +
      (unread.length ? " · " + unread.length + " trip" + (unread.length === 1 ? "" : "s") + " unread" : "");
    noteAttention("changes", rows.length, !unread.length);

    var ackAll = el("button", "mini-btn is-edit", "✓ Acknowledge all"); ackAll.type = "button";
    ackAll.title = "Mark every change below as read. Applies to the whole household.";
    ackAll.addEventListener("click", function () {
      if (!confirm("Mark all " + rows.length + " changes as read?")) return;
      rows.forEach(function (r) { hideCheck(changeKey(r.it.o, r.c), "dismissed"); });
      reviewChanges();
    });
    actions.appendChild(ackAll);

    // Grouped by trip so a cluster of edits to one booking reads as one event
    // rather than four unrelated lines.
    var byTrip = [];
    rows.forEach(function (r) {
      var g = byTrip.filter(function (x) { return x.trip.id === r.trip.id; })[0];
      if (!g) { g = { trip: r.trip, rows: [] }; byTrip.push(g); }
      g.rows.push(r);
    });

    byTrip.forEach(function (g) {
      var card = el("div", "detail-section");
      var h = el("h3", null, g.trip.name || "Untitled trip");
      h.appendChild(el("span", "audit-when", fmtRange(g.trip)));
      card.appendChild(h);
      // Same wrapper trick as the flights view: nth-child has to count rows and
      // not the trip heading. Scoped rather than styling .health-row itself,
      // which the trip check also uses — that list is a set of distinct
      // findings, not a run of like rows, and does not want banding.
      var chgWrap = el("div", "chg-rows");
      card.appendChild(chgWrap);
      g.rows.forEach(function (r) {
        var row = el("div", "health-row warn");
        row.appendChild(el("div", "health-icon", "⟳"));
        var b = el("div", "health-body");
        b.appendChild(el("div", "health-title", changeLabel(r.c.field) + " · " + r.it.name));
        var swap = el("div", "chg-swap");
        swap.appendChild(el("span", "chg-from", changeValue(r.c.field, r.c.from, r.it.tz)));
        swap.appendChild(el("span", "chg-arrow", "→"));
        swap.appendChild(el("span", "chg-to", changeValue(r.c.field, r.c.to, r.it.tz)));
        b.appendChild(swap);
        var meta = "Recorded " + fmtWhen(r.c.at, r.it.tz);
        if (r.c.why) meta += " · " + r.c.why;
        b.appendChild(el("div", "health-detail", meta));
        var acts = el("div", "health-acts");
        var open = el("button", "mini-btn health-fix", "Open trip"); open.type = "button";
        open.addEventListener("click", function () { openTrip(g.trip); });
        var ok = el("button", "mini-btn is-edit", "✓ Acknowledge"); ok.type = "button";
        ok.title = "Mark as read and clear the ⟳ chip. Applies to the whole household.";
        ok.addEventListener("click", function () {
          hideCheck(changeKey(r.it.o, r.c), "dismissed");
          row.remove();
          if (!card.querySelector(".health-row")) card.remove();
          if (!results.querySelector(".health-row")) {
            status.textContent = "All caught up.";
            actions.innerHTML = "";
          }
        });
        acts.appendChild(open); acts.appendChild(ok);
        b.appendChild(acts);
        row.appendChild(b); chgWrap.appendChild(row);
      });
      results.appendChild(card);
    });
  }

  // ---- trip documents ----
  // Two kinds live side by side. A LINK points at somebody else's host — an
  // airline page, an iCloud share — and is only as durable as that link. A FILE
  // is stored in R2 and served back through /api/v1/doc behind Access, so it is
  // exactly as protected as the itinerary, and it still opens in five years when
  // the airline has redesigned its site.
  //
  // Uploading was impossible for the whole life of this app — the old backend's
  // upload endpoint 404'd — which is why all 181 trips had zero documents.
  var MAX_UPLOAD_MB = 25;

  // Which itinerary item a document is attached to, or null.
  //
  // The link lives on the document (parent_type/parent_id), not on the item, so
  // it resolves the same way an expense's does — and fails the same way, by
  // returning nothing when the booking it points at has been deleted rather
  // than by rendering a row for something that is not there.
  function docParent(d, data) {
    if (!d || !d.parent_type || d.parent_id == null || !data) return null;
    return linkedItem({ linked_kind: d.parent_type === "transportation" ? "transport" : d.parent_type,
      linked_id: d.parent_id }, data);
  }

  // Every document attached to one itinerary item.
  function docsFor(o, kind, data) {
    if (!o || !data) return [];
    return (data.documents || []).filter(function (d) {
      return d && d.parent_type === kind && String(d.parent_id) === String(o.id);
    });
  }

  // The API routes documents on the same singulars as everything else, so a
  // transport is "transportation" here too.
  var DOC_PARENT = { transport: "transportation", hosting: "hosting", activity: "activity", expense: "expense" };

  // What a DOCUMENT may be attached to: everything on the itinerary, plus the
  // expenses, because a receipt belongs to the expense it paid for.
  //
  // Deliberately not linkableItems, which answers a different question — what an
  // EXPENSE may be filed under — and must never offer an expense, or one could
  // be filed under itself.
  function documentTargets(data) {
    return linkableItems(data).concat(((data && data.expenses) || []).map(function (x) {
      return { key: "expense:" + x.id, kind: "expense", id: x.id,
        label: "🧾  " + (x.title || x.name || x.description || "Expense") +
          (x.date ? "  ·  " + new Date(x.date + "T12:00:00").toLocaleDateString(dateLocale(),
            { month: "short", day: "numeric" }) : "") };
    }));
  }

  function renderDocuments(root, t, docs, data) {
    docs = docs || [];
    var box = collapsibleSection("Documents");
    var sec = box.body;
    if (docs.length) box.badge(el("span", "health-pill info", String(docs.length)));
    // Both actions on one row of their own. Hung off the heading they wrapped in
    // the narrow side column, dropping Upload File onto its own line under Add
    // Link and reading as two unrelated controls.
    var docActs = el("div", "doc-actions");
    var up = el("button", "mini-btn is-edit", "⬆ Upload File"); up.type = "button";
    up.addEventListener("click", function () { pickAndUpload(t); });
    var add = el("button", "mini-btn is-edit", "🔗 Add Link"); add.type = "button";
    add.addEventListener("click", function () { addDocument(t); });
    docActs.appendChild(up); docActs.appendChild(add);
    sec.appendChild(docActs);

    if (!docs.length) {
      sec.appendChild(el("div", "doc-empty",
        "No documents yet. Upload a passport scan, boarding pass or rental agreement — it's stored privately and opens on any device you sign in on."));
      box.mount(root);
      return;
    }
    // Attached ones first, grouped under the booking they belong to, then the
    // loose ones. A trip's papers divide that way in a folder and in your head.
    var linked = [], loose = [];
    docs.forEach(function (d) {
      var p = docParent(d, data);
      (p ? linked : loose).push({ d: d, parent: p });
    });
    linked.sort(function (a, b) { return String(a.parent.label).localeCompare(String(b.parent.label)); });

    var list = el("div", "doc-rows");
    linked.concat(loose).forEach(function (x) {
      var d = x.d, stored = !!d.r2_key;
      var row = el("div", "doc-row");
      row.appendChild(el("div", "itin-icon", stored ? "📄" : "🔗"));
      var b = el("div", "itin-body");
      b.appendChild(el("div", "itin-title", d.title || "Document"));
      var sub = [];
      if (stored) { if (d.filename) sub.push(d.filename); if (d.size) sub.push(fmtBytes(d.size)); }
      if (x.parent) sub.push("part of " + x.parent.label);
      if (sub.length) b.appendChild(el("div", "itin-sub", sub.join(" · ")));
      var links = el("div", "itin-links");
      var href = d.temp_read_url || d.url;
      if (href) links.appendChild(alink("↗ Open", href));
      // A stored file can be pulled down; a link belongs to whoever hosts it.
      if (stored) links.appendChild(alink("⬇ Download", href + "?download=1"));
      var ed = el("button", "linkchip is-edit", "✎"); ed.type = "button";
      ed.title = "Rename, or change what this is part of";
      ed.addEventListener("click", function () { editDocument(t, d, data); });
      links.appendChild(ed);
      var del = el("button", "linkchip danger is-edit", "🗑"); del.type = "button";
      del.addEventListener("click", function () { deleteDocument(t, d); });
      links.appendChild(del);
      b.appendChild(links);
      row.appendChild(b);
      list.appendChild(row);
    });
    sec.appendChild(list);
    box.mount(root);
  }

  // Rename a document, and choose what it belongs to. Same picker the budget
  // uses for an expense, for the same reason: the thing you are attaching to is
  // an itinerary item, and there is only one sensible way to name one.
  function editDocument(trip, d, data) {
    var cur = d.parent_type && d.parent_id != null
      ? (d.parent_type === "transportation" ? "transport" : d.parent_type) + ":" + d.parent_id : "";
    var opts = [{ value: "", label: "Not part of anything" }].concat(
      documentTargets(data || {}).map(function (i) { return { value: i.key, label: i.label }; }));
    formDialog("Edit “" + String(d.title || "document").slice(0, 40) + "”", [
      { name: "title", label: "Title", value: d.title || "" },
      { name: "linked", label: "Part of", type: "select", value: cur, options: opts },
    ], async function (v) {
      if (!v.title) throw new ApiError("Give it a title.", 0);
      var link = String(v.linked || "").split(":");
      var body = { title: v.title, parent_type: null, parent_id: null };
      if (link.length === 2) { body.parent_type = DOC_PARENT[link[0]] || link[0]; body.parent_id = Number(link[1]); }
      await api("/v1/trip/" + trip.id + "/documents/" + d.id, { method: "PATCH", body: JSON.stringify(body) });
      toast("Saved"); openTrip(trip);
    });
  }

  function fmtBytes(n) {
    n = Number(n) || 0;
    if (!n) return "";
    if (n < 1024) return n + " B";
    if (n < 1048576) return (n / 1024).toFixed(0) + " KB";
    return (n / 1048576).toFixed(1) + " MB";
  }

  // The file picker is created and discarded per use: a persistent hidden input
  // remembers its last selection, which makes re-uploading the same file after a
  // failure silently do nothing.
  function pickAndUpload(t, kind, o) {
    var inp = document.createElement("input");
    inp.type = "file";
    inp.accept = ".pdf,.png,.jpg,.jpeg,.heic,.webp,.txt,.doc,.docx,.pages,.eml";
    inp.addEventListener("change", async function () {
      var f = inp.files && inp.files[0];
      if (!f) return;
      if (f.size > MAX_UPLOAD_MB * 1048576) {
        toast("That file is " + fmtBytes(f.size) + ". The limit is " + MAX_UPLOAD_MB + " MB.");
        return;
      }
      var fd = new FormData();
      fd.append("file", f, f.name);
      fd.append("title", f.name.replace(/\.[^.]+$/, ""));
      var path = kind && o
        ? "/v1/trip/" + t.id + "/" + kind + "/" + o.id + "/documents/upload"
        : "/v1/trip/" + t.id + "/documents/upload";
      // A sticky toast with a bar, rather than an ordinary one that announces
      // the filename and disappears while the upload is still going. See
      // progressToast: the silent middle is when somebody taps Attach again.
      var prog = progressToast("Uploading " + f.name + "…");
      prog.set(0);
      try {
        // No Content-Type header: the browser must set it, because only it
        // knows the multipart boundary it generated.
        await uploadWithProgress(path, fd, function (fraction, text) {
          prog.set(fraction, text);
        });
        prog.done("Uploaded " + f.name);
        openTrip(t);
      } catch (e) {
        // The sticky toast has no timer, so every exit from here must end it.
        prog.fail("Upload failed: " + e.message);
      }
    });
    inp.click();
  }
  // Attaching from an itinerary row.
  //
  // This no longer files a document away under the item. It adds one to the
  // trip's Documents — where every document lives, and where this one can be
  // renamed, re-attached or removed — and links it to the row you started from,
  // so it also appears on that row. One document, two places to reach it,
  // rather than the old arrangement where an attached document was reachable
  // from neither.
  //
  // One chip that asks which, rather than two chips on every row. An itinerary
  // row already carries Maps, Attach, Nearby and more, and the last round of
  // trimming was to get that count DOWN — spending a permanent chip on the
  // rarer of two actions would undo it.
  function attachItemDocument(trip, kind, o, label) {
    openChooser("Attach to “" + String(label || "item").slice(0, 40) + "”", [
      ["⬆️", "Upload A File", function () { pickAndUpload(trip, kind, o); }],
      ["🔗", "Add A Link", function () { attachItemLink(trip, kind, o, label); }]
    ]);
  }

  function attachItemLink(trip, kind, o, label) {
    formDialog("Link on “" + String(label || "item").slice(0, 40) + "”", [
      { name: "title", label: "Title", value: "", placeholder: "Boarding pass" },
      { name: "url", label: "Link (https://…)", value: "", placeholder: "Dropbox / airline / iCloud link" }
    ], async function (v) {
      if (!v.title) throw new ApiError("Give it a title.", 0);
      if (!/^https?:\/\//i.test(v.url)) throw new ApiError("Enter a full link starting with https://", 0);
      await api("/v1/trip/" + trip.id + "/" + kind + "/" + o.id + "/documents", {
        method: "POST", body: JSON.stringify({ title: v.title, url: v.url, file_type: "url" })
      });
      toast("Added to Documents"); openTrip(trip);
    });
  }

  function addDocument(t) {
    formDialog("Add a document link", [
      { name: "title", label: "Title", value: "" , placeholder: "Boarding pass — AA1595" },
      { name: "url", label: "Link (https://…)", value: "", placeholder: "Dropbox / iCloud / airline link" }
    ], async function (v) {
      if (!v.title) throw new ApiError("Give it a title.", 0);
      if (!/^https?:\/\//i.test(v.url)) throw new ApiError("Enter a full link starting with https://", 0);
      await api("/v1/trip/" + t.id + "/documents", { method: "POST", body: JSON.stringify({
        title: v.title, url: v.url, file_type: "url"
      }) });
      toast("Document added"); openTrip(t);
    });
  }
  async function deleteDocument(t, d) {
    if (!window.confirm("Remove “" + (d.title || "this document") + "”?")) return;
    try { await api("/v1/trip/" + t.id + "/documents/" + d.id, { method: "DELETE" }); toast("Removed"); openTrip(t); }
    catch (e) { toast("Couldn't remove: " + e.message); }
  }

  // ---- destination clock ----
  // Shows the current local time where you're going, when it differs from here.
  var destClockTimer = null;
  function startDestClock(inner, t, data) {
    if (destClockTimer) { clearInterval(destClockTimer); destClockTimer = null; }
    var tz = tripTz(t, data);
    if (!tz || tz === LOCAL_TZ) return;
    var meta = inner.querySelector(".detail-meta"); if (!meta) return;
    var chip = el("span", "dest-clock");
    meta.appendChild(chip);
    function tick() {
      if (!document.body.contains(chip)) { clearInterval(destClockTimer); destClockTimer = null; return; }
      try {
        var now = new Date();
        var there = new Intl.DateTimeFormat(undefined, { timeZone: tz, hour: "numeric", minute: "2-digit" }).format(now);
        var city = tz.split("/").pop().replace(/_/g, " ");
        chip.textContent = " · 🕒 " + there + " in " + city;
      } catch (e) { chip.textContent = ""; }
    }
    tick();
    destClockTimer = setInterval(tick, 30000);
  }

  // ---- duplicate a trip ----
  // Clones the trip and every item, shifting all timed values by the difference
  // between the old and new start date so a repeat trip keeps its shape.
  async function duplicateTrip(t) {
    formDialog("Duplicate “" + (t.name || "trip") + "”", [
      { name: "name", label: "New trip name", value: (t.name || "Trip") + " (copy)" },
      { name: "starts_at", label: "New start date", type: "date", value: t.starts_at || "" }
    ], async function (v) {
      if (!v.name) throw new ApiError("Enter a name.", 0);
      if (!v.starts_at) throw new ApiError("Pick a start date.", 0);
      var shift = 0;
      if (t.starts_at) shift = Date.parse(v.starts_at + "T00:00:00Z") - Date.parse(t.starts_at + "T00:00:00Z");
      var days = Math.round(shift / 86400000);
      var newEnd = t.ends_at ? new Date(Date.parse(t.ends_at + "T00:00:00Z") + shift).toISOString().slice(0, 10) : null;

      var created = await api("/v1/trips", { method: "POST", body: JSON.stringify({
        name: v.name, starts_at: v.starts_at, ends_at: newEnd, has_dates: true, timezone: t.timezone || null
      }) });
      var nid = created && created.id;
      if (!nid) throw new ApiError("Could not create the trip.", 0);

      var src = currentData || { transports: [], hostings: [], activities: [], expenses: [] };
      var moved = function (iso) { return iso ? new Date(Date.parse(iso) + shift).toISOString().replace(".000", "") : null; };
      var strip = function (o, keys) { var out = {}; keys.forEach(function (k) { if (o[k] !== undefined && o[k] !== null) out[k] = o[k]; }); return out; };

      // Everything to copy, gathered first, so the progress can say how much
      // there is and one failure does not abandon the rest.
      var jobs = [];
      (src.transports || []).forEach(function (x) {
        var b = strip(x, ["transportation_type", "company", "transport_number", "departure_description", "arrival_description",
          "departure_address", "arrival_address", "departure_latitude", "departure_longitude", "arrival_latitude",
          "arrival_longitude", "departure_timezone", "arrival_timezone", "seat_class", "vehicle_description", "notes", "currency"]);
        b.departure_at = moved(x.departure_at); b.arrival_at = moved(x.arrival_at);
        jobs.push({ plural: "transportations", body: b, label: recordLabel("transport", x) || "a transport" });
      });
      (src.hostings || []).forEach(function (h) {
        var hb = strip(h, ["name", "address", "latitude", "longitude", "timezone", "room_type", "phone", "website", "notes", "currency"]);
        hb.starts_at = moved(h.starts_at); hb.ends_at = moved(h.ends_at);
        jobs.push({ plural: "hostings", body: hb, label: recordLabel("hosting", h) || "a hotel" });
      });
      (src.activities || []).forEach(function (a) {
        var ab = strip(a, ["name", "activity_type", "address", "latitude", "longitude", "timezone", "phone", "website", "notes", "currency"]);
        ab.starts_at = moved(a.starts_at); ab.ends_at = moved(a.ends_at);
        jobs.push({ plural: "activities", body: ab, label: recordLabel("activity", a) || "an activity" });
      });

      // A trip with thirteen items was thirteen awaited POSTs in a row with
      // nothing on screen, and a failure at the eighth threw -- leaving a trip
      // that already had seven items in it, invisible on the dashboard behind
      // an error message about the eighth. Neither half of that is acceptable:
      // it has to say how far it has got, and what it made has to be findable.
      var failed = [];
      if (jobs.length) {
        var done = 0, next = 0;
        var prog = progressToast("Copying 1 of " + jobs.length + "…");
        prog.set(0);
        // Four at a time. Each POST is independent -- sort_order is not copied,
        // so the itinerary orders itself chronologically and arrival order does
        // not matter -- and the same worker-pool shape reviewChanges uses.
        var worker = async function () {
          while (next < jobs.length) {
            var job = jobs[next++];
            try {
              await api("/v1/trip/" + nid + "/" + job.plural, { method: "POST", body: JSON.stringify(job.body) });
            } catch (e) {
              // Recorded and carried on. One unreachable item must not cost you
              // the other twelve, and it must not disappear either.
              failed.push(job.label);
            }
            done++;
            prog.set(done / jobs.length,
              done < jobs.length ? "Copying " + (done + 1) + " of " + jobs.length + "…" : "Finishing…");
          }
        };
        await Promise.all([worker(), worker(), worker(), worker()]);
        prog.done(null);
      }

      var shifted = days ? " (shifted " + days + " days)" : "";
      if (failed.length) {
        // Named, not counted. "2 items failed" tells you to go hunting; the
        // names tell you what to re-add.
        var names = failed.slice(0, 3).join(", ") + (failed.length > 3 ? " and " + (failed.length - 3) + " more" : "");
        toast("Copied " + (jobs.length - failed.length) + " of " + jobs.length +
          " items. These did not copy: " + names, { error: true });
      } else {
        toast("Duplicated" + shifted);
      }
      // Straight into the copy, rather than back to the dashboard. It matters
      // most when something failed: the trip that exists is the one you need to
      // look at, and leaving it in a list of a hundred and eighty is how a
      // half-copied trip goes unnoticed.
      await loadAll();
      var made = (state.own || []).filter(function (x) { return x.id === nid; })[0];
      if (made) openTrip(made); else closeDetail();
    });
  }

  // ---- currency conversion (Frankfurter / ECB reference rates, free) ----
  async function addConverted(headingEl, totals) {
    var home = (state.me && state.me.default_currency) || "USD";
    try {
      var d = await ext("fx?base=" + encodeURIComponent(home));
      if (!d || !d.rates) return;
      var sum = 0, ok = true;
      Object.keys(totals).forEach(function (cur) {
        if (cur === home) { sum += totals[cur]; return; }
        var rate = d.rates[cur];           // rates are "1 home = rate cur"
        if (!rate) { ok = false; return; }
        sum += totals[cur] / rate;
      });
      if (!ok || !sum) return;
      var span = el("span", "budget-conv", " ≈ " + money(sum, home));
      span.title = "Converted at ECB reference rates, " + d.date;
      headingEl.appendChild(span);
    } catch (e) { /* conversion is optional */ }
  }

  // ---- weather (Open-Meteo, free/keyless via /api/ext) ----
  // Only forecast-range days get a reading; Open-Meteo looks ~16 days ahead, so
  // past trips and far-future trips simply show nothing rather than a wrong guess.
  var WX = { 0: "☀️", 1: "🌤️", 2: "⛅", 3: "☁️", 45: "🌫️", 48: "🌫️", 51: "🌦️", 53: "🌦️", 55: "🌦️",
    61: "🌧️", 63: "🌧️", 65: "🌧️", 71: "🌨️", 73: "🌨️", 75: "❄️", 77: "🌨️", 80: "🌦️", 81: "🌧️",
    82: "⛈️", 85: "🌨️", 86: "❄️", 95: "⛈️", 96: "⛈️", 99: "⛈️" };
  async function decorateWeather(dayHeads, data) {
    var keys = Object.keys(dayHeads); if (!keys.length) return;
    var today = new Date().toISOString().slice(0, 10);
    var wanted = keys.filter(function (k) { return k >= today; }).sort();
    if (!wanted.length) return;
    var horizon = new Date(Date.now() + 15 * 86400000).toISOString().slice(0, 10);
    wanted = wanted.filter(function (k) { return k <= horizon; });
    if (!wanted.length) return;
    // The DESTINATION, not the first coordinate -- see destPoint. This line
    // reported Los Angeles for a trip to Spain until 2026-08-28.
    var pt = destPoint(data);
    if (!pt) return;
    try {
      var d = await ext("weather?lat=" + pt.lat + "&lon=" + pt.lng + "&start=" + wanted[0] + "&end=" + wanted[wanted.length - 1] + "&u=" + getDisplay().units);
      if (!d || !d.daily || !d.daily.time) return;
      d.daily.time.forEach(function (day, i) {
        var head = dayHeads[day]; if (!head) return;
        var code = d.daily.weather_code ? d.daily.weather_code[i] : null;
        var hi = d.daily.temperature_2m_max ? Math.round(d.daily.temperature_2m_max[i]) : null;
        var lo = d.daily.temperature_2m_min ? Math.round(d.daily.temperature_2m_min[i]) : null;
        var pop = d.daily.precipitation_probability_max ? d.daily.precipitation_probability_max[i] : null;
        if (hi == null) return;
        var deg = getDisplay().units === "metric" ? "°C" : "°F";
        var bits = (WX[code] || "") + " " + hi + "°/" + lo + deg + (pop >= 30 ? " · " + pop + "% rain" : "");
        var span = el("span", "day-wx", bits);
        // Sunset earns the visible half: it is the one people plan an evening
        // around. Sunrise and the length of the day go in the title, which
        // keeps the line the same width it has always been.
        var ss = d.daily.sunset && d.daily.sunset[i];
        var sr = d.daily.sunrise && d.daily.sunrise[i];
        if (ss) {
          span.appendChild(el("span", "day-sun", " ☾ " + clockOf(ss)));
          var hrs = d.daily.daylight_duration ? (d.daily.daylight_duration[i] / 3600) : null;
          span.title = (sr ? "Sunrise " + clockOf(sr) + ", sunset " + clockOf(ss) : "") +
            (hrs ? " — " + hrs.toFixed(1) + " hours of daylight" : "");
        }
        head.appendChild(span);
      });
    } catch (e) { /* weather is a nicety; never block the itinerary on it */ }

  }

  // Open-Meteo returns "2026-08-28T19:24"; only the clock is wanted, in the
  // reader's own format.
  function clockOf(iso) {
    var m = /T(\d{2}):(\d{2})/.exec(String(iso || ""));
    if (!m) return "";
    var d = new Date(2000, 0, 1, Number(m[1]), Number(m[2]));
    try {
      return d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
    } catch (e) { return m[1] + ":" + m[2]; }
  }

  // ---- what it is usually like, for the trips a forecast cannot reach ----
  //
  // The forecast runs about 16 days. On 2026-08-25 the five upcoming trips were
  // 32, 51, 114, 149 and 240 days out, so this feature was dark on every one of
  // them -- it only ever lit up in the fortnight before departure, which is
  // after the bag is packed.
  //
  // This is the same calendar window averaged over the last five years. It is
  // NOT a forecast and is never dressed as one: the figures are muted, prefixed
  // with "usually", and the title says how many years they came from.
  async function decorateTypical(dayHeads, data) {
    var pt = destPoint(data);
    if (!pt) return;
    var keys = Object.keys(dayHeads);
    // The same horizon decorateWeather uses. Anything past it gets no forecast,
    // which is the whole reason this exists -- so it is computed here rather
    // than handed down from a function that returns before reaching this one.
    var horizon = new Date(Date.now() + 15 * 86400000).toISOString().slice(0, 10);
    var far = keys.filter(function (k) { return k > horizon; }).sort();
    if (!far.length) return;
    try {
      var d = await ext("typical?lat=" + pt.lat + "&lon=" + pt.lng +
        "&start=" + far[0] + "&end=" + far[far.length - 1] + "&u=" + getDisplay().units);
      if (!d || !d.days || !d.days.length) return;
      var byMd = {};
      d.days.forEach(function (x) { byMd[x.md] = x; });
      var deg = getDisplay().units === "metric" ? "°C" : "°F";
      far.forEach(function (day) {
        var head = dayHeads[day]; if (!head) return;
        var x = byMd[day.slice(5)]; if (!x) return;
        var span = el("span", "day-wx is-typical", "usually " + x.hi + "°/" + x.lo + deg);
        span.title = "Average of the same dates over the last " + x.years +
          " years" + (x.wet ? ", " + x.wet + " of them wet" : "") + ". Not a forecast.";
        head.appendChild(span);
      });
    } catch (e) { /* the same nicety rule as the forecast */ }
  }

  // ---- a public holiday where you are going -----------------------------
  //
  // Shops shut, museums shut, and a day of the itinerary quietly stops working.
  // Rendered on the day heading beside the weather rather than anywhere new.
  //
  // NATIONAL holidays only -- the server filters on Nager's `global` flag,
  // which for Spain is 10 of 32; the rest are regional and would fire for a
  // Madrid trip they do not touch. Even so this is a heads-up, not an
  // authority: coverage varies by country and religious observances that close
  // things are often missing, which is why the title says "may be affected"
  // rather than asserting anything.
  async function decorateHolidays(dayHeads, data) {
    var keys = Object.keys(dayHeads); if (!keys.length) return;
    var pt = destPoint(data); if (!pt) return;
    var years = {};
    keys.forEach(function (k) { years[k.slice(0, 4)] = true; });
    try {
      var c = await ext("country?lat=" + pt.lat + "&lon=" + pt.lng);
      if (!c || !c.cc) return;
      var all = [];
      for (var y in years) {
        var h = await ext("holidays?cc=" + c.cc + "&year=" + y);
        if (h && h.results) all = all.concat(h.results);
      }
      all.forEach(function (h) {
        var head = dayHeads[h.date]; if (!head) return;
        var span = el("span", "day-holiday", "🎌 " + h.name);
        span.title = h.english + " — a public holiday in " + (c.name || c.cc) +
          ". Opening hours and transport may be affected.";
        head.appendChild(span);
      });
    } catch (e) { /* same rule: never block the itinerary on a nicety */ }
  }


  // ---- watching a flight you are on ----
  //
  // Flightradar24 by deep link, not by API. Alex's subscription covers the
  // site and the app, not their commercial API, and a link needs neither: it
  // opens a page he is already entitled to, and on a phone the FR24 app claims
  // fr24.com links and opens there instead.
  //
  // /data/flights/<iata> takes the flight number as it is already stored —
  // verified against the live site, which answered "Flight history for Alaska
  // Airlines flight AS1412". The other documented form, fr24.com/<callsign>,
  // wants the ICAO callsign (ASA1412) and would mean carrying an airline
  // lookup table on the client purely to reach the same page.
  //
  // All 206 distinct flight numbers in the database match this pattern.
  function fr24Url(o) {
    if (!o || o.transportation_type !== "airplane") return null;
    var n = String(o.transport_number || "").trim().toUpperCase().replace(/\s+/g, "");
    // Lazy prefix, then a check that it holds a letter. [A-Z0-9]{2,3} on its
    // own matches "1412" — "14" reads as the airline and "12" as the number —
    // and a bare figure with no carrier would have been pasted into a URL as
    // though it meant something. Codes like 3M and 9W are why the letter can
    // sit in either position rather than only the first.
    var m = /^([A-Z0-9]{2,3}?)([0-9]{1,4})$/.exec(n);
    if (!m || !/[A-Z]/.test(m[1])) return null;
    return "https://www.flightradar24.com/data/flights/" + n.toLowerCase();
  }

  // Whether tracking is worth offering yet.
  //
  // A chip on all 275 flights was tried and removed once already, and the
  // reason still holds: something glanced at occasionally does not earn a
  // permanent place on every row for the rest of time. What earns it is the
  // flight being imminent or in the air, which is the only time the answer
  // changes minute to minute.
  //
  // From a day before, because the question the night before a flight is
  // usually "where is the aircraft now" — and until a few hours after landing,
  // because that is when someone checks whether the bags made the connection.
  function trackable(o, nowMs) {
    if (!fr24Url(o)) return false;
    var dep = Date.parse(o.departure_at);
    if (!isFinite(dep)) return false;
    var arr = Date.parse(o.arrival_at);
    var end = isFinite(arr) ? arr : dep + 6 * 3600000;
    return nowMs >= dep - 24 * 3600000 && nowMs <= end + 3 * 3600000;
  }

  function alink(txt, href) { var a = el("a", "linkchip", txt); a.href = href; a.target = "_blank"; a.rel = "noopener"; return a; }

  // tel: and mailto: are handed to the operating system — Phone Link, or
  // whatever holds the association. Opening them in a new tab leaves an empty
  // one sitting there after the handover, so they navigate the current page
  // instead: the handler intercepts before anything unloads and the itinerary
  // stays exactly where it was. Real web links still get their own tab.
  function openContactHref(href) {
    if (!href) return;
    if (/^(tel:|mailto:|sms:)/i.test(href)) { window.location.href = href; return; }
    window.open(href, "_blank", "noopener");
  }

  // Ways to reach a place, in the order you would try them. `emails` is defensive:
  // nothing in the data carries one today, but the column exists and an importer
  // could start filling it, and it may arrive as a string, an array of strings or
  // an array of objects depending on which confirmation it came from.
  // Hotel name plus its city. "Hyatt Regency" alone is hundreds of properties,
  // so the city is what makes the search land — but only when the name does not
  // already carry it, which for this data it often does ("Fontainebleau Las
  // Vegas", "Emporio Zacatecas").
  //
  // Picking the city means skipping the parts of an address that are not one:
  // anything with a digit or a road-type word is a street, two capitals is a
  // state or country code, and a bare country name adds nothing to a search.
  // Tested against 22 stored addresses — 19 yield the right city, and the three
  // that do not are comma-less addresses whose hotel name already names the city.
  var STREETY = /\d|\b(rd|st|ave|avenue|blvd|boulevard|street|road|drive|dr|lane|ln|way|hwy|highway|route|rua|calle|paseo|camino|via|km)\b/i;
  var NOT_A_CITY = /^(usa|us|united states|uk|united kingdom|mexico|canada|france|spain|portugal|italy|greece|japan|costa rica)$/i;
  function lookupQuery(o) {
    var name = String(o.name || "").trim();
    var parts = String(o.address || "").split(",").map(function (x) { return x.trim(); });
    var city = "";
    for (var i = 0; i < parts.length; i++) {
      var p = parts[i];
      if (!p || p.length <= 2) continue;
      if (/^[A-Z]{2}$/.test(p) || NOT_A_CITY.test(p) || STREETY.test(p)) continue;
      city = p; break;
    }
    // Do not repeat a city the name already states.
    if (city && name.toLowerCase().indexOf(city.toLowerCase()) >= 0) city = "";
    return (name + " " + city).trim();
  }
  function contactsOf(o, kind) {
    var out = [];
    // Reviews and photos for a place you are already booked into. Deliberately
    // a plain search URL rather than an API call: no key, no request at render
    // time, nothing stored, and it cannot break the row if a service is down.
    //
    // Lodging only. Worth a tap for somewhere you will sleep; clutter on a
    // dinner reservation or a car hire.
    if ((kind === "hosting" || kind === "lodging") && o.name) {
      // Once the rating has been fetched, the chip says what it found and opens
      // the property's own page. Before that it is still a blind search — the
      // search URL is the honest fallback, not a broken promise of a rating.
      out.push(o.rating
        ? { icon: "⭐", label: o.rating + " · " + (o.rating_count || 0) + " reviews",
            href: o.rating_url || ("https://www.tripadvisor.com/Search?q=" + encodeURIComponent(lookupQuery(o))) }
        : { icon: "⭐", label: "Look Up Reviews",
            href: "https://www.tripadvisor.com/Search?q=" + encodeURIComponent(lookupQuery(o)) });
    }
    if (o.website) {
      var w = String(o.website);
      out.push({ icon: "🔗", label: "Website", href: /^https?:\/\//i.test(w) ? w : "https://" + w });
    }
    // Call only. A WhatsApp link was tried and removed: wa.me resolves solely
    // for numbers registered with WhatsApp, so for a hotel switchboard it offers
    // a route that cannot connect.
    if (o.phone) out.push({ icon: "📞", label: "Call " + fmtPhone(o.phone), href: telHref(o.phone) });
    var mails = [];
    (Array.isArray(o.emails) ? o.emails : (o.emails ? [o.emails] : [])).forEach(function (m) {
      var addr = typeof m === "string" ? m : (m && (m.email || m.address));
      if (addr && String(addr).indexOf("@") > 0) mails.push(String(addr));
    });
    if (o.email && String(o.email).indexOf("@") > 0) mails.push(String(o.email));
    mails.slice(0, 3).forEach(function (m) { out.push({ icon: "✉️", label: "Email " + m, href: "mailto:" + m }); });
    return out;
  }
  // Attached documents. The API labels them `title` (not name/filename) and the
  // link may arrive as url or, for stored files, temp_read_url.
  // The document chips on an itinerary row.
  //
  // These used to read `o.documents` — an array inside the item's own blob that
  // nothing has ever written to. Attaching a file created a row in the
  // documents table with a parent link and left the blob untouched, so the chip
  // never appeared and neither did the document. The link is read from the
  // trip's document list now, which is the same list the sidebar renders, so
  // the two can no longer disagree about what exists.
  //
  // `o.documents` and `provider_document` are still honoured: the importer
  // writes the second, and the first is what an older record may carry.
  function docLinks(o, trip, kind, data) {
    var out = [], docs = [], seen = {};
    docsFor(o, kind, data).forEach(function (d) { docs.push(d); if (d.id) seen[d.id] = 1; });
    if (Array.isArray(o.documents)) o.documents.forEach(function (d) { if (d && !(d.id && seen[d.id])) docs.push(d); });
    if (o.provider_document) docs.push(o.provider_document);
    docs.forEach(function (d) {
      if (!d) return;
      var url = d.temp_read_url || d.url || d.download_url || d.file || d.link;
      if (!url) return;
      var label = d.title || d.name || d.filename || "Document";
      // A stored file and a link behave differently — one is ours and will still
      // open in five years, the other is only as durable as somebody else's
      // site. Worth distinguishing, but not worth a second chip on the row.
      var stored = !!d.r2_key;
      var chip = alink((stored ? "📄 " : "🔗 ") + label, url);
      chip.title = stored
        ? [d.filename, fmtBytes(d.size), "stored file"].filter(Boolean).join(" · ")
        : "Link — opens " + String(url).replace(/^https?:\/\//, "").split("/")[0];
      out.push(chip);
      // Unlink, not delete. Detaching a boarding pass from a flight it does not
      // belong to should not destroy the boarding pass — it stays in Documents,
      // where it can be re-attached to the right one. Deleting is the 🗑 there,
      // which asks first.
      if (trip && kind && d.id && d.parent_type) {
        var x = el("button", "linkchip danger", "✕"); x.type = "button";
        x.title = "Unlink “" + label + "” — it stays in Documents";
        // On a phone this chip lives in the action sheet, where a bare ✕ says
        // nothing — and the one next to it deletes the whole itinerary item.
        x.dataset.sheetLabel = "✕  Unlink " + label;
        x.addEventListener("click", function (ev) {
          ev.stopPropagation();
          api("/v1/trip/" + trip.id + "/documents/" + d.id,
            { method: "PATCH", body: JSON.stringify({ parent_type: null, parent_id: null }) })
            .then(function () { toast("Unlinked — still in Documents"); openTrip(trip); })
            .catch(function (e) { toast("Couldn't unlink: " + e.message); });
        });
        out.push(x);
      }
    });
    return out;
  }

  // ---- budget ----
  //
  // Two kinds of money sit in a trip and they behave differently.
  //
  // A BOOKING carries its own price: a hotel, a flight, a tour. That number
  // belongs to the booking, so the budget shows it and sends you to the booking
  // to change it, rather than keeping a second copy that could disagree.
  //
  // An EXPENSE is money with no booking of its own — a baggage fee, a taxi, a
  // dinner. It can be filed under any category and linked to the booking it
  // belongs to, so a baggage fee sits under its flight instead of floating in
  // "Other" with no explanation.
  // Credit sits last because it is the only one that comes OFF the total, and
  // a deduction reads naturally at the bottom of a list of costs.
  var BUDGET_CATS = ["Lodging", "Transport", "Activities", "Dining", "Other", "Credit"];
  var CREDIT_CAT = "Credit";
  var DINING_CAT = "Dining";

  // Which activity types count as dining. Restaurant is the single biggest
  // type in the database -- 124 of 323 activities, more than "general" -- and
  // the rest are the food-and-drink venues the type list already defines, so a
  // future cafe or wine bar files itself correctly the first time one appears.
  // Nightlife is deliberately out: going out is an activity, not a meal.
  var DINING_TYPES = ["restaurant", "cafe", "bar", "brewery", "winery"];

  // The budget category a linked itinerary item implies. A baggage fee follows
  // its flight to Transport; dinner at a restaurant follows the restaurant to
  // Dining rather than to the catch-all Activities.
  function linkCategory(link) {
    if (!link) return null;
    if (link.kind === "activity" &&
        DINING_TYPES.indexOf((link.obj && link.obj.activity_type) || "") >= 0) return DINING_CAT;
    return KIND_CAT[link.kind] || null;
  }

  // What a line contributes to the total.
  //
  // A credit subtracts: a refund, a voucher, a points redemption, somebody
  // paying you back their share. The magnitude is taken as an absolute value
  // first, so entering "200" and entering "-200" in the Credit category both
  // mean the same thing — two hundred off. Negating whatever was typed would
  // make a minus sign turn a credit into a charge, which is the one mistake
  // this is likely to see.
  function signedAmount(cat, value) {
    var n = Number(value) || 0;
    return cat === CREDIT_CAT ? -Math.abs(n) : n;
  }

  // The natural category for a booking, which is also the default for an
  // expense linked to one.
  var KIND_CAT = { hosting: "Lodging", transport: "Transport", activity: "Activities" };

  // Everything on the itinerary an expense can be attached to.
  //
  // Each carries its date, because a trip repeats its bookings: two nights at
  // the same camp are two records with identical names, and a picker that shows
  // only the name gives you no way to tell which one you are filing against.
  function linkableItems(data) {
    var out = [];
    var when = function (utc, tz) {
      var k = dayKey(utc, tz);
      if (!k) return "";
      var d = new Date(k + "T12:00:00");
      return "  ·  " + fmtMD(d);
    };
    (data.transports || []).forEach(function (x) {
      out.push({ key: "transport:" + x.id, kind: "transport", id: x.id,
        label: transIcon(x.transportation_type) + "  " +
          ([x.company, x.transport_number].filter(Boolean).join(" ") || "Transport") +
          when(x.departure_at, x.departure_timezone) });
    });
    (data.hostings || []).forEach(function (h) {
      out.push({ key: "hosting:" + h.id, kind: "hosting", id: h.id,
        label: "🏨  " + (h.name || "Lodging") + when(h.starts_at, h.timezone) });
    });
    (data.activities || []).forEach(function (a) {
      out.push({ key: "activity:" + a.id, kind: "activity", id: a.id,
        label: "🍽️  " + (a.name || "Activity") + when(a.starts_at, a.timezone) });
    });
    return out;
  }

  // What an expense is linked to, or null. Resolved against the trip actually
  // loaded, so a link to something since deleted simply stops resolving rather
  // than rendering a ghost.
  function linkedItem(x, data) {
    if (!x || !x.linked_kind || x.linked_id == null) return null;
    var list = x.linked_kind === "transport" ? (data.transports || [])
             : x.linked_kind === "hosting" ? (data.hostings || [])
             : x.linked_kind === "activity" ? (data.activities || [])
             // Expenses resolve too, because a receipt attaches to one. An
             // expense never LINKS to another expense — see documentTargets,
             // which is a different list from linkableItems for that reason.
             : x.linked_kind === "expense" ? (data.expenses || []) : [];
    var found = list.filter(function (i) { return String(i.id) === String(x.linked_id); })[0];
    if (!found) return null;
    return {
      kind: x.linked_kind, obj: found,
      label: x.linked_kind === "transport"
        ? ([found.company, found.transport_number].filter(Boolean).join(" ") || "Transport")
        : x.linked_kind === "expense"
        ? (found.title || found.name || found.description || "Expense")
        : (found.name || (x.linked_kind === "hosting" ? "Lodging" : "Activity")),
    };
  }

  // Every line the budget shows, from both sources, already grouped.
  //
  // An expense with no category of its own follows the thing it is linked to —
  // a baggage fee on a flight is Transport without anyone having to say so —
  // and falls back to Other only when it is linked to nothing.
  // What a booking's price is denominated in.
  //
  // Two field names for one fact. The importer was told to write
  // `price_currency` (SKILL.md 8a) while this read `currency`, so an
  // importer-priced booking arrived with no currency the budget could see and
  // silently fell back to the account default. Every affected record happened
  // to be USD, so the totals were right by luck; the first colon or euro
  // booking would have totalled wrong with nothing to show for it.
  //
  // The records that had it were migrated to expenses on 2026-08-19, the price
  // input was taken off the booking forms at the same time, and no booking
  // carries money today. Both names are still read because a blob keeps
  // whatever was last written to it: an older client, a direct API call or an
  // importer ignoring §8a can still put one there, and a price that exists
  // must be shown rather than silently dropped from the total.
  function priceCurrency(o) {
    return (o && (o.currency || o.price_currency)) || null;
  }

  // Every booking price is its own line, even when an expense is linked to the
  // same booking.
  //
  // A first attempt suppressed the booking whenever anything linked to it, on
  // the theory that the expense restated it. The budget fixture caught that
  // immediately, and it was right: a linked expense is almost always an EXTRA
  // -- a baggage fee on a fare, a resort fee on a room rate -- so hiding the
  // fare would under-count the trip, which is a worse failure than the double
  // count it was aimed at. Duplicates are prevented where they are created
  // (the importer never writes a booking price, and skips an expense for a
  // booking that already carries one) and flagged by Trip check when a price
  // and a linked expense come to the same amount.
  //
  // No booking carries a price as of 2026-08-19 -- the nine that did were
  // moved into linked expenses, trip totals unchanged to the penny, and the
  // forms stopped offering the field. These branches stay because the API has
  // no allowlist: anything can still PATCH a price onto a booking, and money
  // that exists in the record has to appear in the total.
  // What an itinerary item cost, according to the expenses attached to it.
  //
  // The item itself no longer holds money — every cost is an expense linked to
  // the booking it pays for — so this is the only honest answer to "what did
  // this cost". Shown on the booking form as a fact, never as an input: a
  // second editable copy is exactly how the same charge ends up counted twice.
  //
  // Summed per currency, because a trip can mix them and adding 500 EUR to
  // 500 USD produces a number that is true of nothing.
  function linkedCost(o, kind, data) {
    if (!o || !data) return null;
    var byCur = {}, n = 0;
    (data.expenses || []).forEach(function (x) {
      if (!x || x.linked_kind !== kind || String(x.linked_id) !== String(o.id)) return;
      // A credit against this booking comes off what it cost — a refunded night
      // is not a cost you still carry.
      var amt = signedAmount(x.category, x.price != null ? x.price : x.amount);
      var cur = x.currency || (state.me && state.me.default_currency) || "USD";
      byCur[cur] = (byCur[cur] || 0) + amt;
      n++;
    });
    if (!n) return null;
    return { text: Object.keys(byCur).map(function (c) { return money(byCur[c], c); }).join(" · "), count: n };
  }

  // The two lines a booking form shows in place of the price input it used to
  // carry. Says where the number comes from, and where to go when there is
  // none, so the blank is an instruction rather than a dead end.
  function costField(o, kind, data) {
    var c = linkedCost(o, kind, data);
    return {
      name: "cost_display", label: "Cost", type: "static",
      value: c ? c.text : "Not recorded yet",
      hint: c
        ? (c.count === 1 ? "From the linked expense. Edit it in Budget."
                         : "From " + c.count + " linked expenses. Edit them in Budget.")
        : "Costs live on expenses. Add one in Budget and link it to this item.",
    };
  }

  function budgetLines(data) {
    var lines = [];
    var push = function (cat, o) { o.cat = cat; lines.push(o); };
    (data.hostings || []).forEach(function (h) {
      if (Number(h.price)) push("Lodging", { kind: "hosting", obj: h, label: h.name || "Lodging",
        amount: Number(h.price), currency: priceCurrency(h), booking: true });
    });
    (data.transports || []).forEach(function (x) {
      if (Number(x.price)) push("Transport", { kind: "transport", obj: x,
        label: [x.company, x.transport_number].filter(Boolean).join(" ") || "Transport",
        amount: Number(x.price), currency: priceCurrency(x), booking: true });
    });
    (data.activities || []).forEach(function (a) {
      if (Number(a.price)) push(
        DINING_TYPES.indexOf(a.activity_type || "") >= 0 ? DINING_CAT : "Activities",
        { kind: "activity", obj: a, label: a.name || "Activity",
          amount: Number(a.price), currency: priceCurrency(a), booking: true });
    });
    (data.expenses || []).forEach(function (x) {
      var link = linkedItem(x, data);
      // Credit is only ever an explicit choice. The fallback derives a category
      // from whatever the expense is attached to, and nothing should become a
      // deduction by accident.
      var cat = x.category || linkCategory(link) || "Other";
      var amt = x.price != null ? x.price : x.amount;
      push(cat, { kind: "expense", obj: x, label: x.title || x.name || x.description || "Expense",
        amount: signedAmount(cat, amt), currency: x.currency, link: link, date: x.date,
        booking: false, credit: cat === CREDIT_CAT });
    });
    return lines;
  }

  // Built-ins first in their own order, then anything the trip has invented,
  // alphabetically. A category nobody used does not appear at all.
  function budgetCategories(lines) {
    var seen = {};
    lines.forEach(function (l) { seen[l.cat] = 1; });
    var extra = Object.keys(seen).filter(function (c) { return BUDGET_CATS.indexOf(c) < 0; }).sort();
    return BUDGET_CATS.filter(function (c) { return seen[c]; }).concat(extra);
  }

  // How much of a trip the Budget total actually accounts for.
  //
  // The pill shows a sum, and a sum reads as "what the trip cost" whether it
  // covers every booking or one of four. That is the same failure as pricing a
  // trip from card transactions -- a partial figure wearing the clothes of a
  // total -- and it was the reason for declining THAT idea, so it cannot be
  // left standing here.
  //
  // A booking counts as covered if it carries its own price (legacy: nothing
  // does any more, see SKILL.md 8a) or has an expense linked to it. Unlinked
  // expenses -- a meal, a taxi -- are real trip costs that belong to no
  // booking, so they add to the total and are not part of this ratio.
  function budgetCoverage(data) {
    var total = 0, covered = 0;
    [["hosting", data.hostings], ["transport", data.transports], ["activity", data.activities]]
      .forEach(function (pair) {
        (pair[1] || []).forEach(function (o) {
          total++;
          if (Number(o.price) || linkedCost(o, pair[0], data)) covered++;
        });
      });
    return { total: total, covered: covered };
  }

  function renderBudget(root, t, data) {
    var lines = budgetLines(data);
    var cats = budgetCategories(lines);
    var totals = {};
    lines.forEach(function (l) {
      var cur = l.currency || (state.me && state.me.default_currency) || "USD";
      totals[cur] = (totals[cur] || 0) + l.amount;
    });
    // The section still appears with nothing in it, because it now carries the
    // control for adding the first expense — without it there would be no way
    // in from here.
    var totalStr = Object.keys(totals).map(function (c) { return money(totals[c], c); }).join(" · ");

    var box = collapsibleSection("Budget");
    var sec = box.body;
    var h3 = box.badge(el("span", "health-pill info", totalStr || "—"));
    // When a trip mixes currencies, add a single converted figure (ECB rates, free).
    if (Object.keys(totals).length > 1) addConverted(h3, totals);

    // Said only when it needs saying: there IS a total, and it does not cover
    // everything. Silence therefore means one of two harmless things -- every
    // booking is accounted for, or nothing is and the pill already shows a
    // dash. That matters because 177 of 184 trips came in from TripIt and
    // Tripsy, which never tracked costs; a line reproaching every one of them
    // for a gap that is expected and closed would be pure noise.
    var cov = budgetCoverage(data);
    if (lines.length && cov.total && cov.covered < cov.total) {
      sec.appendChild(el("div", "budget-coverage",
        "This total covers " + cov.covered + " of " + cov.total +
        " bookings — the rest have no cost recorded."));
    }

    cats.forEach(function (cat) {
      var mine = lines.filter(function (l) { return l.cat === cat; });
      if (!mine.length) return;
      var sub = {};
      mine.forEach(function (l) {
        var cur = l.currency || (state.me && state.me.default_currency) || "USD";
        sub[cur] = (sub[cur] || 0) + l.amount;
      });
      var head = el("div", "budget-row");
      head.appendChild(el("span", "budget-cat", cat));
      head.appendChild(el("span", "budget-amt",
        Object.keys(sub).map(function (cur) { return money(sub[cur], cur); }).join(" · ")));
      sec.appendChild(head);

      // Banding restarts inside each category, so every category opens on the
      // same shade and the stripe reads as "lines under this heading" rather
      // than one running through the headings.
      var body = el("div", "bud-lines");
      sec.appendChild(body);

      mine.forEach(function (l) {
        var row = el("div", "bud-line" + (l.credit ? " is-credit" : ""));
        var side = el("div", "bud-side");
        side.appendChild(el("span", "bud-amt",
          money(l.amount, l.currency || (state.me && state.me.default_currency) || "USD")));
        row.appendChild(side);
        var mid = el("div", "bud-body");
        mid.appendChild(el("div", "bud-title", l.label));
        var meta = [];
        // A booking says so, because its price is edited on the booking rather
        // than here — the chip below opens that, and this explains why.
        if (l.booking) meta.push("from the booking");
        // Otherwise the number reads as whatever the vendor charged, and there
        // is no way to tell a corrected figure from an imported one.
        if (!l.booking && isFieldLocked(l.obj, "amount")) meta.push("🔒 amount set by you");
        if (l.date) meta.push(dayLabel(l.date));
        if (l.link) meta.push("part of " + l.link.label);
        if (meta.length) mid.appendChild(el("div", "bud-meta", meta.join(" · ")));
        // Receipts attached to this line. An expense with a receipt is the one
        // that can still answer a question about it four months later.
        var receipts = l.booking ? [] : docsFor(l.obj, "expense", data);
        if (receipts.length) {
          var rrow = el("div", "bud-receipts");
          receipts.forEach(function (d) {
            var href = d.temp_read_url || d.url;
            if (!href) return;
            rrow.appendChild(alink((d.r2_key ? "🧾 " : "🔗 ") + (d.title || "Receipt"), href));
          });
          if (rrow.childNodes.length) mid.appendChild(rrow);
        }
        row.appendChild(mid);

        var acts = el("div", "bud-acts");
        var ed = el("button", "linkchip is-edit", "✎"); ed.type = "button";
        ed.title = l.booking ? "Edit this booking" : "Edit this expense";
        ed.addEventListener("click", function () {
          if (l.kind === "hosting") editHosting(t, l.obj);
          else if (l.kind === "transport") editTransport(t, l.obj);
          else if (l.kind === "activity") editActivity(t, l.obj);
          else editExpense(t, l.obj);
        });
        acts.appendChild(ed);
        // A receipt goes on the expense it paid for. It lands in Documents like
        // every other document — this only saves picking the expense off a list.
        if (!l.booking) {
          var att = el("button", "linkchip is-edit", "📎"); att.type = "button";
          att.title = "Attach a receipt";
          att.addEventListener("click", function () { attachItemDocument(t, "expense", l.obj, l.label); });
          acts.appendChild(att);
        }
        // Only an expense is deletable from here. A booking is a real part of
        // the trip and removing it because its price was wrong would be a
        // surprising thing for a budget panel to do.
        if (!l.booking) {
          var del = el("button", "linkchip danger is-edit", "🗑"); del.type = "button";
          del.title = "Delete this expense";
          del.addEventListener("click", function () { deleteItem(t, "expense", l.obj); });
          acts.appendChild(del);
        }
        // Under the amount rather than out to the right: three icons need a
        // fraction of the width a long hotel name does.
        side.appendChild(acts);
        body.appendChild(row);
      });
    });

    if (!lines.length) {
      sec.appendChild(el("div", "doc-empty",
        "Nothing costed yet. Prices on flights, lodging and activities appear here automatically; add anything else — baggage, taxis, dinners — below."));
    }

    var addRow = el("div", "doc-actions");
    var addBtn = el("button", "mini-btn is-edit", "＋ Add expense"); addBtn.type = "button";
    addBtn.addEventListener("click", function () { openItemForm(t, "expense", null); });
    addRow.appendChild(addBtn);
    sec.appendChild(addRow);
    box.mount(root);
  }

  // ---- writes ----
  async function toggleChecked(trip, act, box) {
    var next = !act.checked;
    box.classList.toggle("on", next); box.textContent = next ? "✓" : "";
    try { await api("/v1/trip/" + trip.id + "/activity/" + act.id, { method: "PATCH", body: JSON.stringify({ checked: next }) }); act.checked = next; }
    catch (e) { box.classList.toggle("on", act.checked); box.textContent = act.checked ? "✓" : ""; toast("Couldn't update: " + e.message); }
  }
  // ---- editing (inline forms) ----
  // Every dialog in the app is the same two boxes: a full-screen backdrop with
  // a panel inside it, appended to the body.
  //
  // Twenty-two functions built that by hand. The construction was identical in
  // all of them -- the same two el() calls, then the exact same append line,
  // character for character -- so this is that, once.
  //
  // What it deliberately does NOT take over is closing. Most dialogs close by
  // removing the backdrop, but some have teardown of their own (a Leaflet map
  // to destroy, a shut() that does more), and openLocationTriage has no
  // click-outside-to-close at all on purpose: dismissing a triage list by
  // accident throws away the work. Those differences are real, so they stay
  // with the dialogs rather than being flattened into an options bag.
  //
  // The point of having one place is what comes next: a modal stack so Escape
  // closes the top layer instead of every layer, and the role/aria/focus
  // handling that twenty-two anonymous divs currently do not have.
  // Every value in a dialog, as one string. Compared against the snapshot taken
  // just after the dialog was built, this is the difference between "you have
  // typed something" and "you opened this and changed nothing".
  function formSnapshot(root) {
    try {
      return [].map.call(root.querySelectorAll("input,select,textarea"), function (f) {
        return (f.type === "checkbox" || f.type === "radio") ? (f.checked ? "1" : "0") : String(f.value);
      }).join("\u0000");
    } catch (e) { return null; }
  }

  // The topmost dialog, or null. All overlays share z-index 50, so the last one
  // in the document is the one on top.
  // Everything a person can Tab to, in document order, inside one root.
  //
  // The visibility filter matters: these panels hide whole field groups (the
  // seat and gate boxes on a hire car, for one), and a trap that cycles through
  // hidden fields strands a keyboard user on a control they cannot see.
  var FOCUSABLE = "a[href], button:not([disabled]), input:not([disabled]):not([type=hidden])," +
    " select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex=\"-1\"])";

  function focusableIn(root) {
    return Array.prototype.slice.call(root.querySelectorAll(FOCUSABLE)).filter(function (n) {
      return !n.disabled && (n.offsetWidth || n.offsetHeight || n.getClientRects().length);
    });
  }

  var dialogSeq = 0;

  function topLayer() {
    var all = $$(".form-overlay");
    return all.length ? all[all.length - 1] : null;
  }

  function closeTopLayer(back) {
    // Only ask when there is something to lose. A dialog opened and not typed
    // into closes silently, which is the common case and must stay frictionless.
    if (back.__clean != null && formSnapshot(back) !== back.__clean) {
      if (!confirm("Discard your changes?")) return false;
    }
    (back.__close || function () { back.remove(); })();
    return true;
  }

  function overlay(cls, onBackdrop) {
    var back = el("div", "form-overlay");
    var panel = el("div", "form-panel" + (cls ? " " + cls : ""));
    back.appendChild(panel);
    document.body.appendChild(back);
    // Wired HERE, before the panel has any content in it.
    //
    // The backdrop is mounted the moment it exists, so whatever is on screen
    // has to be dismissable from that moment. Every dialog used to install this
    // listener at the END of its own construction -- openCoverDialog builds 349
    // lines first -- which means a throw halfway through would leave a
    // full-screen backdrop with nothing in it and no way out. Before this
    // helper existed the same throw left nothing on screen at all, so that is a
    // window the helper opened and has to close.
    //
    // `false` is openLocationTriage, which deliberately cannot be dismissed by
    // clicking away: losing a triage list to a stray tap throws away the work.
    // A dialog with real teardown -- a Leaflet map to destroy, chips to put
    // back on the toolbar -- passes that in instead of the default.
    // Escape needs to close the TOP layer, and the top layer is whichever
    // .form-overlay is last in the document -- they all share z-index 50, so
    // DOM order is stacking order. It therefore has to be able to close a
    // backdrop it did not build, which means the backdrop carries its own
    // closer rather than the knowledge living in each dialog's scope.
    back.__close = function () { if (onBackdrop) onBackdrop(); else back.remove(); };

    // ---- it is a dialog, so it behaves like one ----
    //
    // These are built from plain divs. Assistive technology announced them as
    // nothing in particular; keyboard focus stayed on the page behind, so a
    // screen reader went on reading the dashboard while a modal covered it; and
    // Tab walked straight out of the panel into controls underneath the
    // backdrop -- focusable, invisible, and unclickable at the same time.
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-modal", "true");
    // So focus has somewhere to land that is the dialog itself.
    panel.tabIndex = -1;

    // Where focus was, so it can be given back. Restoring is the half that gets
    // forgotten: without it, closing drops a keyboard user at the top of the
    // document and they have to walk all the way back to the row they were on.
    var returnTo = document.activeElement;

    // Tab must not leave. Stacked dialogs each get their own trap, and only the
    // one the event reaches -- the innermost -- acts on it.
    back.addEventListener("keydown", function (ev) {
      if (ev.key !== "Tab") return;
      var items = focusableIn(panel);
      if (!items.length) { ev.preventDefault(); panel.focus(); return; }
      var first = items[0], last = items[items.length - 1];
      // document.activeElement rather than ev.target, because the event fires
      // on the panel itself when nothing inside has focus yet.
      var here = document.activeElement;
      if (ev.shiftKey && (here === first || here === panel)) { ev.preventDefault(); last.focus(); }
      else if (!ev.shiftKey && here === last) { ev.preventDefault(); first.focus(); }
    });

    // A dialog closes several ways -- the backdrop, Escape, a Save handler
    // calling back.remove() itself, tearDownDetail sweeping the lot -- so
    // rather than hooking each one, watch for the backdrop leaving.
    var watcher = new MutationObserver(function () {
      if (back.isConnected) return;
      watcher.disconnect();
      if (settling) settling.disconnect();
      // A panel carrying an address gives it up here rather than in any one
      // close handler, because every way of closing -- backdrop, Escape, the
      // Done chip -- ends in the backdrop leaving the document, and only this
      // sees all three. It also has to run BEFORE the focus block below, which
      // returns early when something else has taken focus; the route must be
      // released either way.
      if (back.__route) closePanelRoute(back.__route);
      // Only if focus is actually adrift. If something else has deliberately
      // taken it -- a dialog opened on top, a trip redrawn -- leave it alone.
      var now = document.activeElement;
      if (now && now !== document.body && now !== document.documentElement) return;
      if (returnTo && returnTo.isConnected && returnTo.focus) { try { returnTo.focus(); } catch (e) {} }
    });
    watcher.observe(document.body, { childList: true });

    // ---- the clean snapshot has to survive a dialog that builds itself late ----
    //
    // __clean is meant to record what the fields looked like before anyone
    // touched them. It is taken one tick after the overlay is created, which is
    // right for a dialog built synchronously and wrong for one that awaits a
    // fetch first: openBucketList snapshotted an EMPTY panel, so every later
    // comparison differed and Escape asked "Discard your changes?" on a panel
    // nobody had typed into -- and then refused to close when the answer was no.
    //
    // So the snapshot is re-taken as the panel fills, and stops being re-taken
    // the moment a real input or change event arrives. After that a difference
    // genuinely is the user's edit, which is the only thing worth guarding.
    var touched = false;
    var settling = new MutationObserver(function () {
      if (touched || !back.isConnected) return;
      back.__clean = formSnapshot(back);
    });
    settling.observe(panel, { childList: true, subtree: true });
    var markTouched = function () {
      if (touched) return;
      touched = true;
      settling.disconnect();
    };
    // Capture, so it hears fields that did not exist when this was wired.
    back.addEventListener("input", markTouched, true);
    back.addEventListener("change", markTouched, true);
    if (onBackdrop !== false) {
      back.addEventListener("click", function (ev) {
        if (ev.target !== back) return;
        back.__close();
      });
    }
    // Snapshot the fields once construction has finished, so Escape can tell a
    // dialog you have typed into from one you have only looked at. It has to be
    // deferred: the panel is empty at this point, and inputs built by script
    // never get a defaultValue to compare against.
    setTimeout(function () {
      back.__clean = formSnapshot(back);
      // The caller builds its title AFTER this helper returns, so the label can
      // only be wired once that has happened. Every dialog here opens with a
      // heading; the fallback is for one that does not rather than announcing
      // an unnamed dialog.
      var head = panel.querySelector(".form-title, h2, h3");
      if (head) {
        if (!head.id) head.id = "dlg-title-" + (++dialogSeq);
        panel.setAttribute("aria-labelledby", head.id);
      } else {
        panel.setAttribute("aria-label", "Dialog");
      }
      // Into the dialog rather than left on the page behind it.
      //
      // This is a FLOOR, not a policy. formDialog focuses its first field at
      // 30ms, which is deliberate and long-standing, and wins over this. What
      // this covers is every overlay that is not a formDialog -- the cover
      // picker, Trip Ideas, the traveller sheet -- where focus previously
      // stayed on whatever was behind the backdrop, so a screen reader went on
      // reading the dashboard under a modal and Tab started from the page.
      //
      // The panel rather than a field, because focusing an input programmatically
      // opens the on-screen keyboard, and on a phone that covers the dialog it
      // was meant to help you fill in. Where a dialog wants that, it says so.
      if (!panel.contains(document.activeElement)) panel.focus();
    }, 0);
    return { back: back, panel: panel };
  }

  // Which keyboard a field should summon, and what should stop helping.
  //
  // There was not one inputmode, autocapitalize, autocorrect or spellcheck in
  // the entire app, so every field got the full QWERTY keyboard with
  // sentence-case capitalisation and autocorrect actively fighting entries like
  // LAX and HRK4TQ. Coordinates meant four keyboard-plane switches per number,
  // and phone and website fields missed the tel and URL keyboards entirely.
  //
  // Derived from the field NAME rather than declared at each call site. These
  // fields are built in a dozen places, and a list that has to be maintained by
  // hand is a list the next field added will be missing from -- the same
  // reasoning as the toast tone. A field can still override any of it.
  var FIELD_ATTRS = [
    // Codes and currencies: uppercase, and nothing trying to spell-correct them.
    { on: /^(from|to|airport|provider_reservation_code|transport_number|currency|seat_number|seat_class)$/,
      set: { autocapitalize: "characters", autocorrect: "off", spellcheck: "false" } },
    // Numbers with a decimal point.
    { on: /(^|_)(latitude|longitude)$|^(price|amount)$/,
      set: { inputmode: "decimal", autocorrect: "off", spellcheck: "false" } },
    { on: /^(nights|number_of_days)$/, set: { inputmode: "numeric" } },
    { on: /^phone$/, set: { type: "tel", autocorrect: "off", spellcheck: "false" } },
    { on: /^(website|url|link)$/,
      set: { type: "url", inputmode: "url", autocapitalize: "none", autocorrect: "off", spellcheck: "false" } },
    // An IANA zone is not prose and is not a proper noun.
    { on: /(^|_)timezone$/, set: { autocapitalize: "none", autocorrect: "off", spellcheck: "false" } },
  ];

  function applyFieldAttrs(name, input) {
    if (!name || !input || input.tagName === "SELECT") return;
    FIELD_ATTRS.forEach(function (rule) {
      if (!rule.on.test(name)) return;
      Object.keys(rule.set).forEach(function (k) {
        // type is a property with real behaviour attached; the rest are plain
        // attributes. Never downgrade a type a caller asked for explicitly.
        if (k === "type") { if (input.type === "text") input.type = rule.set[k]; }
        else input.setAttribute(k, rule.set[k]);
      });
    });
  }

  // Every IANA zone the browser knows, offered as you type. Built once and
  // reused: the list is ~600 entries and rebuilding it per dialog is wasted
  // work.
  var tzListEl = null;
  function timezoneListId() {
    if (tzListEl && document.body.contains(tzListEl)) return tzListEl.id;
    tzListEl = document.createElement("datalist");
    tzListEl.id = "iana-timezones";
    var zones = [];
    // Not in every browser; without it the field simply has no suggestions,
    // which is what it had before.
    try { zones = (Intl.supportedValuesOf && Intl.supportedValuesOf("timeZone")) || []; } catch (e) { zones = []; }
    zones.forEach(function (z) {
      var o = document.createElement("option");
      o.value = z;
      tzListEl.appendChild(o);
    });
    document.body.appendChild(tzListEl);
    return tzListEl.id;
  }

  // The authority on whether a zone exists is the same Intl that will be asked
  // to convert with it -- no list to fall out of date.
  function knownTimezone(z) {
    try { new Intl.DateTimeFormat("en-US", { timeZone: String(z) }); return true; }
    catch (e) { return false; }
  }

  function formDialog(title, fields, onSubmit, wide, search) {
    var o = overlay(wide ? "wide" : "", function () { close(); });
    var back = o.back, panel = o.panel;
    panel.appendChild(el("h3", "form-title", title));
    var inputs = {};
    var fieldWrap = wide ? el("div", "form-fields") : panel;
    if (wide) panel.appendChild(fieldWrap);
    fields.forEach(function (f) {
      // Notes and address-style fields read better spanning the full width.
      var full = f.type === "textarea" || f.name === "address" || f.name === "departure_address" || f.name === "arrival_address" || f.name === "name";
      var wrap = el("label", "form-field" + (wide && full ? " full" : ""));
      wrap.appendChild(el("span", "form-label", f.label));
      // A field that reports rather than asks. It has no input, contributes
      // nothing to the submitted values, and exists so a form can state a fact
      // that is derived from somewhere else — a cost that lives on an expense,
      // for one. An input would invite you to type a second copy of it.
      if (f.type === "static") {
        wrap.appendChild(el("div", "form-static", f.value == null ? "—" : String(f.value)));
        if (f.hint) wrap.appendChild(el("div", "form-hint", f.hint));
        fieldWrap.appendChild(wrap);
        return;
      }
      var input;
      if (f.type === "checkbox") {
        input = document.createElement("input");
        input.type = "checkbox";
        input.checked = !!f.value;
        input.className = "form-check";
        inputs[f.name] = input;
        wrap.classList.add("form-field-check");
        wrap.appendChild(input);
        if (f.hint) wrap.appendChild(el("div", "form-hint", f.hint));
        fieldWrap.appendChild(wrap);
        return;
      }
      if (f.type === "textarea") { input = document.createElement("textarea"); input.rows = 3; }
      else if (f.type === "select") { input = document.createElement("select"); (f.options || []).forEach(function (o) { var op = el("option", null, o.label != null ? o.label : o); op.value = o.value != null ? o.value : o; input.appendChild(op); }); }
      else { input = document.createElement("input"); input.type = f.type || "text"; }
      if (f.value != null) input.value = f.value;
      if (f.placeholder) input.placeholder = f.placeholder;
      applyFieldAttrs(f.name, input);
      if (/(^|_)timezone$/.test(f.name || "")) input.setAttribute("list", timezoneListId());
      // An explicit spec always wins over the name-derived defaults.
      if (f.attrs) Object.keys(f.attrs).forEach(function (k) { input.setAttribute(k, f.attrs[k]); });
      input.className = "form-input"; inputs[f.name] = input; wrap.appendChild(input); fieldWrap.appendChild(wrap);
    });
    var err = el("div", "form-err"); err.hidden = true; panel.appendChild(err);
    var btns = el("div", "form-btns");
    var cancel = el("button", "mini-btn", "Cancel"); cancel.type = "button";
    var save = el("button", "primary-btn small", "Save"); save.type = "button";
    btns.appendChild(cancel); btns.appendChild(save); panel.appendChild(btns);
    function close() { back.remove(); }
    cancel.addEventListener("click", close);
    save.addEventListener("click", async function () {
      var vals = {};
      Object.keys(inputs).forEach(function (k) {
        var i = inputs[k];
      // A misspelled zone does not fail loudly on its own. tzShift wraps Intl
      // in a try/catch that returns 0, so "America/Los_Angles" is swallowed and
      // every datetime on the booking converts as if it were UTC -- wrong by
      // hours, surfacing days later as a feasibility warning or a wrong
      // calendar entry, when nothing points back to a typo in this field.
      var badZone = null;
      Object.keys(inputs).forEach(function (k) {
        if (badZone || !/(^|_)timezone$/.test(k)) return;
        var val = String(inputs[k].value || "").trim();
        if (val && !knownTimezone(val)) badZone = val;
      });
      if (badZone) {
        err.textContent = "“" + badZone + "” is not a time zone. Start typing a city and pick from the list.";
        err.hidden = false;
        return;
      }
        vals[k] = i.type === "checkbox" ? i.checked : i.value;
      });
      // A misspelled zone does not fail loudly on its own. tzShift wraps Intl
      // in a try/catch that returns 0, so "America/Los_Angles" is swallowed and
      // every datetime on the booking converts as if it were UTC -- wrong by
      // hours, surfacing days later as a feasibility warning or a wrong
      // calendar entry, when nothing points back to a typo in this field.
      var badZone = null;
      Object.keys(inputs).forEach(function (k) {
        if (badZone || !/(^|_)timezone$/.test(k)) return;
        var val = String(inputs[k].value || "").trim();
        if (val && !knownTimezone(val)) badZone = val;
      });
      if (badZone) {
        err.textContent = "“" + badZone + "” is not a time zone. Start typing a city and pick from the list.";
        err.hidden = false;
        return;
      }
      save.disabled = true; save.textContent = "Saving…"; err.hidden = true;
      try { await onSubmit(vals); close(); } catch (e) { err.textContent = e.message || "Failed"; err.hidden = false; save.disabled = false; save.textContent = "Save"; }
    });
    // Enter saves.
    //
    // The fields are divs, not a <form>, so there is no implicit submission:
    // retyping an amount and pressing Enter did nothing at all -- the most
    // common edit flow there is, and on the phone the return key was simply
    // inert. Only five fields in the whole app had their own Enter handler.
    //
    // A keydown listener rather than a real <form> element, because several
    // fields DO handle Enter themselves -- the place search preventDefaults its
    // own to pick a result -- and wrapping everything in a form would change
    // what those do. Anything already handled arrives with defaultPrevented set
    // and is left alone.
    panel.addEventListener("keydown", function (e) {
      if (e.key !== "Enter" || e.defaultPrevented) return;
      var el2 = e.target;
      if (!el2) return;
      // Newlines in a textarea; buttons and links have their own activation.
      if (el2.tagName === "TEXTAREA" || el2.tagName === "BUTTON" || el2.tagName === "A") return;
      if (save.disabled) return;
      e.preventDefault();
      save.click();
    });

    if (search) {
      (Array.isArray(search) ? search : [search]).forEach(function (s) { attachPlaceSearch(panel, inputs, s); });
    }
    setTimeout(function () { var f0 = panel.querySelector("input,textarea,select"); if (f0) f0.focus(); }, 30);
  }
  // ---- calendar feeds ----
  // The .ics feed a calendar client subscribes to is read-only by nature — no
  // client can write back, whatever we do. What IS editable is everything that
  // decides what goes into it, and that lives here.
  //
  // Each feed carries its own token so one can be revoked without disturbing the
  // others. The original feed predates that and is authenticated by the
  // CAL_TOKEN secret instead; it is editable like any other, but its URL cannot
  // be shown or rotated from here because the secret is deliberately not stored
  // in the database.
  var YN = [{ value: "1", label: "Yes" }, { value: "0", label: "No" }];
  var yn = function (v) { return v ? "1" : "0"; };
  var ynv = function (v) { return v === "1"; };

  function feedUrlOf(f) { return f.token ? location.origin + "/cal/" + f.token + ".ics" : null; }

  // ---- Manage Access ----
  //
  // Worth being clear about what this screen does and does not do. It does not
  // grant anyone a login: Cloudflare Access decides who may reach the app at
  // all, and that list is edited in the Cloudflare dashboard, not here. This
  // only sets what someone Access already admits is allowed to do.
  //
  // So an address added here that is not in the Access policy will never appear;
  // and a person added to Access but not here is View/Read, which is the point —
  // the safe state needs no action, and granting edit is deliberate.
  async function openPeople() {
    var o = overlay("wide");
    var back = o.back, panel = o.panel;
    panel.appendChild(el("h3", "form-title", "Manage Access"));
    panel.appendChild(el("div", "form-hint",
      "Cloudflare Access controls who can sign in. This controls what they can do once they are in. " +
      "Anyone who signs in and is not listed here has View/Read access."));
    var body = el("div", "cal-feed-list");
    panel.appendChild(body);

    var form = el("div", "seg people-add");
    var addr = el("input", "inp"); addr.type = "email"; addr.placeholder = "name@example.com"; addr.autocomplete = "off";
    var pick = el("select", "inp");
    [["view", "View/Read"], ["admin", "Admin/Edit"]].forEach(function (o) {
      var op = el("option", "", o[1]); op.value = o[0]; pick.appendChild(op);
    });
    var addBtn = el("button", "mini-btn", "Add"); addBtn.type = "button";
    form.appendChild(addr); form.appendChild(pick); form.appendChild(addBtn);
    panel.appendChild(form);
    var errBox = el("div", "form-err"); errBox.hidden = true; panel.appendChild(errBox);

    var btns = el("div", "form-btns");
    var close = el("button", "primary-btn small", "Done"); close.type = "button";
    btns.appendChild(close); panel.appendChild(btns);
    close.addEventListener("click", function () { back.remove(); });

    function fail(msg) { errBox.hidden = false; errBox.textContent = msg; }
    async function save(email, role) {
      errBox.hidden = true;
      try {
        await api("/v1/users", { method: "POST", body: JSON.stringify({ email: email, role: role }) });
        await refresh();
        return true;
      } catch (e) { fail(e.message || "Couldn't save that."); return false; }
    }

    async function refresh() {
      body.innerHTML = "";
      body.appendChild(el("div", "doc-empty", "Loading…"));
      var d;
      try { d = await api("/v1/users"); }
      catch (e) { body.innerHTML = ""; fail("Couldn't load the list: " + e.message); return; }
      var rows = d.results || [], you = d.you || "";
      var admins = rows.filter(function (r) { return r.role === "admin"; }).length;
      body.innerHTML = "";
      rows.forEach(function (r) {
        var row = el("div", "people-row");
        var who = el("div", "people-who");
        who.appendChild(el("div", "people-mail", r.email + (r.email === you ? "  (you)" : "")));
        if (r.name) who.appendChild(el("div", "people-name", r.name));
        row.appendChild(who);

        var sel = el("select", "inp");
        [["view", "View/Read"], ["admin", "Admin/Edit"]].forEach(function (o) {
          var op = el("option", "", o[1]); op.value = o[0];
          if (r.role === o[0]) op.selected = true;
          sel.appendChild(op);
        });
        // The last Admin/Edit is frozen here as well as refused by the server,
        // so the reason is visible before the click rather than after it.
        var lastAdmin = r.role === "admin" && admins < 2;
        if (lastAdmin) { sel.disabled = true; sel.title = "The only Admin/Edit account. Promote someone else first."; }
        sel.addEventListener("change", async function () {
          if (!(await save(r.email, sel.value))) sel.value = r.role;
          else if (r.email === you) { state.me.role = sel.value; applyRole(); }
        });
        row.appendChild(sel);

        var rm = el("button", "mini-btn danger", "Remove"); rm.type = "button";
        if (lastAdmin) { rm.disabled = true; rm.title = sel.title; }
        rm.addEventListener("click", async function () {
          if (!confirm("Remove " + r.email + "? They keep their sign-in and become View/Read.")) return;
          errBox.hidden = true;
          try { await api("/v1/users/" + encodeURIComponent(r.email), { method: "DELETE" }); await refresh(); }
          catch (e) { fail(e.message || "Couldn't remove that account."); }
        });
        row.appendChild(rm);
        body.appendChild(row);
      });
      if (!rows.length) body.appendChild(el("div", "doc-empty", "Nobody listed yet."));
    }

    addBtn.addEventListener("click", async function () {
      var v = (addr.value || "").trim();
      if (!v) { fail("Enter an email address."); return; }
      if (await save(v, pick.value)) { addr.value = ""; pick.value = "view"; }
    });
    addr.addEventListener("keydown", function (e) { if (e.key === "Enter") addBtn.click(); });
    refresh();
  }

  async function openCalendarFeeds() {
    var o = overlay("wide");
    var back = o.back, panel = o.panel;
    panel.appendChild(el("h3", "form-title", "Calendar feeds"));
    var body = el("div", "cal-feed-list");
    panel.appendChild(body);
    var btns = el("div", "form-btns");
    var add = el("button", "mini-btn is-edit", "＋ New Feed"); add.type = "button";
    var close = el("button", "primary-btn small", "Done"); close.type = "button";
    btns.appendChild(add); btns.appendChild(close); panel.appendChild(btns);
    close.addEventListener("click", function () { back.remove(); });

    async function refresh() {
      body.innerHTML = "";
      body.appendChild(el("div", "doc-empty", "Loading…"));
      var feeds;
      try { feeds = (await api("/v1/calfeeds")).results || []; }
      catch (e) { body.innerHTML = ""; body.appendChild(el("div", "form-err", "Couldn't load feeds: " + e.message)); return; }
      body.innerHTML = "";
      feeds.forEach(function (f) { body.appendChild(feedRow(f, refresh)); });
      if (!feeds.length) body.appendChild(el("div", "doc-empty", "No feeds yet."));
    }

    add.addEventListener("click", async function () {
      add.disabled = true;
      try {
        var created = await api("/v1/calfeeds", { method: "POST", body: JSON.stringify({ name: "New calendar feed" }) });
        await refresh();
        editCalFeed(created, refresh);
      } catch (e) { toast("Couldn't create feed: " + e.message); }
      finally { add.disabled = false; }
    });

    await refresh();
  }

  function feedRow(f, refresh) {
    var row = el("div", "cal-feed");
    var head = el("div", "cal-feed-head");
    head.appendChild(el("strong", null, f.name || "Calendar feed"));
    var s = f.settings || {};
    var inc = s.include || {};
    var bits = [];
    ["trips", "transport", "lodging", "activities"].forEach(function (k) {
      if (inc[k] !== false) bits.push(k === "transport" ? "travel" : k);
    });
    head.appendChild(el("span", "cal-feed-sub", bits.join(" · ") || "nothing selected"));
    row.appendChild(head);

    var url = feedUrlOf(f);
    if (url) {
      var u = el("div", "cal-feed-url", url);
      row.appendChild(u);
    } else {
      row.appendChild(el("div", "cal-feed-sub",
        "This is the feed already subscribed on your devices. Its URL is held in the CAL_TOKEN secret rather than the database, so it can't be shown or rotated here — but its settings below apply to it."));
    }
    if (f.last_used_at) {
      row.appendChild(el("div", "cal-feed-sub", "Last fetched by a calendar " + fmtShortDate(new Date(f.last_used_at))));
    }

    var acts = el("div", "cal-feed-acts");
    if (url) {
      var cp = el("button", "mini-btn", "Copy URL"); cp.type = "button";
      cp.addEventListener("click", function () { copy(url); cp.textContent = "Copied"; setTimeout(function () { cp.textContent = "Copy URL"; }, 1500); });
      acts.appendChild(cp);
    }
    var ed = el("button", "mini-btn", "Settings"); ed.type = "button";
    ed.addEventListener("click", function () { editCalFeed(f, refresh); });
    acts.appendChild(ed);
    if (!f.legacy) {
      var rot = el("button", "mini-btn is-edit", "New URL"); rot.type = "button";
      rot.addEventListener("click", async function () {
        if (!window.confirm("Generate a new URL for “" + (f.name || "this feed") + "”?\n\nThe old one stops working immediately, and every device subscribed to it must re-subscribe.")) return;
        try { await api("/v1/calfeeds/" + f.id + "/rotate", { method: "POST", body: "{}" }); toast("New URL generated"); refresh(); }
        catch (e) { toast("Couldn't rotate: " + e.message); }
      });
      acts.appendChild(rot);
      var del = el("button", "mini-btn danger is-edit", "Delete"); del.type = "button";
      del.addEventListener("click", async function () {
        if (!window.confirm("Delete “" + (f.name || "this feed") + "”?\n\nAnything subscribed to it stops updating.")) return;
        try { await api("/v1/calfeeds/" + f.id, { method: "DELETE" }); toast("Feed deleted"); refresh(); }
        catch (e) { toast("Couldn't delete: " + e.message); }
      });
      acts.appendChild(del);
    }
    row.appendChild(acts);
    return row;
  }

  function editCalFeed(f, onDone) {
    var s = f.settings || {};
    var inc = s.include || {}, al = s.alarms || {}, busy = s.busy || {};
    var ALARM = [{ value: "0", label: "No Reminder" }, { value: "30", label: "30 minutes before" },
      { value: "60", label: "1 hour before" }, { value: "120", label: "2 hours before" },
      { value: "180", label: "3 hours before" }, { value: "240", label: "4 hours before" }];
    formDialog(f.name ? "“" + clipName(f.name, 40) + "” settings" : "Feed settings", [
      { name: "name", label: "Feed name (shown in the calendar app)", value: f.name || "" },
      { name: "inc_trips", label: "Include trip date bands", type: "select", options: YN, value: yn(inc.trips !== false) },
      { name: "inc_transport", label: "Include flights & transport", type: "select", options: YN, value: yn(inc.transport !== false) },
      { name: "inc_lodging", label: "Include lodging", type: "select", options: YN, value: yn(inc.lodging !== false) },
      { name: "inc_activities", label: "Include activities", type: "select", options: YN, value: yn(inc.activities !== false) },
      // No "lodging style" control any more. Only the trip may be an all-day or
      // a multi-day entry; a stay is always a check-in and a check-out, and a
      // setting whose other options broke that rule was a trap rather than a
      // choice.
      { name: "backDays", label: "How much history to include", type: "select", value: String(s.backDays == null ? 365 : s.backDays), options: [
        { value: "0", label: "Upcoming only" }, { value: "90", label: "Last 3 months" },
        { value: "365", label: "Last year" }, { value: "1825", label: "Last 5 years" },
        { value: "5000", label: "Everything" }
      ] },
      { name: "al_transport", label: "Reminder before flights & transport", type: "select", options: ALARM, value: String(al.transport == null ? 180 : al.transport) },
      { name: "al_lodging", label: "Reminder before lodging", type: "select", options: ALARM, value: String(al.lodging || 0) },
      { name: "al_activity", label: "Reminder before activities", type: "select", options: ALARM, value: String(al.activity || 0) },
      // All four default to No. An itinerary records where you are; it is not a
      // claim on your working hours, and a calendar that blocks out whole days
      // makes you unschedulable for the length of the trip.
      { name: "busy_transport", label: "Flights mark you busy", type: "select", options: YN, value: yn(busy.transport === true) },
      { name: "busy_activity", label: "Activities mark you busy", type: "select", options: YN, value: yn(busy.activity === true) },
      { name: "busy_lodging", label: "Lodging marks you busy", type: "select", options: YN, value: yn(busy.lodging === true) },
      { name: "busy_trips", label: "Trip bands mark you busy", type: "select", options: YN, value: yn(busy.trips === true) },
      { name: "emojis", label: "Emojis in event titles (✈ 🏨)", type: "select", options: YN, value: yn(s.emojis !== false) },
      { name: "rich", label: "Include seat, terminal & notes in the description", type: "select", options: YN, value: yn(s.rich !== false) },
      { name: "link", label: "Link each event back to the trip", type: "select", options: YN, value: yn(s.link !== false) },
      { name: "categories", label: "Tag events by type (for colour rules)", type: "select", options: YN, value: yn(s.categories !== false) }
    ], async function (v) {
      var settings = {
        include: { trips: ynv(v.inc_trips), transport: ynv(v.inc_transport), lodging: ynv(v.inc_lodging), activities: ynv(v.inc_activities) },
        backDays: Number(v.backDays),
        alarms: { transport: Number(v.al_transport), lodging: Number(v.al_lodging), activity: Number(v.al_activity) },
        busy: { transport: ynv(v.busy_transport), activity: ynv(v.busy_activity), lodging: ynv(v.busy_lodging), trips: ynv(v.busy_trips) },
        emojis: ynv(v.emojis), rich: ynv(v.rich), link: ynv(v.link), categories: ynv(v.categories)
      };
      await api("/v1/calfeeds/" + f.id, { method: "PATCH", body: JSON.stringify({ name: v.name, settings: settings }) });
      toast("Feed updated — calendars pick this up on their next refresh");
      if (onDone) onDone();
    }, true);
  }

  // A short list of things you might have meant, instead of a permanent button
  // for each. rows are [emoji, label, action].
  function openChooser(title, rows) {
    var o = overlay();
    var back = o.back, panel = o.panel;
    panel.appendChild(el("h3", "form-title", title));
    rows.forEach(function (row) {
      var b = el("button", "mini-btn add-choice", row[0] + "  " + row[1]);
      b.type = "button";
      b.addEventListener("click", function () { back.remove(); row[2](); });
      panel.appendChild(b);
    });
    var btns = el("div", "form-btns");
    var cancel = el("button", "mini-btn", "Cancel"); cancel.type = "button";
    cancel.addEventListener("click", function () { back.remove(); });
    btns.appendChild(cancel); panel.appendChild(btns);
    return back;
  }

  // ---- add: pick what kind of item first ----
  function openAddForm(trip) {
    var o = overlay();
    var back = o.back, panel = o.panel;
    panel.appendChild(el("h3", "form-title", "Add to " + (trip.name || "trip")));
    [["transport", "✈️", "Flight, transfer or transport"],
     ["hosting", "🏨", "Hotel, rental or lodging"],
     ["activity", "🍽️", "Activity, dining, event or tour"],
     ["note", "📝", "Note"],
     ["expense", "💳", "Expense"]].forEach(function (row) {
      var b = el("button", "mini-btn add-choice", row[1] + "  " + row[2]);
      b.type = "button";
      b.addEventListener("click", function () { back.remove(); openItemForm(trip, row[0], null); });
      panel.appendChild(b);
    });
    var btns = el("div", "form-btns");
    var cancel = el("button", "mini-btn", "Cancel"); cancel.type = "button";
    cancel.addEventListener("click", function () { back.remove(); });
    btns.appendChild(cancel); panel.appendChild(btns);
  }

  // ---- full data export ----
  // The point of this is portability: the file is self-contained and holds
  // every field the API returns, so the whole history can be reconstructed
  // elsewhere without them.
  async function exportEverything(say) {
    say("Loading trip list…");
    var trips = await apiAll("/v1/trips");
    var out = { exported_at: new Date().toISOString(), source: "wayfarer-api", trip_count: trips.length, trips: [] };
    var done = 0, i = 0;
    // A backup MUST NOT silently omit anything.
    //
    // Each of these used to end `.catch(() => [])`, which is defensible in a
    // view and indefensible here: one request failing mid-export wrote a file
    // saying a trip had no flights, with a trip_count and an item_count
    // presenting it as complete. You would keep that file for a year and find
    // out when you tried to restore from it. A backup you cannot trust is worse
    // than no backup, because having one stops you taking another.
    //
    // So each part is tried twice — most failures here are a dropped connection
    // rather than a broken server — and anything still failing aborts the whole
    // export. Refusing to write a file is a good outcome; writing a quietly
    // incomplete one is not.
    // Six workers run at once, so one of them throwing does not stop the other
    // five: Promise.all rejects immediately, the caller writes "Export failed",
    // and the survivors then overwrite that with their next progress line. The
    // user is told the export is still going while it is already dead. So the
    // first failure closes the whole thing down — the others stop taking work,
    // and nothing more is said after the failure is recorded.
    var stopped = false;
    var report = function (m) { if (!stopped) say(m); };
    var fetchPart = async function (path) {
      try { return await apiAll(path); }
      catch (first) {
        await new Promise(function (r) { setTimeout(r, 400); });
        return await apiAll(path);   // a second failure propagates and stops the export
      }
    };
    async function worker() {
      while (i < trips.length && !stopped) {
        var t = trips[i++];
        var parts;
        try {
          parts = await Promise.all([
            fetchPart("/v1/trip/" + t.id + "/transportations"),
            fetchPart("/v1/trip/" + t.id + "/hostings"),
            fetchPart("/v1/trip/" + t.id + "/activities"),
            fetchPart("/v1/trip/" + t.id + "/expenses"),
            fetchPart("/v2/trip/" + t.id + "/documents")
          ]);
        } catch (e) {
          stopped = true;
          throw new ApiError("Couldn't read “" + (t.name || "trip " + t.id) + "” (" +
            (e && e.message ? e.message : "request failed") +
            "). Nothing has been saved — a partial backup would look like a complete one. Try again.", 0);
        }
        out.trips.push({
          trip: t,
          transportations: parts[0], hostings: parts[1],
          activities: parts[2], expenses: parts[3], documents: parts[4]
        });
        done++;
        if (done % 10 === 0 || done === trips.length) report("Exported " + done + " of " + trips.length + " trips…");
      }
    }
    await Promise.all([worker(), worker(), worker(), worker(), worker(), worker()]);
    // The count the file claims must be the count it holds. If these disagree,
    // something dropped a trip on the way and the file must not be written.
    if (out.trips.length !== trips.length) {
      stopped = true;
      throw new ApiError("Export incomplete: " + out.trips.length + " of " + trips.length +
        " trips were read. Nothing has been saved. Try again.", 0);
    }
    // Keep the file in trip order rather than whichever worker finished first.
    out.trips.sort(function (a, b) { return String(a.trip.starts_at || "").localeCompare(String(b.trip.starts_at || "")); });
    out.item_count = out.trips.reduce(function (s, x) {
      return s + x.transportations.length + x.hostings.length + x.activities.length + x.expenses.length;
    }, 0);

    var json = JSON.stringify(out, null, 1);
    var name = "wayfarer-backup-" + new Date().toISOString().slice(0, 10) + ".json";
    // Where supported, let the file go straight to the backup folder instead of
    // the browser's download pile.
    if (window.showSaveFilePicker) {
      try {
        var h = await window.showSaveFilePicker({
          suggestedName: name,
          types: [{ description: "JSON", accept: { "application/json": [".json"] } }]
        });
        var w = await h.createWritable();
        await w.write(json); await w.close();
        say("Saved " + trips.length + " trips / " + out.item_count + " items (" + Math.round(json.length / 1024) + " KB).");
        markExported(out);
        return;
      } catch (e) {
        if (e && e.name === "AbortError") { say("Export cancelled."); return; }
        // fall through to a plain download
      }
    }
    downloadBlob(new Blob([json], { type: "application/json" }), name);
    say("Downloaded " + name + " — " + trips.length + " trips / " + out.item_count + " items (" + Math.round(json.length / 1024) + " KB).");
    markExported(out);
  }
  function markExported(out) {
    try {
      localStorage.setItem("wayfarer_last_export", JSON.stringify({
        at: out.exported_at, trips: out.trip_count, items: out.item_count
      }));
    } catch (e) {}
  }

  // ---- map picker ----
  // Same dialog on desktop and phone, so the two layouts behave identically.
  // ---- who sits where ----
  // One row per traveller on the trip, each with the seats from this booking to
  // choose from. Saving writes `pax` onto the booking, which turns an inferred
  // pairing into a recorded one and retires the "unconfirmed" marker.
  //
  // The seat menu is not restricted to the parsed list — a seat can be missing
  // from it entirely (an airline that emailed only three of five, a seat changed
  // at the gate), so free entry has to stay possible.
  function openSeatEditor(trip, o) {
    var people = tripTravellers(trip);
    var o = overlay("sheet");
    var back = o.back, panel = o.panel;
    panel.appendChild(el("h3", "form-title", "Who sits where"));
    panel.appendChild(el("div", "place-hint", transName(o) + " · " +
      (seatList(o).length ? seatList(o).join(", ") : "no seats recorded")));

    if (!people.length) {
      panel.appendChild(el("div", "doc-empty",
        "Nobody is marked as travelling on this trip yet. Use the Travelling row above the itinerary to say who is coming."));
    }

    var current = {};
    paxOf(o, trip).forEach(function (x) { current[x.id] = x.seat; });
    var rows = el("div", "sheet-list");
    people.forEach(function (person) {
      var row = el("div", "seat-row");
      row.appendChild(el("span", "seat-who", person.name));
      var inp = el("input", "form-input seat-input");
      inp.value = current[person.id] || "";
      inp.placeholder = "Seat";
      inp.setAttribute("list", "seats-" + o.id);
      row.appendChild(inp);
      person._input = inp;
      rows.appendChild(row);
    });
    var dl = el("datalist"); dl.id = "seats-" + o.id;
    seatList(o).forEach(function (s) { var op = el("option"); op.value = s; dl.appendChild(op); });
    rows.appendChild(dl);
    panel.appendChild(rows);

    var btns = el("div", "form-btns");
    var cancel = el("button", "mini-btn", "Cancel"); cancel.type = "button";
    cancel.addEventListener("click", function () { back.remove(); });
    var save = el("button", "primary-btn small", "Save"); save.type = "button";
    save.addEventListener("click", async function () {
      var pax = people.map(function (person) {
        return { id: person.id, seat: person._input.value.trim() };
      }).filter(function (x) { return x.seat; });
      // Two people in one seat is a data-entry slip, not a booking.
      var seen = {}, dupe = null;
      pax.forEach(function (x) {
        var k = x.seat.toUpperCase();
        if (seen[k]) dupe = x.seat; else seen[k] = true;
      });
      if (dupe) { toast("Two travellers are both in seat " + dupe + "."); return; }
      save.disabled = true;
      try {
        await replaceValue("/v1/trip/" + trip.id + "/transportation/" + o.id, "pax", pax,
          Array.isArray(o.pax) ? o.pax : []);
        o.pax = pax;
        back.remove();
        if (currentData) renderItinerary(document.querySelector(".itin"), trip, currentData);
        toast("Seats saved");
      } catch (e) { toast("Couldn't save: " + e.message); save.disabled = false; }
    });
    btns.appendChild(cancel); btns.appendChild(save);
    panel.appendChild(btns);
  }

  // ---- who is in this room ----
  // A toggle per traveller rather than a text box each, because a room holds a
  // set of people and the seat editor's one-line-per-person shape would imply
  // everybody needs a separate room.
  //
  // There is no room NUMBER any more — removed 2026-08-19, empty on all 216
  // lodging records. A second room here is a whole second booking, which is how
  // all 42 same-property same-night pairs are stored, so the number never
  // distinguished them anyway. This asks the one question it can answer: who
  // this booking is for.
  function openRoomEditor(trip, o) {
    var people = tripTravellers(trip);
    var o = overlay("sheet");
    var back = o.back, panel = o.panel;
    panel.appendChild(el("h3", "form-title", "Who is in this room"));
    panel.appendChild(el("div", "place-hint",
      (o.name || "Lodging") + (o.room_type ? " · " + o.room_type : "")));

    if (!people.length) {
      panel.appendChild(el("div", "doc-empty",
        "Nobody is marked as travelling on this trip yet. Use the Travellers row at the top to say who is coming."));
    }

    var current = {};
    roomPaxOf(o, trip).forEach(function (x) { current[x.id] = true; });

    var rows = el("div", "sheet-list");
    var picked = {};
    people.forEach(function (person) {
      var on = !!current[person.id];
      picked[person.id] = on;
      var row = el("button", "seat-row room-pick" + (on ? " on" : "")); row.type = "button";
      var tick = el("span", "room-tick", on ? "✓" : "○");
      row.appendChild(tick);
      row.appendChild(el("span", "seat-who", person.name));
      row.addEventListener("click", function () {
        picked[person.id] = !picked[person.id];
        row.classList.toggle("on", picked[person.id]);
        tick.textContent = picked[person.id] ? "✓" : "○";
      });
      rows.appendChild(row);
    });
    panel.appendChild(rows);

    var btns = el("div", "form-btns");
    var cancel = el("button", "mini-btn", "Cancel"); cancel.type = "button";
    cancel.addEventListener("click", function () { back.remove(); });
    var save = el("button", "primary-btn small", "Save"); save.type = "button";
    save.addEventListener("click", async function () {
      var pax = people.filter(function (p) { return picked[p.id]; })
        .map(function (p) { return { id: p.id }; });
      save.disabled = true;
      try {
        await api("/v1/trip/" + trip.id + "/hosting/" + o.id, { method: "PATCH", body: JSON.stringify({
          pax: pax, if_match: { pax: Array.isArray(o.pax) ? o.pax : [] }
        }) }).catch(function (e) {
          if (e.status === 409) throw new ApiError("The room assignment changed on another device, so nothing was overwritten. Reopen this to see the current one.", 409);
          throw e;
        });
        o.pax = pax;
        back.remove();
        if (currentData) renderItinerary(document.querySelector(".itin"), trip, currentData);
        toast("Saved");
      } catch (e) { toast("Couldn't save: " + e.message); save.disabled = false; }
    });
    btns.appendChild(cancel); btns.appendChild(save);
    panel.appendChild(btns);
  }

  function openMapPicker(title, gl, al) {
    var o = overlay("sheet");
    var back = o.back, panel = o.panel;
    panel.appendChild(el("h3", "form-title", title || "Open in maps"));
    // sheet-row, not bare sheet-list: this is the ONE sheet whose two choices
    // sit side by side on a wide screen. The class is shared with the seat and
    // room editors, the traveller list and Trip Ideas, all of which are
    // vertical lists and stay that way.
    var list = el("div", "sheet-list sheet-row");
    function opt(label, href) {
      if (!href) return;
      var a = el("a", "linkchip sheet-item", label);
      a.href = href; a.target = "_blank"; a.rel = "noopener";
      a.addEventListener("click", function () { setTimeout(function () { back.remove(); }, 60); });
      list.appendChild(a);
    }
    opt("📍  Google Maps", gl);
    opt("🗺️  Apple Maps", al);
    panel.appendChild(list);
    var btns = el("div", "form-btns");
    var cancel = el("button", "mini-btn", "Cancel"); cancel.type = "button";
    cancel.addEventListener("click", function () { back.remove(); });
    btns.appendChild(cancel); panel.appendChild(btns);
  }

  // ---- overflow action sheet (phone) ----
  // Takes the real chip elements, shows them full-width with readable labels,
  // and puts them back on the row afterwards so the next open still has them.
  function openActionSheet(title, chips) {
    var o = overlay("sheet", function () { close(); });
    var back = o.back, panel = o.panel;
    panel.appendChild(el("h3", "form-title", title || "Actions"));
    var list = el("div", "sheet-list");
    var home = [];
    chips.forEach(function (c) {
      home.push({ el: c, parent: c.parentNode, next: c.nextSibling, text: c.textContent });
      c.classList.add("sheet-item");
      // Icon-only chips get a written label while they are in the sheet.
      if (c.dataset && c.dataset.sheetLabel) c.textContent = c.dataset.sheetLabel;
      list.appendChild(c);
      // Any choice closes the sheet; the chip's own handler still runs.
      c.addEventListener("click", function () { setTimeout(close, 60); });
    });
    panel.appendChild(list);
    var btns = el("div", "form-btns");
    var cancel = el("button", "mini-btn", "Close"); cancel.type = "button";
    cancel.addEventListener("click", function () { close(); });
    btns.appendChild(cancel); panel.appendChild(btns);
    function close() {
      // Return each chip to where it came from, then remove the sheet.
      //
      // The reference node is only usable if it is STILL a child of the
      // recorded parent. When every chip in the sheet came from the same
      // container, chip one's recorded neighbour is chip two — which this very
      // function moved out moments ago — and insertBefore throws NotFoundError
      // on a node that is no longer a child. That threw before back.remove()
      // ran, so the sheet stayed on screen and Close looked dead. Iterating in
      // order and appending when the reference has gone rebuilds the original
      // sequence anyway.
      //
      // The finally is the belt: a chip restored to the wrong place is a small
      // wrong, a Close button that does nothing is a much larger one.
      try {
        home.forEach(function (h) {
          h.el.classList.remove("sheet-item");
          if (h.el.dataset && h.el.dataset.sheetLabel) h.el.textContent = h.text;
          if (!h.parent) return;
          var ref = (h.next && h.next.parentNode === h.parent) ? h.next : null;
          h.parent.insertBefore(h.el, ref);
        });
      } finally {
        back.remove();
      }
    }
  }

  // ---- scannable ticket codes ----
  // There is no dedicated barcode field, so the importer writes the value into
  // `notes` on its own line, in a shape both a person and this parser can read:
  //
  //     Ticket code: 27183094471-4
  //     Barcode (CODE128): 9312345678907
  //     Wallet: https://…
  //
  // Anything matching is offered as a code the dashboard can render on screen.
  var CODE_LINE = /^[ \t]*(ticket code|ticket|barcode|qr code|qr|admission code|e-?ticket|pass code)(?:\s*\(([^)]+)\))?\s*[:=]\s*(\S.*?)[ \t]*$/gim;
  function ticketCodes(o) {
    var out = [], seen = {};
    var text = [o && o.notes, o && o.description].filter(Boolean).join("\n");
    if (!text) return out;
    CODE_LINE.lastIndex = 0;
    var m;
    while ((m = CODE_LINE.exec(text))) {
      var value = m[3].trim();
      // A URL on one of these lines is a link to the ticket, not the code itself.
      if (/^https?:\/\//i.test(value)) continue;
      if (value.length < 4 || value.length > 512 || seen[value]) continue;
      seen[value] = true;
      out.push({ label: m[2] ? m[2].trim() : "Code", value: value, kind: (m[1] || "").toLowerCase() });
    }
    return out;
  }
  function openTicketCode(title, tc) {
    var o = overlay();
    var back = o.back, panel = o.panel;
    panel.appendChild(el("h3", "form-title", title || "Ticket"));
    var box = el("div", "qr-box");
    // The dialog opens straight away and fills in when the encoder arrives --
    // waiting on the script before showing anything would make a click that used
    // to be instant feel broken on a slow connection. One catch covers both
    // failures: the script not loading, and it loading but refusing this value.
    box.appendChild(el("div", "doc-empty", "Rendering…"));
    ensureQR().then(function () {
      box.innerHTML = window.RiveraQR.svg(tc.value);
    }).catch(function (e) {
      box.innerHTML = "";
      box.appendChild(el("div", "doc-empty", "Couldn't render this as a QR code: " + e.message));
    });
    panel.appendChild(box);
    var val = el("div", "qr-value", tc.value);
    panel.appendChild(val);
    panel.appendChild(el("div", "place-hint",
      "Rendered on this device from the code in the booking — nothing is sent anywhere. " +
      "If the venue scans a different symbology (a 1-D barcode, say), use the original ticket in your email or wallet."));
    var btns = el("div", "form-btns");
    var cp = el("button", "mini-btn", "Copy Code"); cp.type = "button";
    cp.addEventListener("click", function () { copy(tc.value); cp.textContent = "✓ Copied"; });
    var close = el("button", "primary-btn small", "Done"); close.type = "button";
    close.addEventListener("click", function () { back.remove(); });
    btns.appendChild(cp); btns.appendChild(close); panel.appendChild(btns);
  }

  // ---- trip cover photo ----
  // Verified against the live API: cover_image_url is stored verbatim and is not
  // validated — any https URL works, and so does an inline data: URI. The
  // documented POST /v1/storage/uploads (purpose=trip_cover) is NOT deployed; it
  // returns nginx's own 404, so there is no bucket to upload a file to. That is
  // why "Upload" here resizes the picture in the browser and stores it inline.
  var COVER_MAX_BYTES = 150000;   // ~150 KB of data: URI per trip
  var COVER_MAX_EDGE = 1400;
  // Library images are stored as files in R2 rather than inlined into a trip
  // row, so they can afford real resolution — the 150 KB ceiling above exists
  // only because a data: URI has to fit inside the record itself.
  var COVER_STORE_BYTES = 900000;
  var COVER_STORE_EDGE = 2000;

  // Bytes for whatever the preview is currently showing, ready to upload.
  //
  // Three kinds of source reach this: a data: URI from the old inline path, a
  // same-origin /api/v1/cover/… already in the library, and a remote https URL
  // from the Wikimedia search or the URL tab. Only the third can fail, and it
  // fails for a reason worth saying out loud — a host that does not send CORS
  // headers cannot be read by script, however well the image renders.
  async function coverBlob(src) {
    var sameOrigin = src.charAt(0) === "/" || src.indexOf(location.origin) === 0;
    var res;
    try {
      res = await fetch(src, sameOrigin ? { credentials: "same-origin" } : { mode: "cors" });
    } catch (e) {
      throw new Error("That image's host does not allow copying it. Download it and use the Upload tab instead.");
    }
    if (!res.ok) throw new Error("The image host returned " + res.status + ".");
    var blob = await res.blob();
    if (!/^image\//.test(blob.type)) throw new Error("That link did not return an image.");
    return blob.size > COVER_STORE_BYTES ? shrinkBlob(blob) : blob;
  }

  // Re-encode down to something sane for a cover. Drawn from a blob: URL, which
  // is same-origin, so the canvas is never tainted even when the original came
  // from another host.
  function shrinkBlob(blob) {
    return new Promise(function (resolve, reject) {
      var img = new Image();
      var url = URL.createObjectURL(blob);
      img.onload = function () {
        URL.revokeObjectURL(url);
        var scale = Math.min(1, COVER_STORE_EDGE / Math.max(img.width, img.height));
        var w = Math.max(1, Math.round(img.width * scale)), h = Math.max(1, Math.round(img.height * scale));
        var c = document.createElement("canvas");
        c.width = w; c.height = h;
        c.getContext("2d").drawImage(img, 0, 0, w, h);
        c.toBlob(function (out) {
          if (out) resolve(out); else reject(new Error("Couldn't re-encode that image."));
        }, "image/jpeg", 0.82);
      };
      img.onerror = function () { URL.revokeObjectURL(url); reject(new Error("That file isn't an image the browser can read.")); };
      img.src = url;
    });
  }

  function resizeToDataUri(file) {
    return new Promise(function (resolve, reject) {
      var img = new Image();
      var url = URL.createObjectURL(file);
      img.onload = function () {
        URL.revokeObjectURL(url);
        var scale = Math.min(1, COVER_MAX_EDGE / Math.max(img.width, img.height));
        var w = Math.max(1, Math.round(img.width * scale)), h = Math.max(1, Math.round(img.height * scale));
        var c = document.createElement("canvas");
        var out = "";
        // Step the quality down until it fits. Covers are displayed at ~1200px
        // wide behind a dark scrim, so quality well below 0.5 is still fine.
        for (var q = 0.78; q >= 0.34; q -= 0.08) {
          c.width = w; c.height = h;
          c.getContext("2d").drawImage(img, 0, 0, w, h);
          out = c.toDataURL("image/jpeg", q);
          if (out.length <= COVER_MAX_BYTES) break;
          // Still too big at the lowest quality — shrink the pixels instead.
          if (q - 0.08 < 0.34 && Math.max(w, h) > 700) { w = Math.round(w * 0.8); h = Math.round(h * 0.8); q = 0.78 + 0.08; }
        }
        if (out.length > COVER_MAX_BYTES) reject(new Error("Couldn't get this image under " + Math.round(COVER_MAX_BYTES / 1000) + " KB. Try a smaller one."));
        else resolve(out);
      };
      img.onerror = function () { URL.revokeObjectURL(url); reject(new Error("That file isn't an image the browser can read.")); };
      img.src = url;
    });
  }

  function openCoverDialog(trip, after) {
    var o = overlay("wide");
    var back = o.back, panel = o.panel;
    panel.appendChild(el("h3", "form-title", "Cover for " + (trip.name || "trip")));

    // Pending choice; null until the user picks something.
    var chosen = { image: undefined, gradient: undefined, position: undefined };
    var preview = el("div", "cover-preview");
    function pendingTrip() {
      return {
        cover_image_url: chosen.image !== undefined ? chosen.image : trip.cover_image_url,
        cover_gradient: chosen.gradient !== undefined ? chosen.gradient : trip.cover_gradient,
        cover_position: chosen.position !== undefined ? chosen.position : trip.cover_position
      };
    }
    function paint() {
      var t = pendingTrip();
      preview.setAttribute("style", coverStyle(t));
      if (focal) focal.sync(t);
    }
    var focal = null;
    paint();
    panel.appendChild(preview);

    // The focal point. A 3x3 grid rather than a dropdown because the thing being
    // chosen is a position, and a picture of the position is the shortest route
    // to understanding it.
    //
    // The preview above is a single wide box, so it cannot show what a nearly
    // square card will do with the same image — that is the crop that goes
    // wrong. The hint under the grid carries the number instead.
    var focalWrap = el("div", "focal-wrap");
    focalWrap.appendChild(el("div", "focal-label", "Focal point"));
    var grid = el("div", "focal-grid");
    var cells = COVER_POSITIONS.map(function (pos) {
      var b = el("button", "focal-cell"); b.type = "button";
      b.title = "Keep the " + pos.replace("center center", "middle").replace(" ", " ") + " of the picture";
      b.setAttribute("aria-label", b.title);
      b.addEventListener("click", function () {
        chosen.position = pos;
        paint();
        note.textContent = pos === "center center"
          ? "Centred — the usual choice."
          : "Keeping the " + pos + " of the picture when it has to be cropped.";
      });
      grid.appendChild(b);
      return { pos: pos, el: b };
    });
    focalWrap.appendChild(grid);
    focalWrap.appendChild(el("div", "place-hint",
      "Which part to keep when the picture is cropped. A dashboard card on a phone is nearly square and trims the sides hard; a wide trip header trims top and bottom."));
    panel.appendChild(focalWrap);
    focal = {
      sync: function (t) {
        // Only meaningful for a photograph — a gradient has no subject to miss.
        focalWrap.hidden = !t.cover_image_url;
        var cur = coverPosition(t);
        cells.forEach(function (c) { c.el.classList.toggle("on", c.pos === cur); });
      },
    };
    // Again now that the grid exists: the first call happened before it did, so
    // the trip's current focal point was never marked on opening.
    paint();

    // What actually makes a cover work here, measured off the real layouts
    // rather than guessed. The same image is centre-cropped into boxes ranging
    // from 350x253 (a trip card on a phone, 1.4:1) to 1519x320 (the trip header
    // at full width, 4.75:1), so no single aspect ratio fits them all and the
    // useful advice is about the subject's position, not the file's shape.
    // Collapsed, because at full length it ran to 303px on a phone and pushed
    // the picker itself below the fold. The summary carries the one number most
    // people want, so it is still useful without being opened.
    var spec = document.createElement("details");
    spec.className = "cover-spec";
    var sum = document.createElement("summary");
    sum.className = "cover-spec-h";
    sum.textContent = "Ideal image · 1600 × 900, subject centred";
    spec.appendChild(sum);
    var specList = el("ul", "cover-spec-list");
    [
      ["1600 × 900 or larger", "landscape, 16:9. Anything wider than 2000px is resized down when saved."],
      ["Keep the subject centred", "every crop is taken from the middle, and a wide trip header keeps only the middle third top to bottom."],
      ["Avoid text near the edges", "the sides are trimmed on a narrow card, the top and bottom on a wide header."],
      ["Darker or low-contrast images read best", "the trip name sits over the bottom of the picture on a dashboard card."],
    ].forEach(function (r) {
      var li = el("li");
      li.appendChild(el("strong", null, r[0]));
      li.appendChild(document.createTextNode(" — " + r[1]));
      specList.appendChild(li);
    });
    spec.appendChild(specList);
    panel.appendChild(spec);

    var note = el("div", "place-hint", ""); panel.appendChild(note);

    var tabs = el("div", "seg");
    var body = el("div", "cover-body");
    var TABS = [
      { key: "library", label: "📁 My photos" },
      { key: "search", label: "🔍 Search photos" },
      { key: "url", label: "🔗 Image URL" },
      { key: "upload", label: "⬆ Upload" },
      { key: "gradient", label: "🎨 Gradient" }
    ];
    // The library opens first, because the whole point of it is that the photo
    // you want for the seventeenth Las Vegas trip is already in there.
    var activeTab = "library";
    TABS.forEach(function (t) {
      var b = el("button", t.key === activeTab ? "on" : "", t.label); b.type = "button";
      b.addEventListener("click", function () {
        activeTab = t.key;
        [].forEach.call(tabs.children, function (c) { c.classList.remove("on"); });
        b.classList.add("on");
        paintBody();
      });
      tabs.appendChild(b);
    });
    panel.appendChild(tabs); panel.appendChild(body);

    function paintBody() {
      body.innerHTML = "";
      if (activeTab === "library") {
        var lib = el("div", "cover-grid");
        var libNote = el("div", "place-hint",
          "Photos you have saved, stored privately in your own bucket and reusable on any trip. Pick one, or save the current cover with “Add current cover” below.");
        body.appendChild(libNote);
        body.appendChild(lib);
        lib.appendChild(el("div", "loading", "Loading your photos…"));

        var paintLib = function (rows) {
          lib.innerHTML = "";
          if (!rows.length) {
            lib.appendChild(el("div", "doc-empty",
              "Nothing saved yet. Set a cover from Search, URL or Upload, then use “Add current cover” to keep it for next time."));
            return;
          }
          // Anything labelled like this trip floats to the front — a new Las
          // Vegas trip should not make you hunt through fifteen others.
          var want = String(trip.name || "").trim().toLowerCase();
          rows = rows.slice().sort(function (a, b) {
            var am = want && String(a.label || "").toLowerCase() === want ? 0 : 1;
            var bm = want && String(b.label || "").toLowerCase() === want ? 0 : 1;
            return am - bm;
          });
          rows.forEach(function (p) {
            var wrap = el("div", "cover-libcell");
            var cell = el("button", "cover-cell"); cell.type = "button";
            cell.setAttribute("style", "background-image:url('" + p.url + "')");
            cell.title = p.label;
            if (want && String(p.label || "").toLowerCase() === want) cell.classList.add("match");
            cell.addEventListener("click", function () {
              chosen.image = p.url; chosen.gradient = undefined; paint();
              note.textContent = p.label + " — from your photos.";
              [].forEach.call(lib.querySelectorAll(".cover-cell"), function (c) { c.classList.remove("sel"); });
              cell.classList.add("sel");
            });
            wrap.appendChild(cell);
            var cap = el("div", "cover-libcap");
            var nm = el("button", "cover-liblabel", p.label); nm.type = "button";
            nm.title = "Rename";
            nm.addEventListener("click", async function () {
              var v = prompt("Name this photo", p.label);
              if (v === null) return;
              v = v.trim(); if (!v || v === p.label) return;
              try {
                await api("/v1/covers/" + p.id, { method: "PATCH", body: JSON.stringify({ label: v }) });
                p.label = v; nm.textContent = v; cell.title = v;
              } catch (e) { note.textContent = "Couldn't rename: " + e.message; }
            });
            var del = el("button", "cover-libdel", "✕"); del.type = "button";
            del.title = "Remove from your photos";
            del.addEventListener("click", async function () {
              if (!confirm("Remove “" + p.label + "” from your photos? Trips already using it keep the image until you change their cover.")) return;
              try { await api("/v1/covers/" + p.id, { method: "DELETE" }); wrap.remove(); }
              catch (e) { note.textContent = "Couldn't remove: " + e.message; }
            });
            cap.appendChild(nm); cap.appendChild(del);
            wrap.appendChild(cap);
            lib.appendChild(wrap);
          });
        };

        api("/v1/covers").then(function (d) { paintLib((d && d.results) || []); })
          .catch(function (e) {
            lib.innerHTML = "";
            lib.appendChild(el("div", "doc-empty", "Couldn't load your photos: " + e.message));
          });

        // Saves whatever the preview is currently showing, so the same control
        // works for a Wikimedia result, a pasted URL or a fresh upload.
        var addRow = el("div", "doc-actions");
        var add = el("button", "mini-btn is-edit", "＋ Add current cover"); add.type = "button";
        add.addEventListener("click", async function () {
          var src = chosen.image !== undefined ? chosen.image : trip.cover_image_url;
          if (!src) { note.textContent = "Pick a photo first — from Search, URL or Upload — then save it here."; return; }
          var label = prompt("Name this photo (used to match it to future trips)", trip.name || "");
          if (label === null) return;
          add.disabled = true; note.textContent = "Saving to your photos…";
          try {
            var blob = await coverBlob(src);
            var fd = new FormData();
            fd.append("file", blob, "cover.jpg");
            fd.append("label", label.trim() || trip.name || "Untitled");
            var saved = await api("/v1/covers", { method: "POST", body: fd });
            // Point the trip at the stored copy rather than the original, so the
            // cover survives the source URL going away.
            chosen.image = saved.url; paint();
            note.textContent = "Saved as “" + saved.label + "”.";
            paintBody();
          } catch (e) { note.textContent = "Couldn't save: " + e.message; }
          finally { add.disabled = false; }
        });
        addRow.appendChild(add);
        body.appendChild(addRow);
      } else if (activeTab === "search") {
        var row = el("div", "cover-searchrow");
        var q = document.createElement("input"); q.className = "form-input"; q.value = trip.name || "";
        q.placeholder = "Golden Gate Bridge, Kyoto, Dolomites…";
        var go = el("button", "mini-btn", "Search"); go.type = "button";
        row.appendChild(q); row.appendChild(go); body.appendChild(row);
        var grid = el("div", "cover-grid"); body.appendChild(grid);
        var run = async function () {
          grid.innerHTML = ""; grid.appendChild(el("div", "loading", "Searching Wikimedia Commons…"));
          try {
            var d = await fetch("/api/ext/photos?q=" + encodeURIComponent(q.value)).then(function (r) { return r.json(); });
            grid.innerHTML = "";
            if (!d.photos || !d.photos.length) { grid.appendChild(el("div", "doc-empty", "Nothing found. Try the city or landmark name.")); return; }
            d.photos.forEach(function (p) {
              var cell = el("button", "cover-cell"); cell.type = "button";
              cell.setAttribute("style", "background-image:url('" + p.thumb + "')");
              cell.title = p.title + (p.license ? " · " + p.license : "");
              cell.addEventListener("click", function () {
                chosen.image = p.url; chosen.gradient = undefined; paint();
                note.textContent = p.title + (p.credit ? " — " + p.credit : "") + (p.license ? " (" + p.license + ")" : "") + " · Wikimedia Commons";
                [].forEach.call(grid.children, function (c) { c.classList.remove("sel"); });
                cell.classList.add("sel");
              });
              grid.appendChild(cell);
            });
          } catch (e) { grid.innerHTML = ""; grid.appendChild(el("div", "doc-empty", "Search failed: " + e.message)); }
        };
        go.addEventListener("click", run);
        q.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); run(); } });
        run();
      } else if (activeTab === "url") {
        var lab = el("label", "form-field full");
        lab.appendChild(el("span", "form-label", "Direct link to an image"));
        var inp = document.createElement("input"); inp.className = "form-input"; inp.type = "url";
        inp.placeholder = "https://…/photo.jpg";
        inp.value = (trip.cover_image_url && trip.cover_image_url.slice(0, 5) !== "data:") ? trip.cover_image_url : "";
        lab.appendChild(inp); body.appendChild(lab);
        var use = el("button", "mini-btn", "Use this image"); use.type = "button";
        use.addEventListener("click", function () {
          var v = inp.value.trim();
          if (!/^https:\/\//i.test(v)) { note.textContent = "Needs to be an https link straight to the image file."; return; }
          note.textContent = "Checking the link…";
          var probe = new Image();
          probe.onload = function () { chosen.image = v; chosen.gradient = undefined; paint(); note.textContent = "Looks good — " + probe.naturalWidth + "×" + probe.naturalHeight + "."; };
          probe.onerror = function () { note.textContent = "That link didn't load as an image. It must point at the file itself, not a page showing it."; };
          probe.src = v;
        });
        body.appendChild(use);
        body.appendChild(el("div", "place-hint", "The cover is fetched directly by the browser, so it has to be publicly reachable — a link behind a login or an expiring signature will show blank."));
      } else if (activeTab === "upload") {
        var f = document.createElement("input"); f.type = "file"; f.accept = "image/*"; f.className = "form-input";
        body.appendChild(f);
        // This used to squeeze the picture into a 150 KB data: URI inside the
        // trip row, because there was nowhere to put a file. There is now — the
        // same private bucket the documents use — so an upload becomes a real
        // stored image and joins the library on the way past, which is what
        // makes it reusable on the next trip to the same place.
        var keepRow = el("label", "sec-row");
        var keep = document.createElement("input"); keep.type = "checkbox"; keep.checked = true;
        keepRow.appendChild(keep);
        keepRow.appendChild(el("span", "sec-name", "Also save to My photos, so other trips can use it"));
        body.appendChild(keepRow);
        body.appendChild(el("div", "place-hint",
          "Stored privately in your own bucket, behind the same sign-in as the itinerary. Nothing is public."));
        f.addEventListener("change", async function () {
          var file = f.files && f.files[0]; if (!file) return;
          note.textContent = "Preparing…";
          try {
            var blob = file.size > COVER_STORE_BYTES ? await shrinkBlob(file) : file;
            if (!keep.checked) {
              // Not for the library — keep the old inline behaviour so the trip
              // still gets a cover without leaving anything behind.
              var uri = await resizeToDataUri(file);
              chosen.image = uri; chosen.gradient = undefined; paint();
              note.textContent = file.name + " → " + Math.round(uri.length / 1000) + " KB, stored in the trip.";
              return;
            }
            note.textContent = "Uploading…";
            var fd = new FormData();
            fd.append("file", blob, file.name || "cover.jpg");
            fd.append("label", trip.name || "Untitled");
            var saved = await api("/v1/covers", { method: "POST", body: fd });
            chosen.image = saved.url; chosen.gradient = undefined; paint();
            note.textContent = "Uploaded and saved as “" + saved.label + "” — " + Math.round(blob.size / 1000) + " KB.";
          } catch (e) { note.textContent = e.message; }
        });
      } else {
        var grid2 = el("div", "grad-grid");
        GRADIENTS.forEach(function (g, i) {
          var b = el("button", "grad-cell"); b.type = "button";
          b.setAttribute("style", "background:" + gradientCss(i));
          b.title = "Gradient " + i;
          b.addEventListener("click", function () {
            // A gradient only shows once the photo is gone, so choosing one clears it.
            chosen.gradient = i; chosen.image = ""; paint();
            note.textContent = "Gradient " + i + " — the photo will be removed.";
            [].forEach.call(grid2.children, function (c) { c.classList.remove("sel"); });
            b.classList.add("sel");
          });
          grid2.appendChild(b);
        });
        body.appendChild(grid2);
        body.appendChild(el("div", "place-hint", "A gradient is stored as a palette index rather than colours."));
      }
    }
    paintBody();

    var err = el("div", "form-err"); err.hidden = true; panel.appendChild(err);
    var btns = el("div", "form-btns");
    var rm = el("button", "mini-btn is-edit", "Remove Photo"); rm.type = "button";
    rm.addEventListener("click", function () { chosen.image = ""; paint(); note.textContent = "The photo will be removed; the gradient shows instead."; });
    var cancel = el("button", "mini-btn", "Cancel"); cancel.type = "button";
    cancel.addEventListener("click", function () { back.remove(); });
    var save = el("button", "primary-btn small", "Save cover"); save.type = "button";
    save.addEventListener("click", async function () {
      if (chosen.image === undefined && chosen.gradient === undefined && chosen.position === undefined) { back.remove(); return; }
      save.disabled = true; save.textContent = "Saving…"; err.hidden = true;
      var payload = {};
      if (chosen.image !== undefined) payload.cover_image_url = chosen.image;
      if (chosen.gradient !== undefined) payload.cover_gradient = chosen.gradient;
      if (chosen.position !== undefined) payload.cover_position = chosen.position;
      try {
        var updated = await api("/v1/trips/" + trip.id, { method: "PATCH", body: JSON.stringify(payload) });
        // Keep the in-memory copies in step so the list and detail repaint correctly.
        [trip].concat(state.own || []).forEach(function (x) {
          if (x && x.id === trip.id) {
            x.cover_image_url = updated.cover_image_url;
            x.cover_gradient = updated.cover_gradient;
            x.cover_position = updated.cover_position;
          }
        });
        back.remove(); toast("Cover updated");
        if (after) after(updated);
      } catch (e) { err.textContent = e.message || "Failed"; err.hidden = false; save.disabled = false; save.textContent = "Save cover"; }
    });
    btns.appendChild(rm); btns.appendChild(cancel); btns.appendChild(save); panel.appendChild(btns);
  }

  // ---- create a trip by hand ----
  // For trips that never arrive as a booking email — a road trip, a stay with
  // family, a conference someone else booked.
  function tzOptions() {
    var list = [];
    try { list = Intl.supportedValuesOf("timeZone"); } catch (e) {}
    if (!list.length) list = ["America/Los_Angeles", "America/Denver", "America/Chicago", "America/New_York", "Europe/London", "Europe/Paris", "Asia/Tokyo", "UTC"];
    return list;
  }
  function openNewTripDialog() {
    var here = "America/Los_Angeles";
    try { here = Intl.DateTimeFormat().resolvedOptions().timeZone || here; } catch (e) {}
    var today = new Date().toISOString().slice(0, 10);
    formDialog("New trip", [
      { name: "name", label: "Trip name", value: "", placeholder: "Lisbon, Q4 site visits, Dad's birthday…" },
      { name: "timezone", label: "Main timezone", type: "select", value: here, options: tzOptions() },
      { name: "starts_at", label: "Starts", type: "date", value: today },
      { name: "ends_at", label: "Ends", type: "date", value: today },
      { name: "number_of_days", label: "Or, days (leave dates blank)", type: "number", value: "" },
      { name: "description", label: "Description", type: "textarea", value: "" }
    ], async function (v) {
      if (!v.name.trim()) throw new ApiError("A trip needs a name.", 0);
      var dated = !!(v.starts_at && v.ends_at);
      if (dated && v.ends_at < v.starts_at) throw new ApiError("The end date is before the start date.", 0);
      if (!dated && !v.number_of_days) throw new ApiError("Give either both dates or a number of days.", 0);
      var body = {
        name: v.name.trim(),
        timezone: v.timezone,
        description: v.description || "",
        has_dates: dated,
        // Same rule the importer uses, so a place always gets the same colour.
        cover_gradient: Math.abs(hashCode(v.name.trim())) % GRADIENTS.length
      };
      if (dated) { body.starts_at = v.starts_at; body.ends_at = v.ends_at; }
      else { body.number_of_days = Number(v.number_of_days); }
      var t = await api("/v1/trips", { method: "POST", body: JSON.stringify(body) });
      state.own = [t].concat(state.own || []);
      render();
      toast("Trip created");
      // Straight into the cover picker — a new trip with no photo looks unfinished.
      openCoverDialog(t, function () { render(); });
    }, true);
  }
  function hashCode(s) {
    var h = 0;
    for (var i = 0; i < s.length; i++) { h = (h * 31 + s.charCodeAt(i)) | 0; }
    return h;
  }

  // ---- full add/edit for every object type ----
  // Field names and payload shapes verified against the live API.
  // A latitude/longitude pair off a form, as the API wants it.
  //
  // Blank is a real answer — an item with no address keeps no coordinates —
  // and it has to survive the round trip. Skipping the field when it is blank
  // (which is what this used to do) meant coordinates could be added but never
  // removed: clear the boxes, save, and the old pin was still there because
  // nothing was sent to overwrite it. So blank is sent as an explicit null.
  //
  // Both or neither. Half a pair is worse than none — the map tests only
  // latitude before reading longitude, so a lone latitude puts a marker at an
  // undefined longitude, and Leaflet throws rather than skipping it.
  //
  // Rubbish is refused rather than coerced. Number("") is 0 and Number("N/A")
  // is NaN, and both would sail through as a coordinate: 0,0 is the Gulf of
  // Guinea, which the feasibility check has a whole rule about because a failed
  // lookup used to leave it behind.
  function coordPair(latStr, lonStr) {
    var a = String(latStr == null ? "" : latStr).trim();
    var b = String(lonStr == null ? "" : lonStr).trim();
    // "34.05, -118.24" pasted whole into the latitude box, which is how every
    // map hands coordinates over. Splitting it is the difference between the
    // obvious gesture working and being told off for it.
    if (!b && /^-?\d+(\.\d+)?\s*,\s*-?\d+(\.\d+)?$/.test(a)) {
      var halves = a.split(",");
      a = halves[0].trim();
      b = halves[1].trim();
    }
    if (!a && !b) return { latitude: null, longitude: null };
    if (!a || !b) throw new ApiError("Give both a latitude and a longitude, or leave both blank.", 0);
    var lat = Number(a), lon = Number(b);
    if (!isFinite(lat) || !isFinite(lon)) throw new ApiError("Latitude and longitude must be numbers — or leave both blank.", 0);
    if (Math.abs(lat) > 90 || Math.abs(lon) > 180) throw new ApiError("Latitude must be between -90 and 90, longitude between -180 and 180.", 0);
    return { latitude: lat, longitude: lon };
  }

  function openItemForm(trip, kind, o) {
    o = o || {};
    var isNew = !o.id;
    var data = currentData || {};
    var tz;

    if (kind === "transport") {
      var dtz = o.departure_timezone || tripTz(trip, data);
      var atz = o.arrival_timezone || o.departure_timezone || tripTz(trip, data);
      // Seat, cabin, terminal and gate belong to a flight and to nothing else.
      // Measured across every transportation in the database: 275 flights carry
      // between 127 and 178 of them, and the 94 cars and road trips carry zero
      // — not one seat, class, terminal or gate between them. So on a hire car
      // they were four empty boxes asking a question with no answer.
      //
      // Decided by the type as STORED, because formDialog builds its fields
      // once. Switching the type inside an open dialog will not conjure them;
      // save and reopen. A new transportation defaults to airplane, so adding a
      // flight still gets them straight away.
      var isFlight = (o.transportation_type || "airplane") === "airplane";
      var tFields = [
        { name: "transportation_type", label: "Type", type: "select", value: o.transportation_type || "airplane", options: TRANS_TYPES },
        { name: "company", label: "Carrier / company", value: o.company || "", placeholder: "United, Blacklane…" },
        { name: "transport_number", label: "Flight / service number", value: o.transport_number || "", placeholder: "UA679" },
        { name: "provider_reservation_code", label: "Confirmation code", value: o.provider_reservation_code || "" },
        { name: "departure_description", label: "From (IATA for flights)", value: o.departure_description || "", placeholder: "LAX" },
        { name: "arrival_description", label: "To (IATA for flights)", value: o.arrival_description || "", placeholder: "JFK" },
        { name: "departure_timezone", label: "Departure timezone", value: dtz },
        { name: "arrival_timezone", label: "Arrival timezone", value: atz },
        { name: "departure_at", label: "Departs", type: "datetime-local", value: toLocalInput(o.departure_at, dtz) },
        { name: "arrival_at", label: "Arrives", type: "datetime-local", value: toLocalInput(o.arrival_at, atz) },
        // The same lock lodging has, for the same reason. A hire car gets
        // extended by a phone call to the desk, and the confirmation email keeps
        // saying the original drop-off — so the importer would put it back on
        // every run and log it as though the rental company had moved it.
        { name: "keep_times", label: "If this booking is re-sent", type: "select",
          value: lockedTimes(o).length ? "keep" : "",
          options: [
            { value: "", label: "Update the times from the confirmation" },
            { value: "keep", label: "Keep the times I have set" }
          ] },
        { name: "departure_address", label: "From address", value: o.departure_address || "" },
        { name: "arrival_address", label: "To address", value: o.arrival_address || "" },
        { name: "no_location", label: "No location", type: "checkbox", value: !!o.no_location,
          hint: "Select when item has no place, address or location. Trip check stops asking." },
        { name: "departure_latitude", label: "From lat", value: o.departure_latitude != null ? o.departure_latitude : "" },
        { name: "departure_longitude", label: "From long", value: o.departure_longitude != null ? o.departure_longitude : "" },
        { name: "arrival_latitude", label: "To lat", value: o.arrival_latitude != null ? o.arrival_latitude : "" },
        { name: "arrival_longitude", label: "To long", value: o.arrival_longitude != null ? o.arrival_longitude : "" }
      ];
      if (isFlight) {
        tFields.push(
          { name: "seat_number", label: "Seat", value: o.seat_number || "" },
          { name: "seat_class", label: "Cabin / class", value: o.seat_class || "" },
          { name: "departure_terminal", label: "Departure terminal", value: o.departure_terminal || "" },
          { name: "departure_gate", label: "Departure gate", value: o.departure_gate || "" });
      }
      tFields.push(
        { name: "vehicle_description", label: "Vehicle", value: o.vehicle_description || "" },
        costField(o, "transport", data),
        { name: "notes", label: "Notes", type: "textarea", value: o.notes || "" });

      formDialog(formTitle(isNew, "transport", "transportation", o), tFields, async function (v) {
        if (!v.departure_description || !v.arrival_description) throw new ApiError("From and To are required.", 0);
        var dz = v.departure_timezone || dtz, az = v.arrival_timezone || atz;
        var newDep = fromLocalInput(v.departure_at, dz), newArr = fromLocalInput(v.arrival_at, az);
        // Identical rules to lodging: editing a time locks that end, the select
        // can lock both or release everything, and the comparison is by INSTANT
        // because what is stored carries milliseconds and what comes back from
        // the form does not.
        var wasLockedT = lockedTimes(o), lockedT = [];
        var lockT = function (f) { if (lockedT.indexOf(f) < 0) lockedT.push(f); };
        var movedDep = !sameInstant(newDep, o.departure_at);
        var movedArr = !sameInstant(newArr, o.arrival_at);
        if (v.keep_times === "keep") {
          wasLockedT.forEach(lockT);
          if (movedDep) lockT("departure_at");
          if (movedArr) lockT("arrival_at");
          if (!lockedT.length) { lockT("departure_at"); lockT("arrival_at"); }
        } else if (!wasLockedT.length) {
          if (movedDep) lockT("departure_at");
          if (movedArr) lockT("arrival_at");
        }
        var body = {
          transportation_type: v.transportation_type, company: v.company || null,
          transport_number: v.transport_number || null,
          provider_reservation_code: v.provider_reservation_code || null,
          departure_description: v.departure_description, arrival_description: v.arrival_description,
          departure_address: v.departure_address || null, arrival_address: v.arrival_address || null,
          departure_timezone: dz, arrival_timezone: az,
          departure_at: newDep, arrival_at: newArr, locked_times: lockedT,
          vehicle_description: v.vehicle_description || null, notes: v.notes || null,
          no_location: !!v.no_location
          // No price or currency: the cost is on the linked expense, and a
          // second writable copy here is how one charge becomes two lines.
        };
        if (isFlight) {
          body.seat_number = v.seat_number || null;
          body.seat_class = v.seat_class || null;
          body.departure_terminal = v.departure_terminal || null;
          body.departure_gate = v.departure_gate || null;
        }
        // Both pairs through the same validation every other form uses.
        //
        // This path did a bare Number() with no checks at all: no both-or-
        // neither rule, no range check, no error. So a pasted "34.05, -118.24"
        // became NaN, JSON.stringify turned NaN into null, and the PATCH
        // silently CLEARED the stored coordinate -- on the one form most likely
        // to receive a pasted pair, an airport transfer pickup. Coordinates
        // drive the map, drive times, nearest-airport and the feasibility
        // check, so losing one quietly is expensive.
        //
        // coordPair's messages do not say WHICH pair on a form that has two, so
        // they are prefixed here.
        var leg = function (prefix, label) {
          try { return coordPair(v[prefix + "_latitude"], v[prefix + "_longitude"]); }
          catch (e) { throw new ApiError(label + " — " + e.message, 0); }
        };
        var dep = leg("departure", "Departure");
        body.departure_latitude = dep.latitude;
        body.departure_longitude = dep.longitude;
        var arr = leg("arrival", "Arrival");
        body.arrival_latitude = arr.latitude;
        body.arrival_longitude = arr.longitude;
        await saveItem(trip, "transportation", "transportations", o, body, isNew);
      }, true, [
        { lat: "departure_latitude", lon: "departure_longitude", address: "departure_address", name: "departure_description", placeholder: "Search the departure place or airport…" },
        { lat: "arrival_latitude", lon: "arrival_longitude", address: "arrival_address", name: "arrival_description", placeholder: "Search the arrival place or airport…" }
      ]);
      return;
    }

    if (kind === "hosting") {
      tz = o.timezone || tripTz(trip, data);
      formDialog(formTitle(isNew, "hosting", "lodging", o), [
        { name: "name", label: "Property name", value: o.name || "" },
        { name: "provider_reservation_code", label: "Confirmation code", value: o.provider_reservation_code || "" },
        { name: "timezone", label: "Timezone (IANA)", value: tz },
        { name: "starts_at", label: "Check-in", type: "datetime-local", value: toLocalInput(o.starts_at, tz) },
        { name: "ends_at", label: "Check-out", type: "datetime-local", value: toLocalInput(o.ends_at, tz) },
        // Offered explicitly as well as set automatically, because the automatic
        // rule cannot cover the case where the time you want is already what the
        // confirmation says — a 4pm check-out the hotel happens to have written
        // down, which you still want kept when they re-send an 11am one later.
        { name: "keep_times", label: "If the hotel re-sends this booking", type: "select",
          value: lockedTimes(o).length ? "keep" : "",
          options: [
            { value: "", label: "Update the times from the confirmation" },
            { value: "keep", label: "Keep the times I have set" }
          ] },
        { name: "address", label: "Address", value: o.address || "" },
        { name: "no_location", label: "No location", type: "checkbox", value: !!o.no_location,
          hint: "Select when item has no place, address or location. Trip check stops asking." },
        { name: "latitude", label: "Latitude", value: o.latitude != null ? o.latitude : "" },
        { name: "longitude", label: "Longitude", value: o.longitude != null ? o.longitude : "" },
        { name: "room_type", label: "Room type", value: o.room_type || "" },
        { name: "phone", label: "Phone", value: o.phone || "" },
        { name: "website", label: "Website", value: o.website || "" },
        costField(o, "hosting", data),
        { name: "notes", label: "Notes", type: "textarea", value: o.notes || "" }
      ], async function (v) {
        if (!v.name) throw new ApiError("Property name is required.", 0);
        var tzv = v.timezone || tz;
        var newStart = fromLocalInput(v.starts_at, tzv);
        var newEnd = fromLocalInput(v.ends_at, tzv);
        // Changing a time here means you meant it, so it locks itself: there is
        // no reading of "I typed 4pm" that also means "put 11am back the next
        // time the hotel sends the booking". Choosing "update from the
        // confirmation" is the deliberate opposite and wins over that, so the
        // way to undo a lock is one explicit choice rather than a puzzle.
        var wasLocked = lockedTimes(o);
        var locked = [];
        var lock = function (f) { if (locked.indexOf(f) < 0) locked.push(f); };
        // Compared as INSTANTS, not as strings. The stored value carries
        // milliseconds ("...02:45:00.000Z") and fromLocalInput strips them, so a
        // string compare called every untouched check-in "changed" and locked it
        // — quietly stopping the importer from updating a time nobody had set.
        var movedStart = !sameInstant(newStart, o.starts_at);
        var movedEnd = !sameInstant(newEnd, o.ends_at);
        if (v.keep_times === "keep") {
          wasLocked.forEach(lock);
          if (movedStart) lock("starts_at");
          if (movedEnd) lock("ends_at");
          // Asked for explicitly with nothing edited: they mean both ends.
          if (!locked.length) { lock("starts_at"); lock("ends_at"); }
        } else if (!wasLocked.length) {
          if (movedStart) lock("starts_at");
          if (movedEnd) lock("ends_at");
        }
        var body = {
          name: v.name, address: v.address || null, timezone: tzv,
          starts_at: newStart, ends_at: newEnd, locked_times: locked,
          room_type: v.room_type || null,
          provider_reservation_code: v.provider_reservation_code || null,
          phone: v.phone || null, website: v.website || null, notes: v.notes || null,
          no_location: !!v.no_location
          // No price or currency: the cost is on the linked expense, and a
          // second writable copy here is how one charge becomes two lines.
        };
        Object.assign(body, coordPair(v.latitude, v.longitude));
        await saveItem(trip, "hosting", "hostings", o, body, isNew);
      }, true, { placeholder: "Search the hotel name or address…" });
      return;
    }

    if (kind === "expense") {
      // NOTE: the expense field is `title` (not `name`) and it accepts `date`.
      // Categories: the four the budget already groups by, plus any the trip has
      // grown of its own. Same pattern the activity form uses for its types —
      // built-ins first, then whatever is actually in use, so a category is
      // added by using it rather than by editing a list somewhere.
      // "" is a real choice, not a blank: an expense linked to a flight is
      // Transport without anyone having to say so, and one linked to nothing
      // falls to Other. Picking a category explicitly overrides that.
      var catOpts = [{ value: "", label: "Automatic — follow what it's part of" }]
        .concat(BUDGET_CATS.map(function (c) { return { value: c, label: c }; }));
      var seenCat = {}; BUDGET_CATS.forEach(function (c) { seenCat[c] = 1; });
      (data.expenses || []).forEach(function (x) {
        var c = x && x.category;
        if (c && !seenCat[c]) { seenCat[c] = 1; catOpts.push({ value: c, label: c }); }
      });

      // Anything on the itinerary this expense could belong to. A baggage fee
      // belongs to a flight, a resort fee to a hotel — and once it is linked the
      // budget can say so, which is the difference between a list of numbers and
      // an account of a trip.
      var linkOpts = [{ value: "", label: "Not linked to anything" }].concat(
        linkableItems(data).map(function (i) { return { value: i.key, label: i.label }; }));

      var wasAmountLocked = isFieldLocked(o, "amount");
      var oldAmount = (o.price != null ? o.price : o.amount);

      formDialog(formTitle(isNew, "expense", "expense", o), [
        { name: "title", label: "Description", value: o.title || o.name || o.description || "" },
        { name: "price", label: "Amount", type: "number", value: oldAmount != null ? oldAmount : "" },
        { name: "currency", label: "Currency", value: o.currency || (state.me && state.me.default_currency) || "USD" },
        { name: "category", label: "Category", type: "select", value: o.category || "", options: catOpts },
        { name: "date", label: "Date", type: "date", value: o.date || (trip.has_dates ? trip.starts_at : "") || "" },
        { name: "linked", label: "Part of", type: "select",
          value: o.linked_kind && o.linked_id ? o.linked_kind + ":" + o.linked_id : "", options: linkOpts },
        // The confirmation is the starting point, not the last word. A resort
        // fee it left out, a bill split three ways, a rate that changed at the
        // desk — the number you set has to survive the vendor re-sending the
        // original, exactly as a check-out time does.
        //
        // Offered explicitly as well as set automatically, because the
        // automatic rule cannot cover an amount you want kept that happens to
        // equal what the email said.
        { name: "keep_amount", label: "If this booking is re-sent", type: "select",
          value: wasAmountLocked ? "keep" : "",
          options: [
            { value: "", label: "Update the amount from the confirmation" },
            { value: "keep", label: "Keep the amount I have set" }
          ] }
      ], async function (v) {
        if (!v.title) throw new ApiError("Enter a description.", 0);
        var link = String(v.linked || "").split(":");
        var newAmount = Number(v.price) || 0;
        // Number-to-number, so 730.30 re-saved as "730.3" is not an edit.
        var movedAmount = !isNew && Number(oldAmount || 0) !== newAmount;
        var locked = [];
        if (v.keep_amount === "keep") locked = ["amount"];
        else if (!wasAmountLocked && movedAmount) locked = ["amount"];
        // Choosing "update from the confirmation" releases it, even in the same
        // save that changed the number — saying so is the whole point of the
        // control, and an automatic re-lock would make it impossible to undo.
        if (v.keep_amount !== "keep" && wasAmountLocked) locked = [];
        var body = {
          title: v.title, price: newAmount, currency: v.currency || "USD",
          category: v.category || null, date: v.date || null,
          locked_fields: locked,
          // Both halves or neither — a dangling kind would group the expense
          // under a booking that cannot be found.
          linked_kind: link.length === 2 ? link[0] : null,
          linked_id: link.length === 2 ? Number(link[1]) : null,
        };
        await saveItem(trip, "expense", "expenses", o, body, isNew);
      });
      return;
    }

    // activity + note
    var isNote = kind === "note" || o.activity_type === "note";
    tz = o.timezone || tripTz(trip, data);
    var fields = [{ name: "name", label: isNote ? "Title" : "Name", value: o.name || "" }];
    if (!isNote) {
      // Offer your own categories alongside the built-ins, so an activity
      // can be tagged "Skiing" here and match what the iOS app shows.
      var typeOpts = ACT_TYPES.map(function (s) { return { value: s, label: s }; });
      Object.keys(state.categories || {}).forEach(function (slug) {
        var c = state.categories[slug];
        if (c && c.name) typeOpts.push({ value: slug, label: c.name + "  (my category)" });
      });
      fields.push({ name: "activity_type", label: "Type", type: "select", value: o.activity_type || "general", options: typeOpts });
      fields.push({ name: "all_day", label: "All day", type: "select", value: o.all_day ? "yes" : "no",
        options: [{ value: "no", label: "No — has a time" }, { value: "yes", label: "Yes — all day" }] });
      fields.push({ name: "provider_reservation_code", label: "Confirmation code", value: o.provider_reservation_code || "" });
      fields.push({ name: "timezone", label: "Timezone (IANA)", value: tz });
      fields.push({ name: "starts_at", label: "Starts", type: "datetime-local", value: toLocalInput(o.starts_at, tz) });
      fields.push({ name: "ends_at", label: "Ends", type: "datetime-local", value: toLocalInput(o.ends_at, tz) });
      fields.push({ name: "address", label: "Address", value: o.address || "" });
      // Optional, and genuinely so. Plenty of an itinerary has no address to
      // give: dinner at a friend's, a hike you have not picked a trailhead for,
      // "find a coffee place". Coordinates put an item on the map and let the
      // feasibility check reason about where you are — both already skip an
      // item that has none, so the only cost of leaving them blank is that the
      // item does not appear on the map. That is a fair trade to make yourself,
      // not a reason to refuse to save it.
      fields.push({ name: "latitude", label: "Latitude (optional)", value: o.latitude != null ? o.latitude : "" });
      fields.push({ name: "longitude", label: "Longitude (optional)", value: o.longitude != null ? o.longitude : "" });
      fields.push({ name: "no_location", label: "No location", type: "checkbox",
        value: !!o.no_location, hint: "Select when item has no place, address or location. Trip check stops asking." });
      fields.push({ name: "phone", label: "Phone", value: o.phone || "" });
      fields.push({ name: "website", label: "Website", value: o.website || "" });
      fields.push(costField(o, "activity", data));
    }
    fields.push({ name: "notes", label: "Notes", type: "textarea", value: o.notes || "" });

    formDialog(formTitle(isNew, "activity", isNote ? "note" : "activity", o), fields, async function (v) {
      var body;
      if (isNote) {
        if (!v.name && !v.notes) throw new ApiError("Enter some note text.", 0);
        body = { activity_type: "note", name: v.name || null, notes: v.notes || v.name };
      } else {
        if (!v.name) throw new ApiError("Enter a name.", 0);
        var tzv = v.timezone || tz;
        body = {
          name: v.name, activity_type: v.activity_type || "general", address: v.address || null,
          all_day: v.all_day === "yes",
          timezone: tzv, starts_at: fromLocalInput(v.starts_at, tzv), ends_at: fromLocalInput(v.ends_at, tzv),
          provider_reservation_code: v.provider_reservation_code || null,
          phone: v.phone || null, website: v.website || null, notes: v.notes || null,
          no_location: !!v.no_location
          // No price or currency: the cost is on the linked expense, and a
          // second writable copy here is how one charge becomes two lines.
        };
        Object.assign(body, coordPair(v.latitude, v.longitude));
      }
      await saveItem(trip, "activity", "activities", o, body, isNew);
    }, !isNote, isNote ? null : { placeholder: "Search a restaurant, venue or address…" });
  }

  // POST /v1/trip/{id}/{plural}  ·  PATCH /v1/trip/{id}/{singular}/{itemId}
  // Moving a time re-sorts the day, but that is the SERVER's job now — see
  // reflowDays in functions/api/_core.js. It used to live here, and the browser
  // is not the only writer: an airline schedule change arrives through the
  // importer and would never have re-sorted anything.
  // Which field of the trip's data a collection lands in. The API's plural and
  // the client's field name agree everywhere except transport.
  var COLLECTION_KEY = {
    transportations: "transports", hostings: "hostings", activities: "activities",
    expenses: "expenses", documents: "documents"
  };
  var COLLECTION_PATH = {
    transportations: "/v1/trip/{id}/transportations",
    hostings: "/v1/trip/{id}/hostings",
    activities: "/v1/trip/{id}/activities",
    expenses: "/v1/trip/{id}/expenses",
    documents: "/v2/trip/{id}/documents"
  };
  var SINGULAR_PLURAL = {
    transportation: "transportations", hosting: "hostings",
    activity: "activities", expense: "expenses", document: "documents"
  };

  // Re-read the ONE collection that changed and hand openTrip the rest from
  // memory. A one-item edit used to cost five requests and a blank panel for
  // however long the slowest of them took.
  //
  // Falls back to a full reload whenever anything is uncertain -- an unknown
  // collection, no data in memory, a failed refetch -- because showing a stale
  // itinerary after a write is worse than the flash this avoids.
  async function redrawAfterWrite(trip, plural) {
    var key = COLLECTION_KEY[plural], path = COLLECTION_PATH[plural];
    if (!key || !path || !currentData) { openTrip(trip); return; }
    var fresh = await apiAll(path.replace("{id}", trip.id)).catch(function () { return null; });
    if (!fresh) { openTrip(trip); return; }
    var next = {};
    Object.keys(currentData).forEach(function (k) { next[k] = currentData[k]; });
    next[key] = fresh;
    openTrip(trip, { data: next });
  }

  async function saveItem(trip, singular, plural, o, body, isNew) {
    if (isNew) await api("/v1/trip/" + trip.id + "/" + plural, { method: "POST", body: JSON.stringify(body) });
    else await api("/v1/trip/" + trip.id + "/" + singular + "/" + o.id, { method: "PATCH", body: JSON.stringify(body) });
    toast(isNew ? "Added" : "Saved");
    await redrawAfterWrite(trip, plural);            // re-reads that one list, so the new order shows
  }

  function editExpense(trip, x) { openItemForm(trip, "expense", x); }
  function editActivity(trip, a) { openItemForm(trip, a && a.activity_type === "note" ? "note" : "activity", a); }
  function editTransport(trip, x) { openItemForm(trip, "transport", x); }
  function editHosting(trip, h) { openItemForm(trip, "hosting", h); }

  async function deleteItem(trip, kind, o) {
    // No confirm: see undoToast. The dialog it replaces claimed "Deletes are
    // recoverable" while offering no way to recover one, which is worse than
    // saying nothing at all.
    var plural = SINGULAR_PLURAL[kind];
    var base = "/v1/trip/" + trip.id + "/" + kind + "/" + o.id;
    try {
      await api(base, { method: "DELETE" });
      await redrawAfterWrite(trip, plural);
      undoToast("Deleted " + (recordLabel(kind, o) || kind), async function () {
        await api(base + "/restore", { method: "POST" });
        await redrawAfterWrite(trip, plural);
        toast("Restored");
      });
    }
    catch (e) { toast("Delete failed: " + e.message); }
  }


  // ---- expense report ----
  //
  // Every cost on a trip in one file, for filing. Deliberately CSV: an expense
  // claim ends up in a spreadsheet or somebody else's system, and a PDF of a
  // table is the one shape that helps nobody.
  //
  // BOTH sources are in it. A trip's real cost is the flights and the hotel far
  // more than the taxis, and a report that listed only the standalone expenses
  // would understate a business trip by an order of magnitude — while looking
  // complete, which is worse.
  //
  // Rows carry whether a receipt is attached and what it is called, because the
  // first question anyone asks about a line on a claim is whether it can be
  // evidenced. The files themselves are in Documents; this says which line each
  // belongs to.
  function expenseRows(t, data) {
    var rows = [];
    budgetLines(data).forEach(function (l) {
      var receipts = l.booking ? [] : docsFor(l.obj, "expense", data);
      // A booking's own paperwork counts as its receipt: a hotel folio is
      // attached to the hosting, not to a separate expense.
      if (l.booking) receipts = docsFor(l.obj, DOC_PARENT[l.kind] || l.kind, data);
      rows.push({
        date: l.date || bookingDate(l),
        category: l.cat,
        description: l.label,
        kind: l.booking ? "Booking" : "Expense",
        partOf: l.link ? l.link.label : "",
        amount: l.amount,
        currency: l.currency || (state.me && state.me.default_currency) || "USD",
        confirmation: (l.obj && l.obj.provider_reservation_code) || "",
        receipts: receipts.map(function (d) { return d.title || d.filename || "Receipt"; }),
      });
    });
    // Chronological, because that is the order a claim is read and the order the
    // card statement it will be checked against is in. Undated last rather than
    // first: they are the ones needing a date typed in.
    return rows.sort(function (a, b) {
      if (!a.date && !b.date) return String(a.description).localeCompare(String(b.description));
      if (!a.date) return 1;
      if (!b.date) return -1;
      return String(a.date).localeCompare(String(b.date));
    });
  }

  // A booking's date for the report: when it starts, in its own zone.
  function bookingDate(l) {
    var o = l.obj || {};
    var iso = o.departure_at || o.starts_at || null;
    var tz = o.departure_timezone || o.timezone || null;
    return iso ? dayKey(iso, tz) : "";
  }

  // RFC 4180. A field containing a comma, a quote or a newline is quoted, and an
  // embedded quote is doubled. Hotel names carry commas constantly.
  function csvCell(v) {
    var s = v == null ? "" : String(v);
    return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }
  function csvLine(cells) { return cells.map(csvCell).join(","); }

  function expenseCsv(t, data) {
    var rows = expenseRows(t, data);
    var out = [csvLine(["Date", "Category", "Description", "Type", "Part of",
      "Amount", "Currency", "Confirmation", "Receipt", "Receipt files"])];
    rows.forEach(function (r) {
      out.push(csvLine([r.date, r.category, r.description, r.kind, r.partOf,
        r.amount.toFixed(2), r.currency, r.confirmation,
        r.receipts.length ? "Yes" : "No", r.receipts.join(" | ")]));
    });
    // Totals per currency, as rows rather than a formula: this file is read by
    // people and by systems that will not evaluate one.
    var byCur = {};
    rows.forEach(function (r) { byCur[r.currency] = (byCur[r.currency] || 0) + r.amount; });
    Object.keys(byCur).sort().forEach(function (cur) {
      out.push(csvLine(["", "", "TOTAL " + cur, "", "", byCur[cur].toFixed(2), cur, "", "", ""]));
    });
    return out.join("\r\n") + "\r\n";
  }

  // ---- the styled expense report ----
  //
  // CSV cannot carry formatting -- no bold, no column widths, no colour
  // survive the format, whatever writes it. So the report a PERSON reads is a
  // real .xlsx with real styles, and the CSV stays exactly as it was for the
  // systems that ingest it.
  //
  // The builder is pure and separately tested; the export function is thin
  // glue over xlsx-js-style (SheetJS 0.18.5 + a styling layer), loaded from a
  // pinned CDN on first use, the same pattern as jsPDF.
  function expenseSheet(t, data) {
    var rows = expenseRows(t, data);
    var header = ["Date", "Category", "Description", "Type", "Part of",
      "Amount", "Currency", "Confirmation", "Receipt", "Receipt files"];
    var cellsOf = function (r) {
      return [r.date, r.category, r.description, r.kind, r.partOf,
        r.amount, r.currency, r.confirmation,
        r.receipts.length ? "Yes" : "No", r.receipts.join(" | ")];
    };
    // Grouped by category, chronological within each group, a subtotal row
    // closing every section. The CSV stays strictly chronological -- that one
    // is checked against a card statement, which is a timeline -- but a claim
    // is READ by section, and a section that does not add itself up makes the
    // reviewer do it.
    //
    // Categories come out in the Budget panel's own order, so the spreadsheet,
    // the document and the screen all agree about what comes before what.
    var present = [];
    rows.forEach(function (r) { if (present.indexOf(r.category) < 0) present.push(r.category); });
    var ordered = BUDGET_CATS.filter(function (c) { return present.indexOf(c) >= 0; })
      .concat(present.filter(function (c) { return BUDGET_CATS.indexOf(c) < 0; }).sort());
    // One category needs no subtotal: it would restate the grand total a row
    // above it and call it something else.
    var subtotals = ordered.length > 1;
    var lines = [];
    ordered.forEach(function (cat) {
      var mine = rows.filter(function (r) { return r.category === cat; });
      var byCurHere = {};
      mine.forEach(function (r, i) {
        // Zebra restarts per section, so every category opens on the same
        // shade -- the same reasoning as the Budget panel's banding.
        lines.push({ kind: "row", credit: r.category === CREDIT_CAT, zebra: i % 2 === 1, cells: cellsOf(r) });
        byCurHere[r.currency] = (byCurHere[r.currency] || 0) + r.amount;
      });
      if (subtotals) Object.keys(byCurHere).sort().forEach(function (cur) {
        lines.push({ kind: "subtotal", credit: false, zebra: false,
          cells: ["", "", "Subtotal " + cat, "", "", byCurHere[cur], cur, "", "", ""] });
      });
    });
    var byCur = {};
    rows.forEach(function (r) { byCur[r.currency] = (byCur[r.currency] || 0) + r.amount; });
    Object.keys(byCur).sort().forEach(function (cur) {
      lines.push({ kind: "total", credit: false, zebra: false,
        cells: ["", "", "TOTAL " + cur, "", "", byCur[cur], cur, "", "", ""] });
    });
    // Column widths from the content itself -- "wide enough that nothing is
    // cut off" is a measurement, not a guess. Excel's wch unit is roughly one
    // character; +2 breathes, the cap stops one rambling description turning
    // a column into a football pitch.
    var widths = header.map(function (h, c) {
      var w = String(h).length;
      lines.forEach(function (l) {
        var v = l.cells[c];
        v = v == null ? "" : (c === 5 && typeof v === "number" ? v.toFixed(2) : String(v));
        if (v.length > w) w = v.length;
      });
      return Math.max(9, Math.min(56, w + 2));
    });
    return { header: header, lines: lines, widths: widths, rowCount: 1 + lines.length };
  }

  async function exportExpensesXlsx(t, data, btn) {
    var rows = expenseRows(t, data);
    if (!rows.length) { toast("Nothing is costed on this trip yet."); return; }
    var orig = btn && btn.textContent; if (btn) { btn.disabled = true; btn.textContent = "…"; }
    try {
      if (!window.XLSX) await loadScript("https://cdn.jsdelivr.net/npm/xlsx-js-style@1.2.0/dist/xlsx.bundle.js");
      var XL = window.XLSX;
      var sheet = expenseSheet(t, data);
      var ws = XL.utils.aoa_to_sheet([sheet.header].concat(sheet.lines.map(function (l) { return l.cells; })));
      ws["!cols"] = sheet.widths.map(function (w) { return { wch: w }; });
      // A filter on the header row: sort by category or currency without
      // touching the data. Ranges are 1-based and inclusive.
      ws["!autofilter"] = { ref: "A1:J" + sheet.rowCount };

      var INKS = {
        head: { font: { bold: true, color: { rgb: "FFFFFF" } }, fill: { fgColor: { rgb: "2F6DF6" } },
          alignment: { horizontal: "left" } },
        headAmt: { font: { bold: true, color: { rgb: "FFFFFF" } }, fill: { fgColor: { rgb: "2F6DF6" } },
          alignment: { horizontal: "right" } },
        zebra: { fill: { fgColor: { rgb: "F4F7FD" } } },
        amt: { alignment: { horizontal: "right" }, numFmt: "#,##0.00" },
        credit: { alignment: { horizontal: "right" }, numFmt: "#,##0.00",
          font: { bold: true, color: { rgb: "1F7A4D" } } },
        total: { font: { bold: true }, border: { top: { style: "medium", color: { rgb: "1E2430" } } } },
        totalAmt: { font: { bold: true }, alignment: { horizontal: "right" }, numFmt: "#,##0.00",
          border: { top: { style: "medium", color: { rgb: "1E2430" } } } },
        // A section closing itself: bolder than a row, lighter than the grand
        // total, on the pale blue that marks structure everywhere else here.
        subtotal: { font: { bold: true }, fill: { fgColor: { rgb: "DCE6F8" } },
          border: { top: { style: "thin", color: { rgb: "8A919C" } } } },
        subtotalAmt: { font: { bold: true }, fill: { fgColor: { rgb: "DCE6F8" } },
          alignment: { horizontal: "right" }, numFmt: "#,##0.00",
          border: { top: { style: "thin", color: { rgb: "8A919C" } } } },
      };
      var COLS = "ABCDEFGHIJ";
      function style(r, c, st) {
        var cell = ws[COLS[c] + (r + 1)];
        if (!cell) return;
        // Styles merge shallowly so zebra and number format can coexist.
        cell.s = Object.assign({}, cell.s || {}, st);
      }
      for (var c = 0; c < sheet.header.length; c++) style(0, c, c === 5 ? INKS.headAmt : INKS.head);
      sheet.lines.forEach(function (l, i) {
        var r = 1 + i;
        if (l.kind === "row") {
          if (l.zebra) for (var z = 0; z < l.cells.length; z++) style(r, z, INKS.zebra);
          style(r, 5, l.credit
            ? Object.assign({}, l.zebra ? INKS.zebra : {}, INKS.credit)
            : Object.assign({}, l.zebra ? INKS.zebra : {}, INKS.amt));
        } else if (l.kind === "subtotal") {
          for (var z2 = 0; z2 < l.cells.length; z2++) style(r, z2, z2 === 5 ? INKS.subtotalAmt : INKS.subtotal);
        } else {
          for (var z3 = 0; z3 < l.cells.length; z3++) style(r, z3, z3 === 5 ? INKS.totalAmt : INKS.total);
        }
      });

      var wb = XL.utils.book_new();
      XL.utils.book_append_sheet(wb, ws, (t.name || "Expenses").slice(0, 31).replace(/[\\\/?*\[\]:]/g, "-"));
      var base = "expenses-" + (slug(t.name) || "trip") + "-" + (t.starts_at || "").slice(0, 10);
      XL.writeFile(wb, base + ".xlsx");
    } catch (e) { toast("Excel export failed: " + e.message); }
    finally { if (btn) { btn.disabled = false; btn.textContent = orig; } }
  }

  function exportExpenses(t, data) {
    var rows = expenseRows(t, data);
    if (!rows.length) { toast("Nothing is costed on this trip yet."); return; }
    var csv = expenseCsv(t, data);
    var slug = String(t.name || "trip").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40);
    var name = "expenses-" + (slug || "trip") + "-" + (t.starts_at || "").slice(0, 10) + ".csv";
    // A BOM, because this is opened in Excel more often than anywhere else and
    // without one Excel reads UTF-8 as Latin-1 — every accented hotel name and
    // every currency symbol arrives mangled.
    var blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
    downloadBlob(blob, name);
    var missing = rows.filter(function (r) { return !r.receipts.length; }).length;
    toast(rows.length + " line" + (rows.length === 1 ? "" : "s") + " exported" +
      (missing ? " \u2014 " + missing + " without a receipt" : ""));
  }

  // ---- .ics ----
  function icsDate(utc) { return new Date(utc).toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z"); }
  function icsEsc(s) { return String(s || "").replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\n/g, "\\n"); }
  function downloadIcs(t, data) {
    var lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Wayfarer//EN", "CALSCALE:GREGORIAN"];
    var entries = buildEntries(t, data).filter(function (e) { return e.when; });
    entries.forEach(function (e, i) {
      var o = e.obj || {};
      var start = e.when;
      var end = o.arrival_at || o.ends_at || null;
      lines.push("BEGIN:VEVENT");
      // Both halves of a split item — hotel check-in and check-out, car pick-up
      // and drop-off — carry the same kind and the same object, so without a
      // suffix they serialise to one UID and a calendar client keeps whichever
      // it saw last. The server feed already solves this the same way.
      lines.push("UID:wayfarer-" + t.id + "-" + e.kind + "-" + (o.id || i) +
        (e.isCheckout ? "-b" : "-a") + "@wayfarer");
      lines.push("DTSTART:" + icsDate(start));
      if (end) lines.push("DTEND:" + icsDate(end));
      lines.push("SUMMARY:" + icsEsc((e.kind === "transport" ? "✈ " : e.kind === "hosting" ? "🏨 " : "") + e.title));
      var loc = o.address || o.arrival_description || o.departure_description || "";
      if (loc) lines.push("LOCATION:" + icsEsc(loc));
      if (e.sub) lines.push("DESCRIPTION:" + icsEsc(e.sub + (o.provider_reservation_code ? "\nConf: " + o.provider_reservation_code : "")));
      lines.push("END:VEVENT");
    });
    lines.push("END:VCALENDAR");
    downloadBlob(new Blob([lines.join("\r\n")], { type: "text/calendar" }), slug(t.name) + ".ics");
  }

  // ---- Word / PDF export ----
  function slug(s) { return String(s || "trip").replace(/[^a-z0-9]+/gi, "-").toLowerCase().replace(/^-|-$/g, "") || "trip"; }
  // The shared downloader. It used to be the WEAKER of the app's three copies:
  // it clicked an anchor that was never in the document and revoked after 2s,
  // while both hand-written copies appended to the body first -- which some
  // browsers require -- and waited 4s. The stronger behaviour is the shared one
  // now, and the copies are gone.
  function downloadBlob(blob, name) {
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url; a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
  }
  // Rewritten by build.js with the hashed filename. qr.js is not in index.html:
  // its only consumer is the ticket-code dialog, which almost never opens, so
  // parsing it on every load was pure critical-path waste.
  var QR_SRC = "/qr.82b5ac2afe.js";
  var qrReady = null;
  function ensureQR() {
    if (window.RiveraQR) return Promise.resolve();
    if (!qrReady) qrReady = loadScript(QR_SRC);
    return qrReady;
  }

  function loadScript(src) { return new Promise(function (res, rej) { var s = document.createElement("script"); s.src = src; s.onload = res; s.onerror = function () { rej(new Error("Failed to load " + src)); }; document.head.appendChild(s); }); }

  function orderedEntries(t, data) {
    var entries = buildEntries(t, data);
    var show = getDisplay().showKinds;
    entries = entries.filter(function (e) { return show[e.kind === "transport" ? "transport" : e.kind === "hosting" ? "hosting" : "activity"] !== false; });
    return { scheduled: entries.filter(function (e) { return e.when; }).sort(function (a, b) { return new Date(a.when) - new Date(b.when); }), unscheduled: entries.filter(function (e) { return !e.when; }) };
  }
  // ---- the exported document's look ----
  //
  // The benchmark is the Print dossier: a document with air in it. Three moves
  // carry the whole design, in Word and PDF alike:
  //   - a TIME COLUMN: times hang in a narrow left gutter;
  //   - a coloured KIND BAR on each item -- blue transport, violet lodging,
  //     amber activity;
  //   - real SECTION HEADINGS: the accent colour and a rule under each day.
  //
  // The Word export is a real .docx now -- OOXML built with the docx library
  // from a pinned CDN, the same on-demand pattern as jsPDF and xlsx-js-style.
  // The old .doc was HTML wearing a costume: Word opened it, but in
  // compatibility mode, and Google Docs and Pages sniffed at it. Units in the
  // docx API, because they are three different ones and all invisible bugs:
  // run size is HALF-POINTS (22 = 11pt), border size is EIGHTHS of a point
  // (20 = 2.5pt), cell width is DXA, twentieths of a point (1560 = 78pt).
  async function exportWord(t, data, btn) {
    var orig = btn && btn.textContent; if (btn) { btn.disabled = true; btn.textContent = "…"; }
    try {
      if (!window.docx) await loadScript("https://cdn.jsdelivr.net/npm/docx@8.5.0/build/index.umd.js");
      var D = window.docx;
      var INK = { ink: "1E2430", muted: "5C6570", faint: "8A919C", accent: "2F6DF6",
        rule: "C7D6F6", zebra: "F4F7FD", subtle: "DCE6F8", credit: "1F7A4D" };
      var KIND = { transport: "2F6DF6", hosting: "7C3AED", activity: "B45309" };
      var none = { style: D.BorderStyle.NONE, size: 0, color: "FFFFFF" };
      var noBorders = { top: none, bottom: none, left: none, right: none };
      function run(text, o) { return new D.TextRun(Object.assign({ text: text, font: "Arial" }, o)); }
      function para(runs, o) { return new D.Paragraph(Object.assign({ children: runs }, o)); }

      var children = [];
      children.push(para([run(t.name || "Trip", { bold: true, size: 42, color: INK.ink })],
        { spacing: { after: 40 } }));
      children.push(para(
        [run(fmtRange(t) + (t.has_dates ? " · " + spanDays(t) + " days" : ""), { size: 21, color: INK.muted })],
        { spacing: { after: 160 },
          border: { bottom: { style: D.BorderStyle.SINGLE, size: 20, color: INK.accent, space: 6 } } }));

      function section(label) {
        children.push(para([run(label, { bold: true, size: 25, color: INK.accent })],
          { spacing: { before: 280, after: 140 },
            border: { bottom: { style: D.BorderStyle.SINGLE, size: 12, color: INK.rule, space: 3 } } }));
      }
      function item(e) {
        var o = e.obj || {};
        var content = [para([run((e.icon ? e.icon + " " : "") + e.title, { bold: true, size: 22, color: INK.ink })])];
        if (e.sub) content.push(para([run(e.sub, { size: 19, color: INK.muted })]));
        if (o.provider_reservation_code) content.push(para([run("CONF  " + o.provider_reservation_code, { size: 17, color: INK.faint })]));
        // No notes -- that field holds the fine print, and the document is for
        // following the trip. The app keeps the detail.
        children.push(new D.Table({
          width: { size: 100, type: D.WidthType.PERCENTAGE },
          borders: noBorders,
          rows: [new D.TableRow({ children: [
            new D.TableCell({ width: { size: 1560, type: D.WidthType.DXA }, borders: noBorders,
              children: [para([run(e.meta || "", { size: 19, color: INK.muted })])] }),
            new D.TableCell({
              borders: Object.assign({}, noBorders,
                { left: { style: D.BorderStyle.SINGLE, size: 20, color: KIND[e.kind] || KIND.activity } }),
              margins: { left: 140 },
              children: content }),
          ] })],
        }));
        children.push(para([], { spacing: { after: 90 } }));
      }

      var oe = orderedEntries(t, data), lastDay = null;
      oe.scheduled.forEach(function (e) {
        var k = dayKey(e.when, e.tz);
        if (k !== lastDay) { section(dayLabel(k)); lastDay = k; }
        item(e);
      });
      if (oe.unscheduled.length) { section("Unscheduled"); oe.unscheduled.forEach(item); }

      // The expense table comes from the SAME builder the spreadsheet uses --
      // grouped by category, subtotals per section, signed amounts -- so the
      // document, the sheet and the Budget panel can never disagree.
      if ((data.expenses || []).length) {
        section("Expenses");
        var sheet = expenseSheet(t, data);
        function cell(text, o, opts) {
          opts = opts || {};
          return new D.TableCell({
            borders: opts.topBorder
              ? Object.assign({}, noBorders, { top: { style: D.BorderStyle.SINGLE, size: 16, color: INK.ink } })
              : noBorders,
            shading: opts.shade ? { type: D.ShadingType.CLEAR, fill: opts.shade } : undefined,
            margins: { top: 40, bottom: 40, left: 80, right: 80 },
            children: [para([run(text, o)], opts.right ? { alignment: D.AlignmentType.RIGHT } : undefined)],
          });
        }
        var trows = [new D.TableRow({ tableHeader: true, children: [
          cell("DESCRIPTION", { bold: true, size: 17, color: "FFFFFF" }, { shade: INK.accent }),
          cell("CATEGORY", { bold: true, size: 17, color: "FFFFFF" }, { shade: INK.accent }),
          cell("AMOUNT", { bold: true, size: 17, color: "FFFFFF" }, { shade: INK.accent, right: true }),
        ] })];
        sheet.lines.forEach(function (l) {
          var amtTxt = l.cells[5] === "" || l.cells[5] == null ? "" : money(l.cells[5], l.cells[6] || "USD");
          var shade = l.kind === "subtotal" ? INK.subtle : (l.kind === "row" && l.zebra ? INK.zebra : null);
          var isTotal = l.kind === "total";
          var bold = l.kind !== "row";
          trows.push(new D.TableRow({ children: [
            cell(String(l.cells[2] || ""), { bold: bold, size: 20, color: INK.ink },
              { shade: shade, topBorder: isTotal }),
            cell(l.kind === "row" ? String(l.cells[1] || "") : "", { size: 18, color: INK.muted },
              { shade: shade, topBorder: isTotal }),
            cell(amtTxt, { bold: bold || l.credit, size: 20, color: l.credit ? INK.credit : INK.ink },
              { shade: shade, topBorder: isTotal, right: true }),
          ] }));
        });
        children.push(new D.Table({ width: { size: 100, type: D.WidthType.PERCENTAGE }, rows: trows }));
      }

      var doc = new D.Document({ sections: [{ properties: {}, children: children }] });
      var blob = await D.Packer.toBlob(doc);
      downloadBlob(blob, slug(t.name) + ".docx");
    } catch (e) { toast("Word export failed: " + e.message); }
    finally { if (btn) { btn.disabled = false; btn.textContent = orig; } }
  }
  // ---- send the itinerary to somebody ----
  // Plain text, because the destination is a message rather than a document and
  // all three of them — Messages, WhatsApp, mail — render text and nothing else.
  // A link would be useless: the app sits behind Cloudflare Access, so anybody
  // who is not already on the policy receives a login page instead of a trip.
  //
  // Two rules, both learned from this arriving as one unbroken paragraph:
  //
  //   1. NO LEADING WHITESPACE, ever. The old version indented items by two
  //      spaces and their detail by six. Runs of spaces collapse in most of
  //      these targets, so the structure vanished and every line ran into the
  //      next. Blank lines and upper case survive; indentation does not.
  //   2. One line per item. A message is read in a narrow column on a phone,
  //      and a second wrapped line is indistinguishable from the next entry
  //      once the indentation that used to separate them is gone.
  //
  // This is deliberately less than the trip holds. Addresses and confirmation
  // codes are left out — what somebody meeting you needs is what and when, and
  // a confirmation number in a group chat is somebody else's booking reference
  // sitting in a place nobody can revoke. The PDF, Word, print and calendar
  // exports remain the comprehensive ones.
  function itineraryText(t, data) {
    var out = [];
    out.push(t.name || "Trip");
    out.push(fmtRange(t) + (t.has_dates ? " · " + spanDays(t) + " days" : ""));
    var going = tripTravellers(t);
    if (going.length) out.push("Travelling: " + going.map(function (p) { return p.name; }).join(", "));

    var oe = orderedEntries(t, data), lastDay = null;
    oe.scheduled.forEach(function (e) {
      var k = dayKey(e.when, e.tz);
      if (k !== lastDay) {
        // A blank line before every day, including the first, is what separates
        // the trip header from the itinerary as well.
        out.push("");
        // Upper case rather than indentation or a rule of dashes: it survives
        // every renderer, and it is the only way to make a heading stand out
        // when the medium has one font and no styling.
        out.push(dayLabel(k).toUpperCase());
        lastDay = k;
      }
      // Prefer the row's own time string: for a flight it carries departure AND
      // arrival, which fmtTime(when) alone would lose.
      var when = e.meta || (e.when ? fmtTime(e.when, e.tz) : "");
      var line = (when ? when + " — " : "") + e.title;
      // Airport-to-airport is a route, not an address — it is how you tell one
      // flight from another, so it stays. Street addresses do not.
      //
      // But only where it says something. A hire car's two ends are the same
      // depot and the depot is the company, so the raw field produced "Adobe
      // Rent A Car · Pick-up (Adobe Rent a Car → Adobe Rent a Car)". Drop the
      // repeat, then drop whatever the title already said: a car is left with
      // just its name, a flight still shows LAX → LIR.
      if (e.kind === "transport" && e.sub) {
        var seen = {}, ends = [];
        e.sub.split("→").forEach(function (x) {
          var end = x.trim(); if (!end) return;
          var k = end.toLowerCase();
          if (seen[k] || String(e.title).toLowerCase().indexOf(k) >= 0) return;
          seen[k] = 1; ends.push(end);
        });
        if (ends.length) line += " (" + ends.join(" → ") + ")";
      }
      out.push(line);
    });
    if (oe.unscheduled.length) {
      out.push("");
      out.push("NOT SCHEDULED");
      oe.unscheduled.forEach(function (e) { out.push(e.title); });
    }
    return out.join("\n").replace(/\n{3,}/g, "\n\n").trim();
  }

  // Every route here opens a composer and stops. Nothing is ever sent by the
  // app: the recipient, the wording and the send button all stay with whoever
  // tapped the chip. It is also why there is no contact list of our own — a web
  // page cannot read the address book, and the share sheet already has it.
  function openSendTo(t, data) {
    var text = itineraryText(t, data);
    var subject = (t.name || "Trip") + " — " + fmtRange(t);
    var rows = [];

    // The native sheet is the good path: the only one that reaches Messages,
    // WhatsApp, mail AND the address book in a single tap, and on a phone it is
    // what a share button is already expected to do. Absent on desktop Firefox,
    // which is why the explicit routes below exist rather than being a fallback
    // nobody ever sees.
    if (navigator.share) {
      rows.push(["📤", "Share…", function () {
        navigator.share({ title: subject, text: text }).catch(function (e) {
          if (e && e.name === "AbortError") return;        // sheet dismissed, not a failure
          toast("Share unavailable: " + (e && e.message ? e.message : e));
        });
      }]);
    }

    // A URL-borne body is capped well below what a two-week trip produces, and
    // the handler truncates in silence. Trim deliberately, on a line boundary,
    // and say that is what happened rather than let half a trip arrive looking
    // complete.
    var LIMIT = 1600;
    var short = text.length > LIMIT
      ? text.slice(0, LIMIT).replace(/\n[^\n]*$/, "") + "\n\n… trimmed. Ask me for the full itinerary."
      : text;

    rows.push(["💬", "Message", function () { window.location.href = "sms:?&body=" + encodeURIComponent(short); }]);
    rows.push(["🟢", "WhatsApp", function () { window.open("https://wa.me/?text=" + encodeURIComponent(short), "_blank", "noopener"); }]);
    // Mail copes with far more than a text message does, so it gets the whole
    // itinerary rather than the trimmed copy.
    rows.push(["✉️", "Email", function () {
      window.location.href = "mailto:?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(text);
    }]);
    rows.push(["📋", "Copy", function () {
      copy(text).then(function (ok) {
        toast(ok ? "Itinerary copied — paste it anywhere"
                 : "Couldn't reach the clipboard. Use Email or Message instead.");
      });
    }]);

    openChooser("Send “" + String(t.name || "trip").slice(0, 40) + "”", rows);
  }

  async function exportPdf(t, data, btn) {
    var orig = btn.textContent; btn.disabled = true; btn.textContent = "…";
    try {
      if (!window.jspdf) await loadScript("https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js");
      var doc = new window.jspdf.jsPDF({ unit: "pt", format: "letter" });
      var W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight();
      // Same design as the Word export -- see the note above exportWord. The
      // gutter holds the times; GX is where content starts to their right.
      var M = 54, GUT = 64, GX = M + GUT + 8, y = M;
      // jsPDF's built-in Helvetica is WinAnsi: no emoji, no arrows. It does not
      // reject them -- it writes their UTF-16 code units as single bytes, so
      // "\u2708\uFE0F Alaska \u2192 LIR" printed as "\u00D8\u00D8 Alaska \u00D8 LIR".
      // Every string is washed before drawing: the arrow becomes an en dash,
      // anything else the font lacks is dropped, doubled spaces collapse. The
      // coloured kind bar was always the differentiator here; the icons only
      // ever worked in the Word export, where they stay.
      function pdfSafe(v) {
        return String(v == null ? "" : v)
          .replace(/[\u2192\u2794\u27A1]/g, "\u2013")
          .replace(/[^\x20-\x7E\xA0-\xFF\u2013\u2014\u2018\u2019\u201C\u201D\u2022\u2026]/g, "")
          .replace(/  +/g, " ").replace(/^ | $/g, "");
      }
      var INK = [30, 36, 48], MUTED = [92, 101, 112], FAINT = [138, 145, 156];
      var ACCENT = [47, 109, 246], RULE = [199, 214, 246], ZEBRA = [244, 247, 253], CREDIT = [31, 122, 77];
      var KIND_RGB = { transport: [47, 109, 246], hosting: [124, 58, 237], activity: [180, 83, 9] };

      function ensure(need) { if (y + need > H - M - 16) { doc.addPage(); y = M; } }
      function put(txt, x, size, bold, color, maxW, align) {
        doc.setFont("helvetica", bold ? "bold" : "normal");
        doc.setFontSize(size);
        var c = color || INK; doc.setTextColor(c[0], c[1], c[2]);
        var lines = doc.splitTextToSize(pdfSafe(txt), maxW || (W - M * 2));
        lines.forEach(function (ln) {
          ensure(size * 1.45);
          doc.text(ln, x, y, align ? { align: align } : undefined);
          y += size * 1.45;
        });
        return lines.length;
      }
      function section(label) {
        // Never orphan a heading at the foot of a page: the rule plus at least
        // one item must fit below it, or it moves to the next page whole.
        ensure(64);
        y += 14;
        put(label, M, 12.5, true, ACCENT);
        doc.setDrawColor(RULE[0], RULE[1], RULE[2]); doc.setLineWidth(1.2);
        doc.line(M, y - 12, W - M, y - 12);
        y += 6;
      }

      // ---- title block ----
      put(t.name || "Trip", M, 21, true);
      put(fmtRange(t) + (t.has_dates ? " · " + spanDays(t) + " days" : ""), M, 10.5, false, MUTED);
      y += 2;
      doc.setDrawColor(ACCENT[0], ACCENT[1], ACCENT[2]); doc.setLineWidth(2.5);
      doc.line(M, y - 8, W - M, y - 8);
      y += 14;

      // ---- the itinerary, with a time gutter and a kind bar ----
      var itemW = W - M - GX;
      function item(e) {
        var o = e.obj || {};
        var title = pdfSafe(e.title);
        // The gutter is 64pt and a flight's meta is "Dep 9:57 AM - Arr
        // 12:39 PM" -- about 123pt. Drawn as one run it ploughed straight
        // through the title on the same baseline, which is exactly the
        // "text on top of each other" this looked like. The meta now wraps
        // INSIDE the gutter, splitting first at its own separators so the
        // clauses stack as "Dep 9:57 AM" over "Arr 12:39 PM" rather than
        // breaking mid-time.
        var metaLines = [];
        if (e.meta) {
          doc.setFont("helvetica", "normal"); doc.setFontSize(9.5);
          pdfSafe(e.meta).split("\u00B7").forEach(function (part) {
            part = part.replace(/^ +| +$/g, "");
            if (!part) return;
            // A clause that will not fit breaks after its label word --
            // "Pick-up" over "12:00 PM" -- rather than wherever the wrap
            // happens to land, which produced a dangling "PM" on its own line.
            if (doc.getTextWidth(part) > GUT) part = part.replace(/ /, "\n");
            doc.splitTextToSize(part, GUT).forEach(function (ln) { metaLines.push(ln); });
          });
        }
        // Measure before drawing, so a block never splits across a page --
        // which would also strand its kind bar at the wrong height. The
        // gutter's height counts too: a one-line title beside a three-line
        // meta must reserve the taller of the two.
        doc.setFont("helvetica", "bold"); doc.setFontSize(11);
        var titleLines = doc.splitTextToSize(title, itemW).length;
        doc.setFont("helvetica", "normal"); doc.setFontSize(9.5);
        var subLines = e.sub ? doc.splitTextToSize(pdfSafe(e.sub), itemW).length : 0;
        var contentH = titleLines * 16 + subLines * 13.8 + (o.provider_reservation_code ? 12.5 : 0);
        var gutterH = metaLines.length * 11.5;
        var blockH = Math.max(contentH, gutterH);
        ensure(blockH + 8);
        var top = y;
        doc.setFont("helvetica", "normal"); doc.setFontSize(9.5);
        doc.setTextColor(MUTED[0], MUTED[1], MUTED[2]);
        metaLines.forEach(function (ln, li) { doc.text(ln, M, top + li * 11.5); });
        put(title, GX, 11, true, INK, itemW);
        if (e.sub) put(e.sub, GX, 9.5, false, MUTED, itemW);
        if (o.provider_reservation_code) put("CONF  " + o.provider_reservation_code, GX, 8.5, false, FAINT, itemW);
        // A tall gutter beside a short item must still push the next item
        // clear of its last line.
        if (top + gutterH > y) y = top + gutterH;
        var kc = KIND_RGB[e.kind] || KIND_RGB.activity;
        doc.setFillColor(kc[0], kc[1], kc[2]);
        doc.rect(GX - 8, top - 8.5, 2.5, y - top - 4, "F");
        y += 7;
      }

      var oe = orderedEntries(t, data), lastDay = null;
      oe.scheduled.forEach(function (e) {
        var k = dayKey(e.when, e.tz);
        if (k !== lastDay) { section(dayLabel(k)); lastDay = k; }
        item(e);
      });
      if (oe.unscheduled.length) { section("Unscheduled"); oe.unscheduled.forEach(item); }

      // ---- expenses, as the table they are ----
      // Categories derived exactly as the Budget panel derives them, credits
      // green and negative -- signedAmount, so the document can never disagree
      // with the panel it was exported from.
      if ((data.expenses || []).length) {
        section("Expenses");
        var CATX = W - M - 150, AMTX = W - M;
        doc.setFont("helvetica", "bold"); doc.setFontSize(8);
        doc.setTextColor(MUTED[0], MUTED[1], MUTED[2]);
        doc.text("DESCRIPTION", M, y); doc.text("CATEGORY", CATX, y); doc.text("AMOUNT", AMTX, y, { align: "right" });
        y += 5;
        doc.setDrawColor(INK[0], INK[1], INK[2]); doc.setLineWidth(1);
        doc.line(M, y - 1, W - M, y - 1);
        y += 12;
        var totals = {};
        (data.expenses || []).forEach(function (x, i) {
          var cat = x.category || linkCategory(linkedItem(x, data)) || "Other";
          var amt = x.price != null ? x.price : x.amount;
          var signed = signedAmount(cat, amt);
          var cur = x.currency || "USD";
          totals[cur] = (totals[cur] || 0) + signed;
          var desc = x.title || x.name || x.description || "Expense";
          doc.setFont("helvetica", "normal"); doc.setFontSize(9.5);
          var descLines = doc.splitTextToSize(desc, CATX - M - 14);
          var rowH = descLines.length * 13 + 4;
          ensure(rowH + 4);
          if (i % 2) {
            doc.setFillColor(ZEBRA[0], ZEBRA[1], ZEBRA[2]);
            doc.rect(M - 4, y - 9.5, W - M * 2 + 8, rowH, "F");
          }
          var rowTop = y;
          put(desc, M, 9.5, false, INK, CATX - M - 14);
          var after = y;
          y = rowTop;
          doc.setFont("helvetica", "normal"); doc.setFontSize(8.5);
          doc.setTextColor(MUTED[0], MUTED[1], MUTED[2]);
          doc.text(pdfSafe(cat), CATX, y);
          doc.setFont("helvetica", "bold"); doc.setFontSize(9.5);
          var ac = cat === CREDIT_CAT ? CREDIT : INK;
          doc.setTextColor(ac[0], ac[1], ac[2]);
          doc.text(amt != null ? money(signed, cur) : "", AMTX, y, { align: "right" });
          y = after + 3;
        });
        y += 4;
        doc.setDrawColor(INK[0], INK[1], INK[2]); doc.setLineWidth(1);
        doc.line(CATX - 14, y - 10, W - M, y - 10);
        Object.keys(totals).forEach(function (cur) {
          ensure(16);
          doc.setFont("helvetica", "bold"); doc.setFontSize(10);
          doc.setTextColor(INK[0], INK[1], INK[2]);
          doc.text("Total " + cur, CATX, y);
          doc.text(money(totals[cur], cur), AMTX, y, { align: "right" });
          y += 15;
        });
      }

      // ---- page numbers, last, once the count is known ----
      var pages = doc.getNumberOfPages();
      for (var pi = 1; pi <= pages; pi++) {
        doc.setPage(pi);
        doc.setFont("helvetica", "normal"); doc.setFontSize(8.5);
        doc.setTextColor(FAINT[0], FAINT[1], FAINT[2]);
        doc.text(pdfSafe((t.name || "Trip") + "  \u00B7  page " + pi + " of " + pages), W / 2, H - 22, { align: "center" });
      }

      doc.save(slug(t.name) + ".pdf");
    } catch (e) { toast("PDF export failed: " + e.message); }
    finally { btn.disabled = false; btn.textContent = orig; }
  }

  // ---- misc ----
  // writeText REJECTS rather than throws — the browser refuses when the document
  // is not focused, among other reasons — so the old try/catch caught nothing.
  // The failure surfaced as an unhandled rejection in the console while the
  // caller cheerfully reported success. Resolves to whether it actually worked,
  // so a caller can stop claiming it did.
  function copy(s) {
    try {
      var p = navigator.clipboard && navigator.clipboard.writeText(s);
      if (p && p.then) return p.then(function () { return true; }, function () { return false; });
    } catch (e) { /* falls through */ }
    return Promise.resolve(false);
  }
  // Toasts live in one persistent layer rather than being loose fixed elements.
  //
  // Three things were wrong with the old one. It sat at z-index 40 while
  // .form-overlay sits at 50, so a validation message fired from an open dialog
  // painted BEHIND that dialog's darkened, blurred backdrop -- exactly when a
  // message matters most. Every toast was positioned identically, so a second
  // one covered a first that was still showing. And it was a fresh div each
  // time, which a screen reader announces unreliably; a live region that
  // already exists is announced when its contents change.
  var toastHost = null;
  function toastLayer() {
    if (toastHost && document.body.contains(toastHost)) return toastHost;
    toastHost = el("div", "toast-layer");
    toastHost.setAttribute("role", "status");
    toastHost.setAttribute("aria-live", "polite");
    document.body.appendChild(toastHost);
    return toastHost;
  }

  // 2.6 seconds is right for "Saved" and wrong for "Couldn't save": look away
  // for three seconds -- the normal state of a phone -- and the only record
  // that a write failed is gone, with the UI showing the pre-action state and
  // nothing saying it did not happen.
  //
  // The tone is derived from the message because there are 32 failure toasts
  // and annotating each one means missing the 33rd. opts.error overrides it
  // either way for anything the pattern does not fit.
  var TOAST_MS = 2600, TOAST_ERROR_MS = 6000, TOAST_UNDO_MS = 9000;
  function toast(msg, opts) {
    opts = opts || {};
    var bad = opts.error != null ? !!opts.error
      : /^(Couldn't|Couldn\u2019t|Could not|Failed|.*failed)/.test(String(msg));
    var t = el("div", "toast" + (bad ? " toast-error" : ""), msg);
    // An alert interrupts; a status waits its turn. A failed save has earned
    // the interruption, "Saved" has not.
    if (bad) t.setAttribute("role", "alert");
    toastLayer().appendChild(t);
    setTimeout(function () { t.classList.add("show"); }, 10);
    // A sticky toast has no timer: it belongs to work that is still happening
    // and only whoever started that work knows when it is over. See
    // progressToast -- and note that every sticky toast MUST be ended by its
    // caller, including on the failure path, or it sits there for ever.
    if (!opts.sticky) {
      setTimeout(function () {
        t.classList.remove("show");
        setTimeout(function () { t.remove(); }, 300);
      }, opts.ms || (bad ? TOAST_ERROR_MS : TOAST_MS));
    }
    return t;
  }
  // A toast you can act on.
  //
  // This is why the delete confirms can go away. A confirm asks you to predict,
  // in advance, that you will not regret the delete -- and charges every
  // intentional delete two taps to catch the rare accidental one. Undo inverts
  // it: the common case costs one tap, and the rare case is fixed by looking at
  // the result and disagreeing with it, which is a far easier judgement than
  // predicting it.
  //
  // It could only be built once the server could actually put a row back. The
  // rows were always recoverable in the DATABASE -- delete sets deleted_at and
  // keeps the data -- and the old dialog even said "Deletes are recoverable",
  // but nothing in the app could exercise it. See restoreDeleted in _core.js.
  //
  // Nine seconds: long enough to read the toast, notice what vanished and
  // change your mind; short enough to be gone before you have moved on.
  function undoToast(msg, undo) {
    var t = toast(msg, { error: false, ms: TOAST_UNDO_MS });
    // The layer is pointer-events:none so a toast never eats a tap meant for
    // the page underneath. One carrying a button has to opt back in.
    t.classList.add("has-action");
    var b = el("button", "toast-undo", "Undo");
    b.type = "button";
    b.addEventListener("click", function () {
      b.disabled = true;
      b.textContent = "Undoing\u2026";
      Promise.resolve(undo()).then(
        function () { t.remove(); },
        function (e) { t.remove(); toast("Couldn't undo: " + (e && e.message ? e.message : e)); }
      );
    });
    t.appendChild(b);
    return t;
  }

  // A toast that stays for the length of the work, with a bar.
  //
  // Uploading used to announce the filename in an ordinary toast and vanish
  // after 2.6 seconds. On anything larger than a screenshot that is most of the
  // way BEFORE the upload starts, and for the rest of it the app looked idle --
  // which is exactly when somebody taps the button again and uploads it twice.
  //
  // Returns a handle rather than an element, because the caller has to be able
  // to end it. It has no timer of its own.
  function progressToast(msg) {
    var t = toast(msg, { error: false, sticky: true });
    t.classList.add("has-progress");
    var label = el("span", "toast-msg", msg);
    t.textContent = "";
    t.appendChild(label);
    var track = el("div", "toast-track");
    var bar = el("div", "toast-bar");
    track.appendChild(bar);
    t.appendChild(track);
    // A real progressbar, so aria-valuenow means something. Without the role it
    // is an attribute nothing reads.
    track.setAttribute("role", "progressbar");
    track.setAttribute("aria-valuemin", "0");
    track.setAttribute("aria-valuemax", "100");
    track.setAttribute("aria-label", msg);
    // NO aria-live here. toastHost is already a polite live region and this
    // toast is inside it; a second one nested within announces twice. The
    // percentage is silent either way -- a live region reports text and node
    // changes, not attribute changes, so forty valuenow updates during one
    // upload say nothing, which is the right amount.

    var close = function (finalMsg, bad) {
      t.remove();
      if (finalMsg) toast(finalMsg, { error: !!bad });
    };
    return {
      // 0..1, or null when the total is unknown -- some servers and proxies
      // strip the length, and a bar that guesses is worse than one that admits
      // it does not know.
      set: function (fraction, text) {
        if (text) label.textContent = text;
        if (fraction == null) {
          track.classList.add("is-indeterminate");
          bar.style.width = "100%";
          // A progressbar with no valuenow is the standard way to say
          // "working, amount unknown". Leaving a stale number would be worse
          // than saying nothing.
          track.removeAttribute("aria-valuenow");
          return;
        }
        track.classList.remove("is-indeterminate");
        var pct = Math.max(0, Math.min(1, fraction)) * 100;
        bar.style.width = pct.toFixed(1) + "%";
        track.setAttribute("aria-valuenow", Math.round(pct));
      },
      done: function (m) { close(m, false); },
      fail: function (m) { close(m, true); },
    };
  }

  // fetch cannot report upload progress -- it has an event for bytes received
  // and none for bytes sent -- so an upload that shows one has to go through
  // XMLHttpRequest. Nothing else in the app does; api() stays as it is.
  //
  // Deliberately mirrors api()'s auth header and NOT its Content-Type: a
  // FormData body must carry the boundary the browser generated, and setting
  // the header by hand strips it.
  function uploadWithProgress(path, fd, onProgress) {
    return new Promise(function (resolve, reject) {
      var xhr = new XMLHttpRequest();
      xhr.open("POST", API_BASE + path, true);
      var token = getToken();
      if (token) xhr.setRequestHeader("Authorization", "Token " + token);
      xhr.upload.addEventListener("progress", function (ev) {
        onProgress(ev.lengthComputable && ev.total ? ev.loaded / ev.total : null);
      });
      // The last byte SENT is not the last thing that happens: the server still
      // has to write the file to R2 and the row to D1. Sitting at 100% with no
      // explanation reads as stuck, so say what is going on.
      xhr.upload.addEventListener("load", function () { onProgress(1, "Saving…"); });
      xhr.addEventListener("load", function () {
        var data = safeJson(xhr.responseText || "") || null;
        if (xhr.status >= 200 && xhr.status < 300) {
          // Writes invalidate every cached sweep, the same rule api() applies:
          // a document added here can change what Check Trips reports.
          panelCache = {};
          resolve(data);
          return;
        }
        reject(new Error((data && (data.detail || data.error)) || ("Upload failed (" + xhr.status + ")")));
      });
      // A network error gives no status and no body, so it needs its own words
      // rather than "Upload failed (0)".
      xhr.addEventListener("error", function () { reject(new Error("The connection failed.")); });
      xhr.addEventListener("timeout", function () { reject(new Error("The upload timed out.")); });
      xhr.addEventListener("abort", function () { reject(new Error("Upload cancelled.")); });
      xhr.send(fd);
    });
  }

  // Dismantling the trip view, with no opinion about history. Separated from
  // closeDetail because going BACK also has to run it -- via popstate -- and
  // doing that through closeDetail would push history again from inside a
  // history event.
  function tearDownDetail() {
    shownPanel = null;
    // Any dialog opened from inside the trip goes with it. Left behind, it would
    // float over the dashboard with nothing underneath it to belong to.
    $$(".form-overlay").forEach(function (o) { o.remove(); });
    $("#detail-overlay").hidden = true; $("#detail-content").innerHTML = "";
    shownTrip = null;
    if (dayWatcher) { dayWatcher.disconnect(); dayWatcher = null; }
    // openTrip locks the page behind the panel; unlock it or the dashboard is
    // frozen after the first trip you close.
    document.body.style.overflow = "";
    try { if (leafletMap) { leafletMap.remove(); leafletMap = null; } } catch (e) {}
  }

  // Closing used to push ANOTHER entry -- the bare pathname -- so opening and
  // closing one trip left [dashboard, #trip/N, dashboard] and Back landed on
  // #trip/N, which handleHash dutifully reopened. Every browse cycle added two
  // entries, so leaving the installed PWA took one back-swipe per trip looked
  // at that session.
  //
  // Going back is what actually undoes the navigation. popstate then runs the
  // teardown, so X, Escape and the iOS edge-swipe all converge on one
  // stack-SHRINKING path instead of three that grow it.
  function closeDetail() {
    // Any app address, not just #trip/ -- the panels have their own now.
    if (pushedDetail && location.hash) {
      pushedDetail = false;
      history.back();
      return;
    }
    tearDownDetail();
    // Arrived here by deep link, so there is no entry behind this one to go
    // back to -- replace it rather than stranding the user outside the app.
    if (location.hash) history.replaceState(null, "", location.pathname);
  }
  $$("[data-close]").forEach(function (n) { n.addEventListener("click", closeDetail); });

  // Escape peels ONE layer.
  //
  // It used to call closeDetail, which removes every .form-overlay and the trip
  // behind them -- so a reflexive Escape while typing in "Edit lodging" threw
  // away the edit, the dialog, any sheet above it, and the trip, with no
  // warning. Settings -> Manage Calendar Feeds -> edit stacks three overlays;
  // one keypress destroyed all three.
  document.addEventListener("keydown", function (e) {
    if (e.key !== "Escape") return;
    var top = topLayer();
    if (top) { closeTopLayer(top); return; }
    if (!$("#detail-overlay").hidden) closeDetail();
  });

  // The panels are places you can BE, so they have addresses.
  //
  // Only trips did. A pull-to-refresh or a PWA relaunch part-way through a
  // triage session always landed back on the dashboard, and there was no way to
  // open the phone to the same Check Trips list the desktop was showing -- for
  // a two-device daily user that is the difference between starting something
  // on one and finishing it on the other.
  //
  // They all render into #detail-overlay, the same surface a trip uses, so they
  // close through the same path and inherit the same Back behaviour.
  var PANEL_ROUTES = {
    "#history": function () { openInsights(); },
    "#check": function () { auditAllUpcoming(); },
    "#changes": function () { reviewChanges(); },
    "#calendar": function () { openYearGrid(); },
    "#ideas": function () { openBucketList(); }
  };

  // A sweep is a session's worth of work, and drilling into a finding used to
  // throw it away.
  //
  // Check Trips, Changes and Calendar render into #detail-overlay -- the same
  // surface a trip uses -- so opening a trip from a finding erased the results,
  // and closing that trip landed on the dashboard rather than back on the list.
  // These panels exist for batch triage: fix finding one, then two, then three.
  // The old shape supported fixing exactly one per sweep, and re-entering
  // re-fetched three endpoints for every upcoming trip.
  //
  // So the rendered panel is kept and re-attached rather than rebuilt.
  //
  // It is discarded the moment anything is WRITTEN, which is the case that
  // matters: a sweep whose findings you have just been fixing is precisely the
  // one that must not come back from cache still listing them.
  var panelCache = {};
  var shownPanel = null;

  function cachePanel(hash, node) {
    if (hash) panelCache[hash] = { node: node, scroll: 0 };
  }

  function restorePanel(hash) {
    var hit = panelCache[hash];
    if (!hit || !hit.node) return false;
    var overlay = $("#detail-overlay"), content = $("#detail-content");
    content.innerHTML = "";
    content.appendChild(hit.node);
    overlay.hidden = false;
    document.body.style.overflow = "hidden";
    // After the node is back in the document, or there is nothing to scroll.
    var p = overlay.querySelector(".detail-panel");
    if (p) setTimeout(function () { p.scrollTop = hit.scroll || 0; }, 0);
    return true;
  }

  // Called before anything replaces the panel, so returning lands where the
  // reading left off rather than at the top of a long list of findings.
  function notePanelScroll() {
    if (!shownPanel || !panelCache[shownPanel]) return;
    var p = document.querySelector("#detail-overlay .detail-panel");
    if (p) panelCache[shownPanel].scroll = p.scrollTop;
  }

  // Called by each opener. Guarded on the current hash so that re-entering a
  // panel from popstate -- where the hash is ALREADY the panel's -- does not
  // push a second entry and trap Back in a loop.
  function panelRoute(hash) {
    shownPanel = hash;
    if (location.hash === hash) return;
    history.pushState(null, "", hash);
    pushedDetail = true;
  }

  // The mirror of panelRoute: a panel that has closed gives its address back.
  //
  // Closing one used to take it off the screen and leave both the hash and the
  // history entry behind. The panel looked shut and was not: open a trip, close
  // it, and closeDetail's history.back() landed on #ideas, where handleHash
  // duly re-opened a panel nobody had asked for. Reported as "trip ideas keeps
  // popping up", and true of all three ways of closing it -- the backdrop,
  // Escape and the Done chip alike, since every one of them is back.remove().
  //
  // The panels that render into #detail-overlay never had this: they close
  // through closeDetail, which is where this logic already lived. This is the
  // same handling for the two that render into an overlay() instead.
  function closePanelRoute(hash) {
    if (shownPanel === hash) shownPanel = null;
    // Something else owns the address now -- a trip opened from inside the
    // panel, say. Leave it alone rather than rewriting somebody else's route.
    if (location.hash !== hash) return;
    if (pushedDetail) { pushedDetail = false; history.back(); return; }
    // Arrived by deep link, so there is no entry behind this one; replacing it
    // drops the address without stranding the user outside the app.
    history.replaceState(null, "", location.pathname + location.search);
  }

  // Whether the trip view owes the history stack an entry. A deep link --
  // arriving on #trip/N directly -- did not push one, so there is nothing
  // behind it and history.back() would leave the app entirely.
  var pushedDetail = false;

  // handleHash exists to honour a DEEP LINK -- the address the app was opened
  // on. loadAll() runs it on every call, which was harmless while the only
  // route was #trip/N and the trip was already open, and became a bug the
  // moment panels got addresses: pressing Refresh on the dashboard re-opened
  // History, because #history was still in the address bar from earlier.
  //
  // Back, Forward and address-bar edits still route -- they come through
  // popstate and hashchange, which are unaffected.
  var deepLinkHandled = false;

  function handleHash() {
    var m = location.hash.match(/^#trip\/(\d+)/);
    if (m) { var id = Number(m[1]); var t = state.own.filter(function (x) { return x.id === id; })[0]; if (t) openTrip(t); return; }
    var panel = PANEL_ROUTES[location.hash];
    if (panel) { panel(); return; }
    // Reached by going back, so the entry is already gone: tear down without
    // touching history again.
    pushedDetail = false;
    if (!$("#detail-overlay").hidden) tearDownDetail();
  }
  window.addEventListener("popstate", handleHash);
  // popstate covers Back and Forward, but NOT editing the address bar of an
  // already-open tab -- that is a same-document navigation and fires only
  // hashchange. Without this, an address the app hands out is one it will not
  // honour when it is pasted back in. Neither pushState nor panelRoute fires
  // either event, so this cannot loop.
  window.addEventListener("hashchange", handleHash);

  // The header button cycles; the Settings dialog picks a theme directly.
  $("#theme-toggle").addEventListener("click", function () {
    var i = 0;
    THEMES.forEach(function (o, n) { if (o.value === currentTheme()) i = n; });
    setTheme(THEMES[(i + 1) % THEMES.length].value);
  });
  paintThemeButton();

  // ---- sticky offset (so year-jump lands below the pinned bar) + back to top ----
  function measureSticky() {
    var hdr = document.querySelector(".app-header"); var h = hdr ? hdr.offsetHeight : 56;
    var d = document.querySelector(".dash-sticky"); var dh = (d && !$("#dash-view").hidden) ? d.offsetHeight : 0;
    var root = document.documentElement;
    root.style.setProperty("--header-h", h + "px");
    root.style.setProperty("--sticky-h", (h + dh + 12) + "px");
  }
  window.addEventListener("resize", measureSticky);
  var toTop = $("#to-top");
  if (toTop) { toTop.hidden = false; toTop.addEventListener("click", function () { window.scrollTo({ top: 0, behavior: "smooth" }); }); }
  window.addEventListener("scroll", function () { if (toTop) toTop.classList.toggle("show", window.scrollY > 420); }, { passive: true });

  // ---- Admin/Edit vs View/Read ----
  //
  // This hides what a View/Read account cannot do. It is NOT the control — the
  // Worker refuses the write regardless, and would still refuse it with the
  // console open and every button forced back on. Hiding is here so the app
  // does not offer things it will then reject.
  function isAdmin() { return !state.me || state.me.role !== "view"; }
  // Gating is a class on <body>, and the trips fetch no longer waits for
  // /v1/me -- so render() can now run before the role is known. The default is
  // therefore the conservative one: admin controls stay hidden until /v1/me
  // says otherwise, and a View account never sees a control it cannot use, not
  // even for a frame. The "View Only" tag is deliberately NOT part of that
  // default: it appears only once the role is actually known, so an admin is
  // not shown a label about their own account while it is still in flight.
  function applyRole() {
    var known = !!state.me;
    var view = !known || !isAdmin();
    document.body.classList.toggle("role-view", view);
    var tag = $("#role-tag");
    if (known && view && !tag) {
      // Says why the buttons are missing. Without it the app just looks broken.
      tag = el("span", "role-tag", "View Only");
      tag.id = "role-tag";
      tag.title = "Your account has View/Read access. Ask an Admin/Edit account to change this.";
      var host = $(".header-actions");
      if (host) host.insertBefore(tag, host.firstChild);
    } else if ((!view || !known) && tag) tag.remove();
  }

  // Regaining a connection clears the strip on the next successful read; the
  // event only prompts one. Going offline is left to noteFreshness rather than
  // trusted from the event, for the captive-portal reason above.
  window.addEventListener("online", function () {
    try { loadAll(); } catch (e) {}
  });

  async function boot() {
    // Under Access there is nothing to log into — reaching this code already
    // proves identity. The token gate is vestigial and never fires.
    if (!USE_ACCESS_AUTH && !getToken()) { showLogin(); return; }
    showDashboard();
    // Hide anything role-gated until the role is actually known. See applyRole.
    applyRole();
    // NOT awaited. Nothing the dashboard paints comes from /v1/me -- it feeds
    // the maps key, the role class and the header name -- and awaiting it put a
    // whole round trip in front of the 91KB request the trip list is made of.
    // Behind Access on a phone that was a fifth of a second of dead air before
    // the real work started, on every single open, and up to the service
    // worker's five-second timeout on a network that stalls.
    var mePromise = (async function () {
      try {
        var me = await api("/v1/me"); state.me = me && me.data ? me.data : me;
        // Loading starts here rather than at first paint so the script is
        // usually ready before a map is opened.
        mapsKey = (state.me && state.me.maps_key) || null;
        if (mapsKey) loadGoogleMaps();
        applyRole(); setUser(state.me); showDashboard();
      } catch (e) {
        // This used to be `catch (e) {}`. On 2026-08-23 the dashboard rendered
        // a bare header and nothing else, and the empty console was the single
        // biggest reason it took as long as it did to find -- there was no way
        // to tell a failed boot from a page that had not finished loading.
        //
        // Swallowing is still right for the FLOW: the trip list does not depend
        // on this, and a failed /v1/me must not blank a working app. What was
        // wrong was doing it in silence.
        try {
          console.error("[boot] /v1/me failed — the header name and role will be" +
            " missing and admin controls stay hidden; trips load regardless:",
            (e && e.status ? e.status + " " : "") + (e && e.message ? e.message : e), e);
        } catch (ignored) {}
      }
    })();
    // Both in flight together. loadAll() does not read state.me.
    loadAll();
    return mePromise;
  }
  boot();
})();