// roomPaxOf, plus the document-filtering rule that now follows trip membership.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");
function grab(n) {
  const i = src.indexOf("  function " + n + "(");
  if (i < 0) throw new Error("missing " + n);
  let d = 0, s = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; s = true; } else if (src[j] === "}") { d--; if (s && !d) return src.slice(i, j + 1); }
  }
}
globalThis.state = { me: {} };
eval(["travellers", "travellerById", "travellerName", "tripTravellers", "seatList", "nameInText", "roomPaxOf", "travelDocs"]
  .map(grab).join("\n") + ";Object.assign(globalThis,{roomPaxOf,travelDocs,tripTravellers,travellers});");

const ROSTER = [
  { id: "alex", name: "Alex" }, { id: "sam", name: "Sam" },
  { id: "jo", name: "Jo" }, { id: "robin", name: "Robin" }, { id: "casey", name: "Casey" },
];
state.me.travellers = ROSTER;

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const ok = JSON.stringify(got) === JSON.stringify(want);
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + JSON.stringify(want) + "\n        got  " + JSON.stringify(got));
};
const TRIP = (ids) => ({ id: 1, travellers: ids });
const ALL = TRIP(["alex", "sam", "jo", "robin", "casey"]);

// --- the real Madrid/Lisbon shape ---
t("reads the occupant out of the room description",
  roomPaxOf({ description: "Room 1 - Sam Rivera (Alex's room) - 2 Twin Beds" }, ALL)
    .map((x) => x.name + (x.guessed ? "?" : "")),
  ["Alex?", "Sam?"]);
t("the sibling room names only its own occupant",
  roomPaxOf({ provider_reservation_description: "Santiago Rosales (room 2 of 2) - conf 50352720" }, ALL), []);

// --- a stored assignment always wins ---
t("stored assignment is used verbatim and is not a guess",
  roomPaxOf({ description: "Room 1 - Sam Rivera", pax: [{ id: "jo", room: "412" }] }, ALL),
  [{ id: "jo", name: "Jo", room: "412", guessed: false }]);
t("an empty stored list means deliberately nobody",
  roomPaxOf({ description: "Room 1 - Sam Rivera", pax: [] }, ALL), []);
t("stored assignment survives a name no longer on the roster",
  roomPaxOf({ pax: [{ id: "ghost", room: "9" }] }, ALL),
  [{ id: "ghost", name: "ghost", room: "9", guessed: false }]);

// --- when a guess would say nothing ---
t("everybody named is not a room split, so nothing is drawn",
  roomPaxOf({ notes: "Alex, Sam, Jo, Robin and Casey are all staying here" }, ALL), []);
t("no text at all -> nothing", roomPaxOf({ name: "Hyatt" }, ALL), []);
t("nobody on the trip -> nothing", roomPaxOf({ description: "Room 1 - Sam Rivera" }, TRIP([])), []);
t("a name not on this trip is ignored",
  roomPaxOf({ description: "Room 1 - Sam Rivera" }, TRIP(["alex", "jo"])), []);
// room_number was removed on 2026-08-19. It was empty on all 216 lodging
// records, had two editors between them, and was never going to be filled in —
// so a guess no longer carries a room label even when one is somehow stored.
// Who is in the booking is still answered; which room they are in is not asked.
t("a stored room number is no longer picked up",
  roomPaxOf({ description: "Jo's room", room_number: "412" }, ALL).map((x) => x.name + "/" + x.room),
  ["Jo/"]);
t("but the person still is",
  roomPaxOf({ description: "Jo's room", room_number: "412" }, ALL).map((x) => x.name),
  ["Jo"]);

// --- documents now follow trip membership ---
// Mirrors the filter in auditTrip's F2 block.
const filterDocs = (trip) => {
  const going = tripTravellers(trip);
  let docs = travelDocs();
  if (going.length) {
    const names = {}; going.forEach((p) => (names[p.name.toLowerCase()] = true));
    const known = {}; travellers().forEach((p) => (known[p.name.toLowerCase()] = true));
    docs = docs.filter((d) => {
      const who = String(d.who || "").trim().toLowerCase();
      return !who || names[who] || !known[who];
    });
  }
  return docs.map((d) => d.who + " " + d.kind);
};
state.me.travel_documents = [
  { who: "Alex", kind: "Passport", expires: "2029-03-07" },
  { who: "Sam", kind: "Passport", expires: "2031-06-27" },
  { who: "Sam", kind: "Licence", expires: "2026-07-29" },
  { who: "Jo", kind: "Passport", expires: "2029-03-03" },
  { who: "Robin", kind: "Passport", expires: "2030-11-17" },
];
t("only the people going are checked",
  filterDocs(TRIP(["alex", "sam"])), ["Alex Passport", "Sam Passport", "Sam Licence"]);
t("a solo trip checks one person",
  filterDocs(TRIP(["alex"])), ["Alex Passport"]);
t("NOBODY marked -> everything is still checked (trips with no membership must not go silent)",
  filterDocs(TRIP([])).length, 5);
t("a document for somebody not on the roster is always kept", (() => {
  state.me.travel_documents = state.me.travel_documents.concat([{ who: "Grandma", kind: "Passport", expires: "2030-01-01" }]);
  const r = filterDocs(TRIP(["alex"]));
  state.me.travel_documents = state.me.travel_documents.filter((d) => d.who !== "Grandma");
  return r;
})(), ["Alex Passport", "Grandma Passport"]);
t("a document with no owner is always kept", (() => {
  state.me.travel_documents = state.me.travel_documents.concat([{ who: "", kind: "Visa", expires: "2030-01-01" }]);
  const r = filterDocs(TRIP(["alex"]));
  state.me.travel_documents = state.me.travel_documents.filter((d) => d.kind !== "Visa");
  return r;
})(), ["Alex Passport", " Visa"]);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
