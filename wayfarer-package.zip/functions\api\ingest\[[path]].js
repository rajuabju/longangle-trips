// Machine entry point for the scheduled email importer.
//
// A cron job has no browser session, so Cloudflare Access cannot authenticate
// it the way it does the dashboard. This path therefore sits behind an Access
// *bypass* and is guarded here instead, by a shared secret compared in constant
// time. That is a deliberate, narrow hole: it accepts one header, over TLS, and
// reaches exactly the same API the browser does — no wider surface, no second
// implementation to keep in step.
//
// If the secret is ever suspected, rotate it with:
//   npx wrangler pages secret put IMPORTER_KEY --project-name=wayfarer
// and the old value stops working immediately.
import { handleApi } from "../_core.js";

function safeEqual(a, b) {
  const x = new TextEncoder().encode(String(a));
  const y = new TextEncoder().encode(String(b));
  let diff = x.length ^ y.length;
  const n = Math.max(x.length, y.length);
  for (let i = 0; i < n; i++) diff |= (x[i] || 0) ^ (y[i] || 0);
  return diff === 0;
}

export async function onRequest(context) {
  const { request, env } = context;
  const expected = env.IMPORTER_KEY;
  const supplied = request.headers.get("X-Importer-Key");

  // Not configured means closed, never open.
  if (!expected || !supplied || !safeEqual(supplied, expected)) {
    // Indistinguishable from a path that does not exist, so this endpoint
    // cannot be discovered by probing.
    return new Response("Not found", { status: 404 });
  }
  return handleApi(context, "importer");
}
