import { AIRPORTS } from "./airports-data.js";

// Wayfarer — own API, replacing api.tripsy.app.
//
// It deliberately speaks the *same* dialect Tripsy did: identical paths,
// identical JSON shapes, identical pagination envelope. The dashboard is a
// large, working client; making the server match it means the cutover is one
// changed constant rather than a rewrite, and it can be flipped back instantly
// if something is wrong.
//
// Auth is Cloudflare Access. Access has already authenticated the caller before
// the request reaches this Function and passes a verified identity header, so
// there is no token to store, leak or rotate — a strict improvement on holding
// a Tripsy bearer token in localStorage. Requests that arrive without an Access
// identity are rejected outright rather than defaulting to open.

const KINDS = {
  transportations: { table: "transportations", singular: "transportation" },
  hostings:        { table: "hostings",        singular: "hosting" },
  activities:      { table: "activities",      singular: "activity" },
  expenses:        { table: "expenses",        singular: "expense" },
};
// Same reasoning as MACHINE_ADMINS: BY_SINGULAR["constructor"] on a literal is
// truthy, and the route handler would then destructure .table off a function and
// answer 500 where it should answer 404.
const BY_SINGULAR = Object.create(null);
for (const [plural, v] of Object.entries(KINDS)) BY_SINGULAR[v.singular] = { ...v, plural };

// Columns promoted out of `data` for indexing. Everything else rides in `data`.
const PROMOTED = {
  trips: ["name", "starts_at", "ends_at", "has_dates", "timezone", "description", "hidden",
          "cover_image_url", "cover_gradient", "internal_identifier", "number_of_days"],
  transportations: ["name", "transportation_type", "transport_number", "company", "departure_at",
                    "arrival_at", "departure_timezone", "arrival_timezone",
                    "provider_reservation_code", "sort_order", "internal_identifier"],
  hostings: ["name", "starts_at", "ends_at", "timezone", "address", "latitude", "longitude",
             "provider_reservation_code", "sort_order", "internal_identifier"],
  activities: ["name", "activity_type", "starts_at", "ends_at", "timezone", "address", "latitude",
               "longitude", "provider_reservation_code", "sort_order", "internal_identifier"],
  expenses: ["name", "amount", "currency", "date", "sort_order", "internal_identifier"],
  trip_ideas: ["place", "address", "latitude", "longitude", "target_from", "target_to",
               "season_from", "season_to", "sort_order"],
};
const BOOL_COLS = new Set(["has_dates", "hidden"]);

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: { "content-type": "application/json", "cache-control": "no-store" },
  });
const err = (msg, status = 400) => json({ detail: msg }, status);

const nowIso = () => new Date().toISOString();

// A calendar feed URL is a bearer credential: anyone holding it reads the whole
// itinerary, and it will sit in plain text in an Exchange config and on a phone.
// 32 hex characters from the platform CSPRNG — not Math.random, which is
// seeded per-isolate and would make tokens guessable from each other.
function randomToken() {
  const b = new Uint8Array(16);
  crypto.getRandomValues(b);
  return Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
}

// A stored row becomes the object the client expects: the full original record
// with the promoted columns layered on top, since those are what writes update.
function hydrate(row, table) {
  let base = {};
  try { base = JSON.parse(row.data || "{}"); } catch { base = {}; }
  const out = { ...base, id: row.id };
  for (const c of PROMOTED[table] || []) {
    if (row[c] !== undefined) out[c] = BOOL_COLS.has(c) ? !!row[c] : row[c];
  }
  if (row.trip_id !== undefined && row.trip_id !== null) out.trip = row.trip_id;
  out.created_at = row.created_at;
  out.updated_at = row.updated_at;
  return out;
}

// Keys the retired Tripsy backend hung on every trip and nothing in this app
// reads. `guests` alone is 48% of the list payload -- measured at 92,312 bytes
// of 194,116 across the real 181 trips -- a profile blob carrying S3 photo URLs
// and a ten-key permissions object for a single-household app.
//
// Deliberately short, because being wrong here fails silently. NOT dropped:
// `suggestions`, which renderSuggested reads to build "Ideas for free days";
// `documents`, whose name is shared with per-item blobs the itinerary does
// read; and `emails`, which appears on contact objects.
const TRIP_LIST_DROP = ["guests", "collaborators", "collaborators_count", "owner"];

// ?fields=id,name -- the client has been sending this on detectChangedTrips
// since it was written, and the server ignored it, so every changed trip came
// back whole. `id` is always included: the client keys everything by it, and
// omitting it is never what a caller means.
function project(obj, fields) {
  if (!fields) return obj;
  const want = new Set(String(fields).split(",").map((x) => x.trim()).filter(Boolean));
  if (!want.size) return obj;
  want.add("id");
  const out = {};
  for (const k of Object.keys(obj)) if (want.has(k)) out[k] = obj[k];
  return out;
}

function page(results, url) {
  // Tripsy paginated at 100. The client's apiAll() follows `next` until null,
  // so anything consistent works; matching the envelope is what matters.
  //
  // 500, not 100, because 100 made the trip list two DEPENDENT round trips --
  // apiAll cannot ask for page 2 until page 1 has arrived -- and each request
  // re-ran the same full-table SELECT and re-hydrated all 184 rows before
  // slicing. The whole list is ~91KB now, so one response is the right shape
  // for every collection this app has; the envelope is kept in case one ever
  // is not.
  const per = 500;
  const p = Math.max(1, Number(new URL(url).searchParams.get("page") || 1));
  const slice = results.slice((p - 1) * per, p * per);
  const more = results.length > p * per;
  const u = new URL(url);
  u.searchParams.set("page", String(p + 1));
  return { count: results.length, next: more ? u.toString() : null, previous: null, results: slice };
}

async function nextId(db) {
  // D1 has no sequences. This was an UPDATE followed by a separate SELECT, and
  // the comment here claimed that was "a single statement". It was two round
  // trips with nothing between them, so two concurrent writers could both read
  // the post-increment value and be handed the same id. Collisions are
  // catastrophic: ids are the only link between the importer's ledger and these
  // records.
  //
  // RETURNING makes the write hand back what it wrote, so no one can read it in
  // between.
  const r = await db
    .prepare("UPDATE id_seq SET next = next + 1 WHERE name='global' RETURNING next")
    .first();
  if (!r || r.next == null) throw new Error("id_seq has no 'global' row — see schema.sql");
  return Number(r.next) - 1;
}

// Build the column list for an insert/update from an incoming body.
// Expenses are the one table whose records do not use the names its columns do.
// Every other table stores `name`; an expense record carries `title`, and its
// money is `price` rather than `amount` — Tripsy's shape, which the seeded data
// kept. The columns were declared `name` and `amount` anyway, so both sat NULL
// on every row: an indexed column that never held a value, and a schema that
// described something other than what was in it.
//
// Rather than rename the columns (which would break the client and the importer)
// or rename the fields (which would break the seeded history), accept both and
// let the alias fill the column. `title` and `price` remain in the `data` blob
// untouched, so nothing that reads them changes.
const COLUMN_ALIASES = { expenses: { name: "title", amount: "price" } };

function columnsFor(table, body) {
  const cols = {}, promoted = PROMOTED[table] || [];
  const alias = COLUMN_ALIASES[table] || {};
  for (const c of promoted) {
    let has = Object.prototype.hasOwnProperty.call(body, c);
    let v = has ? body[c] : undefined;
    // Only when the canonical name is absent or empty — an explicit `name` beats
    // an incidental `title`, so a caller that sends both gets what it asked for.
    if ((!has || v === null || v === "") && alias[c] !== undefined &&
        Object.prototype.hasOwnProperty.call(body, alias[c])) {
      v = body[alias[c]];
      has = true;
    }
    if (has) {
      if (BOOL_COLS.has(c)) v = v ? 1 : 0;
      if (v === undefined) v = null;
      cols[c] = v;
    }
  }
  return cols;
}

// Thrown when a write arrives with a body that is valid JSON but is not a
// record. Caught at the bottom of handleApi and answered with a 400.
class BadBody extends Error {}

async function readBody(request) {
  let v;
  // An empty or unparseable body still means "no fields", as it always has.
  try { v = await request.json(); } catch { return {}; }
  // request.json() will happily hand back a string, number, array or null when
  // the body is valid JSON that is not an object — most often a body that was
  // serialised twice by the client. Every caller below spreads or enumerates
  // this value into columns, and spreading a string scatters it one character
  // per key: on 2026-08-10 that wrote 98 columns named "0".."97" onto hosting
  // 1226736 and returned 200, so the client had no idea it had corrupted a row.
  // Refuse it here, once, rather than at sixteen call sites.
  if (v === null || typeof v !== "object" || Array.isArray(v)) {
    const got = v === null ? "null" : Array.isArray(v) ? "an array" : "a " + typeof v;
    throw new BadBody("Request body must be a JSON object, got " + got +
      ". A doubly-encoded body (JSON.stringify called twice) is the usual cause.");
  }
  return v;
}

// The whole API, with authentication deliberately left to the caller. Two entry
// points use it: /api/v1 (browser, authenticated by Cloudflare Access) and
// /api/ingest (the scheduled importer, authenticated by a shared secret because
// Access has no session to offer a cron job). Keeping one implementation means
// the importer and the dashboard cannot drift apart in what they accept.
// Dismissals belong to the household, not to one person. They are stored under
// this sentinel owner, which cannot collide with a Cloudflare Access identity
// because no email address begins with "@". Same trick as the '@legacy' row in
// cal_feeds.
const SHARED_OWNER = "@everyone";

// GET and HEAD change nothing, so View/Read may use them. OPTIONS is included
// because a browser preflight is not the request itself; blocking it would fail
// the write with a CORS error instead of the honest 403.
const SAFE_METHODS = { GET: 1, HEAD: 1, OPTIONS: 1 };

// The two machine identities are not people and are not in the users table. The
// importer authenticates with its own secret on a separate path and exists to
// write; local is the offline preview, which has no Access in front of it.
// Object.create(null), not a literal: MACHINE_ADMINS["constructor"] on a plain
// object is Object.prototype.constructor — truthy — and roleOf would answer
// "admin". No verified Access email can be the string "constructor", so this was
// not reachable, but a lookup table consulted for an authorisation decision
// should not have an inherited answer for anything.
const MACHINE_ADMINS = Object.assign(Object.create(null), { importer: 1, local: 1 });

async function roleOf(db, who) {
  if (MACHINE_ADMINS[who]) return "admin";
  const addr = String(who || "").toLowerCase();
  if (!addr) return "view";
  let row = null;
  try {
    row = await db.prepare("SELECT role FROM users WHERE email = ?").bind(addr).first();
  } catch (e) {
    // Table missing on a database that has not taken the migration yet. Read-only
    // is the safe answer; it degrades the app rather than opening it.
    return "view";
  }
  // Unlisted means View/Read. Access already decided this person may be here at
  // all, so the question is only what they may do, and the quiet answer is look.
  return row && row.role === "admin" ? "admin" : "view";
}

// Is there an admin other than this address? Guards the last-admin case on both
// demotion and deletion.
async function hasOtherAdmin(db, email) {
  const row = await db.prepare("SELECT COUNT(*) AS n FROM users WHERE role='admin' AND email <> ?")
    .bind(String(email || "").toLowerCase()).first();
  return (row && row.n) > 0;
}

// ---- reading a page the user pasted ---------------------------------------
//
// Used only by /v1/linkpeek. Split out here rather than left inline in the route
// because the guard is the part that matters, and a guard buried in the middle
// of a handler is the kind of thing that gets "simplified" away later.

// This endpoint is the only place in the app that fetches an address a person
// typed, which makes it the only place that can be aimed at the network behind
// Cloudflare. The cloud metadata address, the loopback and private ranges, and
// .internal/.local names are all reachable from a Worker and are not where a
// hotel page lives.
//
// Honest about what this does not cover: a public hostname whose DNS answer is
// a private address still gets through, because Workers cannot resolve a name
// and pin the result before fetching it. What contains that is the route being
// POST — so a View/Read account cannot reach it at all, and an Admin/Edit
// account is already Alex.
function isPublicHost(host) {
  const h = String(host || "").toLowerCase().replace(/^\[|\]$/g, "");
  if (!h) return false;
  if (h === "localhost" || h.endsWith(".localhost")) return false;
  if (/\.(local|internal|home|lan|localdomain)$/.test(h)) return false;
  // Refuse every IPv6 literal rather than trying to spell the loopback,
  // unique-local (fc00::/7) and link-local (fe80::/10) ranges correctly. No
  // hotel is published at a v6 literal, so nothing real is lost.
  if (h.includes(":")) return false;
  const m = h.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (m) {
    if (m.slice(1).some((n) => Number(n) > 255)) return false;
    const a = Number(m[1]), b = Number(m[2]);
    if (a === 0 || a === 10 || a === 127) return false;        // this host, private, loopback
    if (a === 169 && b === 254) return false;                  // link-local, incl. 169.254.169.254
    if (a === 172 && b >= 16 && b <= 31) return false;         // private
    if (a === 192 && b === 168) return false;                  // private
    if (a === 100 && b >= 64 && b <= 127) return false;        // carrier-grade NAT
    if (a >= 224) return false;                                // multicast and reserved
  }
  return true;
}

const PEEK_BYTES = 512 * 1024;
const PEEK_MS = 8000;

// Redirects are followed by hand, not by fetch, so that every hop is checked
// against isPublicHost. `redirect: "follow"` would validate the address the user
// typed and then quietly fetch wherever it pointed.
// ---- which airport serves a place ------------------------------------------
//
// Distinct from /v1/airports, and the distinction is the whole point.
// /v1/airports answers "where have I flown", built from this traveller's own
// history, and is right for distance and for "you have been here before". It is
// useless for a place he has never been: Blackberry Farm needs TYS, and TYS
// appears nowhere in fifteen years of flights. So this reads a real dataset.
const AIRPORT_MAX_KM = 400;   // past this, flying into it is not "serving" it

// Home, and the radius inside which a trip idea is a drive rather than a
// flight. Both MUST match HOME and DRIVE_MAX_KM in public/app.js -- airporttest
// reads them out of both files and asserts they agree, because a server that
// fills in an airport the client then hides is a record nobody can see or fix.
// CONFIGURE ME -- and it MUST match HOME in public/app.js, which is what
// airporttest checks. Note this one uses `lon`, the client uses `lng`.
const HOME = { lat: 34.0537, lon: -118.2427 };
const DRIVE_MAX_KM = 402;   // 250 miles

function haversineKm(aLat, aLon, bLat, bLon) {
  const R = 6371, rad = Math.PI / 180;
  const dLat = (bLat - aLat) * rad, dLon = (bLon - aLon) * rad;
  const s1 = Math.sin(dLat / 2), s2 = Math.sin(dLon / 2);
  const h = s1 * s1 + Math.cos(aLat * rad) * Math.cos(bLat * rad) * s2 * s2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
}

// Nearest is not automatically best. A regional field twenty minutes away with
// three flights a day is usually the right answer, but not when a major hub is
// barely further -- so a large airport wins if it is within 1.5x the distance
// of the nearest airport overall. Checked against the real cases: Solvang keeps
// SBA at 50km rather than being sent to LAX at 200km, Walland keeps TYS rather
// than Atlanta, and a place 20km from a regional and 25km from a hub gets the
// hub. Ties broken by distance, so the rule cannot be circular.
// How many of those to actually offer.
//
// The third slot is only shown when it ADDS something. Three cases, and the
// rule falls out of them:
//
//   * *      Two majors is a complete answer. Orly and Charles de Gaulle are
//            real alternatives to each other; a third is noise to read past.
//
//   * -      A major up front and a regional third. The third is a small field
//            you would not fly into when a major is nearer -- it adds nothing,
//            so it is not shown. Kona is this: KOA, then Waimea and Hilo.
//
//   - *      A regional up front and a major third. Now the third is the
//            airport you would actually price a fare into, and hiding it would
//            hide the useful option. Hilton Head is this: HHH, Savannah,
//            Charleston.
//
//   - -      Nothing near is major. Every option counts, so show all three.
//            Nantucket is this: ACK, Hyannis, New Bedford, none of them big.
//
// The pick itself is NOT made from this list -- bestAirport always sees three
// candidates, so the airport that gets stored does not change with how many
// are displayed.
function airportShortlist(near) {
  if (near.length <= 2) return near;
  const bothMajor = near[0].large && near[1].large;
  const neitherMajor = !near[0].large && !near[1].large;
  const thirdEarnsIt = !bothMajor && (near[2].large || neitherMajor);
  return thirdEarnsIt ? near : near.slice(0, 2);
}

function airportsNear(lat, lon, limit) {
  const near = [];
  for (let i = 0; i < AIRPORTS.length; i++) {
    const a = AIRPORTS[i];
    // Cheap rejection before the trigonometry. One degree of latitude is ~111km,
    // so anything outside this box cannot be inside the radius.
    if (Math.abs(a[1] - lat) > AIRPORT_MAX_KM / 111) continue;
    const km = haversineKm(lat, lon, a[1], a[2]);
    if (km > AIRPORT_MAX_KM) continue;
    near.push({ code: a[0], latitude: a[1], longitude: a[2], city: a[3], large: !!a[4], country: a[5], km: Math.round(km) });
  }
  near.sort((x, y) => x.km - y.km);
  return limit ? near.slice(0, limit) : near;
}

function bestAirport(near) {
  if (!near.length) return null;
  const closest = near[0];
  if (closest.large) return closest;
  const hub = near.find((a) => a.large && a.km <= closest.km * 1.5);
  return hub || closest;
}

// Fill in the airport an idea would be flown into, from its coordinates.
//
// Server-side and on the write, so it does not matter which client did it --
// the edit form, the bulk location lookup, or anything added later all get the
// same answer, and the code is stored on the record rather than recomputed on
// every paint.
//
// The one thing it must never do is overwrite a choice. airport_auto records
// which of the two this was:
//
//   a valid code in the body        -> the traveller chose it. Manual, kept.
//   an empty/null airport in the body -> the field was cleared. Re-fill it,
//                                        which is what an auto-filled field
//                                        does; that is how you undo an override.
//   no airport key in the body at all -> an unrelated edit (a note, the nights).
//                                        Leave a manual code alone; fill only if
//                                        there is nothing there.
async function withAutoAirport(db, id, body) {
  const supplied = Object.prototype.hasOwnProperty.call(body || {}, "airport");
  const code = String((body && body.airport) || "").trim().toUpperCase();
  if (supplied && /^[A-Z]{3}$/.test(code)) {
    return { ...body, airport: code, airport_auto: false };
  }

  let stored = null;
  if (id != null) {
    stored = await db.prepare(
      "SELECT latitude, longitude, data FROM trip_ideas WHERE id=?").bind(id).first();
  }
  let blob = {};
  try { blob = stored && stored.data ? JSON.parse(stored.data) : {}; } catch { blob = {}; }

  // An unrelated edit must not quietly relocate a chosen airport.
  if (!supplied && blob.airport && blob.airport_auto === false) return body;

  let lat = body && body.latitude, lon = body && body.longitude;
  if (lat == null) lat = stored && stored.latitude;
  if (lon == null) lon = stored && stored.longitude;
  lat = Number(lat); lon = Number(lon);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return body;

  // Somewhere you would drive to has no airport, and writing one anyway leaves
  // a value the form does not show -- invisible and uneditable.
  if (haversineKm(HOME.lat, HOME.lon, lat, lon) <= DRIVE_MAX_KM) {
    return { ...body, airport: null, airport_auto: null };
  }

  const best = bestAirport(airportsNear(lat, lon, 3));
  // No airport within range is a real answer -- somewhere genuinely remote --
  // and it must not leave a stale code from a previous location behind.
  if (!best) return { ...body, airport: null, airport_auto: null };
  return { ...body, airport: best.code, airport_auto: true };
}

// Airlines publish schedules roughly eleven months ahead. Past that, an empty
// result means "not loaded yet", not "you cannot get there".
const FLIGHT_HORIZON_DAYS = 330;
const FLIGHT_MS = 20000;

// The raw response carries carbon estimates, legroom, aircraft photos and a
// booking token per itinerary. None of that is planning information, and all of
// it would be stored in D1 forever. Keep the shape a person would sketch on
// paper: what it costs, how long it takes, and where you change planes.
function normalizeFlights(raw, from, to, date, back) {
  const mins = (v) => (Number.isFinite(Number(v)) ? Number(v) : null);
  const leg = (f) => ({
    from: (f.departure_airport && f.departure_airport.id) || null,
    from_name: (f.departure_airport && f.departure_airport.name) || null,
    depart: (f.departure_airport && f.departure_airport.time) || null,
    to: (f.arrival_airport && f.arrival_airport.id) || null,
    to_name: (f.arrival_airport && f.arrival_airport.name) || null,
    arrive: (f.arrival_airport && f.arrival_airport.time) || null,
    minutes: mins(f.duration),
    airline: f.airline || null,
    flight: f.flight_number || null,
  });
  const one = (it) => {
    const legs = Array.isArray(it.flights) ? it.flights.map(leg) : [];
    return {
      price: mins(it.price),
      minutes: mins(it.total_duration),
      // Stops are counted from the legs rather than read from a field: an
      // itinerary with three legs has two stops whatever anything else says.
      stops: Math.max(0, legs.length - 1),
      legs,
      layovers: (Array.isArray(it.layovers) ? it.layovers : []).map((L) => ({
        code: L.id || null, name: L.name || null,
        minutes: mins(L.duration), overnight: !!L.overnight,
      })),
    };
  };
  const best = Array.isArray(raw && raw.best_flights) ? raw.best_flights : [];
  const other = Array.isArray(raw && raw.other_flights) ? raw.other_flights : [];
  // Six is what fits on a phone without scrolling past the point of deciding.
  const results = best.concat(other).slice(0, 6).map(one)
    .filter((r) => r.legs.length);
  const ins = (raw && raw.price_insights) || null;
  return {
    from, to, date, return_date: back || null, round_trip: !!back, results,
    typical: ins && Array.isArray(ins.typical_price_range) && ins.typical_price_range.length === 2
      ? { low: ins.typical_price_range[0], high: ins.typical_price_range[1] } : null,
    lowest: ins && Number.isFinite(Number(ins.lowest_price)) ? Number(ins.lowest_price) : null,
  };
}

async function peekFetch(startUrl) {
  let u = startUrl;
  for (let hop = 0; hop < 4; hop++) {
    if (u.protocol !== "http:" && u.protocol !== "https:") {
      throw new Error("Only http and https addresses can be read.");
    }
    if (u.port && u.port !== "80" && u.port !== "443") {
      throw new Error("Only the standard web ports can be read.");
    }
    if (!isPublicHost(u.hostname)) throw new Error("That address is not on the public internet.");
    const res = await fetch(u.toString(), {
      redirect: "manual",
      signal: AbortSignal.timeout(PEEK_MS),
      headers: {
        // Identify honestly. This reads one page the owner asked for; it does
        // not crawl, and it should not pretend to be somebody's browser.
        "user-agent": "RiveraTrips/1.0 (+link preview; single page, no crawling)",
        "accept": "text/html,application/xhtml+xml",
        "accept-language": "en",
      },
    });
    if (res.status >= 300 && res.status < 400) {
      const loc = res.headers.get("location");
      if (!loc) throw new Error("That page redirected without saying where to.");
      u = new URL(loc, u);   // re-checked at the top of the next pass
      continue;
    }
    return { res, url: u };
  }
  throw new Error("That address redirects too many times.");
}

// Stop reading at the cap instead of trusting content-length, which a page is
// free to understate or omit. Everything worth having is in <head> anyway.
async function readCapped(res, max) {
  if (!res.body) return await res.text();
  const reader = res.body.getReader();
  const parts = [];
  let n = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done || !value) break;
    parts.push(value);
    n += value.byteLength;
    if (n >= max) break;
  }
  try { await reader.cancel(); } catch { /* already finished */ }
  const buf = new Uint8Array(n);
  let at = 0;
  for (const p of parts) { buf.set(p, at); at += p.byteLength; }
  // Assume UTF-8 and do not throw on a stray byte: a page cut mid-character at
  // the cap is normal, and a replacement character costs nothing here.
  return new TextDecoder("utf-8", { fatal: false }).decode(buf);
}

const ENTITIES = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " ", ndash: "–", mdash: "—", rsquo: "\u2019", lsquo: "\u2018", ldquo: "\u201c", rdquo: "\u201d", hellip: "…" };
function decodeEntities(s) {
  return String(s || "")
    .replace(/&#(\d+);/g, (m, d) => { try { return String.fromCodePoint(Number(d)); } catch { return m; } })
    .replace(/&#x([0-9a-f]+);/gi, (m, h) => { try { return String.fromCodePoint(parseInt(h, 16)); } catch { return m; } })
    .replace(/&([a-z]+);/gi, (m, w) => ENTITIES[w.toLowerCase()] || m);
}
const escapeRe = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

// Regex, not a parser, because there is no DOM here and a hotel's <head> is not
// adversarial input. Both attribute orders are tried: plenty of sites emit
// content= before property=.
function metaOf(html, attr, name) {
  const n = escapeRe(name);
  const pats = [
    new RegExp("<meta[^>]+" + attr + "\\s*=\\s*[\"']" + n + "[\"'][^>]*?content\\s*=\\s*[\"']([^\"']*)[\"']", "i"),
    new RegExp("<meta[^>]+content\\s*=\\s*[\"']([^\"']*)[\"'][^>]*?" + attr + "\\s*=\\s*[\"']" + n + "[\"']", "i"),
  ];
  for (const re of pats) {
    const m = html.match(re);
    if (m && m[1] && m[1].trim()) return decodeEntities(m[1].trim());
  }
  return "";
}

// schema.org blocks are the highest-signal source by a wide margin: a hotel that
// publishes one gives its own name and its own postal address, which is exactly
// the "hotel & location" title we are trying to build.
function jsonLdNodes(html) {
  const out = [];
  const re = /<script[^>]+type\s*=\s*["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
  let m;
  while ((m = re.exec(html)) && out.length < 60) {
    let v;
    try { v = JSON.parse(m[1].trim()); } catch { continue; }
    const push = (x, depth) => {
      if (!x || typeof x !== "object" || depth > 4 || out.length >= 60) return;
      if (Array.isArray(x)) { x.forEach((y) => push(y, depth + 1)); return; }
      out.push(x);
      if (x["@graph"]) push(x["@graph"], depth + 1);
    };
    push(v, 0);
  }
  return out;
}

const PLACE_TYPES = new Set([
  "hotel", "lodgingbusiness", "resort", "motel", "hostel", "inn", "bedandbreakfast",
  "campground", "apartment", "vacationrental", "suite", "house",
  "restaurant", "bar", "winery", "cafeorcoffeeshop",
  "touristattraction", "touristdestination", "museum", "landmarksorhistoricalbuildings",
  "nationalpark", "park", "beach", "skiresort", "localbusiness", "place", "civicstructure",
]);

// The FULL postal address, street included -- which is the opposite of what
// addrText() below wants.
//
// addrText builds a title: "Ravello, Campania, Italy", deliberately without the
// street, because that is what a person calls the place. This builds something
// a geocoder can find, which is a different job and needs the street most of
// all. OpenStreetMap has no record of "Blackberry Farm, Walland" and does have
// "1471 W Millers Cove Rd".
function postalAddress(a) {
  if (!a) return "";
  if (Array.isArray(a)) { for (const x of a) { const t = postalAddress(x); if (t) return t; } return ""; }
  if (typeof a === "string") return a.replace(/\s+/g, " ").trim();
  if (typeof a !== "object") return "";
  const one = (v) => {
    if (!v) return "";
    if (typeof v === "string") return v.trim();
    if (typeof v === "object") return String(v.name || v.alternateName || "").trim();
    return String(v).trim();
  };
  // Street, town, region, postcode, country -- the order a postal service and a
  // geocoder both expect. Empty slots drop out rather than leaving ", ,".
  const parts = [one(a.streetAddress), one(a.addressLocality), one(a.addressRegion),
    one(a.postalCode), one(a.addressCountry)].filter(Boolean);
  // Deduplicate: some sites put the town in both locality and region.
  const seen = new Set(), keep = [];
  for (const x of parts) {
    const k = x.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k); keep.push(x);
  }
  return keep.join(", ");
}

// Coordinates straight from the property's own page.
//
// This is the best source available to this app, better than any geocoder,
// because it is the place stating where it is rather than a third party
// guessing from a name. A hotel that publishes schema.org almost always
// publishes GeoCoordinates with it, and that single field is the difference
// between Blackberry Farm in Tennessee and Blackberry Farm in south London.
function geoOf(node) {
  let g = node && node.geo;
  if (Array.isArray(g)) g = g[0];
  if (!g || typeof g !== "object") return null;
  const lat = Number(g.latitude), lon = Number(g.longitude);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;
  // 0,0 is in the Gulf of Guinea and is what an empty template serialises to.
  if (Math.abs(lat) < 0.01 && Math.abs(lon) < 0.01) return null;
  if (Math.abs(lat) > 90 || Math.abs(lon) > 180) return null;
  return { latitude: lat, longitude: lon };
}

// An address may be a string, a PostalAddress, or an array of either, and
// addressCountry is as often an object as a two-letter code.
function addrText(a) {
  if (!a) return "";
  if (Array.isArray(a)) { for (const x of a) { const t = addrText(x); if (t) return t; } return ""; }
  if (typeof a === "string") return a.replace(/\s+/g, " ").trim();
  if (typeof a !== "object") return "";
  const one = (v) => {
    if (!v) return "";
    if (typeof v === "string") return v.trim();
    if (typeof v === "object") return String(v.name || v.alternateName || "").trim();
    return "";
  };
  // schema.org country slots are as often "IT" as "Italy", and "Ravello, IT" is
  // not what anyone calls the place. Expanded through the table the country
  // insights already use, so the two cannot disagree about what "CR" means.
  // Only the country slot: "NL" in addressRegion is Newfoundland, not the
  // Netherlands, and expanding it would be worse than leaving it alone.
  const country = (v) => {
    const s = one(v);
    if (!s) return "";
    for (const [re, name] of ADDRESS_COUNTRY) if (re.test(s.trim())) return name;
    return s;
  };
  // Locality first: "Ravello, Campania, Italy" is what somebody would say. The
  // street is deliberately left out — this is a title, not a delivery address.
  return [one(a.addressLocality), one(a.addressRegion), country(a.addressCountry)]
    .filter(Boolean)
    .filter((v, i, all) => all.indexOf(v) === i)
    .join(", ");
}

// Titles arrive as "Hotel Caruso, Ravello | Belmond" or "Belmond — Hotel Caruso".
// The site's own name is noise in a bucket-list entry, so strip it from either
// end. A separator is required, so a title that IS the site name survives whole
// rather than being trimmed to nothing.
function trimTail(title, tails) {
  let t = String(title || "");
  for (const tail of tails.filter(Boolean)) {
    const e = escapeRe(tail);
    const cut = t
      .replace(new RegExp("\\s*[|\\u2013\\u2014\\-\\u00b7:]\\s*" + e + "\\s*$", "i"), "")
      .replace(new RegExp("^\\s*" + e + "\\s*[|\\u2013\\u2014\\-\\u00b7:]\\s*", "i"), "");
    if (cut.trim()) t = cut;
  }
  return t.replace(/\s+/g, " ").trim();
}

// Plenty of sites never emit og:site_name, so the name to strip is also guessed
// from the address: en.wikipedia.org ends every title with "- Wikipedia", and
// nothing but the hostname says so. Labels of two characters or fewer are
// skipped — "en" is a language, not a brand — as are the trailing public-suffix
// pieces, which are never what a site calls itself.
const TLD_ISH = new Set([
  "com", "org", "net", "co", "io", "info", "biz", "me", "tv", "ai", "app", "dev",
  "site", "online", "store", "gov", "edu", "travel",
  "uk", "us", "ca", "au", "nz", "fr", "it", "de", "es", "jp", "ch", "at", "nl", "se", "no", "dk", "ie", "pt", "gr", "mx", "br", "za",
]);
function hostWords(hostname) {
  const labels = String(hostname || "").toLowerCase().split(".").filter(Boolean);
  return labels.filter((w, i) =>
    w !== "www" && w.length > 2 && !(i >= labels.length - 2 && TLD_ISH.has(w)));
}

// Two sentences at most. A bucket-list note is a reminder of why the place was
// worth saving, not the page's marketing copy in full.
function brief(s, max = 220) {
  const t = String(s || "").replace(/\s+/g, " ").trim();
  if (!t || t.length <= max) return t;
  const cut = t.slice(0, max + 1);
  const stop = Math.max(cut.lastIndexOf(". "), cut.lastIndexOf("! "), cut.lastIndexOf("? "));
  if (stop > max * 0.4) return cut.slice(0, stop + 1).trim();
  const sp = cut.lastIndexOf(" ");
  return (sp > 0 ? cut.slice(0, sp) : cut.slice(0, max)).trim() + "…";
}

function readPage(html, finalUrl) {
  const host = finalUrl.hostname.replace(/^www\./, "");
  const site = metaOf(html, "property", "og:site_name");
  const ogTitle = metaOf(html, "property", "og:title") || metaOf(html, "name", "twitter:title");
  const ogDesc = metaOf(html, "property", "og:description") || metaOf(html, "name", "twitter:description");
  const metaDesc = metaOf(html, "name", "description");
  const tm = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const pageTitle = tm ? decodeEntities(tm[1]).replace(/\s+/g, " ").trim() : "";

  let name = "", where = "", note = "", postal = "", geo = null;
  for (const node of jsonLdNodes(html)) {
    const types = [].concat(node["@type"] || []).map((t) => String(t).toLowerCase());
    if (!types.some((t) => PLACE_TYPES.has(t))) continue;
    if (!name && node.name) name = String(node.name).replace(/\s+/g, " ").trim();
    if (!where) where = addrText(node.address);
    if (!postal) postal = postalAddress(node.address);
    if (!geo) geo = geoOf(node);
    if (!note && node.description) note = String(node.description).trim();
    if (name && where && note && postal && geo) break;
  }

  // Fall back through the open-graph tags, then the plain <title>, dropping the
  // site's own name because "Belmond" is not what this place is called.
  const cleanTitle = trimTail(ogTitle || pageTitle, [site, host].concat(hostWords(finalUrl.hostname)));
  // A homepage whose <title> is "Home" tells you nothing, and naming an idea
  // "Home" is worse than naming it after the site: blackberryfarm.com really
  // does answer "Home", and "Blackberryfarm" at least says which place it is.
  const generic = /^(home|homepage|welcome|start|index|main|untitled|official site|home page)$/i;
  const usable = cleanTitle && !generic.test(cleanTitle.trim()) ? cleanTitle : "";
  if (!name) name = usable || site || host;

  // Only append the location when the name does not already carry it, or the
  // title reads "Hotel Caruso, Ravello, Ravello, Italy".
  const lower = name.toLowerCase();
  const tail = where
    .split(",").map((x) => x.trim()).filter(Boolean)
    .filter((part) => !lower.includes(part.toLowerCase()))
    .join(", ");
  const place = brief(tail ? name + ", " + tail : name, 120);

  return {
    url: finalUrl.toString(),
    host,
    site: site || "",
    place,
    name,
    location: where,
    // The two fields that make a link worth following rather than reading.
    // address is for a geocoder; latitude/longitude, when the page publishes
    // them, means no geocoder is needed at all.
    address: postal,
    latitude: geo ? geo.latitude : null,
    longitude: geo ? geo.longitude : null,
    // Which of the two the client got, so it can say so instead of implying the
    // pin was read off the page when it was inferred from an address.
    geo_source: geo ? "page" : (postal ? "address" : null),
    note: brief(note || ogDesc || metaDesc || ""),
    title: pageTitle,
    // True when the page gave us a name and nothing else — no town, no
    // description — so the client can say "this is mostly its title, check it"
    // rather than presenting a guess as though it were read off the page.
    thin: !where && !note && !ogDesc && !metaDesc,
  };
}

export async function handleApi(context, who) {
  const { request, env, params } = context;
  const db = env.DB;
  if (!db) return err("Database binding missing.", 500);

  const url = new URL(request.url);
  let segs = (Array.isArray(params.path) ? params.path : [params.path || ""]).filter(Boolean);
  // The client's own paths carry the API version ("/v1/trips", "/v2/trip/…/documents")
  // and are appended to a base that already ends in /v1, so requests arrive as
  // "v1/trips". Drop a leading version segment: it makes both /v1 and /v2 client
  // paths land on the same handlers, which is what Tripsy did anyway.
  if (segs.length && /^v[12]$/.test(segs[0])) segs = segs.slice(1);
  const method = request.method.toUpperCase();

  // ---- Admin/Edit vs View/Read -------------------------------------------
  //
  // Enforced here, once, rather than per endpoint. Every route in this file
  // passes through this line, so an endpoint added later is read-only to
  // viewers by default instead of open until somebody remembers to guard it.
  // That is the entire reason it lives at the top of the dispatcher.
  const role = await roleOf(db, who);
  if (!SAFE_METHODS[method] && role !== "admin") {
    return err("Your account has View/Read access, so it cannot change anything.", 403);
  }

  try {
    // ---- /v1/users ----
    // Who may edit. Admin/Edit only — including the GET, which is not sensitive
    // in itself but has no business being visible to someone who cannot act on
    // it. The writes below are already blocked by the gate above; this is what
    // stops a viewer reading the list.
    if (segs[0] === "users") {
      if (role !== "admin") return err("Admin/Edit access is required.", 403);
      const email = decodeURIComponent(segs[1] || "").toLowerCase();

      if (method === "GET") {
        const rows = await db.prepare("SELECT email,role,name,added_at,added_by FROM users ORDER BY role, email").all();
        return json({ results: rows.results || [], you: String(who || "").toLowerCase() });
      }
      if (method === "POST" || method === "PUT" || method === "PATCH") {
        const body = await readBody(request);
        const addr = String(body.email || email || "").trim().toLowerCase();
        // Not a validator so much as a guard against storing something that can
        // never match an Access identity and would sit in the list forever.
        if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(addr)) return err("A valid email address is required.", 400);
        const want = body.role === "admin" ? "admin" : "view";
        if (want !== "admin" && !(await hasOtherAdmin(db, addr))) {
          return err("This is the only Admin/Edit account. Promote someone else first.", 409);
        }
        await db.prepare(
          "INSERT INTO users (email,role,name,added_at,added_by) VALUES (?,?,?,datetime('now'),?) " +
          "ON CONFLICT(email) DO UPDATE SET role=excluded.role, name=COALESCE(excluded.name,users.name)"
        ).bind(addr, want, body.name ? String(body.name).trim() : null, String(who || "")).run();
        return json({ email: addr, role: want });
      }
      if (method === "DELETE") {
        if (!email) return err("Which account?", 400);
        if (!(await hasOtherAdmin(db, email))) {
          return err("This is the only Admin/Edit account. Promote someone else first.", 409);
        }
        await db.prepare("DELETE FROM users WHERE email = ?").bind(email).run();
        // Access still admits them; they are simply View/Read again. Removing
        // their login is a change to the Access policy, not to this table.
        return json({ ok: true, email: email });
      }
    }

    // ---- /v1/me ----
    if (segs[0] === "me") {
      if (method === "GET") {
        const rows = await db.prepare("SELECT key,value FROM settings").all();
        const s = {};
        for (const r of rows.results || []) { try { s[r.key] = JSON.parse(r.value); } catch { s[r.key] = r.value; } }
        // `role` goes after the spread deliberately: settings are user-writable,
        // and a key named "role" in there must not be able to promote anyone.
        // maps_key goes AFTER the spread and after role, for the same reason
        // role does: settings are user-writable, and a key named "maps_key" in
        // there must not be able to redirect the map to somebody else's account.
        //
        // It is public by design. A Maps JavaScript key has to reach the
        // browser, so it is protected by HTTP-referrer restrictions rather than
        // by secrecy -- unlike SERPAPI_KEY, which never leaves the Worker.
        //
        // Deliberately a DIFFERENT key from MAPS_SERVER_KEY, which the Routes
        // call uses. A referrer-restricted key is rejected for a Worker fetch,
        // which sends no referrer, and a key loose enough to work from a Worker
        // is too loose to publish in a web page. One key cannot be both.
        return json({ id: 1, email: who || "local", name: s.name || "Wayfarer", ...s,
          role: role, maps_key: env.MAPS_BROWSER_KEY || null });
      }
      if (method === "PATCH") {
        let body = await readBody(request);
        // Same compare-and-set as patchRow, over the settings table. The
        // household roster, the travel documents and the bucket list all live
        // here as whole values, so all three can lose an entry to a second
        // device without it.
        if (body && body.if_match) {
          const keys = Object.keys(body.if_match);
          const rows = keys.length
            ? await db.prepare(`SELECT key,value FROM settings WHERE key IN (${keys.map(() => "?").join(",")})`).bind(...keys).all()
            : { results: [] };
          const cur = {};
          for (const r of rows.results || []) cur[r.key] = safeJson(r.value);
          const stale = staleFields(cur, body.if_match);
          if (stale) return conflict(stale);
          body = withoutIfMatch(body);
        }
        const stmts = Object.entries(body).map(([k, v]) =>
          db.prepare("INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value")
            .bind(k, JSON.stringify(v)));
        if (stmts.length) await db.batch(stmts);
        return json({ ok: true, ...body });
      }
    }

    // ---- /v1/covers — a reusable library of trip cover images ----
    // Las Vegas appears on 16 trips, Pinecrest on 10, Phoenix on 9. Every one of
    // them had a cover chosen by hand, and picking a photo of the same city for
    // the seventeenth time is the work this removes.
    //
    // The bytes live in the same private R2 bucket documents use, so a cover is
    // exactly as protected as the itinerary. The catalogue rides in `settings`
    // rather than a new table: it is a few dozen entries, and a migration for
    // that would cost more than it saves.
    if (segs[0] === "covers") {
      if (!env.DOCS) return err("Image storage is not configured on this deployment.", 503);
      const readLib = async () => {
        const row = await db.prepare("SELECT value FROM settings WHERE key='cover_library'").first();
        const v = row ? safeJson(row.value) : null;
        return Array.isArray(v) ? v : [];
      };
      const writeLib = (lib) => db.prepare(
        "INSERT INTO settings (key,value) VALUES ('cover_library',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value"
      ).bind(JSON.stringify(lib)).run();

      if (method === "GET") return json({ results: await readLib() });

      if (method === "POST") {
        let form;
        try { form = await request.formData(); }
        catch (e) {
          return err("Could not read the upload (content-type: " +
            (request.headers.get("content-type") || "none") + "): " + (e && e.message ? e.message : String(e)), 400);
        }
        const file = form.get("file");
        if (!file || typeof file.arrayBuffer !== "function") return err("No image was attached.", 400);
        if (!file.size) return err("That image is empty.", 400);
        if (file.size > MAX_COVER_BYTES) {
          return err(`That image is ${(file.size / 1048576).toFixed(1)} MB. The limit is 5 MB.`, 413);
        }
        // Only image types a browser will actually paint. These bytes are served
        // back from this origin, so accepting anything else would mean hosting
        // arbitrary content under the app's own domain.
        const type = String(file.type || "").toLowerCase();
        if (!/^image\/(jpeg|png|webp|gif|avif)$/.test(type)) {
          return err("Covers must be JPEG, PNG, WebP, GIF or AVIF. That file is " + (type || "of unknown type") + ".", 415);
        }
        const id = await nextId(db);
        const key = `covers/${id}`;
        await env.DOCS.put(key, await file.arrayBuffer(), { httpMetadata: { contentType: type } });
        const entry = {
          id,
          // The label is what makes it findable again, so it is the field that
          // matters; the trip name is a sensible default and the client sends it.
          label: String(form.get("label") || "Untitled").replace(/[\r\n]+/g, " ").trim().slice(0, 80),
          r2_key: key, content_type: type, size: file.size,
          url: `/api/v1/cover/${id}`, added_at: nowIso(),
        };
        const lib = await readLib();
        lib.unshift(entry);
        try { await writeLib(lib); }
        catch (e) { try { await env.DOCS.delete(key); } catch { /* never orphan bytes */ } throw e; }
        return json(entry, 201);
      }

      if (segs[1] && (method === "DELETE" || method === "PATCH")) {
        const id = Number(segs[1]);
        if (!Number.isFinite(id)) return err("Bad cover id.", 400);
        const lib = await readLib();
        const i = lib.findIndex((x) => Number(x.id) === id);
        if (i < 0) return err("Cover not found.", 404);
        if (method === "PATCH") {
          const body = await readBody(request);
          if (body.label != null) lib[i].label = String(body.label).replace(/[\r\n]+/g, " ").trim().slice(0, 80);
          await writeLib(lib);
          return json(lib[i]);
        }
        const [gone] = lib.splice(i, 1);
        // Catalogue first: a leftover object costs a little storage, a dangling
        // entry breaks the picker.
        await writeLib(lib);
        try { if (gone.r2_key) await env.DOCS.delete(gone.r2_key); } catch { /* ignore */ }
        return new Response(null, { status: 204 });
      }
      return err("Method not allowed.", 405);
    }

    // ---- /v1/cover/{id} — stream one library image ----
    // Separate from /v1/doc: this one is painted by the browser as an image and
    // wants a long cache. Ids are never reused, so the bytes behind one are
    // immutable and can be cached hard.
    if (segs[0] === "cover" && segs[1]) {
      const id = Number(segs[1]);
      if (!Number.isFinite(id)) return err("Bad cover id.", 400);
      if (!env.DOCS) return err("Image storage is not configured.", 503);
      const row = await db.prepare("SELECT value FROM settings WHERE key='cover_library'").first();
      const lib = row ? safeJson(row.value) : null;
      const meta = (Array.isArray(lib) ? lib : []).find((x) => Number(x.id) === id);
      if (!meta) return err("Cover not found.", 404);
      const obj = await env.DOCS.get(meta.r2_key);
      if (!obj) return err("The stored image is missing.", 404);
      return new Response(obj.body, {
        headers: {
          "content-type": meta.content_type || "image/jpeg",
          "cache-control": "private, max-age=31536000, immutable",
          "x-content-type-options": "nosniff",
          "content-security-policy": "default-src 'none'; sandbox",
        },
      });
    }

    // ---- /v1/insights ----
    // Everything the stats view and the map need, in one request.
    //
    // The client cannot assemble this itself: it would take three calls per trip
    // — 543 requests — to see fifteen years at once. Four queries here, folded
    // in memory, is the same shape of fix the calendar feed needed.
    //
    // Distances, airport codes and aircraft live in the `data` blob rather than
    // promoted columns, so they cannot be SUMmed in SQL and are folded in JS.
    // At ~1,100 rows that is comfortably inside a Worker's budget.
    // ---- /v1/inbox — forwarded confirmations waiting to be imported ----
    // Written by the inbox Worker, drained by the importer. The app reads it so
    // you can see that something you forwarded actually arrived, which is the
    // whole reassurance the feature is for.
    if (segs[0] === "inbox") {
      if (method === "GET" && !segs[1]) {
        const want = url.searchParams.get("status") || "pending";
        const rows = want === "all"
          ? await db.prepare("SELECT * FROM inbox ORDER BY received_at DESC LIMIT 200").all()
          : await db.prepare("SELECT * FROM inbox WHERE status = ? ORDER BY received_at DESC LIMIT 200").bind(want).all();
        return json({ results: (rows.results || []).map((r) => ({ ...r, raw_url: `/api/v1/inbox/${r.id}/raw` })) });
      }
      if (segs[1] && segs[2] === "raw" && method === "GET") {
        const id = Number(segs[1]);
        if (!Number.isFinite(id)) return err("Bad id.", 400);
        const row = await db.prepare("SELECT * FROM inbox WHERE id = ?").bind(id).first();
        if (!row) return err("Not found.", 404);
        if (!env.DOCS) return err("Storage is not configured.", 503);
        const obj = await env.DOCS.get(row.r2_key);
        if (!obj) return err("The stored message is missing.", 404);
        return new Response(obj.body, {
          headers: {
            // text/plain rather than message/rfc822: this is read in a browser
            // by a person checking what arrived, not handed to a mail client.
            "content-type": "text/plain; charset=utf-8",
            "cache-control": "private, max-age=60",
            "x-content-type-options": "nosniff",
            "content-security-policy": "default-src 'none'; sandbox",
          },
        });
      }
      if (segs[1] && (method === "PATCH" || method === "DELETE")) {
        const id = Number(segs[1]);
        if (!Number.isFinite(id)) return err("Bad id.", 400);
        const row = await db.prepare("SELECT * FROM inbox WHERE id = ?").bind(id).first();
        if (!row) return err("Not found.", 404);
        if (method === "DELETE") {
          await db.prepare("DELETE FROM inbox WHERE id = ?").bind(id).run();
          try { if (env.DOCS && row.r2_key) await env.DOCS.delete(row.r2_key); } catch { /* ignore */ }
          return new Response(null, { status: 204 });
        }
        const body = await readBody(request);
        const status = ["pending", "imported", "ignored"].includes(body.status) ? body.status : row.status;
        await db.prepare("UPDATE inbox SET status=?, note=?, processed_at=? WHERE id=?")
          .bind(status, body.note == null ? row.note : String(body.note).slice(0, 2000),
                status === "pending" ? null : nowIso(), id).run();
        const after = await db.prepare("SELECT * FROM inbox WHERE id = ?").bind(id).first();
        return json(after);
      }
      return err("Method not allowed.", 405);
    }


    // ---- /v1/linkpeek — a pasted address, read back as a bucket-list entry ----
    // A wish nearly always starts as a page somebody sent you. Retyping the
    // hotel's name, working out which town it is in and writing a sentence about
    // it is the entire friction of keeping the list, so the page is asked to
    // describe itself instead. Nothing here is authoritative — everything it
    // returns is editable before it is saved, and often needs to be.
    //
    // POST rather than GET even though it stores nothing: that puts it behind
    // the Admin/Edit gate at the top of this function, so a View/Read account
    // cannot use the app as a general-purpose URL fetcher.
    // ---- /v1/ideas — the bucket list, grown into a pre-trip planner ----
    //
    // It lived in settings.bucket_list as one JSON array: right for a list of
    // names, wrong once an entry gained a place, a season and a target window.
    // A blob has nothing to index, is rewritten whole on every edit, and grows
    // with every field. This is a table with the same shape as trips, so
    // patchRow and the compare-and-set guard work on it unchanged.
    //
    // Not under /v1/trip/{id}/ like the other collections: an idea has no trip
    // yet. That is the entire point of it.
    // ---- credit-card spend thresholds ----
    if (segs[0] === "cards") {
      // Admin/Edit only, the GET included -- and for the same reason /v1/users
      // guards its read. Cloudflare Access decides who may be in the app at
      // all; a View/Read account belongs to somebody who was given the trips,
      // not somebody who was given a look at what is on Alex's cards.
      if (role !== "admin") return err("Admin/Edit access is required.", 403);
      if (method === "GET" && !segs[1]) return json(await cardsPayload(env, db, { force: false }));
      // An explicit refresh, for when you have just made a large charge and
      // want to see it rather than wait out the six-hour window.
      if (method === "POST" && segs[1] === "sync") return json(await cardsPayload(env, db, { force: true }));

      // Correcting the brand match on one stay. The body carries the decision
      // rather than a toggle, so two devices disagreeing settle on a value
      // instead of flipping each other.
      if (method === "POST" && segs[1] === "stays") {
        const body = await readBody(request);
        const goalId = Number(body.goal_id), hostingId = Number(body.hosting_id);
        if (!goalId || !hostingId) return err("goal_id and hosting_id are required.", 400);
        const ts = nowIso();
        const id = await nextId(db);
        await db.prepare(
          "INSERT INTO card_stay_marks (id, goal_id, hosting_id, counts, created_at, updated_at)" +
          " VALUES (?,?,?,?,?,?)" +
          " ON CONFLICT(goal_id, hosting_id) DO UPDATE SET counts=excluded.counts, updated_at=excluded.updated_at"
        ).bind(id, goalId, hostingId, body.counts ? 1 : 0, ts, ts).run();
        // The whole payload back, because one stay changes the total and the
        // panel would otherwise have to recompute the arithmetic itself.
        return json(await cardsPayload(env, db, { force: false }));
      }

      // Re-reading the balance from the programme. This is the whole design:
      // the authoritative number comes from them, and the card only fills in
      // what has happened since.
      if (method === "POST" && segs[1] === "anchor") {
        const body = await readBody(request);
        const goalId = Number(body.goal_id);
        const units = Number(body.units);
        if (!goalId || !isFinite(units) || units < 0) return err("goal_id and a units figure are required.", 400);
        // The goal must exist. An UPDATE against a wrong id "succeeds" with
        // zero rows changed, and the caller walks away believing the balance
        // was recorded.
        const goal = await db.prepare("SELECT id FROM card_goals WHERE id=? AND deleted_at IS NULL").bind(goalId).first();
        if (!goal) return err("No such goal.", 404);
        // Defaults to today, which is what reading a balance means.
        const asOf = String(body.as_of || nowIso()).slice(0, 10);
        // Shape is not enough: "2026-13-05" passes the regex, and a month typo
        // stored here freezes accrual -- every real transaction date compares
        // below the impossible one. Round-trip through a real calendar.
        if (!/^\d{4}-\d{2}-\d{2}$/.test(asOf)) return err("as_of must be a date.", 400);
        const rt = new Date(asOf + "T00:00:00Z");
        if (isNaN(rt.getTime()) || rt.toISOString().slice(0, 10) !== asOf) return err("as_of is not a real date.", 400);
        // A balance cannot have been read on a day that has not happened.
        if (asOf > nowIso().slice(0, 10)) return err("as_of cannot be in the future.", 400);
        await db.prepare("UPDATE card_goals SET baseline_units=?, baseline_at=?, updated_at=? WHERE id=?")
          .bind(units, asOf, nowIso(), goalId).run();
        return json(await cardsPayload(env, db, { force: false }));
      }

      // Rename a card. Chase reports its card as "CREDIT CARD", the sync
      // overwrites `name` from the bank on every run, and until this route the
      // nickname column that survives that overwrite could only be set by
      // hand-run SQL. Blank clears it: the read is COALESCE-shaped, so NULL
      // falls back to whatever the bank calls it.
      if (method === "POST" && segs[1] === "nickname") {
        const body = await readBody(request);
        const acctId = String(body.plaid_account_id || "");
        if (!acctId) return err("plaid_account_id is required.", 400);
        const nick = String(body.nickname || "").trim().slice(0, 60) || null;
        const r = await db.prepare("UPDATE card_accounts SET nickname=?, updated_at=? WHERE plaid_account_id=? AND deleted_at IS NULL")
          .bind(nick, nowIso(), acctId).run();
        if (!r.meta || !r.meta.changes) return err("No such account.", 404);
        return json(await cardsPayload(env, db, { force: false }));
      }

      return err("Unknown endpoint.", 404);
    }

    if (segs[0] === "ideas" && !segs[1]) {
      if (method === "GET") {
        const rows = await db.prepare(
          `SELECT * FROM trip_ideas WHERE deleted_at IS NULL
            ORDER BY sort_order, target_from IS NULL, target_from, place`
        ).all();
        return json({ results: (rows.results || []).map((r) => hydrate(r, "trip_ideas")) });
      }
      if (method === "POST") {
        let body = await readBody(request);
        const place = String((body && body.place) || "").trim();
        if (!place) return err("An idea needs a place.", 400);
        const id = await nextId(db);
        body = await withAutoAirport(db, null, body);
        // created_at is accepted from the caller so the migration can keep each
        // entry's original `added` date. Nothing else sets it.
        const ts = nowIso();
        const created = typeof body.created_at === "string" && body.created_at ? body.created_at : ts;
        const stored = { ...body, id, place, created_at: created, updated_at: ts };
        delete stored.if_match;
        const cols = columnsFor("trip_ideas", { ...body, place });
        const names = Object.keys(cols);
        await db.prepare(
          `INSERT INTO trip_ideas (id, ${names.concat(["data", "created_at", "updated_at"]).join(",")})
           VALUES (${new Array(names.length + 4).fill("?").join(",")})`
        ).bind(id, ...Object.values(cols), JSON.stringify(stored), created, ts).run();
        const after = await db.prepare("SELECT * FROM trip_ideas WHERE id=?").bind(id).first();
        return json(hydrate(after, "trip_ideas"));
      }
      return err("Method not allowed.", 405);
    }
    if (segs[0] === "ideas" && segs[1]) {
      const ideaId = Number(segs[1]);
      if (!Number.isFinite(ideaId)) return err("Not found.", 404);
      if (method === "PATCH" || method === "PUT") {
        return patchRow(db, "trip_ideas", ideaId,
          await withAutoAirport(db, ideaId, await readBody(request)));
      }
      if (method === "DELETE") {
        // Soft, like everything else here: an idea removed by mistake is
        // recoverable, and the row is tiny.
        const r = await db.prepare(
          "UPDATE trip_ideas SET deleted_at=?, updated_at=? WHERE id=? AND deleted_at IS NULL"
        ).bind(nowIso(), nowIso(), ideaId).run();
        if (!r.meta || !r.meta.changes) return err("Not found.", 404);
        return json({ ok: true });
      }
      return err("Method not allowed.", 405);
    }

    // ---- /v1/airports — where you actually fly from, from your own history ----
    //
    // No airport dataset is shipped or fetched. Every airport here is one this
    // traveller has genuinely used, with the coordinates already stored on the
    // flight: 50 airports across 275 legs, LAX 120 times. That is enough to
    // answer "how far is this idea, and have I been near it before" without a
    // third-party API, a key, or a licence.
    //
    // Coordinates are averaged because the same airport arrives with slightly
    // different coordinates from different confirmations; the spread is metres.
    if (segs[0] === "airports" && method === "GET") {
      const rows = await db.prepare(
        `SELECT code, AVG(lat) AS lat, AVG(lon) AS lon, SUM(n) AS legs FROM (
           SELECT json_extract(data,'$.departure_description') AS code,
                  CAST(json_extract(data,'$.departure_latitude') AS REAL) AS lat,
                  CAST(json_extract(data,'$.departure_longitude') AS REAL) AS lon, 1 AS n
             FROM transportations
            WHERE deleted_at IS NULL AND json_extract(data,'$.transportation_type')='airplane'
              AND json_extract(data,'$.departure_description') IS NOT NULL
              AND json_extract(data,'$.departure_latitude') IS NOT NULL
           UNION ALL
           SELECT json_extract(data,'$.arrival_description'),
                  CAST(json_extract(data,'$.arrival_latitude') AS REAL),
                  CAST(json_extract(data,'$.arrival_longitude') AS REAL), 1
             FROM transportations
            WHERE deleted_at IS NULL AND json_extract(data,'$.transportation_type')='airplane'
              AND json_extract(data,'$.arrival_description') IS NOT NULL
              AND json_extract(data,'$.arrival_latitude') IS NOT NULL
         ) WHERE code <> '' GROUP BY code ORDER BY legs DESC`
      ).all();
      return json({ results: (rows.results || []).map((r) => ({
        code: r.code, latitude: r.lat, longitude: r.lon, legs: r.legs,
      })) });
    }

    // ---- /v1/flightsearch - how you would actually get there ----
    //
    // The rest of this file answers from data we own. This one asks somebody
    // else, and that changes the rules in two ways.
    //
    // IT COSTS MONEY. The allowance is 250 searches a MONTH, so every path that
    // can answer without spending one does: an out-of-range date is rejected
    // before the fetch, a cached route is served from D1, and nothing is ever
    // fetched on a list paint - only when the button is pressed. A feature that
    // silently drains its own budget stops working in week two.
    //
    // IT IS NOT AUTHORITATIVE. These are indicative schedules and prices for a
    // sampled date, not a quote and not a booking. They are never written to a
    // trip, an expense or an itinerary item; they are shown, and the traveller
    // decides. That keeps the promise the rest of the app makes - a guess is
    // never written to the database.
    if (segs[0] === "flightsearch" && method === "GET") {
      // GET is a safe method, so the gate at the top of this function lets a
      // View account through. Spending a metered allowance is not a read, so it
      // is gated here by hand.
      if (role !== "admin") return err("Admin/Edit access is required.", 403);

      // ?probe=1 -- what SHAPE is the stored key, without revealing it.
      //
      // "Invalid API key" is the same message for a truncated paste, a quoted
      // paste, and a genuinely wrong key, and a secret cannot be read back from
      // Cloudflare. These four facts separate those cases and none of them can
      // be reversed into the value. Costs no search: it never calls upstream.
      if (url.searchParams.get("probe") === "1") {
        const k = String(env.SERPAPI_KEY || "");
        return json({ reason: "probe", set: !!k, length: k.length,
          trimmed_length: k.trim().length,
          looks_like_serpapi_key: /^[0-9a-f]{64}$/.test(k.trim()),
          has_surrounding_whitespace: k !== k.trim(),
          has_quotes: /^["']|["']$/.test(k.trim()) });
      }

      const from = String(url.searchParams.get("from") || "").trim().toUpperCase();
      const to = String(url.searchParams.get("to") || "").trim().toUpperCase();
      const date = String(url.searchParams.get("date") || "").trim();
      if (!/^[A-Z]{3}$/.test(from) || !/^[A-Z]{3}$/.test(to)) {
        return err("Give a three-letter airport code for each end.", 400);
      }
      if (from === to) return err("Those are the same airport.", 400);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return err("The date must be YYYY-MM-DD.", 400);
      // Optional. With it this prices a ROUND TRIP, which is what going
      // somewhere actually costs -- a one-way fare is roughly half the answer
      // and on international routes not even that.
      const back = String(url.searchParams.get("return") || "").trim();
      if (back && !/^\d{4}-\d{2}-\d{2}$/.test(back)) {
        return err("The return date must be YYYY-MM-DD.", 400);
      }
      if (back && back <= date) return err("The return has to be after the outbound.", 400);

      // Airlines load schedules about eleven months out. Beyond that there is
      // nothing to find - not "no flights", but "no timetable yet" - and the
      // two read identically in an empty result. Saying so costs no credit and
      // is the honest answer.
      const days = Math.round((Date.parse(date + "T12:00:00Z") - Date.now()) / 86400000);
      if (!Number.isFinite(days)) return err("That is not a real date.", 400);
      if (days < 0) return json({ results: [], reason: "past", from, to, date });
      // The far end of the trip is the one that has to be published, so the
      // horizon is measured against the RETURN when there is one. A window that
      // starts inside the horizon and ends outside it has no round trip to
      // price, and pricing the outbound alone would answer a question nobody
      // asked.
      const lastDay = back || date;
      const spanDays = Math.round((Date.parse(lastDay + "T12:00:00Z") - Date.now()) / 86400000);
      if (spanDays > FLIGHT_HORIZON_DAYS) {
        return json({ results: [], reason: "too_far", from, to, date, return_date: back || null,
          horizon_days: FLIGHT_HORIZON_DAYS });
      }

      // The return date is part of what was asked, so it is part of the key.
      // Without it a round trip would be served the one-way answer it happened
      // to find first, at a price that is not for the journey requested.
      const key = from + ">" + to + ">" + date + ">" + (back || "-") + ">1>USD";
      const fresh = url.searchParams.get("refresh") === "1";
      if (!fresh) {
        const hit = await db.prepare(
          "SELECT payload, fetched_at FROM flight_cache WHERE cache_key=? AND expires_at > ?"
        ).bind(key, nowIso()).first();
        if (hit) {
          try {
            return json({ ...JSON.parse(hit.payload), cached: true, fetched_at: hit.fetched_at });
          } catch { /* a corrupt row is not worth failing over; fall through and refetch */ }
        }
      }

      // Trimmed. A key pasted into the dashboard textarea keeps its trailing
      // newline, and the rejection that causes says "Invalid API key" -- which
      // reads as "you used the wrong key" and sends you to reissue a key that
      // was right all along.
      const apiKey = String(env.SERPAPI_KEY || "").trim();
      if (!apiKey) {
        return json({ results: [], reason: "unconfigured", from, to, date,
          message: "Flight search is not configured on this deployment." });
      }

      const q = new URL("https://serpapi.com/search.json");
      q.searchParams.set("engine", "google_flights");
      q.searchParams.set("departure_id", from);
      q.searchParams.set("arrival_id", to);
      q.searchParams.set("outbound_date", date);
      if (back) q.searchParams.set("return_date", back);
      // 1 is a round trip, 2 is one way. Google rejects a round trip with no
      // return_date, so the two always move together.
      q.searchParams.set("type", back ? "1" : "2");
      q.searchParams.set("currency", "USD");
      q.searchParams.set("hl", "en");
      q.searchParams.set("adults", "1");
      q.searchParams.set("api_key", apiKey);

      let raw;
      try {
        const res = await fetch(q.toString(), { signal: AbortSignal.timeout(FLIGHT_MS) });
        raw = await res.json().catch(() => null);
        if (!res.ok) {
          const why = (raw && (raw.error || raw.message)) || ("HTTP " + res.status);
          console.log("flightsearch upstream " + res.status + ": " + why);
          return json({ results: [], reason: "upstream", from, to, date, message: why });
        }
      } catch (e) {
        console.log("flightsearch fetch failed: " + (e && e.message));
        return json({ results: [], reason: "timeout", from, to, date,
          message: "SerpApi could not be reached: " + ((e && e.message) || "unknown") });
      }
      // A 200 can still carry an error - SerpApi reports a spent allowance and
      // an unrecognised route this way rather than with a status code.
      if (raw && raw.error) {
        console.log("flightsearch upstream error: " + raw.error);
        return json({ results: [], reason: "upstream", from, to, date, message: String(raw.error) });
      }

      let payload;
      try {
        payload = normalizeFlights(raw, from, to, date, back);
      } catch (e) {
        // The search is already paid for at this point. Saying what went wrong
        // beats a 500 that hides both the cause and the fact it cost something.
        console.log("flightsearch could not be read: " + (e && e.message));
        return json({ results: [], reason: "unreadable", from, to, date,
          message: "The answer came back in a shape this app could not read." });
      }
      // Prices move faster close in than they do nine months out, and a stale
      // price is worse than a slightly costlier refresh only when you are
      // nearly booking.
      const ttlDays = days <= 30 ? 2 : 7;
      const expires = new Date(Date.now() + ttlDays * 86400000).toISOString();
      try {
        await db.prepare(
          "INSERT INTO flight_cache (cache_key,origin,destination,depart_on,payload,fetched_at,expires_at) " +
          "VALUES (?,?,?,?,?,?,?) ON CONFLICT(cache_key) DO UPDATE SET " +
          "payload=excluded.payload, fetched_at=excluded.fetched_at, expires_at=excluded.expires_at"
        ).bind(key, from, to, date, JSON.stringify(payload), nowIso(), expires).run();
        // Nothing else ever visits this table, so this is the only chance to
        // sweep it. Expired rows are unreadable by definition -- the read above
        // filters on expires_at -- so without this they accumulate for the life
        // of the database, and a key format change (as happened when the return
        // date joined the key) strands them all at once.
        await db.prepare("DELETE FROM flight_cache WHERE expires_at <= ?").bind(nowIso()).run();
      } catch { /* the answer is already paid for; failing to cache must not lose it */ }
      return json({ ...payload, cached: false, fetched_at: nowIso() });
    }

    // ---- /v1/destinations — the search index, in one request ----
    //
    // The dashboard search matches on hotel names and addresses, which live on
    // the itinerary rather than the trip. The client used to build that index
    // by fetching every trip's hostings and activities separately: two requests
    // per trip, four at a time, up to 362 on a device with an empty cache --
    // fired immediately after first paint, competing with the cover images.
    //
    // Both tables promote `name` and `address` to real columns, so the whole
    // index is two queries and no blob parsing. Read-only and gate-free for the
    // same reason /v1/trips is: it exposes nothing the trip list does not.
    if (segs[0] === "destinations" && method === "GET") {
      const [h, a] = await Promise.all([
        db.prepare("SELECT trip_id, name, address FROM hostings WHERE deleted_at IS NULL").all(),
        db.prepare("SELECT trip_id, address FROM activities WHERE deleted_at IS NULL").all(),
      ]);
      const terms = {};
      const add = (id, v) => {
        if (id == null || !v) return;
        (terms[id] = terms[id] || new Set()).add(String(v).toLowerCase());
      };
      for (const r of h.results || []) { add(r.trip_id, r.name); add(r.trip_id, r.address); }
      for (const r of a.results || []) { add(r.trip_id, r.address); }
      const out = {};
      // Same shape the client stored per trip: terms joined by " | ", capped at
      // 4000 characters so one enormous itinerary cannot bloat the response.
      for (const k of Object.keys(terms)) out[k] = [...terms[k]].join(" | ").slice(0, 4000);
      return json({ results: out });
    }

    // ---- /v1/nearest-airport — which airport serves these coordinates ----
    //
    // Read-only, no key, no upstream: the dataset is in the bundle. Safe for a
    // View account, unlike /v1/flightsearch, because it spends nothing.
    if (segs[0] === "nearest-airport" && method === "GET") {
      const lat = Number(url.searchParams.get("lat"));
      const lon = Number(url.searchParams.get("lon"));
      if (!Number.isFinite(lat) || !Number.isFinite(lon) ||
          Math.abs(lat) > 90 || Math.abs(lon) > 180) {
        return err("Give a latitude and longitude.", 400);
      }
      // Three candidates are always considered, so `best` matches what
      // withAutoAirport would store; how many are SHOWN is a separate question
      // that airportShortlist answers.
      const near = airportsNear(lat, lon, 3);
      const best = bestAirport(near);
      const shown = airportShortlist(near);
      // Alternatives travel with it so the form can offer them. A single answer
      // with no visible alternatives is the shape that made the geocoder
      // dangerous — right often enough to be trusted, wrong often enough to hurt.
      return json({ best, results: shown, max_km: AIRPORT_MAX_KM });
    }

    if (segs[0] === "linkpeek" && method === "POST") {
      const body = await readBody(request);
      let target;
      const raw = String(body.url || "").trim();
      if (!raw) return err("Paste a web address first.", 400);
      try {
        // A pasted address usually arrives without its scheme. Assume https
        // rather than rejecting something that is plainly a URL.
        target = new URL(/^[a-z][a-z0-9+.-]*:\/\//i.test(raw) ? raw : "https://" + raw);
      } catch { return err("That does not look like a web address.", 400); }

      try {
        const { res, url: finalUrl } = await peekFetch(target);
        if (!res.ok) {
          // The big chains sit behind bot protection and answer 403 to anything
          // that is not a browser. Worth naming, because it is not a typo and
          // retrying will not help — the entry just has to be typed.
          const blocked = res.status === 403 || res.status === 401 || res.status === 429;
          return err(blocked
            ? "That site blocks automated reads (" + res.status + ")."
            : "That page answered " + res.status + ".", 502);
        }
        const ct = (res.headers.get("content-type") || "").toLowerCase();
        if (ct && !/text\/html|application\/xhtml|text\/plain/.test(ct)) {
          return err("That address is not a web page (" + ct.split(";")[0].trim() + ").", 415);
        }
        return json(readPage(await readCapped(res, PEEK_BYTES), finalUrl));
      } catch (e) {
        // Anything reachable from here is the far side's problem, not ours, so
        // 502 rather than 500 — and say which so the client can offer to save
        // the link anyway instead of just failing.
        const timedOut = e && (e.name === "TimeoutError" || e.name === "AbortError");
        return err(timedOut ? "That page took too long to answer." : ((e && e.message) || String(e)), 502);
      }
    }

    if (segs[0] === "insights") {
      const [tripRows, trRows, hoRows, acRows] = await Promise.all([
        db.prepare("SELECT id,name,starts_at,ends_at,has_dates FROM trips WHERE deleted_at IS NULL").all(),
        db.prepare("SELECT trip_id,transportation_type,company,departure_at,arrival_at,data FROM transportations WHERE deleted_at IS NULL").all(),
        db.prepare("SELECT trip_id,name,starts_at,ends_at,timezone,latitude,longitude,address FROM hostings WHERE deleted_at IS NULL").all(),
        db.prepare("SELECT trip_id,name,activity_type,latitude,longitude,address FROM activities WHERE deleted_at IS NULL").all(),
      ]);

      const trips = tripRows.results || [];
      const tripById = new Map(trips.map((t) => [t.id, t]));
      const yearOf = (t) => String(t.starts_at || "").slice(0, 4);
      const nightsOf = (t) => (t.starts_at && t.ends_at)
        ? Math.max(0, Math.round((Date.parse(t.ends_at) - Date.parse(t.starts_at)) / 86400000)) : 0;

      const byYear = new Map();
      const bump = (y, k, n) => {
        if (!y) return;
        if (!byYear.has(y)) byYear.set(y, { year: y, trips: 0, nights: 0, flights: 0, miles: 0 });
        byYear.get(y)[k] += n;
      };

      let nights = 0;
      const destinations = new Map();
      for (const t of trips) {
        const y = yearOf(t), n = nightsOf(t);
        nights += n; bump(y, "trips", 1); bump(y, "nights", n);
        const key = (t.name || "").trim();
        if (key) {
          if (!destinations.has(key)) destinations.set(key, { name: key, n: 0, last: null, trips: [] });
          const d = destinations.get(key);
          d.n++; d.trips.push(t.id);
          if (!d.last || String(t.starts_at) > d.last) d.last = t.starts_at;
        }
      }

      const airports = new Map(), airlines = new Map(), aircraft = new Map();
      const tally = (m, k) => { if (k) m.set(k, (m.get(k) || 0) + 1); };
      let flights = 0, meters = 0, tzLegs = 0;
      const places = [];

      for (const x of trRows.results || []) {
        let d = {};
        try { d = x.data ? JSON.parse(x.data) : {}; } catch { d = {}; }
        if (x.transportation_type !== "airplane") continue;
        flights++;
        const t = tripById.get(x.trip_id);
        const y = t ? yearOf(t) : String(x.departure_at || "").slice(0, 4);
        bump(y, "flights", 1);
        const m = Number(d.distance_meters) || 0;
        meters += m; bump(y, "miles", m / 1609.344);
        tally(airlines, x.company);
        tally(aircraft, d.vehicle_description);
        tally(airports, (d.departure_description || "").trim());
        tally(airports, (d.arrival_description || "").trim());
        if (d.departure_timezone && d.arrival_timezone && d.departure_timezone !== d.arrival_timezone) tzLegs++;
        // Where a flight put you is as much a "place visited" as the hotel.
        if (d.arrival_latitude != null && Math.abs(Number(d.arrival_latitude)) > 0.01) {
          places.push({ lat: +d.arrival_latitude, lon: +d.arrival_longitude, kind: "airport",
            name: (d.arrival_description || "Airport").trim(), trip_id: x.trip_id,
            trip: t ? t.name : null, year: y });
        }
      }

      const addPlace = (r, kind) => {
        if (r.latitude == null || Math.abs(Number(r.latitude)) < 0.01) return;
        const t = tripById.get(r.trip_id);
        places.push({ lat: +r.latitude, lon: +r.longitude, kind,
          name: r.name || kind, trip_id: r.trip_id, trip: t ? t.name : null, year: t ? yearOf(t) : null });
      };
      for (const r of hoRows.results || []) addPlace(r, "lodging");
      for (const r of acRows.results || []) addPlace(r, r.activity_type || "activity");

      // ---- hotels ----
      // Counted two ways because they answer different questions. Stays is how
      // often you walk through the door; nights is how much of your life you
      // spent there, and for status and points it is nights that count.
      //
      // Rolled up to the PARENT CHAIN, because loyalty lives at the chain: a
      // Park Hyatt night and an Andaz night are both World of Hyatt. Longest
      // match wins, so "Waldorf Astoria" resolves to Hilton rather than being
      // missed, and "Park Hyatt" is never mistaken for anything else.
      const CHAINS = {
        Hyatt: ["park hyatt", "grand hyatt", "hyatt place", "hyatt regency", "hyatt ziva", "hyatt centric", "hyatt house", "andaz", "thompson", "alila", "miraval", "hyatt"],
        Marriott: ["ritz-carlton", "ritz carlton", "st. regis", "st regis", "autograph", "jw marriott", "le meridien", "le méridien", "renaissance", "residence inn", "courtyard", "westin", "sheraton", "aloft", "moxy", "edition", "marriott"],
        Hilton: ["waldorf astoria", "conrad", "doubletree", "embassy suites", "hampton", "canopy", "lxr", "curio", "tapestry", "hilton"],
        IHG: ["intercontinental", "kimpton", "crowne plaza", "holiday inn", "six senses", "regent"],
        MGM: ["aria resort", "mgm grand", "bellagio", "vdara", "cosmopolitan of las vegas", "mandalay bay"],
        Choice: ["comfort inn", "comfort suites", "quality inn", "sleep inn"],
        Accor: ["fairmont", "sofitel", "raffles", "novotel", "pullman", "banyan tree"],
        "Four Seasons": ["four seasons"],
        "Grand Velas": ["grand velas"],
        Montage: ["montage"],
        Rosewood: ["rosewood"],
        "Mandarin Oriental": ["mandarin oriental"],
        Nayara: ["nayara"],
      };
      const chainOf = (name) => {
        const s = String(name || "").toLowerCase();
        let best = null, len = 0;
        for (const c of Object.keys(CHAINS))
          for (const k of CHAINS[c])
            if (s.includes(k) && k.length > len) { best = c; len = k.length; }
        return best;
      };
      // A STAY is a continuous period at one property, not a booking.
      //
      // Counting rows overstated both numbers badly. Four rooms for one family
      // over the same four nights read as four stays and sixteen nights. And a
      // continuous stay split across confirmations — cash for two nights, points
      // for the third — read as two visits.
      //
      // So merge each property's date ranges where they overlap OR touch, and
      // count the merged intervals. Touching matters: checking out and back in
      // on the same day is one stay, which is exactly how a cash-then-points
      // booking presents.
      //
      // The comparison MUST be in the property's own local time. Grand Wailea's
      // October 2021 bookings read 02→02 Oct and 03→07 Oct in UTC, which do not
      // touch; in Hawaii they are 01→02 and 02→07, which do. Merging on UTC
      // dates would have kept the very bug this is here to fix.
      const localDay = (iso, tz) => {
        const t = Date.parse(iso);
        if (!Number.isFinite(t)) return null;
        try {
          return new Intl.DateTimeFormat("en-CA", {
            timeZone: tz || "UTC", year: "numeric", month: "2-digit", day: "2-digit",
          }).format(new Date(t));
        } catch { return new Date(t).toISOString().slice(0, 10); }
      };
      const dayNum = (ymd) => Math.round(Date.parse(ymd + "T00:00:00Z") / 86400000);

      const byProp = new Map();
      for (const h of hoRows.results || []) {
        const nm = String(h.name || "").trim();
        if (!nm) continue;
        const key = nm.toLowerCase().replace(/\s+/g, " ");
        const g = byProp.get(key) || { name: nm, spans: [], undated: 0 };
        const a = localDay(h.starts_at, h.timezone), b = localDay(h.ends_at || h.starts_at, h.timezone);
        if (a) g.spans.push([dayNum(a), Math.max(dayNum(a), dayNum(b || a))]);
        else g.undated++;
        byProp.set(key, g);
      }

      const props = new Map(), chainAgg = new Map();
      let hotelStays = 0, hotelNights = 0, chainedStays = 0;
      for (const g of byProp.values()) {
        g.spans.sort((x, y) => x[0] - y[0]);
        let stays = 0, nights = 0, cur = null;
        for (const s of g.spans) {
          // <= not < : an interval starting the day the last one ended is the
          // same stay, not the next one.
          if (cur && s[0] <= cur[1]) cur[1] = Math.max(cur[1], s[1]);
          else { if (cur) { stays++; nights += cur[1] - cur[0]; } cur = [s[0], s[1]]; }
        }
        if (cur) { stays++; nights += cur[1] - cur[0]; }
        stays += g.undated;                     // a stay with no dates is still a stay
        if (!stays) continue;

        hotelStays += stays; hotelNights += nights;
        props.set(g.name, { name: g.name, stays, nights });
        const c = chainOf(g.name);
        if (c) {
          chainedStays += stays;
          const e = chainAgg.get(c) || { name: c, stays: 0, nights: 0 };
          e.stays += stays; e.nights += nights; chainAgg.set(c, e);
        }
      }
      const byStays = (m) => [...m.values()].sort((a, b) => b.stays - a.stays || b.nights - a.nights);

      const top = (m, n) => [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, n)
        .map(([name, count]) => ({ name, count }));

      const dated = trips.filter((t) => t.has_dates && t.starts_at && t.ends_at);
      const longest = dated.map((t) => ({ id: t.id, name: t.name, nights: nightsOf(t) }))
        .sort((a, b) => b.nights - a.nights)[0] || null;

      // ---- countries ----
      // From two signals that cannot be wrong, and nothing else.
      //
      // Bounding boxes were tried first and abandoned: measured against the 57
      // trips whose country is obvious from their name, 23 landed in more than
      // one country's box. San Diego sits inside any workable Mexico box and
      // Vancouver inside any workable US one, because the borders are curves and
      // a box is not. Guessing wrong about where somebody has been is worse than
      // admitting the data does not say.
      //
      // So: the IATA code on a flight endpoint, and a country named at the end
      // of a stored address. All 53 airport codes in this database resolve; the
      // trips that resolve to nothing are counted and shown rather than assumed
      // to be domestic.
      const countries = new Map();
      const noCountry = new Set();
      const seenTrip = new Set();
      const addCountry = (tripId, name) => {
        if (!name) return;
        if (!countries.has(name)) countries.set(name, new Set());
        countries.get(name).add(tripId);
      };
      const airportCountry = (v) => {
        const s = String(v || "").trim();
        const m = s.match(/\(([A-Z]{3})\)\s*$/) || s.match(/^([A-Z]{3})$/);
        return m ? AIRPORT_COUNTRY[m[1]] || null : null;
      };
      const addressCountry = (a) => {
        const tail = String(a || "").split(",").map((s) => s.trim()).filter(Boolean).pop() || "";
        for (const [re, name] of ADDRESS_COUNTRY) if (re.test(tail)) return name;
        return null;
      };
      for (const r of trRows.results || []) {
        seenTrip.add(r.trip_id);
        const d = safeJson(r.data) || {};
        if (r.transportation_type === "airplane") {
          addCountry(r.trip_id, airportCountry(d.departure_description));
          addCountry(r.trip_id, airportCountry(d.arrival_description));
        }
        addCountry(r.trip_id, addressCountry(d.departure_address));
        addCountry(r.trip_id, addressCountry(d.arrival_address));
      }
      for (const r of hoRows.results || []) { seenTrip.add(r.trip_id); addCountry(r.trip_id, addressCountry(r.address)); }
      for (const r of acRows.results || []) { seenTrip.add(r.trip_id); addCountry(r.trip_id, addressCountry(r.address)); }
      // Two rules from Alex, 2026-08-15, about his own travel. They are
      // knowledge the data does not carry rather than inference from it, which
      // is exactly the kind of thing worth hard-coding and dating.
      //
      // 1. Pinecrest is Mexico. The stored addresses put it in the US, because the
      //    drive down and the border town share a name and a postcode format —
      //    so this REPLACES what the addresses said rather than adding to it.
      // 2. A trip with no flight on it was driven, and every drive he takes is
      //    domestic. Applied only where nothing else resolved, so a flightless
      //    trip that named a country somewhere keeps it.
      const flew = new Set();
      for (const r of trRows.results || []) if (r.transportation_type === "airplane") flew.add(r.trip_id);
      for (const t of trips) {
        if (!/\bpinecrest\b/i.test(String(t.name || ""))) continue;
        for (const set of countries.values()) set.delete(t.id);
        addCountry(t.id, "Mexico");
      }
      const resolved = new Set();
      for (const set of countries.values()) for (const id of set) resolved.add(id);
      for (const id of seenTrip) if (!resolved.has(id) && !flew.has(id)) addCountry(id, "United States");

      const placed = new Set();
      for (const set of countries.values()) for (const id of set) placed.add(id);
      // What is left is a trip that flew somewhere the airport table does not
      // know, which is a gap worth showing rather than filling.
      for (const id of seenTrip) if (!placed.has(id)) noCountry.add(id);

      return json({
        countries: {
          list: [...countries.entries()].map(([name, set]) => ({ name, trips: set.size }))
            .sort((a, b) => b.trips - a.trips || a.name.localeCompare(b.name)),
          count: countries.size,
          unplaced_trips: noCountry.size,
        },
        totals: {
          trips: trips.length, nights, flights,
          miles: Math.round(meters / 1609.344),
          items: (trRows.results || []).length + (hoRows.results || []).length + (acRows.results || []).length,
          timezone_legs: tzLegs,
          places: places.length,
        },
        by_year: [...byYear.values()].sort((a, b) => a.year.localeCompare(b.year))
          .map((r) => ({ ...r, miles: Math.round(r.miles) })),
        airports: top(airports, 12),
        airlines: top(airlines, 10),
        aircraft: top(aircraft, 8),
        destinations: [...destinations.values()].filter((d) => d.n > 1).sort((a, b) => b.n - a.n).slice(0, 20),
        hotels: {
          stays: hotelStays, nights: hotelNights,
          // Everything that matched no chain: independents, casinos, rentals.
          independent_stays: hotelStays - chainedStays,
          chains: byStays(chainAgg).slice(0, 10),
          properties: byStays(props).slice(0, 12),
        },
        longest,
        places,
      });
    }

    // ---- /v1/doc/{id} — stream a stored file back ----
    // Objects are private in R2 and are never served from a public bucket URL.
    // Every read comes through here, which sits behind Cloudflare Access, so a
    // passport scan is exactly as protected as the itinerary it belongs to.
    if (segs[0] === "doc" && segs[1]) {
      const docId = Number(segs[1]);
      if (!Number.isFinite(docId)) return err("Bad document id.", 400);
      const row = await db.prepare("SELECT * FROM documents WHERE id=? AND deleted_at IS NULL").bind(docId).first();
      if (!row) return err("Document not found.", 404);
      const meta = safeJson(row.data);
      if (!meta.r2_key) return err("This document is a link, not a stored file.", 400);
      if (!env.DOCS) return err("Document storage is not configured.", 503);

      const obj = await env.DOCS.get(meta.r2_key);
      if (!obj) return err("The stored file is missing.", 404);
      // Filenames go in a quoted field, so a quote or a newline in one would
      // let a crafted name break out of the header.
      const safeName = String(meta.filename || row.title || "document")
        .replace(/[\r\n"\\]/g, "_").slice(0, 120);
      const type = meta.content_type || "application/octet-stream";
      // What a browser can be trusted to DISPLAY rather than run. Everything
      // else is sent as a download, which is the one disposition that cannot
      // execute anything in our origin whatever the file turns out to contain.
      //
      // SVG and HTML are deliberately absent: both are script-bearing document
      // formats that happen to look like a picture and a page. Neither is in
      // the upload picker's accept list, and a passport scan has never been
      // one. .doc, .docx and .eml are absent because no browser renders them
      // anyway — sending them as attachments states that instead of leaving it
      // to a fallback.
      const canShow = /^(application\/pdf|image\/(png|jpe?g|gif|webp|heic|heif|avif)|text\/plain)(;|$)/i.test(type);
      const dl = url.searchParams.get("download") === "1" || !canShow;
      return new Response(obj.body, {
        headers: {
          "content-type": type,
          "content-disposition": (dl ? "attachment" : "inline") + `; filename="${safeName}"`,
          "cache-control": "private, max-age=300",
          // The protection against a stored file running as active content in
          // our origin is now the TYPE, not the sandbox.
          //
          // Every file was previously served inline under `default-src 'none';
          // sandbox`. Downloading worked, because an attachment is never
          // rendered; opening a PDF did not, because that pair is precisely
          // what Chrome will not display a PDF under — `sandbox` denies the
          // viewer the same-origin access it needs, and `default-src 'none'`
          // blocks the embed it renders into. Both documents in the database
          // are PDFs, which is why "open" was broken for every one of them and
          // "download" for none.
          //
          // So the dangerous formats are refused a render outright rather than
          // sandboxed into one: canShow above admits only PDFs, raster images
          // and plain text, and anything else — HTML, SVG, whatever a crafted
          // upload declares itself to be — is sent as an attachment, which
          // cannot execute at all. That is a stronger guarantee than the
          // sandbox gave, because it never puts the file on a page to begin
          // with. nosniff keeps the browser from re-deciding the type.
          "content-security-policy": dl
            ? "default-src 'none'; sandbox"
            : "default-src 'none'; object-src 'self'; img-src 'self'; style-src 'unsafe-inline'",
          "x-content-type-options": "nosniff",
        },
      });
    }

    // ---- /v1/packing ----
    // A list either belongs to a trip or is a reusable template (trip_id NULL).
    // Both live in one table because they are the same shape, and templating is
    // just copying the rows across — a ski week packs nothing like Cabo, but you
    // pack the same ski week every January.
    //
    // Items are a JSON array of {text, who, done}. `who` matters here: five
    // people, three of them children, and the question is never "are the boots
    // packed" but "are JO's boots packed".
    if (segs[0] === "packing") {
      const id = segs[1] ? Number(segs[1]) : null;
      const out = (r) => ({ id: r.id, trip_id: r.trip_id, name: r.name,
        items: safeJsonArr(r.items), created_at: r.created_at, updated_at: r.updated_at });

      if (!id) {
        if (method === "GET") {
          const tripId = url.searchParams.get("trip_id");
          const rows = tripId
            ? await db.prepare("SELECT * FROM packing_lists WHERE deleted_at IS NULL AND trip_id=? ORDER BY id").bind(Number(tripId)).all()
            : await db.prepare("SELECT * FROM packing_lists WHERE deleted_at IS NULL AND trip_id IS NULL ORDER BY name").all();
          return json({ results: (rows.results || []).map(out) });
        }
        if (method === "POST") {
          const b = await readBody(request);
          let items = Array.isArray(b.items) ? b.items : [];
          // Starting from a template copies its items and clears every tick —
          // last January's packed boots say nothing about this January's.
          if (b.from_template) {
            const src = await db.prepare("SELECT * FROM packing_lists WHERE id=? AND deleted_at IS NULL").bind(Number(b.from_template)).first();
            if (src) items = safeJsonArr(src.items).map((i) => ({ ...i, done: false }));
          }
          const ts = nowIso();
          await db.prepare("INSERT INTO packing_lists (trip_id,name,items,created_at,updated_at) VALUES (?,?,?,?,?)")
            .bind(b.trip_id ? Number(b.trip_id) : null, String(b.name || "Packing").slice(0, 80), JSON.stringify(items), ts, ts).run();
          const row = await db.prepare("SELECT * FROM packing_lists ORDER BY id DESC LIMIT 1").first();
          return json(out(row));
        }
      } else {
        const row = await db.prepare("SELECT * FROM packing_lists WHERE id=? AND deleted_at IS NULL").bind(id).first();
        if (!row) return err("List not found.", 404);
        if (method === "GET") return json(out(row));
        if (method === "PATCH" || method === "PUT") {
          const b = await readBody(request);
          // A packing list is the one thing two people genuinely tick at the
          // same time, standing in the same room.
          const stale = staleFields({ items: safeJsonArr(row.items), name: row.name }, b && b.if_match);
          if (stale) return conflict(stale);
          const name = b.name != null ? String(b.name).slice(0, 80) : row.name;
          const items = Array.isArray(b.items) ? JSON.stringify(b.items) : row.items;
          await db.prepare("UPDATE packing_lists SET name=?, items=?, updated_at=? WHERE id=?")
            .bind(name, items, nowIso(), id).run();
          const after = await db.prepare("SELECT * FROM packing_lists WHERE id=?").bind(id).first();
          return json(out(after));
        }
        if (method === "POST" && segs[2] === "save-template") {
          const b = await readBody(request);
          const ts = nowIso();
          // A template records WHAT to pack, never what happened to be ticked.
          const items = safeJsonArr(row.items).map((i) => ({ text: i.text, who: i.who || "", done: false }));
          await db.prepare("INSERT INTO packing_lists (trip_id,name,items,created_at,updated_at) VALUES (NULL,?,?,?,?)")
            .bind(String(b.name || row.name).slice(0, 80), JSON.stringify(items), ts, ts).run();
          const made = await db.prepare("SELECT * FROM packing_lists ORDER BY id DESC LIMIT 1").first();
          return json(out(made));
        }
        if (method === "DELETE") {
          await db.prepare("UPDATE packing_lists SET deleted_at=? WHERE id=?").bind(nowIso(), id).run();
          return json({ ok: true, id });
        }
      }
      return err("Method not allowed.", 405);
    }

    // ---- /v1/knownname?q=&address= ----
    //
    // "What do we already call this place?" One question the importer needs and
    // could not previously ask: with no way to look up an existing name, each
    // confirmation email got whatever the sender happened to write, and the same
    // property accumulated aliases. ARIA Resort & Casino was also "Aria", and
    // Hyatt Regency Huntington Beach was split across "Resort and Spa" and
    // "Resort & Spa" — three splits found in one sweep, each quietly halving a
    // property's history everywhere it is counted.
    //
    // Matching is deliberately narrow, on two signals only:
    //
    //   name     the normalised name is identical, so this settles case and
    //            punctuation ("&" vs "and", ALL CAPS vs Title Case)
    //   address  house number plus the first word of the street. This is what
    //            caught the splits by hand, and it cannot conflate two
    //            properties the way name-similarity would — the same fuzziness
    //            that would merge Hyatt Regency Lisbon with Hyatt Regency Madrid.
    //
    // No fuzzy name matching, ever. A miss costs a duplicate name; a false match
    // silently files one hotel's stay under another.
    if (segs[0] === "knownname") {
      if (method !== "GET") return err("Method not allowed.", 405);
      const q = (url.searchParams.get("q") || "").trim();
      const addr = (url.searchParams.get("address") || "").trim();
      if (!q && !addr) return err("q or address is required.", 400);

      // "&" folds to "and" before the squash, or the two spellings this exists
      // to reconcile still miss each other: "Resort & Spa" would normalise to
      // "resort spa" while "Resort and Spa" keeps its "and".
      const norm = (s) => String(s || "").toLowerCase().replace(/&/g, " and ")
        .replace(/[^a-z0-9]+/g, " ").trim();
      const streetKey = (s) => {
        const m = String(s || "").match(/^\s*(\d+)\s+(?:south|north|east|west|s|n|e|w)?\s*([A-Za-z]+)/i);
        return m ? m[1] + " " + m[2].toLowerCase() : "";
      };
      const wantName = norm(q), wantStreet = streetKey(addr);

      const [ho, ac, tr] = await Promise.all([
        db.prepare("SELECT name,address FROM hostings WHERE deleted_at IS NULL AND name IS NOT NULL").all(),
        db.prepare("SELECT name,address FROM activities WHERE deleted_at IS NULL AND name IS NOT NULL").all(),
        db.prepare("SELECT name,company FROM transportations WHERE deleted_at IS NULL").all(),
      ]);
      // Count uses so the winner is the spelling already most common, not
      // whichever row happens to be read first.
      const tally = new Map();
      const add = (name, address) => {
        const n = String(name || "").trim();
        if (!n) return;
        const k = norm(n);
        if (!k) return;
        if (!tally.has(k)) tally.set(k, new Map());
        const byName = tally.get(k);
        byName.set(n, (byName.get(n) || 0) + 1);
        if (address) {
          const sk = streetKey(address);
          if (sk) {
            if (!byStreet.has(sk)) byStreet.set(sk, new Map());
            byStreet.get(sk).set(n, (byStreet.get(sk).get(n) || 0) + 1);
          }
        }
      };
      const byStreet = new Map();
      // Names pool across kinds: a carrier and a hotel cannot share an identical
      // normalised name without being the same business.
      //
      // Addresses do NOT pool. A street key is a BUILDING, and a building holds a
      // hotel, its restaurants and its spa. Feeding activities into the same street
      // map let a first-time restaurant inherit the hotel's name — which the
      // importer would then write verbatim, per the character-for-character rule in
      // its SKILL.md. Only lodging is address-indexed.
      for (const r of ho.results || []) add(r.name, r.address);
      for (const r of ac.results || []) add(r.name, null);
      for (const r of tr.results || []) { add(r.name, null); add(r.company, null); }

      const best = (m) => {
        if (!m || !m.size) return null;
        let name = null, n = 0;
        for (const [k, v] of m) if (v > n) { name = k; n = v; }
        return { name, times: n };
      };
      // Name first: an exact normalised hit is the stronger statement, because
      // the address may be written differently or be missing entirely.
      const byName = wantName ? best(tally.get(wantName)) : null;
      if (byName) return json({ match: byName.name, basis: "name", times: byName.times });
      const byAddr = wantStreet ? best(byStreet.get(wantStreet)) : null;
      if (byAddr) return json({ match: byAddr.name, basis: "address", times: byAddr.times });
      return json({ match: null, basis: null, times: 0 });
    }

    // ---- /v1/recall/{tripId} ----
    // What you did the last times you were here.
    //
    // Wanderlog and its like research places you have never been. That is the
    // wrong tool for this traveller: Las Vegas fifteen times, Pinecrest ten,
    // Phoenix nine. The most useful recommendation engine available is fifteen
    // years of his own history, and until now it was write-only.
    if (segs[0] === "recall" && segs[1]) {
      const tripId = Number(segs[1]);
      if (!Number.isFinite(tripId)) return err("Bad trip id.", 400);
      const me = await db.prepare("SELECT id,name,starts_at FROM trips WHERE id=? AND deleted_at IS NULL").bind(tripId).first();
      if (!me) return err("Trip not found.", 404);

      // Match on the trip name, normalised. Destination names in this data are
      // already the city ("Las Vegas", "Phoenix"), so this is both the simplest
      // and the most accurate signal available — better than guessing from
      // coordinates, which half the older items do not carry.
      // Same fold as /v1/knownname: without it "Resort & Spa" normalises to
      // "resort spa" while "Resort and Spa" keeps its "and", so the two split —
      // the exact defect knownname exists to prevent.
      const norm = (s) => String(s || "").toLowerCase().replace(/&/g, " and ")
        .replace(/[^a-z0-9]+/g, " ").trim();
      const key = norm(me.name);
      if (!key) return json({ trip: me, prior: [], lodging: [], activities: [] });

      const all = await db.prepare("SELECT id,name,starts_at,ends_at FROM trips WHERE deleted_at IS NULL AND id<>?").bind(tripId).all();
      const prior = (all.results || [])
        .filter((t) => norm(t.name) === key)
        .sort((a, b) => String(b.starts_at || "").localeCompare(String(a.starts_at || "")));
      if (!prior.length) return json({ trip: me, prior: [], lodging: [], activities: [] });

      const ids = prior.map((t) => t.id).join(",");
      const [ho, ac] = await Promise.all([
        db.prepare(`SELECT trip_id,name,address,provider_reservation_code FROM hostings WHERE deleted_at IS NULL AND trip_id IN (${ids})`).all(),
        db.prepare(`SELECT trip_id,name,activity_type,address FROM activities WHERE deleted_at IS NULL AND trip_id IN (${ids})`).all(),
      ]);
      const when = new Map(prior.map((t) => [t.id, t.starts_at]));

      // Fold repeats together: a hotel you have used four times is a stronger
      // signal than four separate rows saying the same thing.
      const roll = (rows, extra) => {
        const m = new Map();
        for (const r of rows) {
          const n = String(r.name || "").trim();
          if (!n) continue;
          const k = n.toLowerCase();
          if (!m.has(k)) m.set(k, { name: n, times: 0, last: null, address: r.address || null, ...extra(r) });
          const e = m.get(k);
          e.times++;
          const d = when.get(r.trip_id);
          if (d && (!e.last || d > e.last)) e.last = d;
          if (!e.address && r.address) e.address = r.address;
        }
        return [...m.values()].sort((a, b) => b.times - a.times || String(b.last).localeCompare(String(a.last)));
      };

      return json({
        trip: me,
        prior: prior.map((t) => ({ id: t.id, name: t.name, starts_at: t.starts_at, ends_at: t.ends_at })),
        lodging: roll(ho.results || [], () => ({})),
        activities: roll(ac.results || [], (r) => ({ activity_type: r.activity_type || "general" })),
      });
    }

    // ---- /v1/calfeeds ----
    // Calendar feeds and their settings. The feed itself is read-only .ics; this
    // is where what goes INTO it is edited.
    //
    // The token is returned here because the whole point is to copy the URL into
    // a calendar client — but this endpoint sits behind Cloudflare Access, so
    // only an authenticated family member ever sees one. The '@legacy' row is
    // the subscription that predates this table: its real token is the CAL_TOKEN
    // Pages secret, which is deliberately NOT stored here and never returned, so
    // that row reports its URL as unavailable rather than leaking a placeholder
    // someone would then try to subscribe to.
    if (segs[0] === "calfeeds") {
      // Admin/Edit only, including the GET. A feed token is a bearer credential
      // that works without Cloudflare Access — anyone holding the URL can read
      // the itinerary. Letting a View/Read account read the token would let them
      // hand out access they were never given, which is a wider grant than the
      // read access they hold themselves.
      if (role !== "admin") return err("Admin/Edit access is required.", 403);
      const id = segs[1] ? Number(segs[1]) : null;
      const feedOut = (r) => ({
        id: r.id,
        name: r.name,
        legacy: r.token === "@legacy",
        token: r.token === "@legacy" ? null : r.token,
        settings: safeJson(r.settings) || {},
        created_at: r.created_at,
        last_used_at: r.last_used_at,
      });

      if (!id) {
        if (method === "GET") {
          const rows = await db.prepare(
            "SELECT * FROM cal_feeds WHERE deleted_at IS NULL ORDER BY id"
          ).all();
          return json({ results: (rows.results || []).map(feedOut) });
        }
        if (method === "POST") {
          const body = await readBody(request);
          const token = randomToken();
          const settings = JSON.stringify(body.settings && typeof body.settings === "object" ? body.settings : {});
          const name = String(body.name || "Calendar feed").slice(0, 80);
          await db.prepare(
            "INSERT INTO cal_feeds (token,name,settings,created_at) VALUES (?,?,?,?)"
          ).bind(token, name, settings, new Date().toISOString()).run();
          const row = await db.prepare("SELECT * FROM cal_feeds WHERE token=?").bind(token).first();
          return json(feedOut(row));
        }
      } else {
        const row = await db.prepare("SELECT * FROM cal_feeds WHERE id=? AND deleted_at IS NULL").bind(id).first();
        if (!row) return err("Feed not found.", 404);

        if (method === "GET") return json(feedOut(row));

        if (method === "PATCH" || method === "PUT") {
          const body = await readBody(request);
          const name = body.name != null ? String(body.name).slice(0, 80) : row.name;
          // Merge rather than replace, so a client that knows about fewer
          // settings than the server does cannot silently drop the rest.
          const merged = { ...(safeJson(row.settings) || {}), ...(body.settings || {}) };
          await db.prepare("UPDATE cal_feeds SET name=?, settings=? WHERE id=?")
            .bind(name, JSON.stringify(merged), id).run();
          const after = await db.prepare("SELECT * FROM cal_feeds WHERE id=?").bind(id).first();
          return json(feedOut(after));
        }

        if (method === "POST" && segs[2] === "rotate") {
          if (row.token === "@legacy") {
            return err("This feed is authenticated by the CAL_TOKEN secret. Rotate it with `wrangler pages secret put CAL_TOKEN`, or create a new feed and re-subscribe.", 400);
          }
          const token = randomToken();
          await db.prepare("UPDATE cal_feeds SET token=? WHERE id=?").bind(token, id).run();
          const after = await db.prepare("SELECT * FROM cal_feeds WHERE id=?").bind(id).first();
          return json(feedOut(after));
        }

        if (method === "DELETE") {
          if (row.token === "@legacy") {
            return err("The original feed cannot be deleted here — it is the one already subscribed on your devices. Unset the CAL_TOKEN secret to retire it.", 400);
          }
          await db.prepare("UPDATE cal_feeds SET deleted_at=? WHERE id=?")
            .bind(new Date().toISOString(), id).run();
          return json({ ok: true, id });
        }
      }
      return err("Method not allowed.", 405);
    }

    // ---- /v1/checkstate ----
    // Snoozed and dismissed trip-check findings. This lived in localStorage,
    // which meant a dismissal on the desktop was invisible on the phone and the
    // same finding had to be waved away once per device.
    //
    // One row per finding rather than a single JSON blob per user: each hide and
    // unhide is then an independent upsert or delete, so two devices writing at
    // once cannot clobber each other's unrelated entries. A blob would need
    // read-modify-write and would lose whichever write landed first.
    //
    // Scoped to `owner`, the Access identity, so this syncs a person across
    // their devices without silently hiding a finding from the rest of the
    // family. The importer's own suppressions in processed.json stay separate:
    // those are permanent and deliberately global.
    if (segs[0] === "checkstate") {
      const owner = who || "local";
      if (method === "GET") {
        // The shared rows, plus any personal row predating the change to
        // household-wide hiding. Nothing writes personal rows now and every
        // write sweeps them, so this second scope only matters until the last
        // one is superseded — but dropping it early would un-hide whatever a
        // person had snoozed and never touched since.
        // Where a key has both, dismissed wins: it is the stronger and more
        // considered statement. Resolved here rather than left to the client's
        // iteration order, which would decide it by accident.
        const rows = await db.prepare(
          "SELECT key,mode,until,updated_at FROM check_state WHERE owner=? OR owner=? " +
          "ORDER BY CASE mode WHEN 'dismissed' THEN 0 ELSE 1 END"
        ).bind(owner, SHARED_OWNER).all();
        const seen = new Set(), out = [];
        for (const r of rows.results || []) {
          if (seen.has(r.key)) continue;
          seen.add(r.key); out.push(r);
        }
        return json({ results: out });
      }
      if (method === "PUT" || method === "POST") {
        const body = await readBody(request);
        const key = typeof body.key === "string" ? body.key.trim() : "";
        if (!key) return err("A finding key is required.", 400);
        // mode null/absent means "un-hide" — the client sends this when a
        // snooze is expired or the user restores a finding.
        //
        // Clears every scope. Hiding is household-wide, so restoring has to be
        // too — otherwise a finding waved away for everyone could come back for
        // one person off a leftover row. The `owner<>` sweep below means there
        // should not be leftover rows anyway; this is what makes that true even
        // for ones written before hiding was shared.
        if (!body.mode) {
          await db.prepare("DELETE FROM check_state WHERE key=?").bind(key).run();
          return json({ ok: true, key, mode: null });
        }
        if (body.mode !== "snoozed" && body.mode !== "dismissed") {
          return err("mode must be 'snoozed', 'dismissed', or null.", 400);
        }
        // Both modes are household-wide. Dismissals always were; snoozes used to
        // be personal on the reasoning that "not now" is only true for the
        // person who said it. In a two-person household looking at one shared
        // itinerary that turned out to be wrong in practice — waving a finding
        // away left it sitting there for the other person, who has no way to
        // tell it has already been dealt with, and the panel is only worth
        // reading if quiet means quiet for everybody.
        const scope = SHARED_OWNER;
        const until = body.mode === "snoozed" ? (body.until || null) : null;
        const stmts = [
          db.prepare(
            "INSERT INTO check_state (owner,key,mode,until,updated_at) VALUES (?,?,?,?,?) " +
            "ON CONFLICT(owner,key) DO UPDATE SET mode=excluded.mode, until=excluded.until, updated_at=excluded.updated_at"
          ).bind(scope, key, body.mode, until, new Date().toISOString()),
        ];
        // Sweep any personal row for this key. Nothing writes one any more, but
        // rows predating the change are still in the table, and a surviving
        // personal snooze would outlive a shared hide and resurface the finding
        // for that one person when it expired.
        stmts.push(db.prepare("DELETE FROM check_state WHERE key=? AND owner<>?").bind(key, SHARED_OWNER));
        await db.batch(stmts);
        return json({ ok: true, key, mode: body.mode, until, shared: scope === SHARED_OWNER });
      }
      return err("Method not allowed.", 405);
    }

    // ---- /v1/categories ----
    if (segs[0] === "categories") {
      const rows = await db.prepare("SELECT * FROM categories ORDER BY name").all();
      return json({ results: (rows.results || []).map((r) => ({ ...r, ...safeJson(r.data) })) });
    }

    // ---- /v1/trips  and  /v1/trips/{id} ----
    if (segs[0] === "trips") {
      if (!segs[1]) {
        if (method === "GET") {
          const since = url.searchParams.get("updatedSince") || url.searchParams.get("updated_since");
          const sql = since
            ? "SELECT * FROM trips WHERE deleted_at IS NULL AND updated_at > ? ORDER BY starts_at DESC"
            : "SELECT * FROM trips WHERE deleted_at IS NULL ORDER BY starts_at DESC";
          const st = since ? db.prepare(sql).bind(since) : db.prepare(sql);
          const rows = await st.all();
          const fields = url.searchParams.get("fields");
          const list = (rows.results || []).map((r) => {
            const t = hydrate(r, "trips");
            for (const k of TRIP_LIST_DROP) delete t[k];
            return project(t, fields);
          });
          return json(page(list, request.url));
        }
        if (method === "POST") {
          const body = await readBody(request);
          const id = await nextId(db);
          const ts = nowIso();
          const rec = { ...body, id, created_at: ts, updated_at: ts };
          const cols = columnsFor("trips", body);
          const names = ["id", ...Object.keys(cols), "data", "created_at", "updated_at"];
          const vals = [id, ...Object.values(cols), JSON.stringify(rec), ts, ts];
          await db.prepare(
            `INSERT INTO trips (${names.join(",")}) VALUES (${names.map(() => "?").join(",")})`
          ).bind(...vals).run();
          const row = await db.prepare("SELECT * FROM trips WHERE id=?").bind(id).first();
          return json(hydrate(row, "trips"), 201);
        }
      } else {
        const id = Number(segs[1]);
        if (!Number.isFinite(id)) return err("Bad trip id.", 400);
        if (method === "GET") {
          const row = await db.prepare("SELECT * FROM trips WHERE id=? AND deleted_at IS NULL").bind(id).first();
          return row ? json(hydrate(row, "trips")) : err("Not found.", 404);
        }
        if (method === "PATCH" || method === "PUT") return patchRow(db, "trips", id, await readBody(request));
        if (method === "DELETE") return softDelete(db, "trips", id);
      }
    }

    // ---- /v1/trip/{id}/... and /v2/trip/{id}/documents ----
    if (segs[0] === "trip" && segs[1]) {
      const tripId = Number(segs[1]);
      if (!Number.isFinite(tripId)) return err("Bad trip id.", 400);
      const what = segs[2];

      if (what === "restore" && method === "POST") return restoreDeleted(db, "trips", tripId);
      if (what === "reorder" && method === "POST") return reorderItems(db, tripId, await readBody(request));

      if (!what) {
        if (method === "PATCH" || method === "PUT") return patchRow(db, "trips", tripId, await readBody(request));
        // Both verbs at the same address. DELETE existed only on the plural
        // /v1/trips/{id} while GET and PATCH lived here, so a client using one
        // address for everything -- which is what the app does -- got
        // "Unknown endpoint" on delete alone. softDelete cascades to every
        // transport, hosting, activity, expense and document on the trip.
        if (method === "DELETE") return softDelete(db, "trips", tripId);
        if (method === "GET") {
          const row = await db.prepare("SELECT * FROM trips WHERE id=? AND deleted_at IS NULL").bind(tripId).first();
          return row ? json(hydrate(row, "trips")) : err("Not found.", 404);
        }
      }

      if (what === "collaborators") {
        // Single-household app: the authenticated user is the only traveller.
        return json({ results: [{ id: 1, name: (who || "").split("@")[0] || "Me", email: who || null }] });
      }

      if (what === "documents") {
        if (method === "GET") {
          // Every document on the trip, including the ones attached to an
          // itinerary item. The old `parent_type IS NULL` here was the reason a
          // document attached to a hotel appeared nowhere at all: this list
          // filtered it out, and the itinerary row reads the item's own blob,
          // which the attach never wrote to. It went into the table and out of
          // the interface. The link is now a property of the document rather
          // than a reason to hide it — same shape as an expense linked to a
          // booking, which the budget already works this way.
          const rows = await db.prepare(
            "SELECT * FROM documents WHERE trip_id=? AND deleted_at IS NULL ORDER BY id"
          ).bind(tripId).all();
          return json({ results: (rows.results || []).map((r) => docOut(r)) });
        }
        // Retitle a document, or change what it is attached to. Link and unlink
        // are the same call: parent_type null detaches without deleting, which
        // is the difference between "this is not the boarding pass for that
        // flight" and "throw the boarding pass away".
        if (segs[3] && (method === "PATCH" || method === "PUT")) {
          const docId = Number(segs[3]);
          if (!Number.isFinite(docId)) return err("Bad document id.", 400);
          const body = await readBody(request);
          const row = await db.prepare(
            "SELECT * FROM documents WHERE id=? AND trip_id=? AND deleted_at IS NULL"
          ).bind(docId, tripId).first();
          if (!row) return err("Not found.", 404);
          let pt = row.parent_type, pid = row.parent_id;
          if (Object.prototype.hasOwnProperty.call(body, "parent_type")) {
            pt = body.parent_type || null;
            pid = pt ? Number(body.parent_id) : null;
            // Both or neither, and only a kind this API actually routes on —
            // a parent_type of "flight" would store a link nothing can resolve.
            if (pt && !BY_SINGULAR[pt]) return err("Unknown parent type.", 400);
            if (pt && !Number.isFinite(pid)) return err("A link needs a parent id.", 400);
            if (!pt) pid = null;
          }
          const title = Object.prototype.hasOwnProperty.call(body, "title")
            ? (String(body.title || "").trim() || row.title) : row.title;
          const ts = nowIso();
          await db.prepare(
            "UPDATE documents SET title=?, parent_type=?, parent_id=?, updated_at=? WHERE id=?"
          ).bind(title, pt, pid, ts, docId).run();
          const after = await db.prepare("SELECT * FROM documents WHERE id=?").bind(docId).first();
          return json(docOut(after));
        }
        // Two ways to add one: POST a link (as before), or POST a file to
        // .../documents/upload. The row that results is the same shape either
        // way, so everything downstream stays unchanged.
        if (segs[3] === "upload" && method === "POST") return uploadDoc(db, env, tripId, null, null, request);
        if (method === "POST") return createDoc(db, tripId, null, null, await readBody(request));
        if (segs[3] && method === "DELETE") return deleteDoc(db, env, Number(segs[3]));
      }

      // Plural = collection on the trip.
      if (KINDS[what]) {
        const { table } = KINDS[what];
        if (method === "GET") {
          const since = url.searchParams.get("updatedSince") || url.searchParams.get("updated_since");
          const order = table === "transportations" ? "departure_at" : (table === "expenses" ? "date" : "starts_at");
          const rows = await db.prepare(
            `SELECT * FROM ${table} WHERE trip_id=? AND deleted_at IS NULL ${since ? "AND updated_at > ?" : ""} ORDER BY sort_order, ${order}`
          ).bind(...(since ? [tripId, since] : [tripId])).all();
          return json(page((rows.results || []).map((r) => hydrate(r, table)), request.url));
        }
        if (method === "POST") {
          const body = await readBody(request);
          const id = await nextId(db);
          const ts = nowIso();
          const rec = { ...body, id, trip: tripId, created_at: ts, updated_at: ts };
          const cols = columnsFor(table, body);
          const names = ["id", "trip_id", ...Object.keys(cols), "data", "created_at", "updated_at"];
          const vals = [id, tripId, ...Object.values(cols), JSON.stringify(rec), ts, ts];
          await db.prepare(
            `INSERT INTO ${table} (${names.join(",")}) VALUES (${names.map(() => "?").join(",")})`
          ).bind(...vals).run();
          const row = await db.prepare(`SELECT * FROM ${table} WHERE id=?`).bind(id).first();
          return json(hydrate(row, table), 201);
        }
      }

      // Singular = one item. This is the shape the client uses for edit/delete:
      //   /v1/trip/{tripId}/transportation/{itemId}
      if (BY_SINGULAR[what] && segs[3]) {
        const { table } = BY_SINGULAR[what];
        const itemId = Number(segs[3]);
        if (!Number.isFinite(itemId)) return err("Bad item id.", 400);

        // Nested documents: /v1/trip/{t}/{kind}/{item}/documents[/{docId}]
        if (segs[4] === "documents") {
          if (method === "GET") {
            const rows = await db.prepare(
              "SELECT * FROM documents WHERE parent_type=? AND parent_id=? AND deleted_at IS NULL ORDER BY id"
            ).bind(BY_SINGULAR[what].singular, itemId).all();
            return json({ results: (rows.results || []).map((r) => docOut(r)) });
          }
          if (segs[5] === "upload" && method === "POST") return uploadDoc(db, env, tripId, BY_SINGULAR[what].singular, itemId, request);
          if (method === "POST") return createDoc(db, tripId, BY_SINGULAR[what].singular, itemId, await readBody(request));
          if (segs[5] && method === "DELETE") return deleteDoc(db, env, Number(segs[5]));
        }

        if (method === "GET") {
          const row = await db.prepare(`SELECT * FROM ${table} WHERE id=? AND deleted_at IS NULL`).bind(itemId).first();
          return row ? json(hydrate(row, table)) : err("Not found.", 404);
        }
        if (segs[4] === "restore" && method === "POST") return restoreDeleted(db, table, itemId);
        if (method === "PATCH" || method === "PUT") return patchRow(db, table, itemId, await readBody(request));
        if (method === "DELETE") return softDelete(db, table, itemId);
      }
    }

    return err("Unknown endpoint: " + method + " /" + segs.join("/"), 404);
  } catch (e) {
    // A malformed body is the client's mistake, not ours: 400, not 500.
    if (e instanceof BadBody) return err(e.message, 400);
    return err("Server error: " + (e && e.message ? e.message : String(e)), 500);
  }
}

function safeJson(s) { try { return JSON.parse(s || "{}"); } catch { return {}; } }
function safeJsonArr(s) { try { const v = JSON.parse(s || "[]"); return Array.isArray(v) ? v : []; } catch { return []; } }


function docOut(r) {
  // parent_type/parent_id come last and explicitly: they are columns, and a
  // stale copy inside the blob would otherwise win and report a link that the
  // table no longer holds.
  return {
    ...safeJson(r.data), id: r.id, title: r.title, url: r.url, trip: r.trip_id,
    parent_type: r.parent_type || null,
    parent_id: r.parent_id == null ? null : Number(r.parent_id),
  };
}

// Largest file accepted. Passports, boarding passes and rental agreements are
// well under this; the cap exists so a stray video cannot fill the free tier or
// stall a Worker mid-upload.
// Every IATA code that appears on a flight endpoint in this database, and the
// country it is in. A closed set: all 53 resolve, none is ambiguous, and an
// airport is a far better country signal than a coordinate near a border.
// Add to it when a new airport shows up rather than reaching for a lookup API.
const AIRPORT_COUNTRY = {
  AEP: "Argentina", EZE: "Argentina", MDZ: "Argentina",
  YVR: "Canada", SCL: "Chile", PEK: "China", LIR: "Costa Rica", SJO: "Costa Rica",
  CDG: "France", ORY: "France", JTR: "Greece", HKG: "Hong Kong", NRT: "Japan",
  GDL: "Mexico", MEX: "Mexico", PVR: "Mexico", SJD: "Mexico", TIJ: "Mexico", ZCL: "Mexico",
  LIM: "Peru", LIS: "Portugal", MAD: "Spain", LHR: "United Kingdom",
  ATL: "United States", AUS: "United States", BRO: "United States", CLE: "United States",
  DCA: "United States", DEN: "United States", DFW: "United States", EGE: "United States",
  FAT: "United States", GEG: "United States", HNL: "United States", IAH: "United States",
  JFK: "United States", LAS: "United States", LAX: "United States", LGB: "United States",
  LIH: "United States", MIA: "United States", MRY: "United States", MSO: "United States",
  OAK: "United States", OGG: "United States", PDX: "United States", PHX: "United States",
  SEA: "United States", SFO: "United States", SJC: "United States", SLC: "United States",
  SMF: "United States", TUS: "United States",
};
// Matched against the LAST comma-separated part of an address only, so a street
// called "Calle Portugal" in Mexico City cannot claim the trip for Portugal.
const ADDRESS_COUNTRY = [
  [/^(usa|u\.s\.a\.|united states|us)\.?$/i, "United States"],
  [/^(mexico|méxico|mexico\.|mx)\.?$/i, "Mexico"],
  [/^(costa rica|cr)\.?$/i, "Costa Rica"],
  [/^(portugal|pt)\.?$/i, "Portugal"],
  [/^(spain|españa|espana|es)\.?$/i, "Spain"],
  [/^(france|fr)\.?$/i, "France"],
  [/^(greece|gr)\.?$/i, "Greece"],
  [/^(italy|it)\.?$/i, "Italy"],
  [/^(japan|jp)\.?$/i, "Japan"],
  [/^(canada|ca)\.?$/i, "Canada"],
  [/^(united kingdom|uk|england)\.?$/i, "United Kingdom"],
  [/^(china|cn)\.?$/i, "China"],
  [/^(hong kong|hk)\.?$/i, "Hong Kong"],
  [/^(peru|pe)\.?$/i, "Peru"],
  [/^(chile|cl)\.?$/i, "Chile"],
  [/^(argentina|ar)\.?$/i, "Argentina"],
];

const MAX_DOC_BYTES = 25 * 1024 * 1024;
// Covers are resized client-side before they get here, so this is a backstop
// against an unresized original rather than a working limit.
const MAX_COVER_BYTES = 5 * 1024 * 1024;

// Store an uploaded file in R2 and record it as a document. The row keeps the
// same shape a linked document has — the client renders `url` either way — but
// that url points back into this API rather than out to somebody else's host.
async function uploadDoc(db, env, tripId, parentType, parentId, request) {
  if (!env.DOCS) return err("Document storage is not configured on this deployment.", 503);
  let form;
  try { form = await request.formData(); }
  catch (e) {
    // Say what actually went wrong. This endpoint is behind Access or the
    // importer key, so the detail reaches you and nobody else — and a bare
    // "expected a file upload" cost a deploy cycle to diagnose.
    return err("Could not read the upload (content-type: " +
      (request.headers.get("content-type") || "none") + "): " + (e && e.message ? e.message : String(e)), 400);
  }
  const file = form.get("file");
  if (!file || typeof file.arrayBuffer !== "function") return err("No file was attached.", 400);
  if (file.size > MAX_DOC_BYTES) {
    return err(`That file is ${(file.size / 1048576).toFixed(1)} MB. The limit is 25 MB.`, 413);
  }
  if (!file.size) return err("That file is empty.", 400);

  const id = await nextId(db);
  const rawName = String(form.get("filename") || file.name || "document");
  // The name is stored and echoed in a header later; keep it to something that
  // cannot carry a path or a control character.
  const filename = rawName.replace(/[\r\n"\\/]+/g, "_").replace(/\.{2,}/g, ".").slice(0, 120);
  const title = String(form.get("title") || filename).slice(0, 200);
  const key = `trip/${tripId}/${id}/${filename}`;

  await env.DOCS.put(key, await file.arrayBuffer(), {
    httpMetadata: { contentType: file.type || "application/octet-stream" },
  });

  const ts = nowIso();
  const meta = {
    id, title, file_type: "file", r2_key: key, filename,
    content_type: file.type || "application/octet-stream", size: file.size, uploaded_at: ts,
  };
  const href = `/api/v1/doc/${id}`;
  try {
    await db.prepare(
      "INSERT INTO documents (id,trip_id,parent_type,parent_id,title,url,data,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)"
    ).bind(id, tripId, parentType, parentId, title, href, JSON.stringify({ ...meta, url: href }), ts, ts).run();
  } catch (e) {
    // Never leave an orphan in the bucket that nothing points at.
    try { await env.DOCS.delete(key); } catch { /* ignore */ }
    throw e;
  }
  return json({ ...meta, url: href, trip: tripId }, 201);
}

// Removing a document should remove the bytes too — a soft-deleted row still
// costs storage, and "deleted" ought to mean it.
async function deleteDoc(db, env, docId) {
  const row = await db.prepare("SELECT * FROM documents WHERE id=? AND deleted_at IS NULL").bind(docId).first();
  if (row) {
    const meta = safeJson(row.data);
    if (meta.r2_key && env.DOCS) { try { await env.DOCS.delete(meta.r2_key); } catch { /* ignore */ } }
  }
  return softDelete(db, "documents", docId);
}

async function createDoc(db, tripId, parentType, parentId, body) {
  if (!body || !body.url) return err("A document needs a url.", 400);
  const id = await nextId(db);
  const ts = nowIso();
  const rec = { ...body, id };
  await db.prepare(
    "INSERT INTO documents (id,trip_id,parent_type,parent_id,title,url,data,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)"
  ).bind(id, tripId, parentType, parentId, body.title || body.name || null, body.url, JSON.stringify(rec), ts, ts).run();
  return json({ ...rec, title: body.title || body.name || null }, 201);
}

// Partial update. The stored `data` blob is merged rather than replaced so a
// PATCH of one field cannot silently drop everything the client did not send.
// ---- compare-and-set on whole-value fields ----
//
// A list like `tasks` or `bucket_list` is stored as one value and written as one
// value, so the last writer wins the whole list. Two devices with the trip open
// is the ordinary case here, not a rare one: add a task on the phone, add
// another on the laptop from a page loaded five minutes earlier, and the
// laptop's PATCH carries its stale array and the phone's task is gone. Nothing
// reports it, because from the server's side that is simply what was asked for.
//
// So a caller may send `if_match`, naming the value it believed was stored. If
// the stored value differs, the write is refused with 409 and the current value
// comes back, and the client re-applies its change to fresh data and retries.
// Callers that do not send `if_match` behave exactly as before.
//
// Stable stringify: the client hands back a value it received from here, so key
// order normally survives — but it costs three lines to stop a re-ordered object
// looking like a conflict, and a false conflict is a retry loop.
function stableJson(v) {
  if (v === undefined || v === null) return "null";
  if (Array.isArray(v)) return "[" + v.map(stableJson).join(",") + "]";
  if (typeof v === "object") {
    return "{" + Object.keys(v).sort().map((k) => JSON.stringify(k) + ":" + stableJson(v[k])).join(",") + "}";
  }
  return JSON.stringify(v);
}
// Absent, null and [] are one state: "nothing here". A trip that has never had
// a to-do list carries no `tasks` key at all, while the client that is about to
// add the first one necessarily believes the list is empty. Treating those as a
// disagreement made the FIRST task on every trip conflict, retry four times and
// fail — which is how this was found, and it would have hit all 181 trips.
function nothingThere(v) { return v === undefined || v === null || (Array.isArray(v) && !v.length); }

// The fields whose stored value disagrees with what the caller expected.
function staleFields(current, ifMatch) {
  if (!ifMatch || typeof ifMatch !== "object" || Array.isArray(ifMatch)) return null;
  const stale = {};
  for (const k of Object.keys(ifMatch)) {
    const cur = current ? current[k] : undefined;
    if (nothingThere(cur) && nothingThere(ifMatch[k])) continue;
    if (stableJson(cur) !== stableJson(ifMatch[k])) {
      stale[k] = cur !== undefined ? cur : null;
    }
  }
  return Object.keys(stale).length ? stale : null;
}
// 409 with the current values, so a client can retry without a second request.
function conflict(stale) {
  return json({ detail: "This changed on another device.", conflict: true, current: stale }, 409);
}
// `if_match` is a protocol field, never a stored one.
function withoutIfMatch(body) {
  if (!body || typeof body !== "object" || !("if_match" in body)) return body;
  const copy = { ...body };
  delete copy.if_match;
  return copy;
}

// ---- a changed time puts the day back in chronological order ----
//
// The itinerary sorts by day, then sort_order, then time, and sort_order wins
// when it is set — which a drag-and-drop reorder sets for every row on that day.
// So after one manual reorder, moving a booking's time left it exactly where it
// was: the 9am tour still printing after the 4pm one.
//
// This lives HERE rather than in the browser because the browser is not the
// only writer. An airline schedule change arrives through the importer and
// never touches client code, and that is the case where reordering matters
// most: it is the one the traveller did not initiate. Every writer gets it now
// — the app, the importer, anything else that ever PATCHes a time.
//
// Zero is the documented "no manual order, use the clock" state, so this clears
// rather than renumbers. It does discard a hand-made order on the days
// involved, which is the intent: the times have just been declared to matter.
const ORDERED_TABLES = new Set(["transportations", "hostings", "activities"]);
const TIME_FIELDS = ["departure_at", "arrival_at", "starts_at", "ends_at"];

function sameMoment(a, b) {
  if (!a && !b) return true;
  if (!a || !b) return false;
  const x = Date.parse(a), y = Date.parse(b);
  return isFinite(x) && isFinite(y) ? x === y : String(a) === String(b);
}

// The local calendar day an instant falls on, in its own zone. en-CA gives
// YYYY-MM-DD, which sorts and compares as a string.
// UTC rather than the runtime's zone when a record carries none, so the answer
// does not depend on where this runs. A record without a timezone is rare and
// the cost of getting it wrong is a stale sort order, not a wrong booking.
function dayKeyOf(iso, tz) {
  if (!iso) return null;
  try { return new Date(iso).toLocaleDateString("en-CA", { timeZone: tz || "UTC" }); }
  catch (e) { return String(iso).slice(0, 10); }
}

// Every day a record appears on. A stay and a spanning hire car each show up
// twice — the day they open and the day they close — and both ends need putting
// back in order.
function recordDays(rec) {
  const out = [];
  const add = (iso, tz) => { const k = dayKeyOf(iso, tz); if (k && !out.includes(k)) out.push(k); };
  add(rec.departure_at, rec.departure_timezone);
  add(rec.arrival_at, rec.arrival_timezone || rec.departure_timezone);
  add(rec.starts_at, rec.timezone);
  add(rec.ends_at, rec.timezone);
  return out;
}

function timeMoved(stored, body) {
  return TIME_FIELDS.some((f) =>
    Object.prototype.hasOwnProperty.call(body, f) && !sameMoment(body[f], stored[f]));
}

// Clear the manual order on every day this edit touched, before and after.
// The days one edit disturbed: where the item was, plus where it now is.
function daysTouchedBy(before, after) {
  return [...new Set(recordDays(before).concat(recordDays(after)))];
}

// Does this record have anything on one of those days? Only rows that do get
// their manual order cleared — a reorder on the 22nd must not disturb the 25th.
function touchesAnyDay(rec, days) {
  return recordDays(rec).some((k) => days.includes(k));
}

async function reflowDays(db, tripId, before, after) {
  if (!tripId) return;
  const days = daysTouchedBy(before, after);
  if (!days.length) return;
  const ts = nowIso();
  for (const table of ORDERED_TABLES) {
    // Only rows that actually carry a manual order. Most trips have none, so
    // this is usually an empty result and no writes at all.
    const rows = await db.prepare(
      `SELECT id, data FROM ${table} WHERE trip_id=? AND deleted_at IS NULL AND sort_order IS NOT NULL AND sort_order<>0`
    ).bind(tripId).all();
    for (const r of (rows.results || [])) {
      const rec = safeJson(r.data) || {};
      if (!touchesAnyDay(rec, days)) continue;
      // Column and blob together. The blob is the copy compare-and-set reads,
      // so letting the two disagree would make a later if_match on sort_order
      // check a value that is no longer the stored one.
      await db.prepare(
        `UPDATE ${table} SET sort_order=0, updated_at=?,
           data=json_set(data,'$.sort_order',0,'$.updated_at',?) WHERE id=?`
      ).bind(ts, ts, r.id).run();
    }
  }
}

// One drag, one write.
//
// Reordering a day used to PATCH every row in it, sequentially, awaiting each:
// eight items meant eight round trips one after another, and a failure halfway
// left the day half-renumbered with no way back. This does the whole day in a
// single batch, which D1 runs as one transaction -- so it either all lands or
// none of it does.
//
// trip_id is in every WHERE clause, not just the URL. Without it the body could
// name any row in the database and this would happily renumber another trip's
// itinerary.
//
// Column AND blob, the same pairing reflowDays uses: the blob is the copy that
// compare-and-set reads, so letting them disagree would make a later if_match
// on sort_order check a value that is no longer the stored one.
async function reorderItems(db, tripId, body) {
  const items = body && Array.isArray(body.items) ? body.items : null;
  if (!items || !items.length) return err("Nothing to reorder.", 400);
  // A day with more rows than this is not something a person dragged.
  if (items.length > 200) return err("Too many items to reorder at once.", 400);

  const ts = nowIso();
  const stmts = [];
  const seen = new Set();
  for (const it of items) {
    const kind = it && typeof it.kind === "string" ? it.kind : "";
    const info = BY_SINGULAR[kind];
    const id = Number(it && it.id);
    const order = Number(it && it.sort_order);
    // Only the three that carry a manual order. Expenses have a sort_order
    // column but are not draggable, and accepting one here would let the
    // client write an order nothing reads.
    if (!info || !ORDERED_TABLES.has(info.table)) return err(`Cannot reorder ${kind || "that"}.`, 400);
    if (!Number.isFinite(id) || !Number.isInteger(order) || order < 0) return err("Bad item in reorder.", 400);
    // The same row twice would make the result depend on statement order.
    const key = info.table + ":" + id;
    if (seen.has(key)) return err("The same item appears twice.", 400);
    seen.add(key);
    stmts.push(db.prepare(
      `UPDATE ${info.table} SET sort_order=?, updated_at=?,
         data=json_set(data,'$.sort_order',?,'$.updated_at',?)
       WHERE id=? AND trip_id=? AND deleted_at IS NULL`
    ).bind(order, ts, order, ts, id, tripId));
  }

  const res = await db.batch(stmts);
  const changed = (res || []).reduce((n, r) => n + ((r && r.meta && r.meta.changes) || 0), 0);
  // Reported rather than enforced: a row deleted on another device between the
  // drag and the drop is a real thing that happens, and the reorder that did
  // land is still correct. The client reconciles by redrawing.
  return json({ ok: true, asked: stmts.length, updated: changed });
}

// ---------------------------------------------------------------------------
// Credit-card spend thresholds
//
// Some cards pay a reward for reaching an annual spend figure. The useful thing
// is not the number itself but knowing when to STOP steering spend at a card,
// which needs real transactions rather than a guess.
//
// THE CLASSIFIER IS THE LOAD-BEARING PART, and it was wrong twice before it was
// right. Both wrong answers looked entirely plausible.
//
//   1. Keying off Plaid's personal_finance_category missed $427,904 of Amex
//      payments, because Plaid files "PAYMENT RECEIVED - THANK YOU" as
//      INCOME_SALARY. Those were counted as refunds and SUBTRACTED, understating
//      one card's year by $210,000. The tell was a 65% refund rate.
//
//   2. Treating every remaining negative as a refund subtracted statement
//      credits. The Hilton Aspire's resort credits ($550 over the year) are not
//      refunds -- the purchase they offset still counts toward the threshold.
//
//   3. Every pattern above is AMEX's wording, and Chase's broke all three on
//      contact. Chase truncates its description to "AUTOMATIC PAYMENT - THANK",
//      which the THANK YOU pattern missed; "CREDIT BALANCE REFUND" is positive,
//      so the sign shortcut called an overpayment return a charge; and a Chase
//      Offers credit ("Offer:...") read as a merchant refund and subtracted.
//      A description no rule recognises falls through to "refund", which
//      SUBTRACTS -- so an unrecognised payment is mistake 1 all over again.
//
// The rules below reconciled to within 96 cents of American Express's own
// figure for the Aspire, the 96 cents being a rounded input. Do not "simplify"
// them without re-reconciling against a statement, and treat every new bank as
// a new reconciliation -- tools/plaid-connect.js prints the report for it.
// ---------------------------------------------------------------------------

// Money settling the balance. Amex is consistent in the description, which is
// the only signal that can be trusted here.
const CARD_PAYMENT_RE = /\bPAYMENT\b.*THANK|AUTOPAY|AUTOMATIC\s+PAYMENT|REMITTANCE\s+RECEIVED|\bPAYMENT\s+RECEIVED\b/i;
// Statement credits and points redemptions. Negative, but NOT a reversal of
// spend -- the original charge still counts.
// Amex prints its benefit credits as ordinary negatives, and four of them were
// subtracting as though a merchant had refunded something (found 2026-08-27):
//
//   AMEX Airline Fee Reimbursement   $100 flat, BANK_FEES
//   AMEX Flight Credit               BANK_FEES
//   TSA Global Entry Fee Credit      $120 flat
//   Dell Credit                      $200 flat, the Business Platinum benefit
//
// What was NOT reclassified, on the same evidence: "AMEX Fine Hotels and
// AmexTravel.com" at $494.33, $253.07 and $236.97 is not the flat $100 FHR
// property credit -- those are refunds of hotel bookings, and they belong in
// the refund bucket. Global Blue is a VAT reimbursement on goods bought, which
// genuinely reduces what was spent. Nordstrom, Zara, Banana Republic, Home
// Depot and the rest are plain returns.
//
// The list grows by reading the feed, never by guessing at benefit names.
const CARD_CREDIT_RE = /PAY\s*WITH\s*POINTS|\bPwP\b|STATEMENT\s+CREDIT|REDEEM\s+CRED|FHR\b|HOTEL\s+CREDIT|AIRLINE\s+CREDIT|ADJ\s+REDIST|MEMBERSHIP\s+REWARD|^\s*Offer:|AMEX\s.*\bCREDIT\b|\bFEE\s+(?:CREDIT|REIMBURSEMENT)\b|\bDELL\s+CREDIT\b/i;
// Positive, and NOT spend: the bank returning an overpayment. Chase files it
// under LOAN_PAYMENTS_CREDIT_CARD_PAYMENT, but because the amount is positive
// the "anything positive is a charge" shortcut counted it as spend.
const CARD_BALANCE_REFUND_RE = /CREDIT\s+BALANCE\s+REFUND/i;

// charge | payment | credit | refund. Order matters: description first, and the
// category only as a fallback for what the wording did not catch.
function classifyCardTxn(name, category, amount) {
  const n = String(name || "");
  // Before the sign test, because this one is positive and still not spend.
  if (CARD_BALANCE_REFUND_RE.test(n)) return "payment";
  if (amount > 0) return "charge";
  if (CARD_PAYMENT_RE.test(n)) return "payment";
  if (CARD_CREDIT_RE.test(n)) return "credit";
  const c = String(category || "");
  if (/CREDIT_CARD_PAYMENT/.test(c)) return "payment";
  // A statement credit does not come from a merchant, so Plaid files it under
  // INCOME_* or TRANSFER_IN_*; a real refund lands in a spending category.
  if (/^(INCOME|TRANSFER_IN)/.test(c)) return "credit";
  return "refund";
}

async function plaid(env, endpoint, body) {
  const host = "https://" + (env.PLAID_ENV || "production") + ".plaid.com";
  // A REJECTED fetch -- DNS failure, TLS reset, Plaid down entirely -- is not
  // the same as a non-2xx answer, and without this it threw past every caller
  // and turned the whole panel into a 500. An outage at Plaid must degrade to
  // the same "problems" strip an application error does.
  try {
    const res = await fetch(host + endpoint, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(Object.assign({ client_id: env.PLAID_CLIENT_ID, secret: env.PLAID_SECRET }, body)),
    });
    const data = await res.json().catch(() => null);
    return { ok: res.ok, status: res.status, data };
  } catch (e) {
    return { ok: false, status: 0, data: { error_code: "NETWORK", error_message: String(e && e.message || e) } };
  }
}

// Pull whatever is new for one item and write it down. Incremental: the cursor
// is stored, so this is cheap after the first run.
//
// A failure is RECORDED rather than swallowed. A sync that quietly fails and
// leaves yesterday's totals on screen is the same class of lie as a failed
// request rendering as "no flights" -- see the loaders in app.js.
async function syncCardItem(env, db, item, token) {
  let cursor = item.cursor || null, added = [], modified = [], removed = [], rounds = 0;
  while (rounds++ < 30) {
    const body = { access_token: token };
    if (cursor) body.cursor = cursor;
    const r = await plaid(env, "/transactions/sync", body);
    if (!r.ok) {
      const msg = (r.data && (r.data.error_code + ": " + r.data.error_message)) || ("HTTP " + r.status);
      await db.prepare("UPDATE card_items SET last_error=?, updated_at=? WHERE id=?")
        .bind(msg, nowIso(), item.id).run();
      return { ok: false, error: msg };
    }
    added = added.concat(r.data.added || []);
    modified = modified.concat(r.data.modified || []);
    removed = removed.concat(r.data.removed || []);
    cursor = r.data.next_cursor;
    if (!r.data.has_more) break;
  }

  const ts = nowIso();
  const stmts = [];
  for (const t of added.concat(modified)) {
    const cat = (t.personal_finance_category && t.personal_finance_category.detailed) || "";
    stmts.push(db.prepare(
      "INSERT INTO card_txns (id, plaid_account_id, date, amount, name, category, pending, updated_at)" +
      " VALUES (?,?,?,?,?,?,?,?)" +
      " ON CONFLICT(id) DO UPDATE SET date=excluded.date, amount=excluded.amount, name=excluded.name," +
      " category=excluded.category, pending=excluded.pending, updated_at=excluded.updated_at"
    ).bind(t.transaction_id, t.account_id, t.date, t.amount, t.name || "", cat, t.pending ? 1 : 0, ts));
  }
  // A removed transaction is one the bank retracted. Leaving it in would keep
  // counting spend that no longer happened.
  for (const r of removed) stmts.push(db.prepare("DELETE FROM card_txns WHERE id=?").bind(r.transaction_id));
  if (stmts.length) await db.batch(stmts);

  await db.prepare("UPDATE card_items SET cursor=?, last_sync_at=?, last_error=NULL, updated_at=? WHERE id=?")
    .bind(cursor, ts, ts, item.id).run();
  return { ok: true, added: added.length, modified: modified.length, removed: removed.length };
}

// Refresh the account list too, so a new card on an existing login appears.
async function refreshCardAccounts(env, db, item, token) {
  const r = await plaid(env, "/accounts/get", { access_token: token });
  if (!r.ok) return;
  const ts = nowIso();
  for (const a of r.data.accounts || []) {
    const id = await nextId(db);
    await db.prepare(
      "INSERT INTO card_accounts (id, item_id, plaid_account_id, name, mask, created_at, updated_at)" +
      " VALUES (?,?,?,?,?,?,?)" +
      " ON CONFLICT(plaid_account_id) DO UPDATE SET name=excluded.name, mask=excluded.mask, updated_at=excluded.updated_at"
    ).bind(id, item.id, a.account_id, a.name || "", a.mask || "", ts, ts).run();
  }
}

// ---- goals counted in nights rather than dollars --------------------------
//
// World of Hyatt Globalist is 60 qualifying nights a year from three sources:
// nights the card grants for being held, nights bought with spend (2 per
// $5,000), and nights actually slept in a Hyatt. The app already keeps the
// third one -- that is what the itinerary IS -- so the only real work is
// deciding which stays are Hyatt's.
//
// EVERY HYATT BRAND, including the ones that never print the word. Alila,
// Andaz, Thompson, Miraval and the Unbound Collection are all Hyatt, and a
// reader who only knows "Hyatt" undercounts without saying so.
//
// This match is a DEFAULT, not an answer. It cannot be right on its own:
// "Hotel Seville NoMad" is a Hyatt -- the card statement reads HYATT SEVILLE
// NOMAD -- and nothing in the name it is stored under betrays that. Three
// nights would have gone quietly missing. card_stay_marks is the correction,
// and the panel lists every stay so the default can be seen rather than
// trusted.
const STAY_BRANDS = {
  hyatt: /hyatt|andaz|alila|thompson\s+hotel|miraval|caption\s+by|unbound\s+collection|destination\s+by|jdv\s+by|impression\s+by|secrets\s+resort|dreams\s+resort|breathless\s+resort|zoetry|sunscape|ziva|zilara|urcove/i,
};

// Whole nights between two YYYY-MM-DD dates. Parsed as UTC on purpose: these
// are calendar dates, and a local-time parse moves them across a boundary for
// anyone west of Greenwich.
function stayNights(from, to) {
  const a = Date.parse(String(from || "").slice(0, 10) + "T00:00:00Z");
  const b = Date.parse(String(to || "").slice(0, 10) + "T00:00:00Z");
  if (!a || !b || b < a) return 0;
  return Math.round((b - a) / 86400000);
}

// The day after a YYYY-MM-DD date, for exclusive upper bounds. hostings dates
// are unconstrained TEXT that can carry a time component, so an INCLUSIVE bind
// of win.to would drop "2027-02-28T15:00:00" -- string-greater than
// "2027-02-28" -- which is why every query here keeps a half-open range.
function dayAfter(iso) {
  const d = new Date(Date.parse(String(iso).slice(0, 10) + "T00:00:00Z") + 86400000);
  return d.toISOString().slice(0, 10);
}

async function nightsFromStays(db, goal, win) {
  // The GOAL's window, not the calendar year. A march-period nights goal was
  // counting spend over Mar-Feb and stays over Jan-Dec -- the two halves of
  // one progress figure measured over different periods. The overlap test is
  // ends_at as well as starts_at, so a stay that STRADDLES the window's edge
  // is seen by both years instead of credited wholly to the check-in year.
  const toEx = dayAfter(win.to);
  const rows = (await db.prepare(
    "SELECT id, name, starts_at, ends_at FROM hostings" +
    " WHERE deleted_at IS NULL AND starts_at < ? AND (ends_at IS NULL OR ends_at > ?) ORDER BY starts_at, id"
  ).bind(toEx, win.from).all()).results || [];

  const marks = {};
  for (const m of (await db.prepare("SELECT hosting_id, counts FROM card_stay_marks WHERE goal_id=?")
    .bind(goal.id).all()).results || []) marks[m.hosting_id] = !!m.counts;

  const brand = STAY_BRANDS[String(goal.stay_brand || "").toLowerCase()];
  const today = nowIso().slice(0, 10);

  // Same hotel, same dates, twice over is a SECOND ROOM, not a duplicate row --
  // measured 40 out of 40 across 182 trips. It matters here because two rooms
  // are still one night of occupancy: counting both records would double the
  // stay. Hyatt does credit up to three PAID rooms per stay, so the second
  // room may well qualify -- which is a decision, not an assumption, and lives
  // on the goal as count_extra_rooms.
  const seen = Object.create(null);
  const stays = [];
  let counted = 0, extra = 0, ahead = 0, extraAhead = 0;

  for (const h of rows) {
    const rawNights = stayNights(h.starts_at, h.ends_at);
    const key = (h.name || "") + "|" + String(h.starts_at).slice(0, 10) + "|" + String(h.ends_at).slice(0, 10);
    const room = (seen[key] = (seen[key] || 0) + 1);
    const auto = brand ? brand.test(h.name || "") : false;
    const marked = Object.prototype.hasOwnProperty.call(marks, h.id);
    const counts = marked ? marks[h.id] : auto;
    const future = String(h.starts_at).slice(0, 10) > today;

    // Only the nights INSIDE the window belong to this goal. A stay running
    // 29 Dec - 2 Jan is three nights of the old year and one of the new;
    // crediting all four to the check-in year overcounts one side and lets a
    // night vanish quietly from the other.
    const s0 = String(h.starts_at).slice(0, 10), e0 = String(h.ends_at || "").slice(0, 10);
    const cs = s0 > win.from ? s0 : win.from;
    const ce = e0 && e0 < toEx ? e0 : toEx;
    const nights = stayNights(cs, ce);

    // A stay still to come is real but not yet earned -- and a stay you are
    // IN THE MIDDLE OF has earned only the nights already slept. Crediting
    // the whole booking on check-in day says you have status you have not
    // stayed for, so each stay splits at today: slept counts, the rest is
    // "booked ahead".
    const slept = stayNights(cs, ce < today ? ce : today);
    const pending = nights - slept;

    if (counts && nights > 0) {
      if (room > 1) { extra += slept; extraAhead += pending; }
      else { counted += slept; ahead += pending; }
    }

    stays.push({
      hosting_id: h.id,
      name: h.name || "",
      from: s0,
      to: e0,
      // The stay's own length, not the clamped share -- the list is for
      // checking against reality, and reality is the whole booking.
      nights: rawNights, room, counts, auto,
      overridden: marked && marks[h.id] !== auto,
      future,
      // Keyed off the UNCLAMPED duration: a straddling stay with one night
      // outside this window is not "recorded without its check-out".
      suspect: rawNights === 0,
    });
  }

  return { stays, counted, extra, ahead, extraAhead };
}

const CARD_SYNC_STALE_MS = 6 * 3600 * 1000;

// The stretch of time a goal is measured over.
//
// Every threshold so far ran on the calendar, and that is an assumption rather
// than a fact about loyalty programmes. American's Loyalty Point year runs
// 1 March to the end of February, so on 27 August 2026 the year in progress is
// "2026-27" and began five months ago -- not on 1 January. Every number that
// keys off the start of the year is wrong under the old assumption: elapsed
// days, days remaining, the pace, and which transactions are even in scope.
//
// Dates are handled as UTC calendar dates throughout, matching card_txns.date.
function goalWindow(period, nowMs) {
  const d = new Date(nowMs);
  const y = d.getUTCFullYear();
  const p = String(period || "calendar");

  if (p === "march") {
    // Before March the year in progress is the one that began LAST March.
    const startYear = d.getUTCMonth() >= 2 ? y : y - 1;
    // Day 0 of March is the last day of February, which handles leap years
    // without anyone having to think about them.
    const end = new Date(Date.UTC(startYear + 1, 2, 0));
    return {
      from: startYear + "-03-01",
      to: end.toISOString().slice(0, 10),
      label: startYear + "–" + String(startYear + 1).slice(2),
    };
  }
  return { from: y + "-01-01", to: y + "-12-31", label: String(y) };
}

// Whole days from one YYYY-MM-DD to another, inclusive of both.
function daysInclusive(from, to) {
  return Math.round((Date.parse(to + "T00:00:00Z") - Date.parse(from + "T00:00:00Z")) / 86400000) + 1;
}

async function cardsPayload(env, db, opts) {
  const force = !!(opts && opts.force);
  const items = (await db.prepare("SELECT * FROM card_items WHERE deleted_at IS NULL").all()).results || [];

  const problems = [];
  for (const item of items) {
    const age = item.last_sync_at ? Date.now() - Date.parse(item.last_sync_at) : Infinity;
    if (!force && age < CARD_SYNC_STALE_MS) {
      // Skipped as fresh -- but if the LAST attempt failed, that failure is
      // still the truth of this item, and skipping silently would hide it for
      // up to six hours. Only here is the in-memory row guaranteed to match
      // the database; after a sync it is stale by design.
      if (item.last_error) problems.push((item.institution || "A card") + ": " + item.last_error);
      continue;
    }
    if (!env.PLAID_CLIENT_ID || !env.PLAID_SECRET) { problems.push("Plaid keys are not configured on this deployment."); break; }
    // The row names its secret; the token lives in the Pages environment, not
    // in D1. A stored access token would otherwise ride along in every SQL
    // snapshot the backup task writes to disk, and a bank-linkage token is not
    // something to scatter across backup files for the sake of one column.
    const token = env[item.token_env];
    if (!token) { problems.push((item.institution || "A card") + ": " + item.token_env + " is not set on this deployment."); continue; }
    await refreshCardAccounts(env, db, item, token);
    const r = await syncCardItem(env, db, item, token);
    if (!r.ok) problems.push((item.institution || "A card") + ": " + r.error);
    // The rows below were read before this ran, so the in-memory copy still
    // carries the OLD timestamp -- and "synced never" under a sync that just
    // succeeded is a small lie of exactly the kind this panel must not tell.
    else item.last_sync_at = nowIso();
  }

  const accounts = (await db.prepare("SELECT * FROM card_accounts WHERE deleted_at IS NULL").all()).results || [];
  const goals = (await db.prepare("SELECT * FROM card_goals WHERE deleted_at IS NULL").all()).results || [];
  const byAcct = {};
  for (const a of accounts) byAcct[a.plaid_account_id] = a;

  const out = [];
  for (const g of goals) {
    const acct = byAcct[g.plaid_account_id];
    // Each goal keeps its own clock. A calendar card and an AAdvantage year
    // sit in the same panel and disagree about what "this year" means.
    const win = goalWindow(g.period, Date.now());
    const year = win.from.slice(0, 4);
    const rows = (await db.prepare(
      "SELECT date, amount, name, category, pending FROM card_txns WHERE plaid_account_id=? AND date >= ? AND date <= ? ORDER BY date"
    ).bind(g.plaid_account_id, win.from, win.to).all()).results || [];

    let charges = 0, refunds = 0, payments = 0, credits = 0, running = 0, crossedOn = null, pendingSpend = 0;
    for (const t of rows) {
      const kind = classifyCardTxn(t.name, t.category, t.amount);
      if (kind === "charge") charges += t.amount;
      else if (kind === "refund") refunds += t.amount;
      else if (kind === "payment") { payments += t.amount; continue; }
      else { credits += t.amount; continue; }
      running += t.amount;
      // Pending charges COUNT toward spend -- that is the behaviour the 96-cent
      // Amex reconciliation validated -- but they are surfaced separately, and
      // a crossing is never dated by a charge that might still vanish.
      if (t.pending) { pendingSpend += t.amount; continue; }
      // Only meaningful for a goal the transactions alone can satisfy. A
      // nights goal is crossed by a stay as readily as by a charge, so a date
      // derived from spend would name the wrong day.
      if (!crossedOn && String(g.unit || "usd") === "usd" && running >= g.target) crossedOn = t.date;
    }

    const spend = charges + refunds;

    // A nights goal is measured in nights, and spend is only one of the three
    // ways to get them. Everything below still reports the dollars, because
    // "how much more spend would do it" is a real question -- it is just not
    // the progress bar any more.
    const unit = String(g.unit || "usd");
    const nightsGoal = unit === "nights";
    const pointsGoal = unit === "points";
    let progress = spend, fromSpend = 0, fromStays = null, sinceAnchor = 0;

    // ---- a goal anchored to the programme's own number --------------------
    //
    // Loyalty Points come from card spend AND from flying, and the flying half
    // cannot be computed here: every flight in the itinerary carries price = 0,
    // so the app knows where you flew and never what the ticket cost. An
    // estimate would be a fabricated half of a two-source total presented as
    // progress, which is the exact shape of the mistakes this panel has already
    // made twice.
    //
    // So American's own figure is the anchor, and only card spend recorded
    // AFTER the day it was read is added to it. Spend before that day is
    // already inside the anchor; counting it again would double it. Re-reading
    // the balance from AA moves the anchor forward and absorbs the flying.
    let anchorStale = false;
    if (pointsGoal) {
      let anchorDay = g.baseline_at ? String(g.baseline_at).slice(0, 10) : null;
      // Loyalty balances RESET when the qualification year rolls over -- that
      // is the whole reason goalWindow has a march period. An anchor read in
      // the previous year describes a balance that no longer exists, and
      // adding it to this year's spend overstated progress by last year's
      // entire total. Stale means unanchored: spend-only, and the client says
      // in as many words that the balance needs re-reading.
      if (anchorDay && anchorDay < win.from) { anchorStale = true; anchorDay = null; }
      const rate = g.units_per_step && g.spend_step ? (g.units_per_step / g.spend_step) : 1;
      for (const t of rows) {
        if (anchorDay && t.date <= anchorDay) continue;
        const kind = classifyCardTxn(t.name, t.category, t.amount);
        if (kind === "charge" || kind === "refund") sinceAnchor += t.amount;
      }
      fromSpend = Math.floor(sinceAnchor * rate);
      progress = (anchorStale ? 0 : (g.baseline_units || 0)) + fromSpend;
    }

    if (nightsGoal) {
      // Floor: $4,999 buys nothing. The step is only credited once complete.
      fromSpend = g.spend_step ? Math.floor(spend / g.spend_step) * (g.units_per_step || 0) : 0;
      fromStays = await nightsFromStays(db, g, win);
      progress = (g.base_units || 0) + fromSpend +
        fromStays.counted + (g.count_extra_rooms ? fromStays.extra : 0);
    }
    // Measured across the goal's OWN window, not the calendar year.
    const start = Date.parse(win.from + "T00:00:00Z");
    const today = Date.now();
    const elapsed = Math.max(1, Math.floor((today - start) / 86400000) + 1);
    const totalDays = daysInclusive(win.from, win.to);
    const daysLeft = Math.max(0, totalDays - elapsed);
    // The nights a card GRANTS for being held arrive all at once, not at a
    // daily rate -- projecting them forward said "on track" on the strength of
    // day one. They are subtracted from the pace and added back to the
    // projection as the lump they are. usd and points goals have no such lump.
    const paceBase = nightsGoal ? (g.base_units || 0) : 0;
    const perDay = (progress - paceBase) / elapsed;

    const item = items.find((i) => i.id === (acct && acct.item_id));
    out.push({
      goal_id: g.id,
      // The nickname wins because refreshCardAccounts overwrites `name` from
      // the bank on every sync, and Chase calls this one "CREDIT CARD".
      card: (acct && (acct.nickname || acct.name)) || "Unknown card",
      mask: (acct && acct.mask) || "",
      label: g.label,
      target: g.target,
      unit: unit,
      window_from: win.from,
      window_to: win.to,
      window_label: win.label,
      // The anchor, so the panel can say how old it is and offer to move it.
      baseline_units: pointsGoal && !anchorStale ? (g.baseline_units || 0) : null,
      // The date survives staleness so the client can say WHEN the dead
      // balance was read; the units do not, or they would render as current.
      baseline_at: pointsGoal ? (g.baseline_at || null) : null,
      anchor_stale: pointsGoal ? anchorStale : null,
      spend_since_anchor: pointsGoal ? sinceAnchor : null,
      pending_spend: pendingSpend,
      spend, charges, refunds, payments, credits,
      progress,
      // The three sources, so the panel can show what made the number rather
      // than just the number.
      from_held: nightsGoal ? (g.base_units || 0) : null,
      from_spend: (nightsGoal || pointsGoal) ? fromSpend : null,
      from_stays: nightsGoal ? fromStays.counted : null,
      // Booked-ahead nights follow the same extra-room decision as earned
      // ones: a second room that will never count is not "ahead" of anything.
      stays_ahead: nightsGoal ? fromStays.ahead + (g.count_extra_rooms ? fromStays.extraAhead : 0) : null,
      extra_room_nights: nightsGoal ? fromStays.extra : null,
      count_extra_rooms: !!g.count_extra_rooms,
      spend_step: g.spend_step,
      units_per_step: g.units_per_step,
      stays: nightsGoal ? fromStays.stays : null,
      year,
      met: progress >= g.target,
      crossed_on: crossedOn,
      remaining: Math.max(0, g.target - progress),
      days_left: daysLeft,
      per_day: perDay,
      projected: paceBase + perDay * totalDays,
      needed_per_day: daysLeft > 0 ? Math.max(0, g.target - progress) / daysLeft : null,
      paid_next_year: !!g.paid_next_year,
      last_sync_at: item ? item.last_sync_at : null,
      txn_count: rows.length,
    });
  }

  out.sort((a, b) => (b.progress / b.target) - (a.progress / a.target));
  // Each goal now carries its own window, so there is no single year to
  // report at the top. The calendar one is what the panel's heading means.
  return { results: out, problems, year: String(new Date().getUTCFullYear()) };
}

async function patchRow(db, table, id, body) {
  const row = await db.prepare(`SELECT * FROM ${table} WHERE id=? AND deleted_at IS NULL`).bind(id).first();
  if (!row) return err("Not found.", 404);
  const stored = safeJson(row.data) || {};
  const stale = staleFields(stored, body && body.if_match);
  if (stale) return conflict(stale);
  body = withoutIfMatch(body);
  const merged = { ...stored, ...body, id };
  const ts = nowIso();
  merged.updated_at = ts;
  const cols = columnsFor(table, body);
  const sets = [...Object.keys(cols).map((c) => `${c}=?`), "data=?", "updated_at=?"];
  const vals = [...Object.values(cols), JSON.stringify(merged), ts, id];
  await db.prepare(`UPDATE ${table} SET ${sets.join(",")} WHERE id=?`).bind(...vals).run();
  // Before the read-back, so the response carries the order the caller will see.
  if (ORDERED_TABLES.has(table) && timeMoved(stored, body)) {
    await reflowDays(db, row.trip_id, stored, merged);
  }
  const after = await db.prepare(`SELECT * FROM ${table} WHERE id=?`).bind(id).first();
  return json(hydrate(after, table === "documents" ? "documents" : table));
}

// Soft delete throughout: the audit that cleared 147 duplicates depended on
// being able to inspect what had gone, and a hard DELETE here would make the
// same mistake unrecoverable.
// The reverse of softDelete.
//
// Deleting has always been recoverable in the DATABASE -- the row keeps its
// data and gains a deleted_at -- but there was no way to exercise that from the
// app, while the delete dialog told the user "Deletes are recoverable." A
// promise the UI could not keep is worse than no promise.
//
// For a trip, only the children that went WITH it come back. softDelete stamps
// the cascade with the trip's own deleted_at, so matching that exact timestamp
// restores precisely what that delete took and leaves anything deleted earlier
// where it was. Restoring by trip_id alone would resurrect every item ever
// removed from the trip.
async function restoreDeleted(db, table, id) {
  if (!Number.isFinite(id)) return err("Bad id.", 400);
  const row = await db.prepare(`SELECT deleted_at FROM ${table} WHERE id = ?`).bind(id).first();
  if (!row) return err("Not found.", 404);
  const was = row.deleted_at;
  if (!was) return err("That is not deleted.", 409);
  const ts = nowIso();
  await db.prepare(`UPDATE ${table} SET deleted_at=NULL, updated_at=? WHERE id=?`).bind(ts, id).run();
  if (table === "trips") {
    for (const t of ["transportations", "hostings", "activities", "expenses", "documents"]) {
      await db.prepare(`UPDATE ${t} SET deleted_at=NULL, updated_at=? WHERE trip_id=? AND deleted_at=?`)
        .bind(ts, id, was).run();
    }
  }
  const back = await db.prepare(`SELECT * FROM ${table} WHERE id = ?`).bind(id).first();
  return back ? json(hydrate(back, table)) : err("Not found.", 404);
}

async function softDelete(db, table, id) {
  if (!Number.isFinite(id)) return err("Bad id.", 400);
  const ts = nowIso();
  await db.prepare(`UPDATE ${table} SET deleted_at=?, updated_at=? WHERE id=?`).bind(ts, ts, id).run();
  if (table === "trips") {
    for (const t of ["transportations", "hostings", "activities", "expenses", "documents"]) {
      await db.prepare(`UPDATE ${t} SET deleted_at=?, updated_at=? WHERE trip_id=? AND deleted_at IS NULL`)
        .bind(ts, ts, id).run();
    }
  }
  return new Response(null, { status: 204 });
}
