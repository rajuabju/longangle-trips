// What the build actually ships.
//
// Every other suite in this repo reads public/app.js -- the SOURCE. Nothing
// else looks at the file the browser receives, so a build step that broke,
// silently stopped minifying, or emitted something unparseable would pass all
// 43 suites and only fail in a browser.
//
// Sizes measured 2026-08-23: app.js 636,938 -> 282,010 raw (195KB -> 88.5KB
// gzipped), styles.css 111,780 -> 64,579, and styles.css is the only asset that
// blocks first paint.
const fs = require("fs");
const path = require("path");
const build = fs.readFileSync("build.js", "utf8");
const pkg = JSON.parse(fs.readFileSync("package.json", "utf8"));
const idx = fs.readFileSync("public/index.html", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

console.log("\nthe build minifies");
t("esbuild is a declared dependency, not borrowed from wrangler",
  !!(pkg.devDependencies && pkg.devDependencies.esbuild), true);
t("build.js requires it", /require\("esbuild"\)/.test(build), true);
t("and minifies", /minify:\s*true/.test(build), true);
// Setting a target would start transpiling, which is a much bigger change than
// minification and would ship code that was never tested in that form.
t("without setting a target", /target:/.test(build), false);
t("css goes through the css loader", /loader: ext === "css" \? "css" : "js"/.test(build), true);

console.log("\nthe hash covers what is actually served");
// Hashing the source instead would let two different shipped files share a URL,
// which is the exact bug hashed filenames exist to prevent.
t("the hash is taken over the minified text", /hashOf\(code\)/.test(build), true);
t("and the minified text is what gets written",
  /fs\.writeFileSync\(path\.join\(PUB, name\), code\)/.test(build), true);
t("the old copy-the-source path is gone", /copyFileSync/.test(build), false);

console.log("\nit refuses to ship what it cannot parse");
t("minified JS is parse-checked in the build",
  /does not parse/.test(build), true);
t("and a minifier failure stops the build",
  /could not minify/.test(build), true);

console.log("\nwhat is on disk right now");
const refs = [...new Set((idx.match(/(app|styles|qr|feasibility)\.[a-f0-9]{10}\.(js|css)/g) || []))];
// Three, not four: qr.js is loaded on demand by the ticket dialog, so it is
// deliberately absent from the page and pinned into app.js instead.
t("index.html references three hashed assets", refs.length, 3);
t("and qr.js is not one of them", refs.some((r) => r.startsWith("qr.")), false);
t("app.js carries the hashed qr filename",
  /var QR_SRC = "\/qr\.[0-9a-f]{10}\.js"/.test(fs.readFileSync("public/app.js", "utf8")), true);
// It must still be precached, or the dialog stops working on a plane.
t("the service worker still precaches it",
  /qr\.[0-9a-f]{10}\.js/.test(fs.readFileSync("public/sw.js", "utf8")), true);
t("both remaining scripts are deferred",
  (fs.readFileSync("public/index.html", "utf8").match(/<script defer src=/g) || []).length, 2);
// The skeleton must not be gated behind app.js again.
t("the dashboard section ships visible",
  /<section id="dash-view" class="dash-view">/.test(fs.readFileSync("public/index.html", "utf8")), true);
for (const r of refs) {
  const stem = r.split(".")[0];
  const ext = r.split(".").pop();
  const shipped = fs.statSync(path.join("public", r)).size;
  const source = fs.statSync(path.join("public", stem + "." + ext)).size;
  t(r.split(".")[0] + " ships smaller than its source", shipped < source, true);
  // Comment-heavy sources; anything under a 25% cut means minification silently
  // stopped working rather than the file simply being dense.
  t(stem + " is at least 25% smaller", (1 - shipped / source) > 0.25, true);
  if (ext === "js") {
    const code = fs.readFileSync(path.join("public", r), "utf8");
    let ok = true, why = "";
    try { new Function(code); } catch (e) { ok = false; why = e.message; }
    t(stem + " parses as shipped", ok, true);
    if (!ok) console.log("        " + why);
    t(stem + " really is minified (no indented function declarations)",
      /\n\s{2,}function /.test(code), false);
  }
}

console.log("\none of each helper, not two");
const appSrc = fs.readFileSync("public/app.js", "utf8");
// Two escapers with different guarantees is an invitation to reach for the
// wrong one: the old esc() round-tripped through textContent and so did NOT
// escape quotes, which is unsafe in an attribute. escapeHtml() escapes
// & < > " ' and is the only one now.
t("only one HTML escaper is defined",
  (appSrc.match(/function escapeHtml\(|var esc = function/g) || []).length, 1);
t("and it is the strict one", /function escapeHtml\(/.test(appSrc), true);
// downloadBlob was the WEAKER of three implementations -- it clicked a detached
// anchor. It is the only one now, and carries the append-to-body behaviour the
// two hand-written copies had.
t("only one blob downloader",
  (appSrc.match(/document\.body\.appendChild\(a\); a\.click\(\)/g) || []).length, 1);
t("and it appends before clicking",
  /document\.body\.appendChild\(a\); a\.click\(\); a\.remove\(\);/.test(appSrc), true);
t("the dead settings updater is gone", /function updateSetting\(/.test(appSrc), false);
// Deliberately NOT every short date in the app: the offline strip passes [] so
// it follows the browser rather than the app's own date-format setting.
t("the short-date helper exists", /function fmtMD\(d\)/.test(appSrc), true);
t("and only it builds that option object",
  (appSrc.match(/toLocaleDateString\(dateLocale\(\), \{ month: "short", day: "numeric" \}\)/g) || []).length, 1);

console.log("\nthe version marker survives minification");
// audit-app.js compares this against the source; minified it loses its spaces,
// so the check that reads it has to tolerate that.
const appRef = refs.find((r) => r.startsWith("app."));
const shippedApp = fs.readFileSync(path.join("public", appRef), "utf8");
t("the build marker is present in the shipped bundle",
  /__WAYFARER_BUILD\s*=\s*"v\d+\.\d+"/.test(shippedApp), true);
const audit = fs.readFileSync("tools/audit-app.js", "utf8");
// The needle is assembled from a char code because every quoting layer
// between here and the file eats a backslash otherwise.
var BS = String.fromCharCode(92);
t("and the audit reads it whitespace-tolerantly",
  audit.indexOf("__WAYFARER_BUILD" + BS + "s*=" + BS + 's*"') > -1, true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
