// What happens between opening the app and seeing your trips.
//
// Three things used to stand in the way, in series: boot() awaited /v1/me
// before the trips fetch started, the trips list came back as two DEPENDENT
// pages because the envelope capped at 100, and render() was gated on check
// state -- which itself awaits a serial replay of any writes queued offline.
// On a stalling network each step could wait out the service worker's
// five-second timeout, so the chain alone could cost ~15s to reach data that
// was already cached.
//
// And when it did resolve, the dashboard had been blank the whole time: the app
// never read its own last-good copy, so a complete itinerary sat in storage
// while a skeleton spun.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");
const core = fs.readFileSync("functions/api/_core.js", "utf8");

const fn = (src, decl) => {
  const i = src.indexOf(decl);
  if (i < 0) throw new Error("missing " + decl);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + decl);
};

const boot = fn(app, "  async function boot() {");
const loadAll = fn(app, "  async function loadAll() {");
const applyRole = fn(app, "  function applyRole() {");
const paintOffline = fn(app, "  function paintOffline() {");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

console.log("\nnothing waits on /v1/me any more");
// The whole point: the 91KB request must not queue behind a tiny one.
t("boot does not await it", /var me = await api\("\/v1\/me"\); state\.me/.test(boot) && !/mePromise/.test(boot), false);
t("it runs as its own promise", /var mePromise = \(async function \(\) \{/.test(boot), true);
t("and the trip load is started regardless", /\}\)\(\);\s*\/\/ Both in flight together[\s\S]*loadAll\(\);/.test(boot), true);
// Returning it means a caller can still wait for the role if it ever needs to.
t("the promise is returned rather than dropped", /return mePromise;/.test(boot), true);

console.log("\nso role gating has to be safe before the role is known");
// render() can now run first, and role gating is a class on <body>. The
// conservative default means a View account never sees a control it cannot use.
t("unknown counts as view", /var known = !!state\.me;/.test(applyRole), true);
t("and hides the controls", /var view = !known \|\| !isAdmin\(\);/.test(applyRole), true);
// But do not flash a label about someone's account while it is still in flight.
t("the View Only tag waits until the role is actually known",
  /if \(known && view && !tag\)/.test(applyRole), true);
t("and is removed again if the role becomes unknown",
  /\(!view \|\| !known\) && tag/.test(applyRole), true);
t("boot applies it before anything renders", /applyRole\(\);\s*\/\/ NOT awaited/.test(boot), true);

console.log("\none response, not two dependent ones");
t("the page size clears the dataset", /const per = 500;/.test(core), true);
t("and says why", /two DEPENDENT round trips/.test(core), true);

console.log("\ncheck state is off the render path");
t("it is fired, not awaited in the gate", /^\s*loadCheckState\(\);$/m.test(loadAll), true);
t("and is out of the Promise.all", /Promise\.all\(\[\s*apiAll\("\/v1\/trips"\),\s*api\("\/v1\/categories"\)/.test(loadAll.replace(/\n/g, "")), true);
t("the reason is recorded", /feeds the trip-detail health/.test(loadAll), true);

console.log("\npaint first, ask second");
// Declared outside the branch so the catch below can still name its timestamp.
t("a snapshot is read before the network",
  /var snap = null;/.test(loadAll) && /snap = readSnapshot\(\);/.test(loadAll), true);
t("only when there is nothing on screen", /if \(!state\.own\.length\) \{\s*snap = readSnapshot\(\);/.test(loadAll), true);
t("and saved after every good load", /saveSnapshot\(all\);/.test(loadAll), true);
t("the skeleton is only for having nothing to show", /var blank = !state\.own\.length;/.test(loadAll), true);
// The refresh and reconnect paths used to clear the list before refetching.
t("a refresh over a painted list never blanks it",
  /if \(blank\) \{ loading\.hidden = false; groups\.innerHTML = ""; \}/.test(loadAll), true);
t("the old unconditional clear is gone",
  /loading\.hidden = false; groups\.innerHTML = ""; empty\.hidden = true;/.test(loadAll), false);

console.log("\nand it says when what you are looking at is old");
t("a failed refresh over a snapshot is labelled, not replaced with an error",
  /if \(!blank\) \{[\s\S]*snapshotAt = isNaN/.test(loadAll), true);
t("a good load clears the label", /snapshotAt = null; paintOffline\(\);/.test(loadAll), true);
t("the strip understands both kinds of stale",
  /var when = lastCacheAt \|\| snapshotAt;/.test(paintOffline), true);
// Different situations, different sentences: no network vs a request that failed.
t("offline says offline", /Offline — showing what was saved /.test(paintOffline), true);
t("a failed refresh says that instead", /Couldn't refresh — showing what was saved /.test(paintOffline), true);
t("a snapshot write that fails is not an error the user hears about",
  /Quota, or private browsing/.test(app), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
