// Going back, and getting out of one layer at a time.
//
// Two faults that made the app fight the browser.
//
// Opening a trip pushed #trip/N; CLOSING it pushed another entry -- the bare
// pathname -- so one open/close left [dashboard, #trip/N, dashboard]. Back
// landed on #trip/N and the popstate handler dutifully reopened the trip the
// user had just deliberately closed. Every browse cycle added two entries, so
// leaving the installed PWA took one back-swipe per trip looked at that
// session. Measured after the fix: the stack stays constant across three
// open/close cycles.
//
// And Escape called closeDetail, which removes EVERY .form-overlay and the trip
// behind them. A reflexive Escape while typing in "Edit lodging" threw away the
// edit, the dialog, any sheet above it, and the trip -- silently. Settings ->
// Manage Calendar Feeds -> edit stacks three overlays; one keypress destroyed
// all three.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");

const fn = (decl) => {
  const i = app.indexOf(decl);
  if (i < 0) throw new Error("missing " + decl);
  let d = 0, seen = false;
  for (let j = i; j < app.length; j++) {
    if (app[j] === "{") { d++; seen = true; }
    else if (app[j] === "}") { d--; if (seen && !d) return app.slice(i, j + 1); }
  }
  throw new Error("unterminated " + decl);
};
const closeDetail = fn("  function closeDetail() {");
const handleHash = fn("  function handleHash() {");
const tearDown = fn("  function tearDownDetail() {");
const closeTop = fn("  function closeTopLayer(back) {");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

console.log("\nclosing a trip goes back rather than forward");
t("it calls history.back", /history\.back\(\);/.test(closeDetail), true);
// The old shape. If this returns, so does the reopening bug.
t("and never pushes on close", /history\.pushState/.test(closeDetail), false);
// Any app address, not just #trip/: the panels have their own now, and they
// close through this same path.
t("only when there is an entry to go back to",
  /if \(pushedDetail && location\.hash\) \{/.test(closeDetail), true);
// A deep link did not push, so back() would leave the app entirely.
t("a deep link is replaced, not popped", /history\.replaceState\(null, "", location\.pathname\)/.test(closeDetail), true);
t("opening records that it pushed", /pushedDetail = true;/.test(app), true);

console.log("\nand the teardown is separate from the navigation");
// popstate has to run the teardown too, and doing that through closeDetail
// would push history from inside a history event.
t("tearDownDetail exists", tearDown.length > 0, true);
t("it touches no history", /history\./.test(tearDown), false);
t("it still sweeps dialogs opened from inside the trip",
  /\$\$\("\.form-overlay"\)\.forEach/.test(tearDown), true);
t("and still releases the page scroll lock", /document\.body\.style\.overflow = "";/.test(tearDown), true);
t("and still destroys the map", /leafletMap\.remove\(\)/.test(tearDown), true);
t("popstate tears down instead of re-navigating", /tearDownDetail\(\);/.test(handleHash), true);
t("and clears the pushed flag", /pushedDetail = false;/.test(handleHash), true);

console.log("\nEscape peels one layer");
t("it asks for the top overlay first", /var top = topLayer\(\);/.test(app), true);
t("closes only that one", /if \(top\) \{ closeTopLayer\(top\); return; \}/.test(app), true);
t("and only reaches the trip when no dialog is left",
  /if \(!\$\("#detail-overlay"\)\.hidden\) closeDetail\(\);/.test(app), true);
// All overlays share z-index 50, so document order IS stacking order.
t("the top layer is the last one in the document",
  /return all\.length \? all\[all\.length - 1\] : null;/.test(app), true);
t("each backdrop carries its own closer", /back\.__close = function \(\)/.test(app), true);

console.log("\nand asks before throwing away typing");
t("only when something actually changed",
  /back\.__clean != null && formSnapshot\(back\) !== back\.__clean/.test(closeTop), true);
t("cancelling keeps the dialog open", /if \(!confirm\("Discard your changes\?"\)\) return false;/.test(closeTop), true);
// Built by script, so inputs never get a defaultValue to compare against --
// the snapshot has to be taken after construction finishes.
// U23 put the dialog's labelling and initial focus in the same deferred block,
// for the same reason: none of it can be done until the caller has finished
// building the panel.
t("the clean state is snapshotted after the dialog is built",
  /setTimeout\(function \(\) \{\s*\n\s*back\.__clean = formSnapshot\(back\);/.test(app), true);
t("and it is still deferred to the next tick", /\}, 0\);/.test(app), true);
t("checkboxes are compared by checked, not value",
  /\(f\.type === "checkbox" \|\| f\.type === "radio"\) \? \(f\.checked \? "1" : "0"\)/.test(app), true);

console.log("\nthe panels have addresses too");
// Only trips did. A pull-to-refresh or a PWA relaunch part-way through a triage
// session always landed on the dashboard, and there was no way to open the
// phone to the same Check Trips list the desktop was showing.
const ROUTES = ["#history", "#check", "#changes", "#calendar", "#ideas"];
ROUTES.forEach(function (h) {
  t(h + " is routable", new RegExp('"' + h + '": function \\(\\)').test(app), true);
  t("and its opener claims it", app.indexOf('panelRoute("' + h + '");') > -1, true);
});
t("the router consults the table", /var panel = PANEL_ROUTES\[location\.hash\];/.test(handleHash), true);
t("before falling through to a teardown", handleHash.indexOf("PANEL_ROUTES") < handleHash.indexOf("tearDownDetail"), true);

console.log("\nand claiming one cannot loop");
// Re-entering a panel from popstate arrives with the hash ALREADY set; pushing
// again there would trap Back between two identical entries.
t("panelRoute is a no-op when the hash already matches",
  /if \(location\.hash === hash\) return;/.test(app), true);
t("it pushes rather than replaces", /history\.pushState\(null, "", hash\);/.test(app), true);
t("and records that it owes an entry", /pushedDetail = true;/.test(app), true);

console.log("\nan address the app hands out is one it honours");
// popstate covers Back and Forward but NOT editing the address bar of an open
// tab, which is a same-document navigation firing only hashchange.
t("hashchange routes as well as popstate",
  /window\.addEventListener\("hashchange", handleHash\);/.test(app), true);
t("a deep link of any kind beats the landing preference",
  /if \(location\.hash\) return;\s*\/\/ any deep link wins/.test(app), true);

console.log("\na sweep survives drilling into a finding");
// Check Trips, Changes and Calendar render into #detail-overlay -- the same
// surface a trip uses -- so opening a trip from a finding erased the results
// and closing it landed on the dashboard. These panels exist for batch triage;
// the old shape supported fixing exactly one finding per sweep, and re-entering
// re-fetched three endpoints for every upcoming trip.
t("panels are cached", /var panelCache = \{\};/.test(app), true);
["#check", "#changes", "#calendar"].forEach(function (h) {
  t(h + " restores before rebuilding", app.indexOf('if (restorePanel("' + h + '")) return;') > -1, true);
  t(h + " caches what it built", app.indexOf('cachePanel("' + h + '", inner);') > -1, true);
});
t("restoring re-attaches rather than re-renders", /content\.appendChild\(hit\.node\);/.test(app), true);

console.log("\nand comes back where the reading left off");
t("the scroll position is recorded before the panel is replaced",
  /notePanelScroll\(\);/.test(app), true);
t("openTrip records it", /notePanelScroll\(\);\s*if \(location\.hash !== "#trip\/" \+ t\.id\)/.test(app), true);
t("and restoring applies it", /p\.scrollTop = hit\.scroll \|\| 0;/.test(app), true);
// Applied after the node is back in the document, or there is nothing to scroll.
t("after the node is in the document", /setTimeout\(function \(\) \{ p\.scrollTop/.test(app), true);

console.log("\nbut never shows you what you just fixed");
// The case this exists for: open the sweep, fix a finding, come back. Restoring
// a list that still names the thing you repaired is worse than re-running.
t("any write empties the cache", /if \(res\.ok && opts\.method && opts\.method !== "GET"\) panelCache = \{\};/.test(app), true);
t("reads leave it alone", /opts\.method !== "GET"/.test(app), true);
t("and the reason is recorded", /must not be restored still showing what you just fixed/.test(app), true);

console.log("\nCalendar stopped destroying its own entry");
// closeDetail goes BACK now, so calling it before openTrip popped #calendar and
// the panel could not be returned to. openTrip replaces the content itself.
t("day cells open the trip directly",
  app.indexOf('day.addEventListener("click", function () { openTrip(t); });') > -1, true);
t("so do the span bars",
  app.indexOf('bar.addEventListener("click", function () { openTrip(t); });') > -1, true);
t("neither closes the panel first",
  /closeDetail\(\); openTrip\(t\);/.test(app), false);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
