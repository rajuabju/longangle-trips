// The Word and PDF exports, actually executed.
//
// Redesigned 2026-08-20 to read like the Print dossier instead of a wall of
// bunched paragraphs: a time gutter, a coloured kind bar per item, real section
// headings with rules, and expenses as the table they are.
//
// Regex pins cannot prove a document draws. The Word builder is RUN against a
// fixture and its HTML inspected; the PDF builder is RUN against a stub jsPDF
// that records every call and rejects any non-finite coordinate — the failure
// mode of hand-tracked layout math is y drifting to NaN, and a NaN never
// crashes jsPDF, it just draws nothing, silently.
//
// Fixtures are invented.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");

function grab(name, prefix) {
  const key = (prefix || "  function ") + name + "(";
  const i = src.indexOf(key);
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
function grabVar(name) {
  const i = src.indexOf("  var " + name + " = ");
  if (i < 0) throw new Error("missing var " + name);
  // An object literal is brace-matched; a one-liner runs to its newline --
  // cutting at the first ";" truncated FONT inside its own string value.
  const eq = i + ("  var " + name + " = ").length;
  if (src[eq] === "{") {
    let d = 0;
    for (let j = eq; j < src.length; j++) {
      if (src[j] === "{") d++;
      else if (src[j] === "}") { d--; if (!d) return src.slice(i, src.indexOf(";", j) + 1); }
    }
    throw new Error("unterminated var " + name);
  }
  return src.slice(i, src.indexOf("\n", i)).trimEnd();
}

// Stubs for what the builders lean on but this suite is not about.
globalThis.fmtRange = () => "Jan 22 – 31, 2027";
globalThis.spanDays = () => 10;
globalThis.dayKey = (iso) => String(iso).slice(0, 10);
globalThis.dayLabel = (k) => "Day " + k;
globalThis.money = (n, c) => (n < 0 ? "-" : "") + (c || "USD") + " " + Math.abs(Number(n)).toFixed(2);
globalThis.state = { me: { default_currency: "USD" } };
globalThis.slug = (s) => String(s || "trip").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "trip";
let toasts = [];
globalThis.toast = (m) => toasts.push(m);
globalThis.loadScript = () => Promise.resolve();
// The real esc() builds a DOM node, which node has none of. Same contract:
// textContent -> innerHTML escapes & < > and leaves quotes alone.
globalThis.esc = (v) => String(v == null ? "" : v)
  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

const FIX = {
  entries: {
    scheduled: [
      // The metas are the REAL shapes buildEntries makes. Short fixture times
      // like "9:57 AM" hid the overlap bug: a flight's actual meta is ~123pt
      // wide and the gutter is 64.
      { kind: "transport", icon: "✈️", meta: "Dep 9:57 AM · Arr 12:39 PM", title: "Alaska AS1412 LAX → LIR",
        sub: "Los Angeles (LAX) → Liberia (LIR)", when: "2027-01-22T16:57:00Z",
        obj: { provider_reservation_code: "DZQKRT",
          notes: "Cancellation: non-refundable after 24h. Deposit $200 due at booking. Mileage Plan 1234." } },
      { kind: "transport", icon: "🚗", meta: "Pick-up 12:00 PM", title: "Adobe Rent a Car · Pick-up",
        sub: "Liberia Airport office", when: "2027-01-22T19:00:00Z", obj: {} },
      { kind: "hosting", icon: "🏨", meta: "4:00 PM", title: "Nayara Tented Camp · Check-in",
        sub: "La Fortuna, Alajuela, Costa Rica", when: "2027-01-22T22:00:00Z", obj: {} },
      { kind: "activity", icon: "🍽️", meta: "7:30 PM", title: "Dinner at Amor Loco",
        when: "2027-01-23T01:30:00Z", obj: {} },
    ],
    unscheduled: [{ kind: "activity", icon: "📍", title: "Find a coffee place", obj: {} }],
  },
  data: {
    activities: [{ id: 50, name: "Amor Loco", activity_type: "restaurant" }],
    expenses: [
      { id: 1, title: "Alaska AS1412 — taxes", price: 121.05, currency: "USD",
        linked_kind: "transport", linked_id: 9 },
      { id: 2, title: "Dinner at Amor Loco", price: 240, currency: "USD",
        linked_kind: "activity", linked_id: 50 },
      { id: 3, title: "Cancelled night refunded", price: 300, currency: "USD", category: "Credit" },
    ],
  },
};
globalThis.orderedEntries = () => FIX.entries;

eval([grabVar("BUDGET_CATS"), grabVar("KIND_CAT"), grabVar("CREDIT_CAT"),
  grabVar("DINING_CAT"), grabVar("DINING_TYPES"),
  grab("signedAmount"), grab("linkCategory"), grab("linkedItem"),
  grab("exportPdf", "  async function "),
  grab("exportWord", "  async function ")].join("\n") +
  ";Object.assign(globalThis,{CREDIT_CAT,signedAmount,linkCategory," +
  "linkedItem,exportPdf,exportWord});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

console.log("\nthe PDF, drawn against a recording stub");
function StubDoc() {
  const self = this;
  this.pages = 1; this.texts = []; this.rects = []; this.lines = []; this.saved = null;
  this._size = 10;
  this.internal = { pageSize: { getWidth: () => 612, getHeight: () => 792 } };
  const fin = (v, what) => { if (!Number.isFinite(v)) throw new Error("non-finite " + what + ": " + v); return v; };
  this.setFont = () => {}; this.setFontSize = (n) => { self._size = n; };
  this.getTextWidth = (t) => String(t).length * self._size * 0.52;
  this.setTextColor = (r, g, b) => { self._ink = [r, g, b]; };
  this.setDrawColor = () => {}; this.setLineWidth = () => {}; this.setFillColor = () => {};
  this.splitTextToSize = (txt, w) => {
    // Real jsPDF honours embedded newlines before width-wrapping; the stub
    // must too, or the label-break trick ("Pick-up\n12:00 PM") never splits
    // here and the suite fails code the real renderer draws correctly.
    const per = Math.max(8, Math.round(fin(w, "wrap width") / (self._size * 0.52)));
    const out = [];
    String(txt).split("\n").forEach((seg) => {
      while (seg.length > per) { out.push(seg.slice(0, per)); seg = seg.slice(per); }
      out.push(seg);
    });
    return out;
  };
  this.text = (txt, x, y, opts) => { fin(x, "x"); fin(y, "y"); self.texts.push({ txt: String(txt), x, y, size: self._size, page: self.pages, ink: self._ink, align: opts && opts.align }); };
  this.line = (a, b, c, d) => { [a, b, c, d].forEach((v) => fin(v, "line")); self.lines.push([a, b, c, d]); };
  this.rect = (x, y, w, h, st) => { [x, y, w, h].forEach((v) => fin(v, "rect")); self.rects.push({ x, y, w, h, st }); };
  this.addPage = () => { self.pages++; };
  this.setPage = (i) => { if (i < 1 || i > self.pages) throw new Error("setPage " + i + " of " + self.pages); };
  this.getNumberOfPages = () => self.pages;
  this.save = (name) => { self.saved = name; };
}
let stub;
globalThis.window = { jspdf: { jsPDF: function () { stub = new StubDoc(); return stub; } } };

(async () => {
  const btn = { textContent: "PDF", disabled: false };
  await exportPdf({ name: "Costa Rica", has_dates: true }, FIX.data, btn);
  t("it saved rather than toasting a failure", toasts, []);
  t("with the slug filename", stub.saved, "costa-rica.pdf");
  t("every coordinate was finite (the stub would have thrown)", !!stub.saved, true);
  t("the button was restored", [btn.textContent, btn.disabled], ["PDF", false]);
  const all = stub.texts.map((x) => x.txt);
  t("the title is drawn", all.indexOf("Costa Rica") >= 0, true);

  // The clarity complaint, pinned. Helvetica is WinAnsi: it has no emoji and no
  // arrow, and jsPDF does not reject them — it writes their code units as
  // single bytes, so "✈️ Alaska → LIR" printed as garbage ("ØØ Alaska Ø LIR").
  // Every drawn string must be inside the set the font can actually shape.
  const SAFE = /^[\x20-\x7E\xA0-\xFF–—‘’“”•…]*$/;
  const unsafe = stub.texts.filter((x) => !SAFE.test(x.txt));
  t("every drawn string is inside Helvetica's glyph set", unsafe.map((x) => x.txt), []);
  t("the arrow became an en dash, not a dropped word",
    all.some((x) => /Alaska AS1412 LAX – LIR/.test(x)), true);
  t("no emoji reached the page", all.some((x) => /[✈\uD83C-\uD83E]/.test(x)), false);
  // ---- the gutter never invades the content column ----
  //
  // The overlap bug, pinned: a flight's meta ("Dep 9:57 AM · Arr 12:39 PM")
  // is twice the gutter's width, and drawn as one run it printed straight
  // through the bold title on the same baseline. It must arrive as stacked
  // clauses now, every one of them narrow enough to stay left of x=126.
  // Scoped by draw order: expense descriptions also draw at x=54 size 9.5 and
  // are legitimately wide -- the gutter rule applies to the itinerary, which is
  // everything before the Expenses heading.
  const expIdx = stub.texts.findIndex((x) => x.txt === "Expenses");
  const gutterTexts = stub.texts.filter((x, i) => x.x === 54 && x.size === 9.5 && i < expIdx);
  t("every gutter line fits the gutter",
    gutterTexts.filter((x) => x.txt.length * 9.5 * 0.52 > 70).map((x) => x.txt), []);
  t("the flight meta stacked into its clauses",
    ["Dep 9:57 AM", "Arr 12:39 PM"].every((c) => gutterTexts.some((x) => x.txt === c)), true);
  t("a too-wide clause breaks after its label, not mid-time",
    gutterTexts.some((x) => x.txt === "Pick-up") && gutterTexts.some((x) => x.txt === "12:00 PM"), true);
  t("no orphaned fragment like a bare PM",
    gutterTexts.some((x) => x.txt === "PM" || x.txt === "AM"), false);
  t("stacked clauses descend, never share a baseline",
    (() => { const d = gutterTexts.filter((x) => x.txt === "Dep 9:57 AM")[0];
      const a = gutterTexts.filter((x) => x.txt === "Arr 12:39 PM")[0];
      return d && a && a.y > d.y && a.page === d.page; })(), true);
  t("kind bars are drawn as filled rects",
    stub.rects.filter((r) => r.st === "F" && r.w === 2.5).length >= 4, true);
  t("the amount column is right-aligned",
    stub.texts.filter((x) => /USD /.test(x.txt)).every((x) => x.align === "right"), true);
  t("the credit was inked green before drawing",
    stub.texts.some((x) => x.txt === "-USD 300.00" && x.ink && x.ink[0] === 31 && x.ink[1] === 122), true);
  t("the signed total is drawn", all.indexOf("USD 61.05") >= 0, true);
  const footers = stub.texts.filter((x) => / of /.test(x.txt));
  t("every page carries its number", footers.length, stub.pages);
  t("and knows the real page count",
    footers.every((x) => x.txt.indexOf("of " + stub.pages) >= 0), true);


  // ---- the Word document, as OOXML against a recording stub ----
  //
  // The .doc was HTML in a costume; this is the real format, built object by
  // object. The real artifact was verified once by unzipping document.xml --
  // title, kind bars, CONF, excluded notes, three subtotal rows, the green
  // negative credit and the grand total all present. This stub keeps the
  // construction honest from here on.
  console.log("\nthe Word document, as OOXML");
  function Rec(tag) { return class { constructor(o) { this.$ = tag; this._ = o || {}; } }; }
  const Dstub = {
    Document: Rec("doc"), Paragraph: Rec("para"), TextRun: Rec("run"),
    Table: Rec("table"), TableRow: Rec("tr"), TableCell: Rec("tc"),
    Packer: { toBlob: async (d) => ({ _doc: d }) },
    BorderStyle: { SINGLE: "single", NONE: "none" },
    WidthType: { PERCENTAGE: "pct", DXA: "dxa" },
    ShadingType: { CLEAR: "clear" },
    AlignmentType: { RIGHT: "right" },
  };
  globalThis.dayKey = (u) => (u ? String(u).slice(0, 10) : null);
  globalThis.DOC_PARENT = { transport: "transportation", hosting: "hosting", activity: "activity", expense: "expense" };
  globalThis.docsFor = () => [];
  eval([grab("priceCurrency"), grab("budgetLines"), grab("budgetCategories"), grab("bookingDate"),
    grab("expenseRows"), grab("expenseSheet"),
    grab("exportExpensesXlsx", "  async function ")].join("\n") +
    ";Object.assign(globalThis,{expenseSheet,exportExpensesXlsx});");
  window.docx = Dstub;
  let savedDoc = null, savedDocName = null;
  globalThis.downloadBlob = (blob, name) => { savedDoc = blob._doc; savedDocName = name; };

  await exportWord({ name: "Costa Rica", has_dates: true }, FIX.data, null);
  t("it saved a .docx", savedDocName, "costa-rica.docx");

  const runs = [], cells = [];
  (function walk(node) {
    if (node == null || typeof node !== "object") return;
    if (node.$ === "run") runs.push(node._);
    if (node.$ === "tc") cells.push(node._);
    const o = node._ || node;
    ["children", "rows", "sections"].forEach((k) => {
      const v = o[k];
      if (Array.isArray(v)) v.forEach((x) => { walk(x); if (x && x.children) x.children.forEach(walk); });
    });
  })(savedDoc);
  const texts = runs.map((r) => r.text);

  t("the title is bold at 21pt (42 half-points)",
    runs.some((r) => r.text === "Costa Rica" && r.bold && r.size === 42), true);
  t("day headings carry the accent", runs.some((r) => /^Day /.test(r.text || "") && r.color === "2F6DF6" && r.bold), true);
  t("the gutter is a 78pt DXA cell holding the meta",
    cells.some((c) => c.width && c.width.size === 1560 && c.width.type === "dxa"), true);
  t("the flight meta rides in a run", texts.indexOf("Dep 9:57 AM · Arr 12:39 PM") >= 0, true);
  const kindBars = cells.filter((c) => c.borders && c.borders.left && c.borders.left.style === "single")
    .map((c) => c.borders.left.color);
  t("kind bars in all three colours",
    ["2F6DF6", "7C3AED", "B45309"].every((k) => kindBars.indexOf(k) >= 0), true);
  t("the confirmation reads as a small faint label",
    runs.some((r) => r.text === "CONF  DZQKRT" && r.size === 17 && r.color === "8A919C"), true);
  t("the fine print stays out of the document",
    texts.some((x) => /Cancellation: non-refundable/.test(x || "")), false);
  t("the expense header is white on the accent",
    cells.some((c) => c.shading && c.shading.fill === "2F6DF6"), true);
  t("a subtotal row closes the Dining section",
    runs.some((r) => r.text === "Subtotal Dining" && r.bold), true);
  t("on the pale structural blue",
    cells.some((c) => c.shading && c.shading.fill === "DCE6F8"), true);
  t("the credit prints green and negative",
    runs.some((r) => r.text === "-USD 300.00" && r.color === "1F7A4D"), true);
  t("the grand total is bold over a rule",
    runs.some((r) => r.text === "TOTAL USD" && r.bold) &&
    cells.some((c) => c.borders && c.borders.top && c.borders.top.style === "single" && c.borders.top.color === "1E2430"), true);
  t("and it sums signed: 121.05 + 240 - 300", texts.indexOf("USD 61.05") >= 0, true);

  // ---- the styled expense report (.xlsx) ----
  //
  // CSV cannot carry formatting, so the report a person reads is a real .xlsx.
  // The real artifact was verified once by unzipping it: 6 bold fonts, the
  // blue header fill, zebra, the green credit, medium borders and numFmtId 4
  // all present in styles.xml. This stub keeps the glue honest from here on.
  console.log("\nthe styled expense report");
  const XDATA = { activities: [{ id: 50, name: "Amor Loco", activity_type: "restaurant" }],
    expenses: [
      { id: 1, title: "Alaska AS1412 — taxes on award ticket, five passengers, conf DZQKRT",
        price: 121.05, currency: "USD", date: "2027-01-22" },
      { id: 2, title: "Dinner", price: 240, currency: "USD", date: "2027-01-23",
        linked_kind: "activity", linked_id: 50 },
      { id: 3, title: "Cancelled night refunded", price: 300, currency: "USD",
        date: "2027-01-25", category: "Credit" },
      { id: 4, title: "Souvenir", price: 90, currency: "EUR", date: "2027-01-26" },
    ] };

  const sheet = expenseSheet({ name: "Costa Rica" }, XDATA);
  // Grouped by category in the Budget panel's order, chronological inside each
  // group, a subtotal per category per currency, grand totals last. Zebra
  // restarts per section.
  t("the report reads by section",
    sheet.lines.map((l) => l.kind + ":" + l.cells[2]),
    ["row:Dinner", "subtotal:Subtotal Dining",
     "row:Alaska AS1412 — taxes on award ticket, five passengers, conf DZQKRT",
     "row:Souvenir", "subtotal:Subtotal Other", "subtotal:Subtotal Other",
     "row:Cancelled night refunded", "subtotal:Subtotal Credit",
     "total:TOTAL EUR", "total:TOTAL USD"]);
  t("the multi-currency section subtotals per currency",
    sheet.lines.filter((l) => l.kind === "subtotal" && l.cells[2] === "Subtotal Other")
      .map((l) => l.cells[6] + " " + l.cells[5].toFixed(2)),
    ["EUR 90.00", "USD 121.05"]);
  t("every column is at least as wide as its longest value, capped",
    sheet.widths.every((w, c) => {
      const longest = Math.max(String(sheet.header[c]).length,
        ...sheet.lines.map((l) => {
          const v = l.cells[c]; return v == null ? 0 : (c === 5 && typeof v === "number" ? v.toFixed(2) : String(v)).length;
        }));
      return w >= Math.min(56, longest) && w <= 56 && w >= 9;
    }), true);
  t("the 67-character description hits the cap, not the ceiling", sheet.widths[2], 56);
  t("the credit row is marked", sheet.lines.filter((l) => l.credit).map((l) => l.cells[2]),
    ["Cancelled night refunded"]);
  t("amounts stay numeric for Excel to sum",
    sheet.lines.every((l) => typeof l.cells[5] === "number"), true);
  t("zebra restarts per section",
    sheet.lines.filter((l) => l.kind === "row").map((l) => l.zebra), [false, false, true, false]);

  // The glue, against a stub XLSX shaped like the real utils.
  const encc = (r, c) => "ABCDEFGHIJ"[c] + (r + 1);
  let savedWb = null, savedName = null;
  globalThis.window.XLSX = { utils: {
    aoa_to_sheet: (aoa) => { const ws = {}; aoa.forEach((row, r) => row.forEach((v, c) => {
      if (v != null) ws[encc(r, c)] = { v: v, t: typeof v === "number" ? "n" : "s" }; }));
      ws["!ref"] = "A1:J" + aoa.length; return ws; },
    book_new: () => ({ Sheets: {}, SheetNames: [] }),
    book_append_sheet: (wb, ws, n) => { wb.Sheets[n] = ws; wb.SheetNames.push(n); },
  }, writeFile: (wb, name) => { savedWb = wb; savedName = name; } };

  await exportExpensesXlsx({ name: "Costa Rica", starts_at: "2027-01-22" }, XDATA, null);
  const xws = savedWb.Sheets[savedWb.SheetNames[0]];
  t("it saved with the trip in the filename", savedName, "expenses-costa-rica-2027-01-22.xlsx");
  t("the sheet is named for the trip", savedWb.SheetNames[0], "Costa Rica");
  t("column widths reach the file", (xws["!cols"] || []).map((c) => c.wch), sheet.widths);
  t("the header row has a filter", xws["!autofilter"].ref, "A1:J" + sheet.rowCount);
  t("headings are bold on the accent fill",
    ["A1","B1","C1","D1","E1","F1","G1","H1","I1","J1"].every((k) =>
      xws[k] && xws[k].s && xws[k].s.font && xws[k].s.font.bold &&
      xws[k].s.fill && xws[k].s.fill.fgColor.rgb === "2F6DF6"), true);
  t("the amount heading is right-aligned like its column",
    xws.F1.s.alignment.horizontal, "right");
  const creditRow = 2 + sheet.lines.findIndex((l) => l.credit);
  t("the credit amount is green, bold and negative",
    xws["F" + creditRow].v === -300 && xws["F" + creditRow].s.font.color.rgb === "1F7A4D" &&
    xws["F" + creditRow].s.font.bold === true, true);
  const subRow = 2 + sheet.lines.findIndex((l) => l.kind === "subtotal");
  t("subtotal rows are bold on the structural blue",
    xws["C" + subRow].s.font.bold === true &&
    xws["C" + subRow].s.fill.fgColor.rgb === "DCE6F8", true);
  const totalRow = 2 + sheet.lines.findIndex((l) => l.kind === "total");
  t("totals carry the bold top border",
    xws["C" + totalRow].s.font.bold === true &&
    xws["C" + totalRow].s.border.top.style === "medium", true);
  t("amounts carry the two-decimal number format",
    xws.F2.s.numFmt, "#,##0.00");

  console.log("\n  " + pass + " passed, " + fail + " failed");
  process.exit(fail ? 1 : 0);
})();
