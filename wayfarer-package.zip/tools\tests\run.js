// Runs every suite in this directory and sums the result.
//
//   npm test
//
// These are pure-logic tests: each one reads the real function out of
// public/app.js and exercises it against synthetic fixtures, so a suite cannot
// drift from the code it covers — if a function is renamed or removed, the
// suite fails loudly instead of quietly testing a stale copy.
//
// Deliberately no data dumps. An earlier draft shipped 1.5MB of real trips
// alongside these, which meant confirmation codes, addresses, phone numbers and
// passenger names in the repository. Anything needing live data belongs in a
// scratch directory, never here.
const { execFileSync } = require("child_process");
const fs = require("fs");
const path = require("path");

const dir = __dirname;
const suites = fs.readdirSync(dir).filter((f) => f.endsWith(".js") && f !== "run.js").sort();

let passed = 0, failed = 0, broken = 0;
for (const s of suites) {
  let out = "";
  try {
    out = execFileSync(process.execPath, [path.join(dir, s)], { encoding: "utf8", cwd: path.join(dir, "..", "..") });
  } catch (e) {
    out = (e.stdout || "") + (e.stderr || "");
  }
  const m = out.match(/(\d+) passed, (\d+) failed/);
  if (!m) {
    broken++;
    console.log("  " + s.padEnd(14) + "DID NOT REPORT — suite is broken");
    console.log(out.split("\n").slice(-6).map((l) => "      " + l).join("\n"));
    continue;
  }
  passed += Number(m[1]);
  failed += Number(m[2]);
  const bad = Number(m[2]) > 0;
  console.log("  " + s.padEnd(14) + m[1] + " passed" + (bad ? ", " + m[2] + " FAILED" : ""));
  if (bad) console.log(out.split("\n").filter((l) => /FAIL/.test(l)).map((l) => "    " + l).join("\n"));
}

console.log("\n  " + suites.length + " suites · " + passed + " passed · " + failed + " failed" +
  (broken ? " · " + broken + " broken" : ""));
process.exit(failed || broken ? 1 : 0);
