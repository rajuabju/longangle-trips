// Feasibility rules — "could a body actually do this?"
//
// The trip check in app.js compares items of the same kind: flight to flight,
// car return to flight, parking to flight. That misses a whole class of defect
// where every individual booking is fine but the sequence is impossible.
//
// The case that prompted this: Costa Rica, Jan 2027. AS1412 lands at LIR at
// 6:25pm. The Waldorf Astoria check-in was stored as 3:00pm the same day —
// because 3:00pm is the PROPERTY'S check-in policy, which is what the
// confirmation email says, and the importer recorded it faithfully. Nothing
// caught it: not open-ended, not an overlap, not outside the trip dates, and
// the car pickup was genuinely after landing. The itinerary simply claimed you
// were in a hotel three and a half hours before your plane touched down.
//
// So this module models presence. Two assertions:
//   1. You cannot be at a place before you have ARRIVED in that region.
//   2. Moving between two places TAKES TIME.
//
// Everything here is pure — no DOM, no network, no app helpers — so app.js and
// the batch auditor in tools/ run identical logic. Loaded as a plain script in
// the browser; require()d for its global in Node.
(function (root) {
  "use strict";

  var MIN = 60000, HOUR = 3600000;

  // ---- geometry ----------------------------------------------------------
  function km(aLat, aLon, bLat, bLon) {
    if (aLat == null || bLat == null || aLon == null || bLon == null) return null;
    var R = 6371, p = Math.PI / 180;
    var dLat = (bLat - aLat) * p, dLon = (bLon - aLon) * p;
    var s = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(aLat * p) * Math.cos(bLat * p) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    return R * 2 * Math.atan2(Math.sqrt(s), Math.sqrt(1 - s));
  }

  // Ground travel time from a straight-line distance, with no routing API and
  // no key. Two corrections to the great circle: roads wind (more so over short
  // and mountainous distances), and average speed rises with distance as you
  // spend proportionally longer on trunk roads.
  //
  // Deliberately OPTIMISTIC. This check exists to catch impossibilities, not to
  // second-guess an ambitious afternoon. If the estimate is wrong it should be
  // wrong in the direction of staying quiet.
  function driveMinutes(distKm) {
    if (distKm == null) return null;
    if (distKm < 1) return 0;
    var factor = distKm < 5 ? 1.6 : distKm < 25 ? 1.45 : distKm < 100 ? 1.35 : 1.25;
    var roadKm = distKm * factor;
    var kph = roadKm < 5 ? 30 : roadKm < 25 ? 45 : roadKm < 100 ? 65 : 80;
    return (roadKm / kph) * 60;
  }

  // Wheels-down to standing outside the terminal with your bags. Crossing into
  // another timezone usually means immigration, so the allowance grows.
  function airportExitMinutes(leg) {
    var far = (leg.departure_timezone || "") !== (leg.arrival_timezone || "");
    return far ? 50 : 30;
  }

  // ---- local time --------------------------------------------------------
  // Stored times are UTC instants; the timezone column says how to read them.
  // Intl is the only thing that gets DST right, and it exists in both runtimes.
  function localParts(iso, tz) {
    var t = Date.parse(iso);
    if (isNaN(t)) return null;
    try {
      var f = new Intl.DateTimeFormat("en-CA", {
        timeZone: tz || "UTC", hour12: false,
        year: "numeric", month: "2-digit", day: "2-digit",
        hour: "2-digit", minute: "2-digit"
      });
      var g = {};
      f.formatToParts(new Date(t)).forEach(function (p) { g[p.type] = p.value; });
      var hh = parseInt(g.hour, 10) % 24;             // some ICU builds emit 24
      return {
        date: g.year + "-" + g.month + "-" + g.day,
        hour: hh, minute: parseInt(g.minute, 10),
        minutes: hh * 60 + parseInt(g.minute, 10),
        text: String(hh).padStart(2, "0") + ":" + g.minute
      };
    } catch (e) { return null; }
  }

  function clockLabel(iso, tz) {
    var p = localParts(iso, tz);
    if (!p) return "";
    var h = p.hour % 12 || 12, ap = p.hour < 12 ? "am" : "pm";
    return h + (p.minute ? ":" + String(p.minute).padStart(2, "0") : "") + ap;
  }
  function dateLabel(iso, tz) {
    var p = localParts(iso, tz);
    if (!p) return "";
    var d = new Date(p.date + "T12:00:00Z");
    return d.toLocaleDateString(undefined, { timeZone: "UTC", weekday: "short", day: "numeric", month: "short" });
  }
  function dur(ms) {
    var m = Math.round(Math.abs(ms) / MIN);
    if (m < 60) return m + " min";
    var h = Math.floor(m / 60), r = m % 60;
    return h + "h" + (r ? String(r).padStart(2, "0") : "");
  }

  // ---- classification ----------------------------------------------------
  // A flight moves you. A hire car is a RESOURCE you hold for a week — it does
  // not explain your position at any given moment, and treating it as a moving
  // leg would silently suppress every ground check for the whole trip.
  var LEG_TYPES = /^(airplane|train|ferry|boat|bus|shuttle|subway|tram|helicopter)$/;
  var RESOURCE_TYPES = /^(car|roadtrip|bike|motorcycle|rv|campervan)$/;
  function isLeg(x) { return LEG_TYPES.test(x.transportation_type || ""); }
  function isResource(x) { return RESOURCE_TYPES.test(x.transportation_type || ""); }

  function legLabel(x) {
    return [x.company, x.transport_number].filter(Boolean).join(" ") ||
      (x.transportation_type ? x.transportation_type[0].toUpperCase() + x.transportation_type.slice(1) : "Transport");
  }

  // Round an instant up to the next quarter hour — suggested times should look
  // like something a person would write, not 20:26.
  function roundUp15(ms) { return Math.ceil(ms / (15 * MIN)) * (15 * MIN); }

  // ---- the audit ---------------------------------------------------------
  // Returns findings shaped like app.js's own: {level, title, detail}, plus
  // `ref` so the caller can hang the right fix button on it, and `suggest`
  // with a computed replacement time where one can be derived.
  //
  // `soft: true` marks a finding as being about data that is MISSING or merely
  // advisory, rather than data that is WRONG. Callers drop those once a trip is
  // over: no confirmation number can be added to a flight already flown, and a
  // tight connection you in fact made is not a defect. Anything duplicated or
  // factually impossible is never soft — it distorts totals, the map and the
  // history itself, so it stays worth fixing forever.
  // 0,0 is the Gulf of Guinea. Nothing is ever there — it is what a failed
  // geocode leaves behind, and it reads as a real coordinate to every distance
  // check downstream, which is how a Denver airport hotel ended up "11254 km"
  // from Denver. Treat it as absent.
  function nullIsland(lat, lon) {
    return lat != null && lon != null && Math.abs(lat) < 0.01 && Math.abs(lon) < 0.01;
  }
  function scrub(x, latKey, lonKey) {
    if (nullIsland(x[latKey], x[lonKey])) { x = Object.assign({}, x); x[latKey] = null; x[lonKey] = null; }
    return x;
  }

  // Two records are the same booking only if the CONFIRMATION matches too.
  // Matching on name and times alone is actively dangerous: a family that books
  // two hotel rooms, or splits fourteen people across two PNRs on one flight,
  // produces records identical in every visible field. Mexico City has both —
  // one hotel under 1231881 and 26627302, one flight under MOOWBR and HJ2JL9
  // with different seat blocks. Telling someone to delete half of that would
  // lose a real reservation. Distinct confirmations mean distinct bookings;
  // only when they agree (or are both absent) is it the same thing stored twice.
  function dupKey(x, kind) {
    var conf = (x.provider_reservation_code || "").trim().toLowerCase();
    if (kind === "transport") {
      return ["t", x.transportation_type || "", (x.company || "") + (x.transport_number || ""),
        x.departure_at || "", x.arrival_at || "", conf, (x.seat_number || "").trim()].join("|").toLowerCase();
    }
    return [kind[0], (x.name || "").trim(), x.starts_at || "", x.ends_at || "", conf].join("|").toLowerCase();
  }

  // A single flight does not last a day. Anything that claims to has a wrong
  // date on one end, and — more importantly — must be kept out of the presence
  // model, or it swallows the whole trip and every stay inside it looks
  // impossible. The longest scheduled passenger flights run about 19 hours.
  function legHours(x) { return (Date.parse(x.arrival_at) - Date.parse(x.departure_at)) / HOUR; }
  function legTooLong(x) {
    var h = legHours(x);
    return h > ((x.transportation_type === "airplane") ? 20 : 30);
  }

  function audit(input) {
    var trans = (input.transports || []).filter(Boolean)
      .map(function (x) { return scrub(scrub(x, "departure_latitude", "departure_longitude"), "arrival_latitude", "arrival_longitude"); });
    var host = (input.hostings || []).filter(Boolean).map(function (x) { return scrub(x, "latitude", "longitude"); });
    var acts = (input.activities || []).filter(Boolean).map(function (x) { return scrub(x, "latitude", "longitude"); });
    var out = [];
    var add = function (f) { out.push(f); };

    // ---- G0. duplicates, and legs whose dates cannot be right -------------
    // Both run first: they report once, then remove themselves from the data
    // so the position rules below aren't reasoning about corrupted input.
    var seen = {}, dupes = [];
    var keep = function (list, kind) {
      return list.filter(function (x) {
        var k = dupKey(x, kind);
        if (seen[k]) { dupes.push({ kind: kind, item: x }); return false; }
        seen[k] = true; return true;
      });
    };
    trans = keep(trans, "transport"); host = keep(host, "hosting"); acts = keep(acts, "activity");
    if (dupes.length) {
      var names = dupes.map(function (d) {
        return d.kind === "transport" ? legLabel(d.item) : (d.item.name || "an item");
      });
      add({
        level: "issue",
        title: dupes.length === 1 ? "A booking is stored twice" : dupes.length + " bookings are stored twice",
        detail: names.slice(0, 4).join(", ") + (names.length > 4 ? " and " + (names.length - 4) + " more" : "") +
          " appear more than once with the same times AND the same confirmation number, so this is one booking stored twice " +
          "rather than a second room or a second party — those would carry different confirmations. " +
          "Duplicates double the budget total and show twice on every day.",
        ref: { kind: dupes[0].kind, id: dupes[0].item.id },
        duplicates: dupes.map(function (d) { return { kind: d.kind, id: d.item.id, name: d.kind === "transport" ? legLabel(d.item) : d.item.name }; })
      });
    }

    // Null island is worth naming on its own: unlike a missing coordinate it
    // renders — as a map pin in the Atlantic, a thousand miles from anywhere.
    var atSea = [];
    (input.transports || []).forEach(function (x) {
      if (nullIsland(x.departure_latitude, x.departure_longitude) ||
          nullIsland(x.arrival_latitude, x.arrival_longitude)) atSea.push(legLabel(x));
    });
    (input.hostings || []).concat(input.activities || []).forEach(function (x) {
      if (x && nullIsland(x.latitude, x.longitude)) atSea.push(x.name || "An item");
    });
    if (atSea.length) {
      add({
        level: "warn",
        title: atSea.length + " item" + (atSea.length === 1 ? " has" : "s have") + " coordinates of 0, 0",
        detail: atSea.slice(0, 4).join(", ") + (atSea.length > 4 ? "…" : "") +
          " sits at latitude 0, longitude 0 — the Gulf of Guinea. That is what a failed lookup leaves behind, " +
          "and it puts a pin in the middle of the ocean on the trip map. Re-run “🔎 Find” on the address, or clear the coordinates.",
        ref: null, soft: true
      });
    }

    var allLegs = trans.filter(function (x) { return isLeg(x) && x.departure_at && x.arrival_at; })
      .sort(function (a, b) { return Date.parse(a.departure_at) - Date.parse(b.departure_at); });
    var broken = allLegs.filter(legTooLong);
    broken.forEach(function (f) {
      add({
        level: "issue",
        title: legLabel(f) + " lasts " + Math.round(legHours(f)) + " hours",
        detail: legLabel(f) + " is stored as leaving " + (f.departure_description || "") + " on " +
          dateLabel(f.departure_at, f.departure_timezone) + " and arriving " +
          (f.arrival_description || "") + " on " + dateLabel(f.arrival_at, f.arrival_timezone) +
          ". No flight runs that long — one end has the wrong date. " +
          "Check whether this duplicates another copy of the same flight with the right dates.",
        ref: { kind: "transport", id: f.id }
      });
    });
    var legs = allLegs.filter(function (f) { return !legTooLong(f); });

    // Everything that pins you to a place at a time. Transport contributes two
    // anchors (you leave from here, you land there); a stay and an activity one
    // each. `free` marks an anchor whose time is a policy or a default rather
    // than an observation — those are the ones allowed to move.
    var anchors = [];
    trans.forEach(function (x) {
      if (x.departure_at) anchors.push({
        at: Date.parse(x.departure_at), lat: x.departure_latitude, lon: x.departure_longitude,
        tz: x.departure_timezone, name: legLabel(x) + (isResource(x) ? " pick-up" : " departs"),
        kind: "transport", item: x, leg: isLeg(x)
      });
      if (x.arrival_at) anchors.push({
        at: Date.parse(x.arrival_at), lat: x.arrival_latitude, lon: x.arrival_longitude,
        tz: x.arrival_timezone, name: legLabel(x) + (isResource(x) ? " drop-off" : " lands"),
        kind: "transport", item: x, leg: isLeg(x), landing: isLeg(x), end: true
      });
    });
    host.forEach(function (h) {
      if (h.starts_at) anchors.push({
        at: Date.parse(h.starts_at), lat: h.latitude, lon: h.longitude, tz: h.timezone,
        name: h.name || "Lodging", kind: "hosting", item: h, free: true
      });
    });
    acts.forEach(function (a) {
      // Airport parking is a resource held for the whole trip, not a place you
      // must be at a moment: it starts when you drop the car at your ORIGIN and
      // runs until you collect it. Treated as a position it teleports you home
      // mid-trip. app.js already checks parking against the returning flight,
      // which is the question actually worth asking about it.
      if (a.activity_type === "parking") return;
      if (a.starts_at) anchors.push({
        at: Date.parse(a.starts_at), lat: a.latitude, lon: a.longitude, tz: a.timezone,
        name: a.name || "Activity", kind: "activity", item: a
      });
    });
    anchors = anchors.filter(function (a) { return !isNaN(a.at); })
      .sort(function (a, b) { return a.at - b.at; });

    // ---- G1. you cannot be there at that time ----------------------------
    // Scheduled legs partition the trip into intervals, and in each one your
    // position is known: before the first departure you are at that departure
    // point; between two legs you are wherever the earlier one put you; during
    // a leg you are in transit. Anything that claims otherwise is impossible.
    //
    // Deriving position this way, rather than looking for the nearest arrival,
    // is what distinguishes "hotel booked before your plane lands" from
    // "airport parking that starts before your return flight gets back" — the
    // second is normal, and a nearest-arrival rule flags it every time.
    var REGION_KM = 250;
    var TRANSIT_EDGE = 30 * MIN;   // slop at each end for boarding and deplaning

    anchors.forEach(function (a) {
      if (a.kind === "transport" || a.lat == null) return;
      var p = presenceAt(a.at, legs);
      if (!p) return;

      var lp = localParts(anchorTime(a), a.tz);
      var when = clockLabel(anchorTime(a), a.tz) + " on " + dateLabel(anchorTime(a), a.tz);
      // A stay whose check-in sits exactly on a round afternoon hour is the
      // signature of an imported policy time rather than a real arrival.
      var policyish = a.kind === "hosting" && lp && lp.minute === 0 && lp.hour >= 14 && lp.hour <= 16;

      if (p.kind === "transit") {
        var f = p.leg;
        add({
          level: "issue",
          title: a.name + (a.kind === "hosting" ? " starts before you land" : " is scheduled mid-flight"),
          detail: a.name + " is on your itinerary at " + when + ", but you are on " + legLabel(f) +
            " at that moment — it leaves " + (f.departure_description || "") + " at " +
            clockLabel(f.departure_at, f.departure_timezone) + " and doesn't reach " +
            (f.arrival_description || "your destination") + " until " +
            clockLabel(f.arrival_at, f.arrival_timezone) + ", " +
            dur(Date.parse(f.arrival_at) - a.at) + " later. " +
            (policyish
              ? "That looks like the property's standard check-in time carried over from the confirmation email, not the time you will actually walk in."
              : "One of these times is wrong."),
          ref: { kind: a.kind, id: a.item.id },
          suggest: a.kind === "hosting" ? arriveBy(a, f, anchors) : null,
          // A stay left on the property's policy hour is a cosmetic import
          // artifact: once the trip is over, the hour you walked in is of no
          // consequence and the date, place and cost are all still right. An
          // arbitrary hour mid-flight is different — that is a genuinely wrong
          // timestamp, which puts the item on the wrong DAY in your history,
          // so it keeps reporting however old the trip is.
          soft: policyish
        });
        return;
      }

      var d = km(p.lat, p.lon, a.lat, a.lon);
      if (d == null || d <= REGION_KM) return;
      add({
        level: "issue",
        title: a.name + " is in the wrong part of the world for that day",
        detail: a.name + " is at " + when + ", but at that point the itinerary has you " +
          Math.round(d) + " km away near " + (p.where || "your last stop") +
          ", with no flight or train in between. Either a leg is missing or the date is wrong.",
        // Usually a leg that was never imported, which is missing data.
        ref: { kind: a.kind, id: a.item.id }, soft: true
      });
    });

    // ---- G2. not enough time to get there --------------------------------
    // Consecutive anchors, ground travel only. A scheduled leg between them
    // explains the movement; a hire car does not.
    for (var i = 0; i < anchors.length - 1; i++) {
      var A = anchors[i], B = anchors[i + 1];
      if (A.lat == null || B.lat == null) continue;
      if (A.item === B.item) continue;                       // a leg's own two ends
      // Airline connections belong to the connection rule in app.js, which
      // knows about minimum connect times and airport changes. Applying a
      // driving estimate to them just reports every normal connection as an
      // eight-hour drive between two terminals.
      if (A.leg && B.leg) continue;
      var spanned = legs.some(function (f) {
        var s = Date.parse(f.departure_at), e = Date.parse(f.arrival_at);
        return s < B.at && e > A.at;
      });
      if (spanned) continue;

      var d = km(A.lat, A.lon, B.lat, B.lon);
      if (d == null || d < 2) continue;
      var need = driveMinutes(d) * MIN;
      if (A.landing) need += airportExitMinutes(A.item) * MIN;
      // No counter allowance here: a rental's pick-up time IS the moment you
      // reach the desk, so adding queue time would double-count it.

      var have = B.at - A.at;
      var shortfall = need - have;
      if (shortfall < 25 * MIN) continue;
      // Over a very long distance the ground estimate stops being meaningful —
      // you would have flown, and a missing flight is a different finding.
      if (d > 600) continue;

      // A rental pick-up time is what the voucher says, not a commitment — the
      // desk is still open if you turn up late. Worth mentioning, never an
      // "issue".
      var advisory = B.kind === "transport" && isResource(B.item);
      add({
        level: (shortfall > 60 * MIN && !advisory) ? "issue" : "warn",
        title: "Not enough time between " + A.name + " and " + B.name,
        detail: A.name + " is at " + clockLabel(anchorTime(A), A.tz) +
          " and " + B.name + " at " + clockLabel(anchorTime(B), B.tz) + " — " + dur(have) +
          " apart, but they are " + Math.round(d) + " km apart, which is about " +
          dur(need) + " once you allow for " +
          (A.landing ? "getting out of the airport and " : "") + "the drive.",
        ref: { kind: B.kind, id: B.item.id }, soft: true
      });
    }

    // ---- G3. REMOVED: "departure at an implausible local hour" -----------
    //
    // This rule flagged any flight leaving between 00:15 and 04:30 local, and
    // claimed corroboration when the stored UTC value, read as if it were a
    // local time, landed in normal hours — supposedly the signature of an
    // importer writing a local time into a UTC column.
    //
    // That signal is circular. For a zone at UTC−6, a genuine 01:45 local
    // departure is ALWAYS stored as 07:45Z, which always reads as a plausible
    // morning departure. The test therefore fires identically on a real
    // red-eye and on a corrupted record: it cannot separate them, and the
    // "far more typical departure" line is arithmetic restating the offset,
    // not evidence.
    //
    // It cried wolf on the first real case it met. Alaska AS1351 was flagged
    // for departing SJO at 1:45am; confirmation DWDNED says the flight leaves
    // San José at 01:45 and reaches LAX at 06:00, and the stored record — both
    // times, the code, and all five seats — was already exactly right.
    //
    // Nothing is lost by deleting it. A departure hour that is wrong because a
    // date is wrong still shows up in the leg-duration check above, which has
    // a real signal to work from. A check that fires on every red-eye and
    // cannot tell a real one from a bug is worse than no check at all: it
    // teaches you to skim past the panel that is supposed to catch the
    // Costa Rica hotel.

    var rank = { issue: 0, warn: 1, info: 2 };
    out.sort(function (a, b) { return rank[a.level] - rank[b.level]; });
    return out;
  }

  function anchorTime(a) {
    if (a.kind === "hosting") return a.item.starts_at;
    if (a.kind === "activity") return a.item.starts_at;
    return a.end ? a.item.arrival_at : a.item.departure_at;
  }

  // Where the itinerary says you are at instant T, given the scheduled legs.
  // `at` carries coordinates; `transit` means you are aboard something.
  var TRANSIT_SLOP = 30 * 60000;
  function presenceAt(T, legs) {
    if (!legs.length) return null;
    var first = legs[0];
    if (T < Date.parse(first.departure_at)) {
      return {
        kind: "at", lat: first.departure_latitude, lon: first.departure_longitude,
        where: first.departure_description || "your departure point"
      };
    }
    for (var i = 0; i < legs.length; i++) {
      var s = Date.parse(legs[i].departure_at), e = Date.parse(legs[i].arrival_at);
      // Boarding and deplaning bleed past the scheduled times; leave room so a
      // lounge visit or a curbside pickup isn't called impossible.
      if (T > s + TRANSIT_SLOP && T < e - TRANSIT_SLOP) return { kind: "transit", leg: legs[i] };
      var nextS = i + 1 < legs.length ? Date.parse(legs[i + 1].departure_at) : Infinity;
      if (T >= e - TRANSIT_SLOP && T <= nextS) {
        return {
          kind: "at", lat: legs[i].arrival_latitude, lon: legs[i].arrival_longitude,
          where: legs[i].arrival_description || "your last stop"
        };
      }
    }
    return null;
  }

  // Walk forward from the inbound landing through whatever the itinerary says
  // you do next, and work out when you could realistically reach `a`.
  function arriveBy(a, inbound, anchors) {
    var t = Date.parse(inbound.arrival_at) + airportExitMinutes(inbound) * MIN;
    var here = { lat: inbound.arrival_latitude, lon: inbound.arrival_longitude };
    // A rental collected between landing and the stay is a real detour — but
    // only its PICK-UP is; the drop-off is days away at the far end of the trip
    // and must not be walked through as if it were on the way.
    anchors.forEach(function (x) {
      if (x.kind !== "transport" || !isResource(x.item) || x.end) return;
      var p = Date.parse(x.item.departure_at);
      if (p < Date.parse(inbound.arrival_at) || p > Date.parse(inbound.arrival_at) + 24 * HOUR) return;
      var leg1 = driveMinutes(km(here.lat, here.lon, x.lat, x.lon));
      if (leg1 != null) t = Math.max(t + leg1 * MIN, p) + 20 * MIN;   // counter time
      here = { lat: x.lat, lon: x.lon };
    });
    var drive = driveMinutes(km(here.lat, here.lon, a.lat, a.lon));
    if (drive == null) return null;
    var iso = new Date(roundUp15(t + drive * MIN)).toISOString();
    return { at: iso, field: "starts_at", local: clockLabel(iso, a.tz) + " on " + dateLabel(iso, a.tz) };
  }

  root.WayfarerFeasibility = {
    audit: audit,
    km: km,
    driveMinutes: driveMinutes,
    localParts: localParts,
    clockLabel: clockLabel
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
