// The trim used for sms:/wa.me bodies, lifted from openSendTo.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");

// Pull the real expression out of the source so this cannot drift from it.
const m = src.match(/var LIMIT = (\d+);[\s\S]*?var short = text\.length > LIMIT\s*\n\s*\?([\s\S]*?)\n\s*: text;/);
if (!m) { console.log("  FAIL — could not find the trim expression in app.js"); process.exit(1); }
const LIMIT = Number(m[1]);
const trimExpr = m[2].trim();
console.log("  LIMIT = " + LIMIT);
const trim = new Function("text", "var LIMIT=" + LIMIT + "; return text.length > LIMIT ? " + trimExpr + " : text;");

let pass = 0, fail = 0;
const t = (label, cond) => { cond ? pass++ : fail++; console.log("  " + (cond ? "ok  " : "FAIL") + "  " + label); };

// Short text passes through untouched.
const shortText = "Trip\nDay one\n  09:00  Flight";
t("short text is returned unchanged", trim(shortText) === shortText);
t("short text carries no trim notice", !/trimmed/.test(trim(shortText)));

// A long itinerary: many equal-length lines so the cut lands mid-line.
const line = "  10:30 AM  Alaska Airlines AS1412 to Liberia Guanacaste";
const long = ["Big Trip", ""].concat(Array.from({ length: 120 }, () => line)).join("\n");
t("test fixture is actually over the limit", long.length > LIMIT);

const out = trim(long);
t("long text is trimmed", out.length < long.length);
t("trim notice is appended", /trimmed/.test(out));
// The point of the line-boundary cut: never hand somebody half a flight.
const bodyOnly = out.split("\n\n… trimmed")[0];
t("cut lands on a line boundary, not mid-line",
  bodyOnly.split("\n").every((l) => l === "" || l === "Big Trip" || l === line));
t("result stays near the limit", out.length < LIMIT + 80);
t("nothing after the last newline is a partial line", !/\n {2}\d?\d:\d\d [AP]M {2}[^\n]{0,20}$/.test(bodyOnly));

// Exactly at the limit is not trimmed.
const exact = "x".repeat(LIMIT);
t("text exactly at the limit is untouched", trim(exact) === exact);
t("one character over is trimmed", trim("x".repeat(LIMIT + 1)) !== "x".repeat(LIMIT + 1));

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
