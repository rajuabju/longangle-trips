// Editing one thing in a trip, without leaving the trip.
//
// openTrip was the universal post-write refresh: saveItem, deleteItem, an
// upload, a drag reorder and the trip-type toggle all came back through it. It
// blanked the panel, re-inserted the skeleton, reset the scroll to the top and
// refetched all five collections -- so fixing a typo halfway down a ten-day
// itinerary cost a blank flash, five round trips, and a scroll hunt back to the
// row you had just edited.
//
// Measured after: a save preserves the scroll exactly (700.36 -> 700.36) and
// re-reads ONE collection; the type toggle re-reads none at all.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");

const fn = (decl) => {
  const i = app.indexOf(decl);
  if (i < 0) throw new Error("missing " + decl);
  let d = 0, seen = false;
  for (let j = i; j < app.length; j++) {
    if (app[j] === "{") { d++; seen = true; }
    else if (app[j] === "}") { d--; if (seen && !d) return app.slice(i, j + 1); }
  }
  throw new Error("unterminated " + decl);
};
const openTrip = fn("  async function openTrip(t, opts) {");
const saveItem = fn("  async function saveItem(trip, singular, plural, o, body, isNew) {");
const deleteItem = fn("  async function deleteItem(trip, kind, o) {");
const redrawAfter = fn("  async function redrawAfterWrite(trip, plural) {");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

console.log("\nopening and redrawing are different things now");
t("a redraw is recognised", /var redraw = shownTrip === t\.id && !\$\("#detail-overlay"\)\.hidden;/.test(openTrip), true);
t("the scroll is captured before anything is replaced", /keepScroll = open \? open\.scrollTop : 0;/.test(openTrip), true);
// The old line reset it on every single call, including every write path.
t("only a fresh open starts at the top",
  /if \(!redraw\) overlay\.querySelector\("\.detail-panel"\)\.scrollTop = 0;/.test(openTrip), true);
t("the unconditional reset is gone",
  /overlay\.hidden = false; overlay\.querySelector\("\.detail-panel"\)\.scrollTop = 0;/.test(app), false);
t("and a redraw is put back where it was", /back\.scrollTop = keepScroll;/.test(openTrip), true);
// After layout, or there is nothing tall enough to scroll to yet.
t("after the new content is laid out", /setTimeout\(function \(\) \{ back\.scrollTop = keepScroll; \}, 0\);/.test(openTrip), true);

console.log("\nand a caller that knows what changed says so");
t("openTrip accepts data", /async function openTrip\(t, opts\)/.test(app), true);
t("and uses it instead of fetching", /if \(opts\.data\) \{\s*data = opts\.data;/.test(openTrip), true);
t("otherwise it still loads all five", /load\("Documents", "\/v2\/trip\/" \+ t\.id \+ "\/documents"\)/.test(openTrip), true);
// One field changed; none of the five collections can have.
t("the type toggle re-reads nothing", app.indexOf("openTrip(t, { data: currentData });") > -1, true);

console.log("\none collection, not five");
t("saveItem re-reads only its own", /await redrawAfterWrite\(trip, plural\);/.test(saveItem), true);
// U8 lifted the lookup to a local so the undo path can reuse it.
t("deleteItem maps its kind to a collection", /var plural = SINGULAR_PLURAL\[kind\];/.test(deleteItem), true);
t("and re-reads only that one", /await redrawAfterWrite\(trip, plural\);/.test(deleteItem), true);
// The API's plural and the client's field name agree everywhere except
// transport, which is exactly the kind of thing to get wrong silently.
t("transportations lands in transports", /transportations: "transports"/.test(app), true);
t("and documents come from v2", /documents: "\/v2\/trip\/\{id\}\/documents"/.test(app), true);
t("the merge keeps every other collection", /Object\.keys\(currentData\)\.forEach/.test(redrawAfter), true);

console.log("\nbut falls back whenever anything is uncertain");
// A stale itinerary after a write is worse than the flash this avoids.
t("an unknown collection reloads everything", /if \(!key \|\| !path \|\| !currentData\) \{ openTrip\(trip\); return; \}/.test(redrawAfter), true);
t("so does a failed refetch", /if \(!fresh\) \{ openTrip\(trip\); return; \}/.test(redrawAfter), true);
t("and the reason is recorded", /showing a stale\s*\/\/ itinerary after a write is worse/.test(app), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
