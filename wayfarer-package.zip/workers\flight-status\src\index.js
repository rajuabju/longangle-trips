// Flight status, from FlightAware's AeroAPI.
//
// WHAT THIS WRITES, AND WHAT IT REFUSES TO.
//
// A gate and a terminal are facts about the flight that genuinely change, and
// the importer already writes them from confirmation emails. Those are updated
// in place, so they appear on the itinerary and in "What changed" with no new
// interface at all.
//
// The booked departure time is NOT touched. A delay is a different fact from a
// schedule change: the ticket still says 13:00 and the aeroplane now leaves at
// 14:20, and overwriting the first with the second loses the thing you would be
// holding up at a desk. Estimates land in `live_status` instead, beside the
// booking rather than on top of it — the same principle as a locked check-out
// time, for the same reason.
//
// COST. AeroAPI's Personal tier includes $5 of usage a month. Nothing here is
// worth an unexpected bill, so spending is bounded structurally rather than
// hopefully: a monthly counter in the settings table, a hard cap, and a
// per-flight schedule that asks rarely when a flight is far off and often when
// it is close. If the cap is reached the run stops and says so; it does not
// degrade into "just this once".
//
// WRITES GO THROUGH THE APP'S OWN API, not through the D1 binding. The binding
// is here only to find candidate flights in one query rather than fetching
// every trip over HTTP. Writing directly would mean a second implementation of
// the blob merge, the promoted columns and the `changes` ledger, and the two
// would drift. /api/ingest is the same handler the browser reaches.

// IATA to ICAO, for the sixteen carriers this database has ever flown.
//
// AeroAPI takes either, but an IATA ident is ambiguous — two airlines can share
// a two-letter code across regions — and it resolves ICAO exactly. A closed set
// maintained by hand, like AIRPORT_COUNTRY in the API: add to it when a new
// airline appears rather than reaching for a lookup service.
//
// An unmapped carrier is not an error. The IATA ident is sent as-is, which
// usually works; it is simply less certain.
const ICAO = {
  AA: "AAL", AF: "AFR", AM: "AMX", AS: "ASA", B6: "JBU", BA: "BAW",
  CX: "CPA", DL: "DAL", HA: "HAL", JL: "JAL", LA: "LAN", TO: "TVF",
  UA: "UAL", WN: "SWA", Y4: "VOI",
};

// "AS1412" becomes "ASA1412". Anything that is not two characters followed by
// digits is returned unchanged, for AeroAPI to interpret.
export function aeroIdent(transportNumber) {
  const s = String(transportNumber || "").trim().toUpperCase().replace(/\s+/g, "");
  const m = /^([A-Z0-9]{2})(\d{1,4})$/.exec(s);
  if (!m) return s || null;
  const icao = ICAO[m[1]];
  return icao ? icao + m[2] : s;
}

// How long before asking about a flight again. The tapering is what keeps this
// inside the free allowance: a flight three weeks out changes rarely, a flight
// in two hours changes constantly.
export function checkIntervalMinutes(minutesToDeparture) {
  if (minutesToDeparture > 12 * 60) return 6 * 60;   // a day or two out: four times a day
  if (minutesToDeparture > 3 * 60) return 60;        // same day: hourly
  return 10;                                          // close in, and in the air
}

export function dueForCheck(flight, nowMs) {
  const dep = Date.parse(flight.departure_at);
  if (!isFinite(dep)) return false;
  // Once it has landed there is nothing left to learn. Two hours past the
  // scheduled arrival is generous enough for a delay to have resolved.
  const arr = Date.parse(flight.arrival_at || flight.departure_at);
  if (isFinite(arr) && nowMs > arr + 2 * 3600000) return false;
  const last = Date.parse(flight.last_status_check || "");
  if (!isFinite(last)) return true;
  return (nowMs - last) / 60000 >= checkIntervalMinutes((dep - nowMs) / 60000);
}

// What differs between what we hold and what AeroAPI says.
//
// Only fields that genuinely differ, and never a blank overwriting a value: an
// empty gate in the feed means "not announced yet", not "no gate". That
// distinction is the whole difference between useful and infuriating, because
// gates are assigned late and the feed is empty for most of a flight's life.
export function statusDiff(stored, live) {
  const out = {};
  const set = (field, value) => {
    if (value == null || value === "") return;
    if (String(stored[field] == null ? "" : stored[field]) === String(value)) return;
    out[field] = value;
  };
  set("departure_gate", live.gate_origin);
  set("departure_terminal", live.terminal_origin);
  set("arrival_terminal", live.terminal_destination);
  return out;
}

// The status block that sits beside the booking rather than on top of it.
export function liveStatus(live, nowIso) {
  const est = live.estimated_out || live.actual_out || null;
  const sched = live.scheduled_out || null;
  let delay = null;
  if (est && sched) {
    const d = Math.round((Date.parse(est) - Date.parse(sched)) / 60000);
    if (isFinite(d)) delay = d;
  }
  return {
    checked_at: nowIso,
    source: "FlightAware AeroAPI",
    cancelled: !!live.cancelled,
    diverted: !!live.diverted,
    status: live.status || null,
    scheduled_out: sched,
    estimated_out: est,
    estimated_in: live.estimated_in || live.actual_in || null,
    actual_out: live.actual_out || null,
    actual_in: live.actual_in || null,
    delay_minutes: delay,
    progress_percent: typeof live.progress_percent === "number" ? live.progress_percent : null,
  };
}

// Which of the flights AeroAPI returned is ours: the one scheduled closest to
// the departure we hold. An ident alone is not enough — the same flight number
// flies every day, and the query window spans more than one.
export function pickFlight(list, departureAtIso) {
  const want = Date.parse(departureAtIso);
  if (!Array.isArray(list) || !list.length || !isFinite(want)) return null;
  let best = null, bestGap = Infinity;
  for (const f of list) {
    const t = Date.parse(f.scheduled_out || f.estimated_out || f.actual_out || "");
    if (!isFinite(t)) continue;
    const gap = Math.abs(t - want);
    if (gap < bestGap) { bestGap = gap; best = f; }
  }
  // More than a day apart is a different flight, whatever it is called.
  return bestGap <= 24 * 3600000 ? best : null;
}

// ---- the monthly budget ----------------------------------------------------
const USAGE_KEY = "aeroapi_usage";

async function readUsage(env, month) {
  const row = await env.DB.prepare("SELECT value FROM settings WHERE key=?").bind(USAGE_KEY).first();
  let v = null;
  try { v = row ? JSON.parse(row.value) : null; } catch (e) { v = null; }
  // A new month starts the count again, which is what the allowance does.
  if (!v || v.month !== month) return { month, queries: 0 };
  return { month, queries: Number(v.queries) || 0 };
}
async function writeUsage(env, usage) {
  await env.DB.prepare(
    "INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value"
  ).bind(USAGE_KEY, JSON.stringify(usage)).run();
}

// ---- AeroAPI ---------------------------------------------------------------
// AeroAPI will not accept a window reaching more than two days into the future.
// Asking for departure +24h on a flight leaving tomorrow puts `end` 2.4 days
// out and the whole call comes back 400 INVALID_ARGUMENT — which is how the
// first live probe failed on all three flights at once. Kept at 47h rather than
// 48 so a slow request cannot drift over the boundary between building the URL
// and the server reading it.
export const MAX_FUTURE_MS = 47 * 3600000;

// An instant AeroAPI will accept: whole minutes, no milliseconds.
export function isoMinute(ms) {
  return new Date(Math.floor(ms / 60000) * 60000).toISOString().replace(".000", "");
}

// Whether a flight is close enough for AeroAPI to answer about it at all.
export function withinAeroWindow(departureAtIso, nowMs) {
  const dep = Date.parse(departureAtIso);
  if (!isFinite(dep)) return false;
  return dep <= nowMs + MAX_FUTURE_MS;
}

export function aeroWindow(departureAtIso, nowMs) {
  const dep = Date.parse(departureAtIso);
  const ceiling = nowMs + MAX_FUTURE_MS;
  return {
    start: isoMinute(Math.min(dep - 12 * 3600000, ceiling - 3600000)),
    end: isoMinute(Math.min(dep + 12 * 3600000, ceiling)),
  };
}

async function fetchStatus(env, ident, departureAtIso) {
  // A window either side of the booked departure, clamped to what AeroAPI
  // allows. Twelve hours is enough to catch the right day's flight without
  // reaching past the two-day ceiling for anything inside the polling window.
  // max_pages=1 because billing is per PAGE of fifteen results, not per query.
  const dep = Date.parse(departureAtIso);
  const nowMs = Date.now();
  const ceiling = nowMs + MAX_FUTURE_MS;
  const w = aeroWindow(departureAtIso, nowMs);
  const start = w.start, end = w.end;
  const url = "https://aeroapi.flightaware.com/aeroapi/flights/" + encodeURIComponent(ident) +
    "?start=" + encodeURIComponent(start) + "&end=" + encodeURIComponent(end) + "&max_pages=1";
  const res = await fetch(url, { headers: { "x-apikey": env.AEROAPI_KEY, accept: "application/json" } });
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error("AeroAPI " + res.status + " " + body.slice(0, 160));
  }
  const data = await res.json();
  return Array.isArray(data.flights) ? data.flights : [];
}

// ---- writing ---------------------------------------------------------------
// Through /api/ingest, which is the same handler the browser reaches. The
// importer's key opens it.
async function patchItem(env, tripId, itemId, body) {
  const res = await fetch(env.API_BASE + "/trip/" + tripId + "/transportation/" + itemId, {
    method: "PATCH",
    headers: { "content-type": "application/json", "X-Importer-Key": env.IMPORTER_KEY },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error("PATCH " + res.status + " " + text.slice(0, 160));
  }
  return res.json();
}

const MAX_CHANGES = 20;

export async function run(env, opts) {
  const dry = !!(opts && opts.dry);
  const now = new Date();
  const nowMs = now.getTime();
  const nowIso = now.toISOString();
  const month = nowIso.slice(0, 7);
  const cap = Number(env.AEROAPI_MONTHLY_CAP || 400);
  const report = { at: nowIso, dry, checked: 0, updated: 0, skipped: 0, errors: [], capped: false };
  // Successful queries are what the budget counts, so failures need their own
  // ceiling or a broken key would retry every candidate on every run forever.
  let attempts = 0;
  const MAX_ATTEMPTS = 40;

  if (!env.AEROAPI_KEY) { report.errors.push("AEROAPI_KEY is not set"); return report; }

  const usage = await readUsage(env, month);
  if (usage.queries >= cap) {
    report.capped = true;
    report.errors.push("Monthly cap of " + cap + " reached; nothing further will be queried until " + month + " ends.");
    return report;
  }

  // Candidates: flights from six hours ago (possibly still in the air) to a day
  // ahead. Everything else is either history or too far off to have news.
  // 24 hours ahead by default. The manual endpoint may widen it — useful for
  // proving the whole chain works on a day when nothing is imminent — but the
  // cron never does: a wider routine window is more queries for news that will
  // still be there tomorrow.
  const aheadH = Math.min(Number((opts && opts.aheadHours) || 24) || 24, 47);
  const from = new Date(nowMs - 6 * 3600000).toISOString();
  const to = new Date(nowMs + aheadH * 3600000).toISOString();
  report.window_hours = aheadH;
  const rows = await env.DB.prepare(
    "SELECT id, trip_id, data, departure_at, arrival_at FROM transportations " +
    "WHERE deleted_at IS NULL AND departure_at BETWEEN ? AND ? ORDER BY departure_at"
  ).bind(from, to).all();

  for (const row of (rows.results || [])) {
    let rec = {};
    try { rec = JSON.parse(row.data) || {}; } catch (e) { rec = {}; }
    if (rec.transportation_type !== "airplane") continue;

    if (!dueForCheck({ departure_at: row.departure_at, arrival_at: row.arrival_at,
      last_status_check: rec.last_status_check }, nowMs)) { report.skipped++; continue; }

    const ident = aeroIdent(rec.transport_number);
    if (!ident) { report.skipped++; continue; }

    if (usage.queries >= cap) { report.capped = true; break; }
    if (attempts >= MAX_ATTEMPTS) { report.errors.push("Stopped after " + MAX_ATTEMPTS + " attempts in one run."); break; }

    // Beyond AeroAPI's two-day horizon there is no point asking; the call is a
    // guaranteed 400. The polling window is narrower than this anyway, so this
    // is a guard rather than a filter.
    if (!withinAeroWindow(row.departure_at, nowMs)) { report.skipped++; continue; }

    let live = null;
    attempts++;
    try {
      live = pickFlight(await fetchStatus(env, ident, row.departure_at), row.departure_at);
      // Counted only once the request succeeded. Charging the monthly budget for
      // calls FlightAware rejected would let one systematic error — a bad window,
      // an expired key — burn the whole allowance without a single answer, and
      // lock the month out for something that was never billed.
      usage.queries++;
      report.checked++;
    } catch (e) {
      report.errors.push(ident + ": " + (e && e.message ? e.message : "failed"));
      continue;
    }

    // Asked and got nothing useful. The check is still stamped, or every run
    // re-asks the same unanswerable flight and spends the allowance on it.
    const body = { last_status_check: nowIso };

    if (live) {
      body.live_status = liveStatus(live, nowIso);
      // Gate and terminal move into the record itself, and each one that does is
      // recorded in the same ledger the importer writes — so it surfaces in
      // "What changed", marks the item on the itinerary, and prints in the
      // dossier, with no new interface anywhere.
      const changed = statusDiff(rec, live);
      const entries = [];
      for (const field of Object.keys(changed)) {
        body[field] = changed[field];
        entries.push({
          at: nowIso, field,
          from: rec[field] == null ? null : rec[field],
          to: changed[field],
          why: "FlightAware AeroAPI (" + ident + ")",
        });
      }
      if (entries.length) {
        const prior = Array.isArray(rec.changes) ? rec.changes : [];
        body.changes = prior.concat(entries).slice(-MAX_CHANGES);
        report.updated++;
      }
    }

    if (!dry) {
      try { await patchItem(env, row.trip_id, row.id, body); }
      catch (e) { report.errors.push(ident + ": " + e.message); }
    }
  }

  if (!dry) await writeUsage(env, usage);
  report.queries_this_month = usage.queries;
  report.cap = cap;
  return report;
}

// A single named flight, asked about now, writing nothing.
//
// The polling window is deliberately narrow — 24 hours — so on an ordinary day
// a dry run correctly reports that it did nothing, which proves the database
// query works and proves nothing about AeroAPI. This asks about the next few
// upcoming flights whatever their date, so the key, the ident mapping and the
// parsing can all be checked on demand.
export async function probe(env, limit) {
  const out = { at: new Date().toISOString(), probe: true, flights: [] };
  if (!env.AEROAPI_KEY) { out.error = "AEROAPI_KEY is not set"; return out; }
  const rows = await env.DB.prepare(
    "SELECT id, trip_id, data, departure_at FROM transportations " +
    "WHERE deleted_at IS NULL AND departure_at > ? ORDER BY departure_at LIMIT ?"
  ).bind(new Date().toISOString(), Number(limit) || 3).all();

  for (const row of (rows.results || [])) {
    let rec = {};
    try { rec = JSON.parse(row.data) || {}; } catch (e) { rec = {}; }
    if (rec.transportation_type !== "airplane") continue;
    const ident = aeroIdent(rec.transport_number);
    const entry = {
      trip: row.trip_id, item: row.id,
      booked_number: rec.transport_number || null,
      asked_as: ident,
      departs: row.departure_at,
      route: [rec.departure_description, rec.arrival_description].filter(Boolean).join(" to ") || null,
    };
    if (!withinAeroWindow(row.departure_at, Date.parse(out.at))) {
      entry.matched = false;
      entry.note = "More than two days out — AeroAPI does not answer that far ahead, so nothing was asked.";
      out.flights.push(entry);
      continue;
    }
    entry.window = aeroWindow(row.departure_at, Date.parse(out.at));
    try {
      const list = await fetchStatus(env, ident, row.departure_at);
      entry.returned = list.length;
      const live = pickFlight(list, row.departure_at);
      if (!live) {
        entry.matched = false;
        entry.note = list.length
          ? "AeroAPI knows this flight number but none of its departures is within a day of yours."
          : "AeroAPI returned nothing for this ident in the window.";
      } else {
        entry.matched = true;
        entry.status = liveStatus(live, out.at);
        entry.would_write = statusDiff(rec, live);
      }
    } catch (e) {
      entry.error = e && e.message ? e.message : "failed";
    }
    out.flights.push(entry);
  }
  return out;
}

export default {
  async scheduled(event, env, ctx) {
    ctx.waitUntil(run(env).then((r) => console.log(JSON.stringify(r))));
  },
  // A manual run, for checking this works without waiting for the cron. Guarded
  // by the same key the importer uses, and a wrong key is indistinguishable from
  // a path that does not exist. `?dry=1` queries AeroAPI and writes nothing.
  async fetch(request, env) {
    const supplied = request.headers.get("X-Importer-Key");
    if (!env.IMPORTER_KEY || supplied !== env.IMPORTER_KEY) return new Response("Not found", { status: 404 });
    const url = new URL(request.url);
    if (url.searchParams.get("probe") === "1") {
      const report = await probe(env, url.searchParams.get("limit"));
      return new Response(JSON.stringify(report, null, 2), {
        headers: { "content-type": "application/json", "cache-control": "no-store" },
      });
    }
    const dry = url.searchParams.get("dry") === "1";
    const report = await run(env, { dry, aheadHours: url.searchParams.get("hours") });
    return new Response(JSON.stringify(report, null, 2), {
      headers: { "content-type": "application/json", "cache-control": "no-store" },
    });
  },
};
