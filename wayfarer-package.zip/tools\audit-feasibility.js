#!/usr/bin/env node
// Run the feasibility rules over every trip in a backup export.
//
// The same rules the PWA's TRIP CHECK runs, applied in bulk — useful for
// sweeping history after a rule changes, and for the scheduled importer to
// report on trips it has just touched without opening a browser.
//
//   node tools/audit-feasibility.js <backup.json> [--upcoming] [--level=issue] [--all]
//
// Once a trip is over, findings about MISSING or merely advisory data are
// dropped — matching the app, so "it moved to Past" and "the check went quiet"
// always agree. Duplicates and impossible times still report, because those
// distort history and totals however old they are. `--all` keeps everything.
//
// Exit code is 1 if any `issue` was found, so it can gate a scheduled run.
"use strict";

const fs = require("fs");
const path = require("path");

require(path.join(__dirname, "..", "public", "feasibility.js"));
const F = globalThis.WayfarerFeasibility;

const args = process.argv.slice(2);
const file = args.find((a) => !a.startsWith("--"));
const onlyUpcoming = args.includes("--upcoming");
const keepSoft = args.includes("--all");
const minLevel = (args.find((a) => a.startsWith("--level=")) || "--level=info").split("=")[1];

if (!file) {
  console.error("usage: node tools/audit-feasibility.js <backup.json> [--upcoming] [--level=issue|warn|info] [--all]");
  process.exit(2);
}

const RANK = { issue: 0, warn: 1, info: 2 };
const TODAY = new Date().toISOString().slice(0, 10);

const data = JSON.parse(fs.readFileSync(file, "utf8"));
const trips = (data.trips || []).slice().sort((a, b) =>
  String(a.trip.starts_at || "").localeCompare(String(b.trip.starts_at || "")));

let totals = { issue: 0, warn: 0, info: 0 };
let flagged = 0, softDropped = 0;

// Same test the app uses: a dated trip whose last day has passed. An undated
// trip is neither upcoming nor past and keeps every check.
const isPast = (t) => !!t.has_dates && String(t.ends_at || t.starts_at || "") < TODAY;

for (const rec of trips) {
  const t = rec.trip;
  if (onlyUpcoming && isPast(t)) continue;
  const past = isPast(t);

  const findings = F.audit({
    trip: t,
    transports: rec.transportations || [],
    hostings: rec.hostings || [],
    activities: rec.activities || []
  }).filter((f) => {
    if (RANK[f.level] > RANK[minLevel]) return false;
    if (past && f.soft && !keepSoft) { softDropped++; return false; }
    return true;
  });

  if (!findings.length) continue;
  flagged++;

  const when = t.starts_at ? `${t.starts_at} → ${t.ends_at}` : "no dates";
  console.log(`\n${"=".repeat(72)}`);
  console.log(`${t.name}   [${when}]   id=${t.id}`);
  console.log("=".repeat(72));

  for (const f of findings) {
    totals[f.level]++;
    const tag = f.level === "issue" ? "ISSUE" : f.level === "warn" ? "WARN " : "INFO ";
    console.log(`  ${tag}  ${f.title}`);
    console.log(`         ${f.detail}`);
    if (f.suggest && f.suggest.at) {
      console.log(`         → suggested ${f.suggest.field}: ${f.suggest.local || f.suggest.at}  (${f.suggest.at})`);
    }
  }
}

console.log(`\n${"-".repeat(72)}`);
console.log(`${trips.length} trips scanned${onlyUpcoming ? " (upcoming only)" : ""}, ${flagged} flagged`);
console.log(`issues ${totals.issue}   warnings ${totals.warn}   info ${totals.info}`);
if (softDropped) {
  console.log(`${softDropped} missing-data finding${softDropped === 1 ? "" : "s"} on finished trips suppressed (--all to show)`);
}
process.exit(totals.issue ? 1 : 0);
