// One version, written in one place.
//
// There used to be two hand-maintained constants. APP_VERSION climbed 1.5.0 ->
// 1.8.2 across eight releases while __WAYFARER_BUILD sat on "v119" the whole
// time -- so the Settings pill, whose entire job is telling "I refreshed" apart
// from "I have the new code", answered with a build number from months earlier
// and no one could tell.
//
// Now package.json is the source and build.js writes both. These tests fail if
// that ever stops being true.
const fs = require("fs");
const pkg = JSON.parse(fs.readFileSync("package.json", "utf8"));
const app = fs.readFileSync("public/app.js", "utf8");
const build = fs.readFileSync("build.js", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

const m = /^(\d+)\.(\d+)\.(\d+)$/.exec(pkg.version);

console.log("\nthe shape of the number");
t("package.json is MAJOR.MINOR.PATCH", !!m, true);
// npm demands three parts; the app shows two. The third is deliberately unused
// so there is never a second dimension to reason about.
t("the patch digit is unused", m && m[3], "0");
t("the major is a v-number, not a semver 1", m && Number(m[1]) >= 100, true);

console.log("\nwhat the app displays");
const shown = "v" + m[1] + "." + m[2];
const appVer = (/var APP_VERSION = "([^"]*)"/.exec(app) || [])[1];
const buildVer = (/window\.__WAYFARER_BUILD = "([^"]*)"/.exec(app) || [])[1];
t("APP_VERSION is derived from package.json", appVer, shown);
t("and so is the build marker", buildVer, shown);
// The failure that motivated all of this: the two disagreeing.
t("the two agree with each other", appVer === buildVer, true);
t("it reads as vMAJOR.MINOR", /^v\d+\.\d+$/.test(appVer), true);

console.log("\nthey are generated, not policed");
// Validation still leaves two places to edit and a build that fails until you
// have edited both. Generation leaves one.
t("build.js writes APP_VERSION",
  /set\(\/var APP_VERSION = "\[\^"\]\*"\//.test(build), true);
t("build.js writes the build marker",
  build.indexOf(', "__WAYFARER_BUILD");') > -1 &&
  build.indexOf("__WAYFARER_BUILD = \"' + shown + '\"") > -1, true);
t("it refuses a version it cannot parse",
  /is not MAJOR\.MINOR\.PATCH/.test(build), true);
t("and refuses a constant it cannot find",
  /is missing from public\/app\.js/.test(build), true);
// If this ever comes back, someone has reintroduced the hand-edit.
t("no mismatch check remains — there is nothing to mismatch",
  /version mismatch/.test(build), false);

console.log("\nwhich bundle is actually running");
// With both constants generated from one number they say the same thing, so
// the pill would prove nothing about the code on the device. It names the
// bundle it was loaded from instead.
t("the pill reads the running script's hash",
  /app\\.\(\[0-9a-f\]\{6,\}\)\\.js/.test(app), true);
t("and shows it beside the version",
  app.indexOf('(running ? " \u00b7 " + running : "")') > -1, true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
