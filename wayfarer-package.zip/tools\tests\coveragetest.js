// How much of a trip the Budget total actually accounts for.
//
// The Budget pill shows a sum, and a sum reads as "what the trip cost" whether
// it covers every booking or one of four. Pasadena showed $591 against one
// booking of one -- fine -- but the same pill would have shown $591 against
// four, and nothing said which.
//
// That is precisely the objection that killed pricing trips from card
// transactions on 2026-08-29: Plaid sees 4 of ~20 cards, so a trip paid on an
// unlinked card would total as CHEAP rather than as unknown. A partial figure
// wearing the clothes of a total. Having refused it from card data, the app
// cannot leave it standing in its own Budget.
//
// The line is deliberately conditional. 177 of 184 trips came in from TripIt
// and Tripsy, which never tracked costs, and every one of them would otherwise
// carry a reproach for a gap that is both expected and closed -- costs are
// tracked going forward, and SKILL.md forbids backfilling a finished trip.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

function lift(decl) {
  const at = app.indexOf(decl);
  if (at < 0) throw new Error("not found: " + decl);
  let depth = 0, i = app.indexOf("{", at);
  for (; i < app.length; i++) {
    if (app[i] === "{") depth++;
    else if (app[i] === "}") { depth--; if (!depth) break; }
  }
  return app.slice(at, i + 1);
}

// The real pair: coverage leans on linkedCost, so lifting both means a change
// to either fails here rather than drifting.
// money() only formats the text linkedCost returns; coverage reads its
// truthiness, so a stub keeps the lift honest without dragging in Intl.
const cover = new Function(
  "signedAmount", "money", "state",
  lift("function budgetCoverage(data)") + "\n" + lift("function linkedCost(o, kind, data)") +
  "\nreturn budgetCoverage;"
)((cat, amt) => amt, (n, c) => c + " " + n, { me: { default_currency: "USD" } });

const H = (id) => ({ id });
const X = (id) => ({ id });
const A = (id) => ({ id });
const exp = (kind, id, amount) => ({ linked_kind: kind, linked_id: id, amount, currency: "USD" });

console.log("\ncounting what the total accounts for");
{
  // The stored link values are "hosting", "transport", "activity" -- verified
  // against production, where 24 linked expenses use exactly those. SKILL.md's
  // "transportation" is the API path segment, not the link value; keying on it
  // would silently score every flight uncovered.
  const data = {
    hostings: [H(1), H(2)],
    transports: [X(10)],
    activities: [A(20)],
    expenses: [exp("hosting", 1, 500), exp("transport", 10, 300)],
  };
  t("every booking is counted", cover(data).total, 4);
  t("only the linked ones are covered", cover(data).covered, 2);
  t("a transport link is recognised, not missed by a name mismatch",
    cover({ transports: [X(10)], expenses: [exp("transport", 10, 1)] }).covered, 1);
  t("an activity link is recognised",
    cover({ activities: [A(20)], expenses: [exp("activity", 20, 1)] }).covered, 1);
}

console.log("\nwhat does NOT count against coverage");
{
  // A meal or a taxi is a real trip cost belonging to no booking. It adds to
  // the total and must not make the ratio look worse.
  const d = { hostings: [H(1)], expenses: [exp("hosting", 1, 500), { amount: 40, currency: "USD" }] };
  t("an unlinked expense is not an uncovered booking", cover(d), { total: 1, covered: 1 });
  // Legacy: a booking carrying its own price is covered without an expense.
  t("a booking's own price counts as covered",
    cover({ hostings: [{ id: 1, price: 818.02 }], expenses: [] }).covered, 1);
  t("a zero price does not", cover({ hostings: [{ id: 1, price: 0 }], expenses: [] }).covered, 0);
  // An expense pointing at an id that is not on this trip covers nothing.
  t("a dangling link covers nothing",
    cover({ hostings: [H(1)], expenses: [exp("hosting", 999, 500)] }).covered, 0);
  t("a trip with no bookings at all", cover({ expenses: [] }), { total: 0, covered: 0 });
  t("missing collections do not throw", cover({}), { total: 0, covered: 0 });
}

console.log("\nthe line appears only when it says something");
{
  // Mirrors the guard in renderBudget: a total must exist AND be partial.
  const show = (lines, c) => !!(lines && c.total && c.covered < c.total);
  t("partial total, with lines: shown", show(2, { total: 4, covered: 2 }), true);
  // The 177 imported trips: no expenses, so the pill reads "—" and there is no
  // total to misread. A reproach here would be noise on almost every trip.
  t("no costs at all: silent", show(0, { total: 4, covered: 0 }), false);
  // Complete: silence IS the statement, and it keeps a clean trip clean.
  t("fully covered: silent", show(4, { total: 4, covered: 4 }), false);
  t("no bookings to cover: silent", show(1, { total: 0, covered: 0 }), false);
}

console.log("\nthe wording qualifies rather than complains");
{
  const body = lift("function renderBudget(root, t, data)");
  t("it states what the total covers", /This total covers/.test(body), true);
  // "missing" would assert the rest SHOULD have a cost. Plenty of bookings
  // legitimately have none -- an award ticket, a night at The Ranch.
  t("it does not call the rest missing", /\bmissing\b/.test(body), false);
  t("and it is guarded on both lines and partiality",
    /lines\.length && cov\.total && cov\.covered < cov\.total/.test(body), true);
}

console.log("\n" + pass + " passed, " + fail + " failed\n");
process.exit(fail ? 1 : 0);
