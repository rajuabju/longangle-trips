// Wayfarer service worker — offline support.
// Shell is cache-first; trip data (GET /api/v1/*) is network-first with a cache
// fallback so previously loaded trips remain viewable on a plane.
// Bump SHELL whenever app.js/styles.css change — the shell is cache-first, so an
// unchanged cache name leaves existing visitors (and installed PWAs) on the old bundle.
var SHELL = "wayfarer-shell-aed8a9a835";
var DATA = "wayfarer-data-v1";
// Keep the ?v= in sync with index.html so the shell caches the same URLs the page requests.
var SHELL_ASSETS = ["/", "/index.html", "/app.96d2a456f6.js", "/qr.82b5ac2afe.js", "/feasibility.b947e898ea.js", "/styles.221d7aaeba.css", "/manifest.webmanifest", "/icon-192.png", "/icon-512.png", "/icon-180.png", "/favicon.svg", "/mark-blue.svg", "/mark-white.svg", "/mark-navy.svg", "/mark-sand.svg", "/mark-sun.svg"];
// Without these the app cannot run at all, so a failure to cache one is a
// failure to install. Everything else in SHELL_ASSETS is an icon or a logo:
// worth having offline, not worth refusing to install over. addAll() is
// all-or-nothing, so a single 404 on a decorative file used to leave every
// existing visitor stranded on the previous service worker indefinitely — the
// one failure mode that cannot be fixed by shipping again.
var CORE = ["/", "/index.html", "/app.96d2a456f6.js", "/feasibility.b947e898ea.js", "/styles.221d7aaeba.css"];

// How long to wait for the network before reaching for the cache.
//
// Not a nicety. A hotel or aeroplane network that ACCEPTS the connection and
// then never answers is the common case abroad, and fetch() has no timeout of
// its own — it waits, and the app sits blank for as long as the captive portal
// feels like holding the socket. Failing over to a cached copy after a few
// seconds is the difference between "my itinerary is there" and "my itinerary
// is a white screen". The request is left running: if it does come back it
// still refreshes the cache for next time.
var NET_TIMEOUT_MS = 5000;

// The data cache holds one entry per URL and nothing ever removed one, so it
// grew forever — 1200+ entries on a browser in ordinary use. That matters on a
// phone, where a large origin cache is likelier to be evicted WHOLESALE by the
// OS reclaiming space, which loses the offline copy at exactly the moment it is
// wanted. Capped, oldest first: Cache Storage iterates keys in insertion order.
var DATA_MAX = 400;

self.addEventListener("install", function (e) {
  e.waitUntil(caches.open(SHELL).then(function (c) {
    // Core first and strictly: if this rejects, the install fails, which is
    // correct — a shell without app.js is not a shell.
    // addAll() would accept the SPA fallback's 200 and cache HTML as the app
    // bundle. Fetch each core file and check what actually came back, so a
    // deploy race fails the install instead of persisting a broken shell --
    // leaving the previous service worker, and the previous WORKING bundle,
    // in place until the asset really is there.
    return Promise.all(CORE.map(function (u) {
      return fetch(u, { cache: "reload" }).then(function (res) {
        if (!res.ok) throw new Error("core " + u + " HTTP " + res.status);
        if (wrongType(u, res)) throw new Error("core " + u + " served as HTML");
        return c.put(u, res);
      });
    })).then(function () {
      // Then the rest, each allowed to fail on its own.
      return Promise.all(SHELL_ASSETS.filter(function (u) { return CORE.indexOf(u) < 0; })
        .map(function (u) { return c.add(u).catch(function () {}); }));
    });
  }).then(function () { return self.skipWaiting(); }));
});
self.addEventListener("activate", function (e) {
  e.waitUntil(caches.keys().then(function (keys) {
    return Promise.all(keys.map(function (k) { if (k !== SHELL && k !== DATA) return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});

// caches.match resolves to UNDEFINED on a miss, and respondWith(undefined) is a
// TypeError that fails the request outright. Every fallback below used to end
// there, so a network blip on a file that happened not to be in the cache did
// not degrade to "fetch it normally" — it degraded to "this asset does not
// load". For styles.css that is an unstyled page and for app.js a blank one:
// exactly the shape of a "rendering is broken" report, always transient, and
// cleared by the hard refresh that goes straight to the network.
//
// The window for it is widest right after a deploy, because activate() has just
// deleted the previous shell cache while the page is still pulling assets.
//
// So: on a miss, try the network once more before giving up, and give up with a
// real Response rather than with nothing.
// A cached answer, labelled as one.
//
// Serving a stale itinerary on a plane is the point of this worker. Serving it
// while looking identical to a live one is not: the page had no way to tell,
// so a gate number from four hours ago read exactly like a gate number from
// four seconds ago. The client shows a strip when it sees these headers.
//
// Headers on a cached Response are immutable, so this rebuilds it. The body is
// passed through as a stream rather than read, so nothing is buffered.
//
// `date` is the response's own header, set by the server when the copy was
// fetched — a genuine "as of", not the time it happened to be read.
function labelled(res) {
  if (!res) return res;
  try {
    const h = new Headers(res.headers);
    h.set("X-SW-Cache", "hit");
    h.set("X-SW-Cached-At", h.get("date") || "");
    return new Response(res.body, { status: res.status, statusText: res.statusText, headers: h });
  } catch (e) {
    // A label is a nicety; the itinerary is not. Never fail the request over it.
    return res;
  }
}

function cacheOrRetry(req, key) {
  return caches.match(key || req).then(function (hit) {
    if (hit) return labelled(hit);
    return fetch(req).catch(function () {
      return new Response("", { status: 504, statusText: "Offline and not cached" });
    });
  });
}

// A URL worth keeping a copy of. Some are asked once with a value that will
// never recur — `updatedSince` carries a timestamp, so every poll mints a new
// key that can never be read again and never be replaced. Those filled most of
// the cache while being useless in it.
// Cloudflare Pages answers a request for a file it does not have with
// index.html and a 200 -- SPA routing, and not something this project can turn
// off. For a <script> tag that is a silent catastrophe: the browser receives
// HTML where JavaScript should be, fails to parse it, and the app never runs.
// No 404, no exception, nothing in the console. The page paints its shell and
// stops, which reads exactly like "the site is down".
//
// Seen on 2026-08-23. trips.example.com served 10,608 bytes of index.html for
// the app bundle during a deploy. The dashboard rendered as a bare header
// with no trips, no buttons and no errors, and stayed that way until the
// bundle was re-fetched by hand. install() had made it durable by caching the
// HTML under the script's URL, because addAll() treats any 200 as a success.
//
// So: a response is only allowed to stand in for a script or a stylesheet if
// it actually is one. Anything else is treated as a failed request.
function wrongType(url, res) {
  var path;
  try { path = new URL(url, self.location.origin).pathname; } catch (e) { return false; }
  if (!/\.(js|css)$/.test(path)) return false;
  var ct = (res && res.headers && res.headers.get("content-type") || "").toLowerCase();
  // No content-type at all is left alone: some proxies strip it, and refusing
  // on absence would break more than it fixes. HTML in a .js is unambiguous.
  return ct.indexOf("text/html") > -1;
}

function worthCaching(url) {
  if (url.searchParams.has("updatedSince") || url.searchParams.has("updated_since")) return false;
  if (url.pathname.indexOf("/knownname") >= 0) return false;
  return true;
}

// The trip list is the one response offline mode cannot do without: it is what
// the dashboard paints from, and every other cached response is a detail view
// reached FROM it. Cache Storage iterates in insertion order and this trims
// oldest-first, so the trips pages -- written first on every load -- were
// always first in the queue to be evicted once the cache filled. Protect them
// explicitly and take the excess from everything else.
function isCore(url) {
  try { return new URL(url).pathname.indexOf("/api/v1/trips") === 0; }
  catch (e) { return false; }
}

function trim(cacheName, max) {
  return caches.open(cacheName).then(function (c) {
    return c.keys().then(function (keys) {
      if (keys.length <= max) return;
      var over = keys.length - max;
      var droppable = keys.filter(function (k) { return !isCore(k.url); });
      // If literally everything is core there is nothing safe to drop; letting
      // the cache run slightly over is better than deleting the itinerary.
      return Promise.all(droppable.slice(0, over).map(function (k) { return c.delete(k); }));
    });
  });
}

function save(cacheName, req, res, max) {
  // The single most important line here: caching HTML under a script URL is
  // what turned a transient deploy race into a permanently broken install.
  if (wrongType(req.url, res)) return;
  var copy = res.clone();
  caches.open(cacheName).then(function (c) {
    return c.put(req, copy).then(function () { if (max) return trim(cacheName, max); });
  }).catch(function () {});
}

// Network first, but only for as long as the network is actually answering.
// `key` is an alternative cache key, used for navigations, which are requests
// for a URL the cache holds under /index.html.
function networkFirst(req, cacheName, key, max) {
  return new Promise(function (resolve) {
    var settled = false;
    var finish = function (r) { if (!settled) { settled = true; resolve(r); } };
    var timer = setTimeout(function () {
      // Only pre-empt the network if there is in fact something to show. With
      // nothing cached, waiting is still better than a 504.
      caches.match(key || req).then(function (hit) { if (hit) finish(labelled(hit)); });
    }, NET_TIMEOUT_MS);
    fetch(req).then(function (res) {
      clearTimeout(timer);
      // HTML where a script belongs is a failed request wearing a 200. Fall
      // back to the cache, which is likely to hold the previous WORKING bundle.
      if (wrongType(req.url, res)) { cacheOrRetry(req, key).then(finish); return; }
      // Still worth storing even if the timeout already served the cached copy —
      // that is what makes the next load current.
      if (res && res.ok && worthCaching(new URL(req.url))) save(cacheName, req, res, max);
      finish(res);
    }).catch(function () {
      clearTimeout(timer);
      cacheOrRetry(req, key).then(finish);
    });
  });
}

self.addEventListener("fetch", function (e) {
  var req = e.request;
  if (req.method !== "GET") return;
  var url = new URL(req.url);

  // Trip data: network-first, fall back to cache when offline.
  // This must track whatever API_BASE the client uses. After the backend swap
  // it was still matching the old prefix, which silently disabled offline
  // access to trips — the requests simply stopped matching anything.
  if (url.origin === location.origin && url.pathname.indexOf("/api/v1/") === 0) {
    e.respondWith(networkFirst(req, DATA, null, DATA_MAX));
    return;
  }

  // App navigations: serve cached shell when offline.
  if (req.mode === "navigate") {
    e.respondWith(networkFirst(req, SHELL, "/index.html"));
    return;
  }

  // Same-origin static assets: network-first (so deploys apply immediately when
  // online), falling back to cache only when offline.
  if (url.origin === location.origin) {
    e.respondWith(networkFirst(req, SHELL));
  }
  // Cross-origin (Leaflet, map tiles): let the browser handle it.
});
