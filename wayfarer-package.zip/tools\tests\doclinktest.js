// Documents and what they are attached to.
//
// Attaching a document to an itinerary item used to put it somewhere neither
// half of the interface looked: the sidebar's query filtered out anything with
// a parent, and the itinerary row read `o.documents` — an array in the item's
// own blob that the attach never wrote to. The document existed in the table
// and nowhere else. So the two directions of the same link are what this pins:
// a document knowing its item, and an item finding its documents.
//
// Fixtures are invented — no real documents or signed URLs in this directory.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");

function grab(name) {
  const i = src.indexOf("  function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
function grabVar(name) {
  const i = src.indexOf("  var " + name + " = ");
  if (i < 0) throw new Error("missing " + name);
  return src.slice(i, src.indexOf(";", i) + 1);
}

globalThis.dayKey = (utc) => (utc ? String(utc).slice(0, 10) : null);
globalThis.dateLocale = () => "en-US";
globalThis.transIcon = () => "*";

eval([grabVar("DOC_PARENT"),
  ...["linkedItem", "linkableItems", "docParent", "docsFor"].map(grab)].join("\n") +
  ";Object.assign(globalThis,{DOC_PARENT,linkedItem,linkableItems,docParent,docsFor});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

const TRIP = {
  transports: [{ id: 1, company: "Delta Air Lines", transport_number: "DL395" }],
  hostings: [{ id: 10, name: "Hotel Example" }, { id: 11, name: "Nayara Tented Camp" }],
  activities: [{ id: 20, name: "Walking tour" }],
  documents: [
    { id: 100, title: "Boarding pass", parent_type: "transportation", parent_id: 1, url: "https://x/1" },
    { id: 101, title: "Rate confirmation", parent_type: "hosting", parent_id: 10, r2_key: "k/1" },
    { id: 102, title: "Second rate sheet", parent_type: "hosting", parent_id: 10, url: "https://x/2" },
    { id: 103, title: "Travel insurance", parent_type: null, parent_id: null, url: "https://x/3" },
    { id: 104, title: "Tour voucher", parent_type: "activity", parent_id: 20, url: "https://x/4" },
  ],
};

// ---- a document knowing its item ------------------------------------------
const by = (id) => TRIP.documents.filter((d) => d.id === id)[0];
t("a boarding pass names its flight", docParent(by(100), TRIP).label, "Delta Air Lines DL395");
t("a rate sheet names its hotel", docParent(by(101), TRIP).label, "Hotel Example");
t("a voucher names its activity", docParent(by(104), TRIP).label, "Walking tour");
t("an unattached document names nothing", docParent(by(103), TRIP), null);

// The API's singular for a flight is "transportation"; the itinerary and the
// budget's picker both call it "transport". docParent bridges the two, and
// getting it wrong makes every attached boarding pass look unattached.
t("transportation resolves as transport",
  docParent({ parent_type: "transportation", parent_id: 1 }, TRIP).kind, "transport");
t("and the picker writes it back as transportation", DOC_PARENT.transport, "transportation");
t("a hotel needs no translation", DOC_PARENT.hosting, "hosting");
t("nor an activity", DOC_PARENT.activity, "activity");

// Bookings get deleted; the link is a pair of columns, not a foreign key.
t("a link to a deleted booking resolves to nothing",
  docParent({ parent_type: "hosting", parent_id: 999 }, TRIP), null);
t("a half-written link is no link", docParent({ parent_type: "hosting" }, TRIP), null);
t("no data, no parent", docParent(by(100), null), null);
t("a parent_type nothing routes on resolves to nothing",
  docParent({ parent_type: "flight", parent_id: 1 }, TRIP), null);

// ---- an item finding its documents -----------------------------------------
t("a hotel finds both of its documents",
  docsFor(TRIP.hostings[0], "hosting", TRIP).map((d) => d.title),
  ["Rate confirmation", "Second rate sheet"]);
t("a flight finds its one",
  docsFor(TRIP.transports[0], "transportation", TRIP).map((d) => d.title), ["Boarding pass"]);
t("a booking with none finds none",
  docsFor(TRIP.hostings[1], "hosting", TRIP).length, 0);
// Ids collide across tables — hosting 10 and a transport 10 are different
// things — so the kind has to be part of the match, not just the id.
t("the kind is part of the match",
  docsFor({ id: 10 }, "transportation", TRIP).length, 0);
// D1 returns ids as numbers; a link written from a form arrives as a string.
t("a string parent_id still matches",
  docsFor({ id: 10 }, "hosting", { documents: [{ id: 1, parent_type: "hosting", parent_id: "10" }] }).length, 1);
t("no data, no documents", docsFor(TRIP.hostings[0], "hosting", null).length, 0);
t("an unattached document belongs to no item",
  [].concat(
    docsFor(TRIP.transports[0], "transportation", TRIP),
    docsFor(TRIP.hostings[0], "hosting", TRIP),
    docsFor(TRIP.hostings[1], "hosting", TRIP),
    docsFor(TRIP.activities[0], "activity", TRIP)
  ).some((d) => d.id === 103), false);

// ---- the two directions agree ----------------------------------------------
// Every document that names an item must be found by that item, and nothing
// else. This is the invariant the old arrangement broke.
const reachable = [];
linkableItems(TRIP).forEach((i) => {
  const kind = DOC_PARENT[i.kind];
  docsFor({ id: i.id }, kind, TRIP).forEach((d) => reachable.push(d.id));
});
t("every attached document is reachable from its item",
  TRIP.documents.filter((d) => d.parent_type).map((d) => d.id).sort(),
  reachable.slice().sort());
t("and none is reachable twice", reachable.length, new Set(reachable).size);

// ---- the server contract ----------------------------------------------------
// The sidebar query must not filter on parent_type — that filter is what hid
// attached documents — and docOut must carry the link back out.
const api = fs.readFileSync("functions/api/_core.js", "utf8");
// The SQL only — the prose around it explains the filter that was removed, and
// an earlier version of this test matched that comment and reported the bug
// still present. Quoted strings are the code; everything else is commentary.
const sql = (api.match(/"SELECT[^"]*FROM documents[^"]*"/g) || []).map((q) => q.slice(1, -1));
// The whole-trip list: scoped by trip, not by a single id. The word boundary
// keeps `trip_id=?` from counting as `id=?` — the underscore before "id" is a
// word character, so no boundary falls there.
const tripList = sql.filter((q) => /trip_id=\?/.test(q) && !/\bid=\?/.test(q) && !/parent_id/.test(q));
t("the trip's document query was found", tripList.length, 1);
t("the trip's document list no longer hides attached ones",
  /parent_type IS NULL/.test(tripList[0]), false);
t("it is still scoped to the trip and to undeleted rows",
  /trip_id=\? AND deleted_at IS NULL/.test(tripList[0]), true);
t("docOut carries parent_type", /parent_type: r\.parent_type/.test(api), true);
t("docOut carries parent_id", /parent_id: r\.parent_id/.test(api), true);
// The nested GET is what the per-item view used to need and no longer does; it
// must still exist, because deleting it would break the iOS app's fetch.
t("the nested per-item list still exists",
  /parent_type=\? AND parent_id=\?/.test(api), true);

// ---- what may render, and what may only be downloaded ----------------------
// Serving a stored file inline puts it on a page in our own origin. The rule
// that keeps that safe is the TYPE: only formats that cannot carry script are
// shown, and everything else is sent as an attachment, which never renders.
//
// This replaced a CSP sandbox that tried to render everything safely and could
// not render a PDF at all — `sandbox` denies Chrome's PDF viewer the same-origin
// access it needs, and `default-src 'none'` blocks the embed it draws into, so
// opening any PDF gave a blank tab while downloading it worked. Both stored
// documents in the database are PDFs, which is why open was broken for all of
// them and download for none.
//
// The regex is lifted from the source rather than restated, so the suite cannot
// drift into testing a copy that agrees with itself.
const canShowSrc = api.slice(api.indexOf("const canShow = ") + "const canShow = ".length);
const canShow = eval(canShowSrc.slice(0, canShowSrc.indexOf(".test(type)")));
const shows = (ct) => canShow.test(ct);

t("a PDF is shown", shows("application/pdf"), true);
t("a PDF with a parameter is shown", shows("application/pdf; charset=binary"), true);
t("a JPEG is shown", shows("image/jpeg"), true);
t("the jpg spelling is shown", shows("image/jpg"), true);
t("a PNG is shown", shows("image/png"), true);
t("a HEIC from a phone is shown", shows("image/heic"), true);
t("plain text is shown", shows("text/plain"), true);
// The two that matter. Both are a picture-or-page that can carry script, and an
// SVG rendered inline in our origin is the textbook way to take a session.
t("SVG is never rendered", shows("image/svg+xml"), false);
t("HTML is never rendered", shows("text/html"), false);
t("XHTML is never rendered", shows("application/xhtml+xml"), false);
t("XML is never rendered", shows("text/xml"), false);
// A crafted type must not slip through by wearing an allowed one as a prefix.
t("a type that merely starts like an allowed one is refused", shows("text/html+plain"), false);
t("nor one that extends an allowed name", shows("application/pdf-evil"), false);
t("an unknown type is refused", shows("application/octet-stream"), false);
t("a Word document is refused", shows("application/msword"), false);

// The disposition follows from that, plus an explicit ?download=1.
const disposition = (ct, dl) => (dl || !shows(ct) ? "attachment" : "inline");
t("a PDF opens inline", disposition("application/pdf", false), "inline");
t("a PDF downloads when asked", disposition("application/pdf", true), "attachment");
t("an SVG downloads without being asked", disposition("image/svg+xml", false), "attachment");
t("HTML downloads without being asked", disposition("text/html", false), "attachment");

// And the policy on the inline path must not carry `sandbox` — that directive
// is what blanked the viewer.
const inlineCsp = (api.match(/"default-src 'none'; object-src[^"]*"/) || [""])[0];
t("the inline policy exists", inlineCsp.length > 0, true);
t("the inline policy does not sandbox", /sandbox/.test(inlineCsp), false);
t("it still denies everything by default", /default-src 'none'/.test(inlineCsp), true);
t("it permits no scripts", /script-src/.test(inlineCsp), false);
t("the download path keeps the sandbox", /"default-src 'none'; sandbox"/.test(api), true);
t("nosniff is still sent", /x-content-type-options/.test(api), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
