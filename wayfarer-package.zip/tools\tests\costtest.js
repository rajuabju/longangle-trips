// Where a cost lives, and whose number wins.
//
// Decided 2026-08-19: a cost lives in exactly one place — an expense linked to
// the booking it pays for — captured from the confirmation email when the email
// states one. The booking itself stops carrying money.
//
// Two things had to be true for that to be safe. A figure set by hand has to
// survive the vendor re-sending the original, exactly as a check-out time does.
// And the nine bookings that carried a price from before the decision had to
// move without changing a single trip total.
//
// They were migrated on 2026-08-19 -- nine expenses created, nine prices
// cleared, every per-trip total identical to the penny and every line landing
// in the category it was already in. The price input came off the booking
// forms at the same time, so no booking carries money and none can be given
// any from the app. The booking-price paths below are still covered because
// the API has no allowlist: a direct call can still put one there, and a price
// that exists has to be counted rather than quietly dropped.
//
// Fixtures are invented. The SHAPES are ones the live data actually has.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");

// The importer lives in its own repository, which is the whole reason this
// section exists: the two halves disagreeing about a field name is exactly how
// `price_currency` came to be written for a budget that read `currency`. Read
// it if it is there, and say plainly when it is not rather than asserting
// against an empty string and reporting green.
const SKILL_PATH = "C:/Users/YOU/Claude/Scheduled/wayfarer-importer/SKILL.md";
let skill = null;
try { skill = fs.readFileSync(SKILL_PATH, "utf8"); } catch (e) { skill = null; }

function grab(name) {
  const i = src.indexOf("  function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
globalThis.state = { me: { default_currency: "USD" } };
globalThis.money = (n, c) => c + " " + Number(n).toFixed(2);
const CREDIT_LINE = src.slice(src.indexOf("  var CREDIT_CAT = "),
  src.indexOf(";", src.indexOf("  var CREDIT_CAT = ")) + 1);
eval(CREDIT_LINE + "\n" +
  ["priceCurrency", "lockedFields", "isFieldLocked", "signedAmount", "linkedCost", "costField"]
  .map(grab).join("\n") +
  ";Object.assign(globalThis,{CREDIT_CAT,priceCurrency,lockedFields,isFieldLocked," +
  "signedAmount,linkedCost,costField});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

console.log("\nwhich currency a booking price is in");
// The importer was told to write price_currency (SKILL.md 8a) while the budget
// read currency, so an importer-priced booking arrived with no currency the
// budget could see and fell back to the account default. Two live records were
// in that state — the Keith Urban concert and the Nature Safari Float — and
// both happened to be USD, so the totals were right by luck. Both are expenses
// now, but the fallback stays: a blob keeps whatever was last written to it.
t("the canonical name", priceCurrency({ currency: "EUR" }), "EUR");
t("what the importer actually wrote", priceCurrency({ price_currency: "CRC" }), "CRC");
// An explicit currency beats an incidental one, the same way name beats title.
t("currency wins when both are set",
  priceCurrency({ currency: "USD", price_currency: "EUR" }), "USD");
t("neither is null, not a guess", priceCurrency({ price: 500 }), null);
t("no object at all", priceCurrency(null), null);

console.log("\nan amount you set yourself");
t("no lock by default", isFieldLocked({ price: 100 }, "amount"), false);
t("a locked amount", isFieldLocked({ locked_fields: ["amount"] }, "amount"), true);
t("locking one field does not lock another",
  isFieldLocked({ locked_fields: ["amount"] }, "currency"), false);
// Junk from the blob must not throw: locked_fields is merged from whatever was
// last written, and patchRow accepts arbitrary fields with no allowlist.
t("a string instead of a list is no lock", lockedFields({ locked_fields: "amount" }), []);
t("null is no lock", lockedFields({ locked_fields: null }), []);
t("no object at all", lockedFields(null), []);

console.log("\nwhat the form does with it");
const form = src.slice(src.indexOf('if (kind === "expense")'),
  src.indexOf('await saveItem(trip, "expense", "expenses"'));
// Changing the figure locks it without being asked. The confirmation is the
// starting point, not the last word.
t("editing the amount locks it",
  /if \(!wasAmountLocked && movedAmount\) locked = \["amount"\]/.test(form), true);
// Offered explicitly too, because the automatic rule cannot cover an amount you
// want kept that happens to equal what the email said.
t("and it can be asked for outright", /v\.keep_amount === "keep"/.test(form), true);
t("the control is offered", /name: "keep_amount", label: "If this booking is re-sent"/.test(form), true);
// Releasing has to be possible in the same save that changed the number, or the
// automatic re-lock makes the control one-way.
t("choosing to update releases the lock",
  /if \(v\.keep_amount !== "keep" && wasAmountLocked\) locked = \[\]/.test(form), true);
// 730.30 re-saved as "730.3" is not an edit. Comparing as strings would lock
// half the expenses on the trip the first time they were opened.
t("the comparison is numeric, not textual",
  /Number\(oldAmount \|\| 0\) !== newAmount/.test(form), true);
t("a new expense is never born locked", /!isNew && Number\(oldAmount/.test(form), true);
// Otherwise a corrected figure is indistinguishable from an imported one.
t("the budget says which amounts are yours",
  /isFieldLocked\(l\.obj, "amount"\)/.test(src), true);

console.log("\nwhat an item cost, read off its expenses");
// The migration cleared every booking price, which left the Price input on
// each booking form blank -- reading as "nobody filled this in" when the truth
// is "this is not where it lives". The forms now report the figure instead of
// asking for it: an input would invite a second copy of a number the linked
// expense already holds, and the budget adds both.
const DATA = { expenses: [
  { id: 1, price: 1941.97, currency: "USD", linked_kind: "hosting", linked_id: 10 },
  { id: 2, price: 45, currency: "USD", linked_kind: "hosting", linked_id: 10 },
  { id: 3, price: 221.06, currency: "USD", linked_kind: "transport", linked_id: 20 },
  { id: 4, price: 90, currency: "EUR", linked_kind: "activity", linked_id: 30 },
  { id: 5, price: 15, currency: "USD", linked_kind: "activity", linked_id: 30 },
  { id: 6, price: 60, currency: "USD" },
] };
t("one expense", linkedCost({ id: 20 }, "transport", DATA).text, "USD 221.06");
// A room rate and the resort fee on it are both real money on the same stay.
t("two expenses on one booking add up", linkedCost({ id: 10 }, "hosting", DATA).text, "USD 1986.97");
t("and it says how many", linkedCost({ id: 10 }, "hosting", DATA).count, 2);
// Adding 90 EUR to 15 USD gives a number that is true of nothing.
t("mixed currencies are kept apart", linkedCost({ id: 30 }, "activity", DATA).text, "EUR 90.00 · USD 15.00");
t("nothing linked is null, not zero", linkedCost({ id: 99 }, "hosting", DATA), null);
// The kind matters: ids are only unique within a table, so a hosting #20 and a
// transport #20 both exist and must not borrow each other's costs.
t("an id alone does not match", linkedCost({ id: 20 }, "hosting", DATA), null);
t("an unlinked expense belongs to no item",
  linkedCost({ id: 6 }, "activity", DATA), null);
t("no data at all does not throw", linkedCost({ id: 10 }, "hosting", null), null);
t("no item at all does not throw", linkedCost(null, "hosting", DATA), null);
// An expense with amount but no price is the shape the importer writes.
t("amount is read when price is absent",
  linkedCost({ id: 7 }, "activity",
    { expenses: [{ id: 8, amount: 12.5, currency: "USD", linked_kind: "activity", linked_id: 7 }] }).text,
  "USD 12.50");

console.log("\nand the form reports rather than asks");
t("it is a static field, with no input", costField({ id: 20 }, "transport", DATA).type, "static");
t("showing the figure", costField({ id: 20 }, "transport", DATA).value, "USD 221.06");
// The blank has to be an instruction, not a dead end.
t("a blank says where to put it", costField({ id: 99 }, "hosting", DATA).value, "Not recorded yet");
t("and points at Budget",
  /Add one in Budget and link it to this item/.test(costField({ id: 99 }, "hosting", DATA).hint), true);
t("the singular reads naturally",
  /From the linked expense/.test(costField({ id: 20 }, "transport", DATA).hint), true);
t("and the plural counts them",
  /From 2 linked expenses/.test(costField({ id: 10 }, "hosting", DATA).hint), true);

console.log("\nno booking form writes money any more");
// A writable price on the booking is the second copy that made one charge two
// lines. All three forms show the derived figure instead.
t("no form sends a price", /price: v\.price/.test(src), false);
t("the transport form shows the cost", /costField\(o, "transport", data\)/.test(src), true);
t("the hosting form shows the cost", /costField\(o, "hosting", data\)/.test(src), true);
t("the activity form shows the cost", /costField\(o, "activity", data\)/.test(src), true);
// A static field must contribute nothing to the submitted values, or it lands
// in the body as a string like "USD 221.06".
t("a static field submits nothing",
  /if \(f\.type === "static"\) \{[\s\S]{0,320}return;/.test(src), true);

// A first attempt suppressed a booking's price whenever any expense linked to
// it. The budget fixture caught it: a linked expense is usually an EXTRA — a
// baggage fee on a fare, a resort fee on a room rate — so hiding the fare would
// under-count, which is worse than the double count it was aimed at.
//
// Two regex assertions used to sit here saying that guard was absent. They
// asserted nothing: the guard was reverted before it was ever committed, so the
// patterns matched no version of the file and would have kept passing if it
// came back under any other name.
//
// The real protection is behavioural and already exists: budgettest's fixture
// has a $420 flight with a $75 baggage expense linked to it and asserts SEVEN
// budget lines. Suppress the booking and that count drops to six, loudly.

console.log("\nthe duplicate that does matter");
// Two figures matching to the penny on the same booking is one charge written
// twice. Measured before shipping: zero occurrences across all 182 trips, and
// after the migration nothing is left for it to fire on.
t("checked by amount, not by linkage", /Number\(b\.price\) !== amt\) return;/.test(src), true);
t("and it is a warning, not a silent correction",
  /add\("warn", "This cost may be counted twice"/.test(src), true);
t("pointing at the expense, which is the keeper",
  /clear the price on the booking/.test(src), true);

if (!skill) {
  console.log("\nwhat the importer is told");
  console.log("  SKIP  SKILL.md not readable at " + SKILL_PATH);
  console.log("        The importer half of the money rules is UNVERIFIED in this run.");
} else {
console.log("\nwhat the importer is told");
t("money goes on the expense", /### 8a\. Money goes on the expense, never on the booking/.test(skill), true);
t("and never on the booking",
  /Do not write `price` or `price_currency` onto a hosting, transportation or\nactivity/.test(skill), true);
// The old instruction told it to do both, on the same fact.
t("the old write-it-on-the-booking table is gone",
  /\| Total paid for the booking \| `price` \|/.test(skill), false);
// refundable is not money and is only knowable at parse time.
t("refundable is still captured", /Whether it can be changed \| `refundable`/.test(skill), true);
t("a booking that already states a price gets no expense",
  /a non-zero `price` on the booking itself/.test(skill), true);
t("a locked amount is left alone", /A locked amount is his, not yours/.test(skill), true);
t("and the difference is reported rather than applied",
  /a real price change is visible without being applied/.test(skill), true);
// Past trips are out of scope by instruction, not by accident.
t("past trips are not touched", /Past trips are out of scope entirely/.test(skill), true);

}

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
