// One overlay, built one way.
//
// Twenty-two functions each built the same two boxes by hand -- a backdrop and
// a panel, appended to the body. The construction was identical in all of them:
// the same two el() calls, then the exact same append line, character for
// character across all 22. What differed was only what closing means, and that
// stayed with the dialogs.
//
// The reason to have one place is not the duplication. It is that a modal stack
// (so Escape closes the top layer, not every layer) and role/aria/focus have
// somewhere to live other than 22 separate edits.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

console.log("\nthere is exactly one of it");
t("one place creates a backdrop",
  (app.match(/el\("div", "form-overlay"\)/g) || []).length, 1);
t("one place puts it in the document",
  (app.match(/document\.body\.appendChild\(back\)/g) || []).length, 1);
t("and it is the helper",
  /function overlay\(cls, onBackdrop\) \{[\s\S]*?document\.body\.appendChild\(back\);/.test(app), true);

console.log("\nand every dialog goes through it");
t("all 22 call sites", (app.match(/var o = overlay\(/g) || []).length, 22);
t("each takes both boxes from it",
  (app.match(/var back = o\.back, panel = o\.panel;/g) || []).length, 22);
// The class is the only thing the helper varies, and it is appended, not
// replaced -- "form-panel wide", never just "wide".
t("the class is appended to form-panel",
  /"form-panel" \+ \(cls \? " " \+ cls : ""\)/.test(app), true);

console.log("\nthe variants that actually exist still do");
["settings", "wide insights", "wide dossier-panel", "wide", "sheet"].forEach(function (cls) {
  t('overlay("' + cls + '") is used',
    new RegExp('overlay\\("' + cls + '"[,)]').test(app), true);
});
t("the plain one takes no argument", app.indexOf("var o = overlay();") > -1, true);
// formDialog computes its class rather than naming it, which the argument
// handles without a special case in the helper.
t("and one caller computes its class",
  app.indexOf('var o = overlay(wide ? "wide" : "", function () { close(); });') > -1, true);

console.log("\nthe backdrop is dismissable from the moment it is mounted");
// The helper mounts the backdrop immediately, but each dialog used to install
// its own click-outside listener at the END of its construction --
// openCoverDialog builds 349 lines first. A throw in between would have left a
// full-screen backdrop with nothing in it and no way out. Before the helper
// existed the same throw left nothing on screen at all, so this is a window the
// helper opened and had to close.
t("the listener is wired inside the helper",
  /function overlay\(cls, onBackdrop\)[\s\S]*?back\.addEventListener\("click"/.test(app), true);
t("and before the caller gets the panel back",
  app.indexOf("back.addEventListener") < app.indexOf("return { back: back, panel: panel };"), true);
t("no dialog installs its own any more",
  (app.match(/back\.addEventListener\("click", function \((e|ev)\) \{ if \(\1\.target === back\)/g) || []).length, 0);

console.log("\nbut what closing MEANS still belongs to each dialog");
// Four have real teardown -- a Leaflet map to destroy, chips to put back on the
// toolbar -- and pass it in rather than having it flattened into the helper.
t("openInsights destroys its map", app.indexOf('overlay("wide insights", function () { shut(); });') > -1, true);
t("three others route through their own close()",
  (app.match(/overlay\([^)]*, function \(\) \{ close\(\); \}\)/g) || []).length, 3);
t("the default is a plain removal", /if \(onBackdrop\) onBackdrop\(\); else back\.remove\(\);/.test(app), true);
// And one dialog opts out entirely, which is the whole reason for `false`.
t("openLocationTriage cannot be dismissed by clicking away",
  app.indexOf('var o = overlay("wide", false);') > -1, true);
t("which the helper honours", /if \(onBackdrop !== false\)/.test(app), true);
t("for a stated reason",
  app.indexOf("losing a triage list to a stray tap throws away the work") > -1, true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
