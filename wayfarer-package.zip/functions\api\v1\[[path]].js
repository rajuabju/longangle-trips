// Browser entry point. Authentication is Cloudflare Access, and this file's job
// is to prove that a request actually came from it.
//
// It used to take Access at its word: read the email out of the JWT payload and
// trust it, on the reasoning that Access sits in front and a client cannot forge
// what Access sends. Both halves of that were wrong.
//
// Access sits in front of trips.example.com. It does not sit in front of
// wayfarer.pages.dev, which serves these same Functions. Cloudflare
// strips client-supplied Cf-Access-Authenticated-User-Email and
// Cf-Access-Client-Id at the edge — but NOT Cf-Access-Jwt-Assertion. So anyone
// could send an unsigned alg:none token naming any email they liked and get a
// 200 with the entire database:
//
//   curl https://wayfarer.pages.dev/api/v1/trips \
//     -H 'Cf-Access-Jwt-Assertion: eyJhbGciOiJub25lIn0.eyJlbWFpbCI6Ii4uLiJ9.'
//
// A signature is only worth anything if somebody checks it. This does: RS256
// against the team's published keys, and the aud claim against this specific
// application, so a valid token minted for a sibling app on the same Cloudflare
// team cannot be replayed here either. Everything fails closed — a missing
// token, an unknown key, an unreachable JWKS endpoint, unset config.
import { handleApi } from "../_core.js";

// Cached per isolate. Access rotates signing keys periodically and publishes the
// new one before it starts using it, so an hour-stale copy still verifies; a kid
// we have never seen forces a refetch anyway.
const JWKS_TTL_MS = 3600000;
let jwks = { at: 0, team: "", keys: null };

async function signingKeys(team, force) {
  const now = Date.now();
  if (!force && jwks.keys && jwks.team === team && now - jwks.at < JWKS_TTL_MS) return jwks.keys;
  const r = await fetch("https://" + team + "/cdn-cgi/access/certs", {
    cf: { cacheTtl: 3600, cacheEverything: true },
  });
  if (!r.ok) throw new Error("jwks " + r.status);
  const d = await r.json();
  if (!d || !Array.isArray(d.keys) || !d.keys.length) throw new Error("jwks empty");
  jwks = { at: now, team: team, keys: d.keys };
  return jwks.keys;
}

function b64urlText(s) {
  const t = String(s).replace(/-/g, "+").replace(/_/g, "/");
  return atob(t + "=".repeat((4 - (t.length % 4)) % 4));
}
function b64urlBytes(s) {
  const bin = b64urlText(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

// Returns the caller's identity, or null. Null always means reject — there is no
// path through here that returns an identity without a verified signature.
async function verifyAccessJwt(token, team, aud) {
  const parts = String(token).split(".");
  if (parts.length !== 3) return null;

  let head;
  try { head = JSON.parse(b64urlText(parts[0])); } catch { return null; }
  // Pin the algorithm. Trusting the token's own alg is how "none" gets accepted.
  if (head.alg !== "RS256" || !head.kid) return null;

  let keys = await signingKeys(team, false);
  let jwk = keys.find((k) => k.kid === head.kid);
  // Unknown kid: could be a rotation we have not picked up. One refetch, then no.
  if (!jwk) {
    keys = await signingKeys(team, true);
    jwk = keys.find((k) => k.kid === head.kid);
    if (!jwk) return null;
  }

  const key = await crypto.subtle.importKey(
    "jwk", { kty: jwk.kty, n: jwk.n, e: jwk.e, alg: "RS256", ext: true },
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]
  );
  const signed = new TextEncoder().encode(parts[0] + "." + parts[1]);
  if (!(await crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, b64urlBytes(parts[2]), signed))) return null;

  let p;
  try { p = JSON.parse(b64urlText(parts[1])); } catch { return null; }
  const now = Math.floor(Date.now() / 1000);
  if (typeof p.exp === "number" && p.exp <= now) return null;
  // 60s of slack for clock skew, and no more.
  if (typeof p.nbf === "number" && p.nbf > now + 60) return null;
  if (p.iss && p.iss !== "https://" + team) return null;
  const auds = Array.isArray(p.aud) ? p.aud : [p.aud];
  if (!auds.includes(aud)) return null;

  // Service tokens authenticate as a common_name rather than a person.
  return p.email || p.common_name || p.sub || null;
}

function denied(detail) {
  return new Response(JSON.stringify({ detail: detail }), {
    status: 401,
    headers: { "content-type": "application/json", "cache-control": "no-store" },
  });
}

export async function onRequest(context) {
  const { request, env } = context;

  // Local preview only, passed on the command line so it can never reach a
  // deploy. Checked first: without Access in front there is no token to verify.
  //
  // "1" is the machine identity `local`, which is Admin/Edit. Anything else is
  // taken as an email and goes through the ordinary role lookup, which is the
  // only way to sit in the View/Read seat without a second Access account:
  //   --binding ALLOW_UNAUTHENTICATED=viewer@example.com
  const preview = env.ALLOW_UNAUTHENTICATED;
  if (preview) return handleApi(context, preview === "1" ? "local" : String(preview).toLowerCase());

  const team = env.ACCESS_TEAM_DOMAIN, aud = env.ACCESS_AUD;
  if (!team || !aud) return denied("Access verification is not configured.");

  const token = request.headers.get("Cf-Access-Jwt-Assertion");
  if (!token) return denied("Not authenticated.");

  let who = null;
  try {
    who = await verifyAccessJwt(token, team, aud);
  } catch (e) {
    // Reaching the JWKS endpoint failed. Refusing is the only safe answer, and
    // 503 says "try again" rather than "your token is bad".
    return new Response(JSON.stringify({ detail: "Could not verify identity." }), {
      status: 503, headers: { "content-type": "application/json", "cache-control": "no-store" },
    });
  }
  if (!who) return denied("Not authenticated.");

  return handleApi(context, who);
}
