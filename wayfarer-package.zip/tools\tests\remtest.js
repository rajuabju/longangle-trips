// U24 -- the app follows the reader's own text size.
//
// Everything was sized in px: `font-size:calc(15px * var(--fs))`. A px is a px
// whatever the reader has asked for, so the app ignored the browser's font-size
// setting and Android's text-scaling accessibility slider entirely -- the two
// controls someone with poor eyesight actually reaches for. The app's own
// Settings slider worked, and nothing else did.
//
// --px is one CSS pixel expressed in rem (1/16rem), which is exactly 1px while
// the root is the 16px browsers ship with. Every sized rule multiplies by it.
// --fs is untouched and keeps doing its own job; the two multiply, so a reader
// who has set both gets both.
//
// Measured in the browser, before and after:
//   BEFORE, changing the root from 16px to 20px:
//     small 15 -> 15,  medium 16.5 -> 16.5,  large 18.3 -> 18.3   (no effect)
//   AFTER, the same change:
//     small 15 -> 18.75, medium 16.5 -> 20.625, large 18.3 -> 22.875
//     every one of them exactly 1.25x, and the app setting still orders them
//   AND at the browser default nothing moved at all -- body 18.3px, .chip
//     16.47px, .icon-btn 20.13px, .brand-mark 18.3px and 31.7188px wide, all
//     identical to the px-based values they replaced
//   at a 12px root, body scaled to 0.75x
//   at data-text=large with a 24px root, body 27.45px and the page still did
//     not scroll sideways
const fs = require("fs");
const css = fs.readFileSync("public/styles.css", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

console.log("\nthere is one scaling unit, and it is rem");
t("--px is defined", /--px:0\.0625rem;/.test(css), true);
// 1/16rem is exactly 1px at the 16px root browsers ship with, which is what
// makes the conversion invisible by default. Any other value would resize the
// whole app the moment it shipped.
t("it is exactly one sixteenth of a rem", 1 / 0.0625, 16);
t("declared beside --fs, which it multiplies with", /:root \{ --px:0\.0625rem; --fs:1\.22;/.test(css), true);
t("and the app's own setting is unchanged", /:root\[data-text="small"\]\s*\{ --fs:1; \}/.test(css), true);

console.log("\nevery scaled rule went through");
const remCalc = (css.match(/calc\([\d.]+ \* var\(--px\) \* var\(--fs\)\)/g) || []).length;
const pxCalc  = (css.match(/calc\([\d.]+px \* var\(--fs\)\)/g) || []).length;
// A floor, not an exact count: the stylesheet keeps growing and every new
// sized rule adds one. The strict invariant is the line below -- that none
// are left in px -- which is what actually breaks if a rule is added the
// old way. It was 197 at the conversion and is 200 after the trip header
// gained its own sizes.
t("every scaled declaration goes through --px", remCalc >= 197, true);
// The one that matters: a single missed rule is a line of text that refuses to
// grow with the rest, which looks like a bug rather than a setting.
t("and none are left in px", pxCalc, 0);

console.log("\nit is not only font sizes");
// .brand-mark is sized to match the text beside it. Left in px it would have
// stayed put while every label around it grew.
t("the brand mark scales too", /\.brand-mark \{ width:calc\(26 \* var\(--px\) \* var\(--fs\)\);/.test(css), true);
t("as does body text", /body \{[^}]*font-size:calc\(15 \* var\(--px\) \* var\(--fs\)\)/.test(css), true);

console.log("\nnothing blocks the browser from scaling it");
// text-size-adjust:none or 100% would switch off exactly the Android font
// boost this change exists to honour. There is none, and there must not be.
t("no text-size-adjust anywhere", /text-size-adjust/.test(css), false);

console.log("\nthe widths are deliberately still px");
// --main-w and friends are layout maxima, not type. Scaling those with the
// reader's font size would widen the page as the text grew, which is the
// opposite of what a larger text size is asking for: fewer characters per line,
// not more.
t("the layout maxima stay in px", /--main-w:1600px; --cards-w:1000px; --detail-w:1200px;/.test(css), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
