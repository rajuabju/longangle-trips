// Qualifying spend per card, per calendar year -- the reconciliation report to
// run against a bank's own tracker before any total is trusted.
//
//   node tools/plaid-spend.js            (amex)
//   node tools/plaid-spend.js chase
//   node tools/plaid-spend.js citi
//
// The bank picks the token: PLAID_<BANK>_ACCESS_TOKEN in .dev.vars, the same
// name card_items.token_env points at.
//
// THE CLASSIFIER IS NOT DEFINED HERE. It lives in tools/plaid-rules.js, which
// mirrors the authority in functions/api/_core.js -- tools/tests/cardstest.js
// pins the two against each other. This file used to carry its own copy, and
// that copy quietly went stale: it predated the Chase wording and the Amex
// benefit credits, so running it against a linked bank re-made the exact
// misclassifications the app had already fixed. A reconciliation tool running
// different rules than the thing it reconciles is worse than no tool.
const fs = require("fs");
const path = require("path");
const RULES = require("./plaid-rules");

const BANK = (process.argv[2] || "amex").toLowerCase().replace(/[^a-z0-9]/g, "");
const TOKEN_KEY = "PLAID_" + BANK.toUpperCase() + "_ACCESS_TOKEN";

const env = {};
for (const line of fs.readFileSync(path.join(process.cwd(), ".dev.vars"), "utf8").split(/\r?\n/)) {
  const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/.exec(line);
  if (m) env[m[1]] = m[2].replace(/^["']|["']$/g, "");
}
const BASE = "https://" + (env.PLAID_ENV || "production") + ".plaid.com";
const money = (n) => (n < 0 ? "-" : "") + "$" + Math.abs(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

async function call(endpoint, body) {
  const res = await fetch(BASE + endpoint, {
    method: "POST", headers: { "content-type": "application/json" },
    body: JSON.stringify(Object.assign({ client_id: env.PLAID_CLIENT_ID, secret: env.PLAID_SECRET }, body)),
  });
  return { ok: res.ok, data: await res.json().catch(() => null) };
}

(async () => {
  const token = env[TOKEN_KEY];
  if (!token) { console.error("No " + TOKEN_KEY + " in .dev.vars -- run 'node tools/plaid-connect.js start " + BANK + "' first."); process.exit(1); }

  const acc = await call("/accounts/get", { access_token: token });
  if (!acc.ok) { console.error("accounts/get failed: " + JSON.stringify(acc.data).slice(0, 200)); process.exit(1); }
  const names = {};
  for (const a of acc.data.accounts) names[a.account_id] = (a.name || "?") + " **" + (a.mask || "");

  let cursor = null, added = [], rounds = 0;
  while (rounds++ < 40) {
    const s = await call("/transactions/sync", cursor ? { access_token: token, cursor } : { access_token: token });
    if (!s.ok) break;
    added = added.concat(s.data.added || []);
    cursor = s.data.next_cursor;
    if (!s.data.has_more) break;
  }

  const YEARS = [...new Set(added.map((t) => String(t.date).slice(0, 4)))].sort();

  console.log("\n" + BANK.toUpperCase() + " — QUALIFYING SPEND = charges - merchant refunds");
  console.log("payments excluded entirely; statement credits and points NOT subtracted\n");

  for (const yr of YEARS) {
    console.log(yr + ":");
    console.log("  " + "card".padEnd(32) + "charges".padStart(14) + "refunds".padStart(12) +
      "qualifying".padStart(15) + "[payments]".padStart(16) + "[credits]".padStart(14));
    let any = false;
    for (const id of Object.keys(names)) {
      const mine = added.filter((t) => t.account_id === id && String(t.date).slice(0, 4) === yr);
      if (!mine.length) continue;
      any = true;
      const q = RULES.qualifying(mine);
      console.log("  " + names[id].slice(0, 30).padEnd(32) +
        money(q.charges).padStart(14) + money(q.refunds).padStart(12) +
        money(q.spend).padStart(15) + money(q.payments).padStart(16) + money(q.credits).padStart(14));
    }
    if (!any) console.log("  (no transactions)");
    console.log("");
  }

  // The report that catches a new bank's wording before it costs anything:
  // every negative treated as a MERCHANT REFUND, largest first. A card payment
  // in this list means the rules need that bank's phrasing.
  console.log("NEGATIVES TREATED AS MERCHANT REFUNDS (these subtract from spend):");
  const unmatched = RULES.describeNegatives(added);
  if (!unmatched.length) console.log("  (none)");
  for (const u of unmatched.slice(0, 15)) {
    console.log("  " + u.name.padEnd(48) + String(u.count).padStart(4) +
      money(u.total).padStart(15) + "  " + u.category.slice(0, 30));
  }

  for (const id of Object.keys(names)) {
    const mine = added.filter((t) => t.account_id === id);
    const q = RULES.qualifying(mine);
    const rate = q.charges ? Math.abs(q.refunds) / q.charges : 0;
    if (rate > 0.08) {
      console.log("\n  ** " + names[id] + ": refunds are " + (rate * 100).toFixed(0) + "% of charges.");
      console.log("     On a card settled monthly that is the signature of payments being");
      console.log("     read as refunds -- the $210,000 mistake. Check the list above.");
    }
  }

  console.log("\nCHECK the qualifying figure against the bank's own tracker before");
  console.log("anything depends on it. That reconciliation caught every earlier version");
  console.log("of these rules being wrong.\n");
})();
