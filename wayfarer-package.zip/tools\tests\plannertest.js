// The planner list: how long you would go for, what that does to the price,
// and how a list that is meant to grow stays navigable.
//
// Four things here are easy to get subtly wrong and impossible to see:
//
//   a RETURN date decides the price, and the horizon has to be measured
//   against it rather than the outbound -- a window that starts inside the
//   schedule window and ends outside it has no round trip to look up;
//   "in season now" cannot use inSeason(), which answers a different question
//   and says yes when no season was declared;
//   "soonest first" must put UNDATED ideas last, because "someday" is not
//   sooner than 2027;
//   "nearest first" must put ideas with no location last, because an unknown
//   distance is not a short one.
//
// Fixtures are invented.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");
const core = fs.readFileSync("functions/api/_core.js", "utf8");

function grab(name) {
  const head = "  function " + name + "(";
  const i = app.indexOf(head);
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < app.length; j++) {
    if (app[j] === "{") { d++; seen = true; }
    else if (app[j] === "}") { d--; if (seen && !d) return app.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
const chunk = (start, end) => app.slice(app.indexOf(start), app.indexOf(end, app.indexOf(start)) + end.length);
const decl = (start) => app.slice(app.indexOf(start), app.indexOf(";", app.indexOf(start)) + 1);

eval([
  decl("  var HOME = {"), decl("  var HOME_MAX_KM = "), decl("  var DRIVE_MAX_KM = "),
  decl("  var DEFAULT_NIGHTS = "),
  decl("  var FLIGHT_HORIZON_DAYS = "), decl("  var MONTHS = ["),
  chunk("  var IDEA_SORTS = [", "];"), chunk("  var IDEA_FILTERS = [", "];"),
  grab("km"), grab("hasText"), grab("inSeason"), grab("nearestAirport"), grab("flightHours"),
  grab("reachability"),
  grab("sampleDate"), grab("flightWindow"), grab("nightsOf"), grab("returnDate"),
  grab("bookableNow"), grab("seasonNow"), grab("sortIdeas"), grab("filterIdeas"),
  grab("geoQueries"),
].join("\n") + ";Object.assign(globalThis,{HOME,HOME_MAX_KM,DRIVE_MAX_KM,DEFAULT_NIGHTS,FLIGHT_HORIZON_DAYS," +
  "MONTHS,IDEA_SORTS,IDEA_FILTERS,km,hasText,inSeason,nearestAirport,flightHours,reachability,sampleDate," +
  "flightWindow,nightsOf,returnDate,bookableNow,seasonNow,sortIdeas,filterIdeas,geoQueries});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

const NOW = Date.parse("2026-08-22T12:00:00Z");

console.log("\nhow long you would go for");
t("the default when nothing is said", nightsOf({}), 7);
t("and it is the constant, not a copy", nightsOf({}), DEFAULT_NIGHTS);
t("a set value is used", nightsOf({ nights: 4 }), 4);
t("a string from a form field still counts", nightsOf({ nights: "10" }), 10);
// Zero nights is not a trip, and a negative one is not anything.
t("zero falls back", nightsOf({ nights: 0 }), 7);
t("negative falls back", nightsOf({ nights: -3 }), 7);
t("nonsense falls back", nightsOf({ nights: "a while" }), 7);

console.log("\nthe return date");
t("outbound plus the nights", returnDate({}, "2027-05-15"), "2027-05-22");
t("with a custom stay", returnDate({ nights: 3 }, "2027-05-15"), "2027-05-18");
// Crossing a month, and a leap year, because +7 on a date is where this breaks.
t("it crosses a month end", returnDate({}, "2027-05-28"), "2027-06-04");
t("and a year end", returnDate({}, "2027-12-29"), "2028-01-05");
t("and February in a leap year", returnDate({ nights: 2 }, "2028-02-28"), "2028-03-01");
// An explicit end to the window is the traveller saying so outright.
t("an explicit end date wins",
  returnDate({ target_to: "2027-05-30", nights: 3 }, "2027-05-15"), "2027-05-30");
// A window ending in a MONTH names no day, so it cannot be a return date.
t("a month-resolution end is not a date",
  returnDate({ target_to: "2027-06" }, "2027-05-15"), "2027-05-22");
t("an end before the outbound is ignored",
  returnDate({ target_to: "2027-05-01" }, "2027-05-15"), "2027-05-22");
t("no outbound, no return", returnDate({}, null), null);

console.log("\nclose enough to price — measured on the far end");
t("next month is", bookableNow({ target_from: "2026-09" }, NOW), true);
// THE case. Outbound lands inside the horizon, the return does not, so there is
// no round trip to price and offering the button would be a lie.
const edge = new Date(NOW + (FLIGHT_HORIZON_DAYS - 3) * 86400000).toISOString().slice(0, 10);
t("an outbound just inside the horizon, with a week's return, is NOT",
  bookableNow({ target_from: edge }, NOW), false);
t("the same outbound with a one-night stay is",
  bookableNow({ target_from: edge, nights: 1 }, NOW), true);
t("two years out is not", bookableNow({ target_from: "2028-06" }, NOW), false);
t("a bare year names no month, so no", bookableNow({ target_from: "2027" }, NOW), false);
t("nothing set, no", bookableNow({}, NOW), false);
t("a window already gone, no", bookableNow({ target_from: "2026-01" }, NOW), false);

console.log("\nin season now — stricter than the warning is");
// inSeason() answers "is there anything that rules this month out", so it says
// yes when nothing was declared. Right for a warning, useless as a filter.
t("inSeason says yes with no season declared", inSeason(8, null, null), true);
t("the FILTER says no", seasonNow({}, 8), false);
t("declared and matching", seasonNow({ season_from: 5, season_to: 10 }, 8), true);
t("declared and not", seasonNow({ season_from: 5, season_to: 10 }, 2), false);
t("a wrapping season still wraps", seasonNow({ season_from: 12, season_to: 3 }, 1), true);
t("half a season is not a season", seasonNow({ season_from: 5 }, 8), false);

console.log("\nordering a list that is meant to grow");
const PORTS = [
  { code: "LAX", latitude: 33.9434, longitude: -118.4084, legs: 120 },
  { code: "OGG", latitude: 20.8986, longitude: -156.4305, legs: 6 },
];
const IDEAS = [
  { place: "Zermatt", target_from: "2027-01", created_at: "2026-01-01", season_from: 12, season_to: 3 },
  { place: "Maui", target_from: "2026-11", created_at: "2026-08-01",
    latitude: 20.79, longitude: -156.33, season_from: 4, season_to: 10 },
  { place: "Someday Place", created_at: "2026-05-01" },
  { place: "Aspen", target_from: "2026-12", created_at: "2026-03-01",
    latitude: 39.19, longitude: -106.82 },
];
const names = (l) => l.map((i) => i.place);

t("soonest first", names(sortIdeas(IDEAS, "target", PORTS)),
  ["Maui", "Aspen", "Zermatt", "Someday Place"]);
// "Someday" is not sooner than 2027. An undated idea sorting FIRST would push
// every real plan below the fold.
t("and undated goes last, not first",
  sortIdeas(IDEAS, "target", PORTS)[3].place, "Someday Place");
t("A to Z", names(sortIdeas(IDEAS, "name", PORTS)),
  ["Aspen", "Maui", "Someday Place", "Zermatt"]);
t("most recently added first", names(sortIdeas(IDEAS, "added", PORTS))[0], "Maui");
// Aspen is closer to Los Angeles than Maui is; both are closer than an idea
// with no coordinates at all, which must not read as distance zero.
t("nearest first", names(sortIdeas(IDEAS, "near", PORTS)).slice(0, 2), ["Aspen", "Maui"]);
// Both unlocated ideas land after both located ones, and tie-break by name --
// Infinity - Infinity is NaN, so this ordering must come from a real rule.
t("and every unlocated idea sorts after every located one",
  names(sortIdeas(IDEAS, "near", PORTS)).slice(2).sort(), ["Someday Place", "Zermatt"]);
t("ties break by name, not by chance",
  names(sortIdeas(IDEAS, "near", PORTS)).slice(2), ["Someday Place", "Zermatt"]);
t("sorting does not mutate the original", names(IDEAS)[0], "Zermatt");
// reachability() walks every airport to find the nearest, so calling it from
// inside the comparator is ~50 haversines per compare -- about 70,000 to sort a
// hundred ideas, for a distance that cannot change mid-sort.
t("each distance is measured once, not once per comparison",
  /var dist = new Map\(\);/.test(app), true);

console.log("\nfiltering it");
t("all means all", filterIdeas(IDEAS, "all", PORTS, NOW).length, 4);
// August: Maui's season is Apr-Oct, Zermatt's is Dec-Mar, Aspen declared none.
t("in season in August", names(filterIdeas(IDEAS, "season", PORTS, NOW)), ["Maui"]);
const jan = Date.parse("2027-01-15T12:00:00Z");
t("and in January", names(filterIdeas(IDEAS, "season", PORTS, jan)), ["Zermatt"]);
t("no location yet", names(filterIdeas(IDEAS, "noplace", PORTS, NOW)),
  ["Zermatt", "Someday Place"]);
// An address is NOT a location here. Alex typed sixteen real street addresses
// and every one stayed inert: the map, the distance, the drive time and the
// airport all need a pin, and none of them can read prose.
t("a typed address is still not a location",
  filterIdeas([{ place: "X", address: "1471 W Millers Cove Rd, Walland, TN" }], "noplace", PORTS, NOW).length, 1);
t("a pin is", filterIdeas([{ place: "X", latitude: 1, longitude: 2 }], "noplace", PORTS, NOW).length, 0);
// Some ideas have no address YET and never will until something is booked. The
// itinerary has had this exemption for a while; the ideas list needed it too,
// or the prompt counts a decision already made and teaches you to ignore it.
t("an idea marked as having no address yet is not counted",
  filterIdeas([{ place: "Rafting", no_location: true }], "noplace", PORTS, NOW).length, 0);
t("the prompt respects it too",
  /latitude == null && !i\.no_location/.test(app), true);
t("and the form offers the tick", /noLocBox\.checked/.test(app), true);
// And the address is what gets searched, which is the difference between a
// reliable lookup and the coin toss that put Blackberry Farm in south London.
t("the address drives the lookup when there is one",
  geoQueries({ place: "P", address: "A, B, C" })[0], "A, B, C");
t("and the row says which query matched", /"matched: " \+ usedQuery/.test(app), true);
t("an unknown filter returns everything rather than nothing",
  filterIdeas(IDEAS, "wat", PORTS, NOW).length, 4);
t("every filter key is implemented",
  IDEA_FILTERS.every((f) => f.key === "all" || /season|bookable|noplace/.test(f.key)), true);
t("every sort key is implemented",
  IDEA_SORTS.map((o) => o.key).sort(), ["added", "name", "near", "target"]);

console.log("\nwhat to search for, coarsest last");
// Verified against the live geocoder: OpenStreetMap has NOTHING for
// "1471 W Millers Cove Rd, Walland, TN 37886" and resolves "Walland, TN 37886"
// immediately. For which-airport-serves-this a town is precise enough -- TYS
// is 19km from Walland either way -- so a town that resolves beats a street
// that does not.
const BB = { place: "Blackberry Farm", address: "1471 W Millers Cove Rd, Walland, TN 37886" };
t("the full address is tried first", geoQueries(BB)[0], BB.address);
t("then the street line is dropped", geoQueries(BB)[1], "Walland, TN 37886");
t("and the name is the last resort", geoQueries(BB).slice(-1), ["Blackberry Farm"]);
// "TN 37886" alone is not a place, so the last two components always survive.
t("a two-part address is never coarsened away",
  geoQueries({ place: "X", address: "Paradise Island, Bahamas" }),
  ["Paradise Island, Bahamas", "X"]);
t("no address falls back to the name alone", geoQueries({ place: "Somewhere" }), ["Somewhere"]);
t("an address equal to the name is not searched twice",
  geoQueries({ place: "Atlantis", address: "Atlantis" }), ["Atlantis"]);
t("nothing at all yields nothing to search", geoQueries({}), []);
t("the cascade stops at the first hit",
  /if \(hits\.length\) \{ usedQuery = qs\[qi\]; break; \}/.test(app), true);
t("each extra attempt still waits for the geocoder", /if \(qi\) await new Promise/.test(app), true);
// A hit on the town is a different pin from the front door, and saving it
// without saying so quietly moves the property a few kilometres.
t("a coarser match is flagged as one", /searched\.classList\.add\("is-coarse"\)/.test(app), true);

console.log("\nwhat the code does with it");
t("the panel measures the horizon on the return",
  /var win = flightWindow\(ret \|\| day\)/.test(app), true);
t("and sends the return to the API", /searchFlights\(dep, arr, day, ret, refresh\)/.test(app), true);
t("the server prices a round trip when given one",
  /q\.searchParams\.set\("type", back \? "1" : "2"\)/.test(core), true);
t("and never a round trip without a return date",
  /if \(back\) q\.searchParams\.set\("return_date", back\)/.test(core), true);
// A round trip served from a one-way cache row is a wrong price, silently.
t("the return date is part of the cache key",
  /const key = from \+ ">" \+ to \+ ">" \+ date \+ ">" \+ \(back \|\| "-"\)/.test(core), true);
t("the server checks the horizon against the return",
  /const lastDay = back \|\| date;/.test(core), true);
t("a return before the outbound is refused",
  /The return has to be after the outbound/.test(core), true);
t("the result says which kind of trip it priced",
  /data\.round_trip \? "Round trip " : "One way "/.test(app), true);

console.log("\nthe bulk lookup proposes, it does not decide");
t("only what you pick gets written", /Only what you pick gets saved/.test(app), true);
// Nominatim's usage policy is one request a second. Seventeen parallel fetches
// would be a policy violation, and the fix is not a smaller list.
t("the run is spaced for the geocoder's policy", /GEOCODE_GAP_MS/.test(app), true);
t("and it is at least a second", /var GEOCODE_GAP_MS = 11\d\d;/.test(app), true);
t("closing the dialog stops the run",
  /if \(!document\.body\.contains\(panel\)\) return;/.test(app), true);
t("a no-match is said out loud, not skipped silently",
  /No match — add this one by hand\./.test(app), true);
// /api/ext/geocode reports an upstream rate-limit as a 200 carrying
// {results: [], error: "geocoder 429"}, which is indistinguishable from "this
// place does not exist" unless the error field is read. It was not, so a block
// rendered as "No match" and sent you off to type an address for somewhere
// that would have resolved a minute later. Seen for real: seventeen ideas all
// reported no match while a direct call returned results.
t("a rate-limit is not reported as an absence",
  /not the same as no match/.test(app), true);
t("the error field is actually read",
  /if \(d && d\.error\) \{ upstream = String\(d\.error\); break; \}/.test(app), true);
// Continuing at one request a second while being told to stop is exactly the
// behaviour the gap exists to avoid.
t("three refusals in a row stops the run", /if \(blocked >= 3\)/.test(app), true);
// Both halves have to be true: the run stopped, AND whatever was already found
// survives. "Nothing was saved" alone reads as "your matches are gone".
t("and says what survives the stop",
  /already found are still yours to save/.test(app), true);
t("while still saying nothing was written when there is nothing",
  /Nothing was found — try again in a few minutes/.test(app), true);
t("a success resets the counter", /blocked = 0;/.test(app), true);
// The same trap in the single-field search every booking form uses.
t("the booking forms' place search reads it too",
  /Lookup unavailable \(" \+ d\.error \+ "\)/.test(app), true);
// Measured on the real list: of the first seven, the geocoder put Blackberry
// Farm in south London, Atlantis in Palm Beach County and Biltmore in Raleigh.
// Preselecting those would write three wrong places on an unread Save, so
// "Leave this one" is what starts selected and Save is disabled until you pick.
t("alternatives are offered, not one answer", /hits\.slice\(0, 4\)/.test(app), true);
t("the skip option is the one preselected", /sr\.checked = true;/.test(app), true);
t("Save is disabled until something is chosen", /save\.disabled = !n;/.test(app), true);
t("and the note is shown as the evidence to judge by",
  /el\("div", "find-note"/.test(app), true);
t("the warning says the geocoder is confidently wrong",
  /often confident and wrong about a bare name/.test(app), true);
t("a failed save names what failed",
  /failed\.push\(take\[j\]\.title\)/.test(app), true);
// One triage screen serves both callers, so each pick carries its own save.
t("and each pick knows how to save itself",
  /await take\[j\]\.apply\(take\[j\]\.chosen\)/.test(app), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
