-- Tripsy replacement — D1 schema.
--
-- Design rule: column names match the Tripsy API's field names exactly, and
-- every table keeps a `data` JSON blob holding the full record. The API can
-- therefore return byte-identical shapes to what the dashboard already consumes,
-- so the client changes by one line rather than being rewritten — and no field
-- is silently lost in migration just because I didn't think to give it a column.
--
-- The promoted columns exist only for the things we filter, sort or join on.
-- Everything else lives in `data` and is merged back on read.

CREATE TABLE IF NOT EXISTS trips (
  id                INTEGER PRIMARY KEY,
  name              TEXT,
  starts_at         TEXT,          -- YYYY-MM-DD
  ends_at           TEXT,
  has_dates         INTEGER NOT NULL DEFAULT 1,
  timezone          TEXT,
  description       TEXT,
  hidden            INTEGER NOT NULL DEFAULT 0,
  cover_image_url   TEXT,
  cover_gradient    INTEGER,
  internal_identifier TEXT,
  number_of_days    INTEGER,
  data              TEXT NOT NULL DEFAULT '{}',
  created_at        TEXT NOT NULL,
  updated_at        TEXT NOT NULL,
  deleted_at        TEXT
);
CREATE INDEX IF NOT EXISTS trips_starts   ON trips(starts_at);
CREATE INDEX IF NOT EXISTS trips_updated  ON trips(updated_at);
CREATE INDEX IF NOT EXISTS trips_deleted  ON trips(deleted_at);

-- Transportations, hostings, activities and expenses share a shape, but keeping
-- them in separate tables preserves the API's separate endpoints and lets each
-- promote the columns it actually sorts on.

CREATE TABLE IF NOT EXISTS transportations (
  id                    INTEGER PRIMARY KEY,
  trip_id               INTEGER NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  name                  TEXT,
  transportation_type   TEXT,
  transport_number      TEXT,
  company               TEXT,
  departure_at          TEXT,      -- ISO-8601 UTC
  arrival_at            TEXT,
  departure_timezone    TEXT,
  arrival_timezone      TEXT,
  provider_reservation_code TEXT,
  sort_order            INTEGER NOT NULL DEFAULT 0,
  internal_identifier   TEXT,
  data                  TEXT NOT NULL DEFAULT '{}',
  created_at            TEXT NOT NULL,
  updated_at            TEXT NOT NULL,
  deleted_at            TEXT
);
CREATE INDEX IF NOT EXISTS tr_trip    ON transportations(trip_id);
CREATE INDEX IF NOT EXISTS tr_dep     ON transportations(departure_at);
CREATE INDEX IF NOT EXISTS tr_updated ON transportations(updated_at);
CREATE INDEX IF NOT EXISTS tr_iid     ON transportations(internal_identifier);

CREATE TABLE IF NOT EXISTS hostings (
  id                    INTEGER PRIMARY KEY,
  trip_id               INTEGER NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  name                  TEXT,
  starts_at             TEXT,
  ends_at               TEXT,
  timezone              TEXT,
  address               TEXT,
  latitude              REAL,
  longitude             REAL,
  provider_reservation_code TEXT,
  sort_order            INTEGER NOT NULL DEFAULT 0,
  internal_identifier   TEXT,
  data                  TEXT NOT NULL DEFAULT '{}',
  created_at            TEXT NOT NULL,
  updated_at            TEXT NOT NULL,
  deleted_at            TEXT
);
CREATE INDEX IF NOT EXISTS ho_trip    ON hostings(trip_id);
CREATE INDEX IF NOT EXISTS ho_start   ON hostings(starts_at);
CREATE INDEX IF NOT EXISTS ho_updated ON hostings(updated_at);
CREATE INDEX IF NOT EXISTS ho_iid     ON hostings(internal_identifier);

CREATE TABLE IF NOT EXISTS activities (
  id                    INTEGER PRIMARY KEY,
  trip_id               INTEGER NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  name                  TEXT,
  activity_type         TEXT,
  starts_at             TEXT,
  ends_at               TEXT,
  timezone              TEXT,
  address               TEXT,
  latitude              REAL,
  longitude             REAL,
  provider_reservation_code TEXT,
  sort_order            INTEGER NOT NULL DEFAULT 0,
  internal_identifier   TEXT,
  data                  TEXT NOT NULL DEFAULT '{}',
  created_at            TEXT NOT NULL,
  updated_at            TEXT NOT NULL,
  deleted_at            TEXT
);
CREATE INDEX IF NOT EXISTS ac_trip    ON activities(trip_id);
CREATE INDEX IF NOT EXISTS ac_start   ON activities(starts_at);
CREATE INDEX IF NOT EXISTS ac_updated ON activities(updated_at);
CREATE INDEX IF NOT EXISTS ac_iid     ON activities(internal_identifier);

CREATE TABLE IF NOT EXISTS expenses (
  id                    INTEGER PRIMARY KEY,
  trip_id               INTEGER NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  name                  TEXT,
  amount                REAL,
  currency              TEXT,
  date                  TEXT,
  sort_order            INTEGER NOT NULL DEFAULT 0,
  internal_identifier   TEXT,
  data                  TEXT NOT NULL DEFAULT '{}',
  created_at            TEXT NOT NULL,
  updated_at            TEXT NOT NULL,
  deleted_at            TEXT
);
CREATE INDEX IF NOT EXISTS ex_trip    ON expenses(trip_id);
CREATE INDEX IF NOT EXISTS ex_updated ON expenses(updated_at);

-- Documents attach either to a trip or to a single item on it.
CREATE TABLE IF NOT EXISTS documents (
  id            INTEGER PRIMARY KEY,
  trip_id       INTEGER NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  parent_type   TEXT,               -- null = trip-level, else transportation|hosting|activity
  parent_id     INTEGER,
  title         TEXT,
  url           TEXT,
  data          TEXT NOT NULL DEFAULT '{}',
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL,
  deleted_at    TEXT
);
CREATE INDEX IF NOT EXISTS doc_trip   ON documents(trip_id);
CREATE INDEX IF NOT EXISTS doc_parent ON documents(parent_type, parent_id);

-- Custom activity categories (Tripsy's /v1/categories).
CREATE TABLE IF NOT EXISTS categories (
  id          INTEGER PRIMARY KEY,
  slug        TEXT NOT NULL,
  name        TEXT,
  icon_name   TEXT,
  color       TEXT,
  data        TEXT NOT NULL DEFAULT '{}',
  created_at  TEXT NOT NULL,
  updated_at  TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS cat_slug ON categories(slug);

-- Single-row account settings, replacing Tripsy's /v1/me.
CREATE TABLE IF NOT EXISTS settings (
  key    TEXT PRIMARY KEY,
  value  TEXT NOT NULL
);

-- Monotonic id source. Tripsy's ids are large integers and the migration keeps
-- them verbatim, so new records must start above the highest imported id or a
-- new booking could collide with a 2011 flight.
CREATE TABLE IF NOT EXISTS id_seq (
  name  TEXT PRIMARY KEY,
  next  INTEGER NOT NULL
);

-- Without this row nextId()'s UPDATE matches nothing and every write 500s, so a
-- database rebuilt from this file alone would look healthy and refuse to accept
-- a single record.
--
-- DO NOTHING, never OR REPLACE: re-running this file must not wind a live
-- counter backwards and start re-issuing ids that already exist. Order against
-- seed.sql therefore does not matter — seed.sql uses INSERT OR REPLACE and wins
-- whichever runs second, so the value below only ever applies to a rebuild that
-- has no seed at all, and such a rebuild has no rows to collide with.
INSERT INTO id_seq (name, next) VALUES ('global', 3856003)
ON CONFLICT(name) DO NOTHING;

-- Packing lists. A row either belongs to a trip or, with trip_id NULL, is a
-- reusable template — the same shape, so templating is just copying the items
-- across. `items` is a JSON array of {text, who, done}; `who` matters because
-- with five travellers the question is never "are the boots packed" but "are
-- JO's boots packed". Copying a template clears every tick, and saving a list
-- back as a template records only what to pack, never what happened to be
-- ticked at the time.
CREATE TABLE IF NOT EXISTS packing_lists (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  trip_id     INTEGER,        -- NULL = reusable template
  name        TEXT NOT NULL,
  items       TEXT NOT NULL,  -- JSON [{text, who, done}]
  created_at  TEXT NOT NULL,
  updated_at  TEXT NOT NULL,
  deleted_at  TEXT
);
CREATE INDEX IF NOT EXISTS idx_packing_trip ON packing_lists(trip_id);

-- Calendar feeds. The .ics a client subscribes to is read-only by nature — no
-- calendar can write back — but everything deciding what goes INTO it is edited
-- in the PWA and stored here. One token per feed so one can be revoked without
-- disturbing the others.
--
-- The row with token '@legacy' is the subscription that predates this table. Its
-- real token is the CAL_TOKEN Pages secret and is deliberately NOT stored here:
-- the Worker checks the secret and maps a match onto this row, so the feed
-- already on the phone keeps working and becomes editable, without the secret
-- ever being copied into the database.
CREATE TABLE IF NOT EXISTS cal_feeds (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  token         TEXT NOT NULL UNIQUE,
  name          TEXT NOT NULL,
  settings      TEXT NOT NULL,   -- JSON: include/backDays/lodgingStyle/alarms/busy/rich/link/categories
  created_at    TEXT NOT NULL,
  last_used_at  TEXT,            -- when a calendar client last polled it
  deleted_at    TEXT
);

-- Who may change things, as opposed to who may look.
--
-- This table does NOT decide who can log in — Cloudflare Access does, and an
-- address that is not in its policy never reaches the Worker at all. This
-- decides what someone Access has already admitted is allowed to do.
--
-- An address that is not listed is View/Read, not rejected. Adding a family
-- member is therefore one step in Access and they can see everything and change
-- nothing; promoting them to Admin/Edit is a separate, deliberate act. The safe
-- state is the default state.
--
-- Roles are enforced in the Worker, at the single point every endpoint passes
-- through, not by hiding buttons in the client. The client hides them too, but
-- only so the app does not offer what it will refuse.
--
-- The last Admin/Edit cannot be demoted or removed. Without that guard a
-- mis-click leaves nobody able to promote anybody, recoverable only by hand:
--   npx wrangler d1 execute wayfarer-data --remote \
--     --command "UPDATE users SET role='admin' WHERE email='you@example.com'"
CREATE TABLE IF NOT EXISTS users (
  email      TEXT PRIMARY KEY,     -- the Cloudflare Access identity, lowercased
  role       TEXT NOT NULL DEFAULT 'view',   -- 'admin' | 'view'
  name       TEXT,                 -- optional label, for the Settings list
  added_at   TEXT NOT NULL,
  added_by   TEXT
);

-- CONFIGURE ME. A placeholder admin, so the table is never empty on a
-- fresh deploy -- an empty table means no admins and no way to appoint one
-- through the app. Point it at your own Access login (SETUP.md, Part 1.9) — an empty table
-- would mean no admins, and no way to appoint one through the app.
INSERT INTO users (email, role, name, added_at, added_by)
VALUES ('you@example.com', 'admin', 'Alex', datetime('now'), 'schema')
ON CONFLICT(email) DO NOTHING;

-- Snoozed and dismissed trip-check findings, one row per finding rather than a
-- JSON blob per person: each hide and unhide is then an independent upsert or
-- delete, so two devices writing at once cannot clobber each other's unrelated
-- entries. `owner` is the Cloudflare Access identity, so this syncs one person
-- across their devices without hiding a finding from the rest of the family.
-- `owner` is the Cloudflare Access identity for a snooze, and the sentinel
-- '@everyone' for a dismissal. The split is the point: a snooze says "not now",
-- which is only true for the person who said it; a dismissal says the finding is
-- wrong or does not apply, which is true for whoever looks at it. So a snooze
-- syncs across your own devices and a dismissal reaches the whole household.
-- '@everyone' cannot collide with a real identity because no email begins '@'.
CREATE TABLE IF NOT EXISTS check_state (
  owner       TEXT NOT NULL,
  key         TEXT NOT NULL,
  mode        TEXT NOT NULL,   -- 'snoozed' | 'dismissed'
  until       TEXT,            -- ISO 8601, snoozed only
  updated_at  TEXT NOT NULL,
  PRIMARY KEY (owner, key)
);

-- Dismissals made before they were shared. Idempotent, so it is safe to re-run:
-- INSERT OR REPLACE collapses the case where two people had each dismissed the
-- same finding, which would otherwise collide on the primary key.
INSERT OR REPLACE INTO check_state (owner, key, mode, until, updated_at)
  SELECT '@everyone', key, 'dismissed', NULL, MAX(updated_at)
    FROM check_state WHERE mode = 'dismissed' AND owner <> '@everyone'
   GROUP BY key;
DELETE FROM check_state WHERE mode = 'dismissed' AND owner <> '@everyone';

-- Forwarded booking confirmations, captured by the inbox Worker.
--
-- The importer pulls Gmail and Outlook directly twice a day, which covers the
-- ordinary case. This covers the two it cannot: a confirmation that arrives at
-- an address the scan does not watch, and one you want captured the moment it
-- lands rather than at the next run.
--
-- The Worker deliberately does NOT parse. It stores the raw message in R2 and
-- the headers here, and the importer — which has a model and the field rules —
-- does the understanding on its next pass. Capture and comprehension are
-- separate jobs and a Worker is only good at the first.
CREATE TABLE IF NOT EXISTS inbox (
  id            INTEGER PRIMARY KEY,
  received_at   TEXT NOT NULL,
  from_addr     TEXT,
  to_addr       TEXT,
  subject       TEXT,
  message_id    TEXT,             -- RFC 5322 Message-ID, for deduplication
  size          INTEGER,
  r2_key        TEXT NOT NULL,    -- the full raw message, in the docs bucket
  status        TEXT NOT NULL DEFAULT 'pending',   -- pending | imported | ignored
  note          TEXT,             -- what the importer decided, and why
  processed_at  TEXT
);
CREATE INDEX IF NOT EXISTS inbox_status ON inbox(status, received_at);
CREATE UNIQUE INDEX IF NOT EXISTS inbox_msgid ON inbox(message_id) WHERE message_id IS NOT NULL;

-- Trip ideas: the bucket list, grown into a pre-trip planner.
--
-- It began as one JSON array in settings.bucket_list -- 17 entries, 5.4KB,
-- rewritten whole on every edit. That was right for a list of names and wrong
-- the moment an entry gained a place, a season and a target window, because the
-- blob grows with every field and there is nothing to index or query.
--
-- The shape follows the trips table deliberately: same id_seq, same soft
-- delete, same promoted-columns-plus-data-blob split, so everything already
-- written for trips -- patchRow, compare-and-set, hydrate -- works unchanged.
--
-- What each column is for:
--   place        the name, and the only required field. An idea can be a
--                property ("Blackberry Farm") or a destination ("Hawaii Big
--                Island"); 16 of the first 17 were properties, which is why
--                address and coordinates matter here at all.
--   address      +latitude/longitude: where it IS. On conversion these become
--                the trip's first hosting record, so the map and the
--                No-location rule work from the first minute.
--   target_from  +target_to: a WINDOW, not dates. "2027-09" means September
--                2027; "2027-09-14" means that week. Stored as text so a month
--                and a day are the same field, and sorted as text because
--                ISO-8601 sorts correctly either way.
--   season_from  +season_to: month numbers, 1-12, for when the place is worth
--                going. Nantucket is 5-10. Wraps: 11-3 is November to March.
--   converted_at when it became a trip. The row is deleted on conversion --
--                the list is for what you have NOT booked -- so this exists
--                only for the brief window before the delete lands.
CREATE TABLE IF NOT EXISTS trip_ideas (
  id            INTEGER PRIMARY KEY,
  place         TEXT NOT NULL,
  address       TEXT,
  latitude      REAL,
  longitude     REAL,
  target_from   TEXT,             -- "2027" | "2027-09" | "2027-09-14"
  target_to     TEXT,
  season_from   INTEGER,          -- 1-12, inclusive
  season_to     INTEGER,          -- 1-12, inclusive; < season_from means it wraps the year
  sort_order    INTEGER NOT NULL DEFAULT 0,
  data          TEXT NOT NULL DEFAULT '{}',   -- note, links[], nearest airport, anything later
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL,
  deleted_at    TEXT
);
CREATE INDEX IF NOT EXISTS ideas_target  ON trip_ideas(target_from);
CREATE INDEX IF NOT EXISTS ideas_updated ON trip_ideas(updated_at);
CREATE INDEX IF NOT EXISTS ideas_deleted ON trip_ideas(deleted_at);

-- Flight routing lookups, cached.
--
-- The free SerpApi allowance is 250 searches a MONTH, so the cache is not a
-- speed optimisation -- it is the thing that keeps the feature inside its
-- budget. A row is keyed by exactly what was asked (route, date, cabin,
-- passengers) and is served until it expires, so opening the same idea twice
-- costs one search, not two.
--
-- Nothing here is authoritative and none of it is a booking. It is a cache of
-- somebody else's answer to "roughly how do I get there", and it is allowed to
-- go stale; expires_at is when we stop believing it, not when it is deleted.
CREATE TABLE IF NOT EXISTS flight_cache (
  cache_key     TEXT PRIMARY KEY,   -- "LAX>OGG>2027-05-15>1>USD"
  origin        TEXT NOT NULL,
  destination   TEXT NOT NULL,
  depart_on     TEXT NOT NULL,      -- YYYY-MM-DD, the sampled date
  payload       TEXT NOT NULL,      -- the normalised itineraries, not the raw response
  fetched_at    TEXT NOT NULL,
  expires_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS flight_cache_expires ON flight_cache(expires_at);

-- ---------------------------------------------------------------------------
-- Credit-card spend thresholds
--
-- Some cards pay a reward for hitting an annual spend figure -- $60k on the
-- Hilton Aspire for two free nights, $250k on the Business Platinum for a
-- $1,200 flight credit. The point of tracking it is knowing when to STOP
-- steering spend at a card, which is only answerable from real transactions.
-- ---------------------------------------------------------------------------

-- One Plaid Item: a single login at one institution, which may cover several
-- cards. The Amex login returned four.
CREATE TABLE IF NOT EXISTS card_items (
  id            INTEGER PRIMARY KEY,
  institution   TEXT,
  -- The NAME of the Pages secret holding this item's Plaid access token, not
  -- the token. That token reads bank transactions, and a column holding it
  -- would ride along in every SQL snapshot the backup task writes to disk --
  -- a bank linkage scattered across backup files to save one indirection.
  -- Set the secret with: wrangler pages secret put <token_env>
  token_env     TEXT NOT NULL,
  cursor        TEXT,                    -- /transactions/sync, so syncs are incremental
  last_sync_at  TEXT,
  last_error    TEXT,                    -- a failed sync must not read as "no spend"
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL,
  deleted_at    TEXT
);

CREATE TABLE IF NOT EXISTS card_accounts (
  id                INTEGER PRIMARY KEY,
  item_id           INTEGER NOT NULL REFERENCES card_items(id) ON DELETE CASCADE,
  plaid_account_id  TEXT NOT NULL UNIQUE,
  name              TEXT,
  mask              TEXT,
  -- Chase names this card "CREDIT CARD". A nickname survives the sync, which
  -- overwrites `name` from the bank every time; COALESCE picks it when set.
  nickname      TEXT,
  created_at        TEXT NOT NULL,
  updated_at        TEXT NOT NULL,
  deleted_at        TEXT
);

-- Transactions are kept, not just totals. The classifier took three attempts to
-- get right -- Plaid files Amex payments as INCOME_SALARY, and statement
-- credits are not refunds -- so a future correction has to be applicable
-- without re-syncing two years of history.
CREATE TABLE IF NOT EXISTS card_txns (
  id                TEXT PRIMARY KEY,       -- plaid transaction_id
  plaid_account_id  TEXT NOT NULL,
  date              TEXT NOT NULL,
  amount            REAL NOT NULL,          -- POSITIVE is a charge, negative is money back
  name              TEXT,
  category          TEXT,                   -- personal_finance_category.detailed
  pending           INTEGER NOT NULL DEFAULT 0,
  updated_at        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS card_txns_acct ON card_txns(plaid_account_id, date);

CREATE TABLE IF NOT EXISTS card_goals (
  id                INTEGER PRIMARY KEY,
  plaid_account_id  TEXT NOT NULL,
  label             TEXT NOT NULL,          -- "2 free Hilton nights"
  target            REAL NOT NULL,
  -- 'calendar' | 1 January to 31 December
  -- 'march'    | 1 March to the end of February, which is American's Loyalty
  --            | Point year. Not a detail: every figure keyed off 1 January is
  --            | wrong for it, including which transactions are in scope.
  period            TEXT NOT NULL DEFAULT 'calendar',
  -- The Platinum's $1,200 credit for 2025 spend landed in March 2026. Saying
  -- "earned" without saying when it arrives sends you looking for a credit that
  -- is months away.
  paid_next_year    INTEGER NOT NULL DEFAULT 0,

  -- ---- goals counted in something other than dollars --------------------
  --
  -- World of Hyatt Globalist is 60 qualifying NIGHTS a year, and card spend is
  -- only one of three ways to get them:
  --
  --   base_units       nights the card grants for holding it (5 on the Hyatt
  --                    card), before a dollar is spent
  --   units_per_step   nights earned per spend_step of spend (2 per $5,000)
  --   stay_brand       whose hotels count, matched against the itinerary the
  --                    app already keeps -- one night credited per night stayed
  --
  -- Which is why $140,000 of pure card spend reaches Globalist with no stays
  -- at all: 5 held + 2 x 28 increments = 61.
  --
  -- A 'usd' goal leaves all of these null and behaves exactly as before.
  -- 'usd'    | a dollar threshold, counted from transactions alone
  -- 'nights'  | qualifying nights, part spend and part stays
  -- 'points'  | a loyalty balance anchored to the programme's own figure
  unit              TEXT NOT NULL DEFAULT 'usd',
  base_units        REAL NOT NULL DEFAULT 0,
  spend_step        REAL,
  units_per_step    REAL,
  stay_brand        TEXT,
  -- Hyatt credits qualifying nights on up to three PAID rooms per stay, and
  -- Alex routinely books two. Counting them is therefore legitimate and also
  -- not something to assume, so it is a setting rather than a rule -- see
  -- card_stay_marks for the same reasoning applied per stay.
  count_extra_rooms INTEGER NOT NULL DEFAULT 0,

  -- ---- goals anchored to a figure only the programme knows ---------------
  --
  -- Loyalty Points come from card spend AND from flying, and the flying half
  -- is not derivable here: every flight in the itinerary carries price = 0, so
  -- the app knows where Alex flew and never what the ticket cost. Estimating
  -- it would present a fabricated half of a two-source total as progress.
  --
  -- So American's own balance is the anchor and only card spend recorded AFTER
  -- baseline_at is added to it. Re-reading the balance moves the anchor forward
  -- and absorbs whatever flying has happened since.
  baseline_units    REAL NOT NULL DEFAULT 0,
  baseline_at       TEXT,

  created_at        TEXT NOT NULL,
  updated_at        TEXT NOT NULL,
  deleted_at        TEXT
);

-- Which stays count toward a nights goal, where the automatic answer is wrong.
--
-- No name test can be trusted here, and the 2026 itinerary proves it in both
-- directions. "Hotel Seville NoMad" IS a Hyatt -- the card statement says
-- HYATT SEVILLE NOMAD -- but nothing in the name it is stored under says so,
-- and three nights would have gone quietly uncounted. Meanwhile Alila,
-- Thompson, Andaz and the Unbound Collection are all Hyatt brands that never
-- print the word.
--
-- Undercounting silently is the failure this app keeps being punished for, so
-- the brand match is a DEFAULT and this table is the correction. A row here
-- overrides it in either direction: counts=1 includes a stay the match missed,
-- counts=0 drops one it should not have claimed.
CREATE TABLE IF NOT EXISTS card_stay_marks (
  id          INTEGER PRIMARY KEY,
  goal_id     INTEGER NOT NULL REFERENCES card_goals(id) ON DELETE CASCADE,
  hosting_id  INTEGER NOT NULL REFERENCES hostings(id) ON DELETE CASCADE,
  counts      INTEGER NOT NULL,
  created_at  TEXT NOT NULL,
  updated_at  TEXT NOT NULL,
  UNIQUE(goal_id, hosting_id)
);
CREATE INDEX IF NOT EXISTS csm_goal ON card_stay_marks(goal_id);
