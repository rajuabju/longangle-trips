// The trip header, built like a dashboard card.
//
// It started as one flex row holding the name, the countdown and three
// controls, wrapping wherever it ran out of width -- so on a phone the break
// landed somewhere different on every trip. That was split into two rows, and
// then the header was made to match the card you tapped to get here:
//
//   .detail-cover        the image, with a gradient scrim
//     .cd-badge          "In 34 days", top-left, exactly as on a card
//     .detail-coverbody
//       h2.detail-name   the trip name, over the scrim
//   .detail-inner
//     .detail-when       the dates and day count -- BELOW the image, on purpose
//     .detail-chiprow    kind, edit, delete
//
// Moving the name onto the cover is what pays for the larger type: it no longer
// shares a line with the dates, so it has the whole width. Measured at 390px,
// before and after:
//     name    20.7px, 91% of the 181 real names on one line
//          -> 29.3px, 99-100% on one line   (better fit AND bigger)
//     dates   14.0px -> 15.9px
// and the countdown moving to the cover is what pays for the three remaining
// chips being a size larger.
//
// Verified at 390 and 1280, all three text sizes: name on one line (two are
// allowed and clamped at two), dates whole, chip row one line, no overflow.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");
const css = fs.readFileSync("public/styles.css", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

console.log("\nthe name and the countdown sit on the image");
t("the name is built into the cover", /var nameEl = el\("h2", "detail-name", t\.name \|\| "Untitled trip"\);/.test(app), true);
t("inside a body element, as on a card", /coverBody\.appendChild\(nameEl\);\s*\n\s*cover\.appendChild\(coverBody\);/.test(app), true);
// One name in 181 needs two lines at the large text size; this is how the rest
// of a clipped name stays reachable.
t("and carries its full name", /nameEl\.title = t\.name \|\| "Untitled trip";/.test(app), true);
t("the countdown is a badge on the cover", /if \(cdText\) cover\.appendChild\(el\("span", "cd-badge", cdText\)\);/.test(app), true);
// The same class the dashboard card uses, so the two cannot drift apart.
t("using the same class a card does", /var cd = countdown\(t\); if \(cd\) \{ var badge = el\("span", "cd-badge", cd\); cover\.appendChild\(badge\); \}/.test(app), true);
t("and the cover goes in after both", app.indexOf("cover.appendChild(coverBody);") < app.indexOf("content.appendChild(cover);"), true);

console.log("\nthe dates stay below the image");
t("appended straight to the inner panel", /if \(when\) inner\.appendChild\(el\("div", "detail-when", when\)\);/.test(app), true);
// The row that used to hold the name and the dates together is gone.
t("no title row survives", /detail-titlerow/.test(app), false);
t("nor its stylesheet rule", /\.detail-titlerow/.test(css), false);

console.log("\nthree controls below, not four");
t("kind", /chipRow\.appendChild\(typeBtn\);/.test(app), true);
t("edit", /chipRow\.appendChild\(editBtn\);/.test(app), true);
t("delete", /chipRow\.appendChild\(delBtn\);/.test(app), true);
t("in that order",
  app.indexOf("chipRow.appendChild(typeBtn);") < app.indexOf("chipRow.appendChild(editBtn);") &&
  app.indexOf("chipRow.appendChild(editBtn);") < app.indexOf("chipRow.appendChild(delBtn);"), true);
t("and exactly three of them", (app.match(/chipRow\.appendChild\(/g) || []).length, 3);
// .cd-pill was the countdown's chip in that row. Nothing renders it now, so the
// rule would be dead CSS -- the same trap .sec-arrow was.
t("the old countdown chip class is gone from the app", /cd-pill/.test(app), false);
t("and from the stylesheet", /cd-pill/.test(css), false);

console.log("\nthe cover carries text, so it is built to");
t("it is positioned and bottom-aligned", /\.detail-cover \{[\s\S]*?position:relative; display:flex; align-items:flex-end; \}/.test(css), true);
// Covers are arbitrary photographs. Without a floor under the text it is
// legible on some and not on others, and "some" is the only guarantee.
t("with the same scrim the cards use", /\.detail-cover::after \{ content:""; position:absolute; inset:0;/.test(css), true);
t("the same gradient, not an approximation of it",
  (css.match(/background:linear-gradient\(to top,rgba\(0,0,0,\.74\) 0%,rgba\(0,0,0,\.25\) 44%,rgba\(0,0,0,0\) 70%\)/g) || []).length, 2);
t("the body sits above the scrim", /\.detail-coverbody \{ position:relative; z-index:1; width:100%;/.test(css), true);
t("and the name has a shadow as well as the scrim", /\.detail-name \{[\s\S]*?text-shadow:0 1px 6px rgba\(0,0,0,\.5\);/.test(css), true);
// The cover is a fixed ratio; a third line would climb out of the readable part
// of the gradient.
t("two lines at most", /-webkit-line-clamp:2/.test(css), true);

console.log("\nthe sizes the change bought");
t("the name is 30 on desktop", /\.detail-name \{[\s\S]*?font-size:calc\(30 \* var\(--px\) \* var\(--fs\)\)/.test(css), true);
t("and 24 on a phone", /\.detail-name \{ font-size:calc\(24 \* var\(--px\) \* var\(--fs\)\); \}/.test(css), true);
t("the dates are 15.5 on desktop", /\.detail-when \{ color:var\(--muted\); font-size:calc\(15\.5 \* var\(--px\) \* var\(--fs\)\)/.test(css), true);
t("and 13 on a phone", /\.detail-when \{ font-size:calc\(13 \* var\(--px\) \* var\(--fs\)\); \}/.test(css), true);
t("the three chips grew too", (css.match(/\.detail-chiprow \.type-toggle \{ padding:5px 13px; font-size:calc\(13 \* var\(--px\) \* var\(--fs\)\); \}/g) || []).length, 2);

console.log("\nthe close button sits on the image");
// The cover is capped to --cards-w so its crop matches a dashboard card, which
// leaves it inset from the panel on a wide screen -- 100px at Default, 60px at
// Compact. The close button is positioned against the PANEL, so it sat out in
// the margin beside the photo. Verified after: 12px inside the cover's right
// edge at all three width settings, and still 12px on a phone.
t("it is walked in by the cover's own inset",
  /right: max\(12px, calc\(12px \+ \(100% - var\(--cards-w, 100%\)\) \/ 2\)\);/.test(css), true);
// max() because the term goes NEGATIVE on a phone -- measured -293px, off the
// screen entirely. --cards-w is 1000px there, not the 100% the phone block
// sets: that declaration is inside a media query and a later plain :root
// overrides it, because a media query adds no specificity.
t("floored so it cannot leave the screen", /right: max\(12px,/.test(css), true);
// Check Trips, Changes and Calendar render into this same panel with no image,
// and there the button belongs at the panel edge.
t("and only where there is a cover to sit on",
  /\.detail-panel:has\(\.detail-cover\) \.overlay-close \{/.test(css), true);
t("the unscoped rule still puts it at the edge",
  /\.overlay-close \{ position:absolute; top:12px; right:12px; z-index:2; \}/.test(css), true);

console.log("\nthe prior-visits link is a footnote");
// Reference material: useful when planning a return visit, noise every other
// time. It reads as a footnote to the itinerary, so it sits under the last day
// rather than above the first.
t("it is appended to the itinerary column", /var recallWrap = el\("div"\); colMain\.appendChild\(recallWrap\);/.test(app), true);
t("after the itinerary itself", app.indexOf("colMain.appendChild(itin);") < app.indexOf("colMain.appendChild(recallWrap);"), true);
t("and no longer near the top of the panel", /var recallWrap = el\("div"\); inner\.appendChild\(recallWrap\);/.test(app), false);
// An aside about other trips, not a fact about this one.
t("set in italic", /\.recall-link \{[^}]*font-style:italic;/.test(css), true);

console.log("\nand a heading it should never have touched");
// The previous version shrank `.detail-inner h2` to 17 on a phone for the trip
// name's sake. The trip name was not the only h2 in there: "What changed",
// "Calendar" and "Check all upcoming trips" share the selector and were shrunk
// with it. The name has left .detail-inner, so the override is gone.
t("no phone override on .detail-inner h2 remains", /\.detail-inner h2 \{ font-size:calc\(17/.test(css), false);
t("and panel headings keep their own size", /\.detail-inner h2 \{ margin:0; font-size:calc\(23 \* var\(--px\) \* var\(--fs\)\); \}/.test(css), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
