// Trip type: the default, and how search matches it.
//
// The rule under test is a judgment call, which is exactly the kind that gets
// "simplified" later: matching the type is a PREFIX of at least four characters,
// while the name and destination matches beside it are substrings. Nearly all
// 183 trips are personal, so a substring match on "per" would return almost the
// whole list and bury a search for Perth.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");

function grab(name) {
  const i = src.indexOf("  function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
const varBlock = (name) => {
  const i = src.indexOf("  var " + name + " = {");
  if (i < 0) throw new Error("missing var " + name);
  return src.slice(i, src.indexOf("\n  };", i) + 5);
};

eval(varBlock("TRIP_TYPES") + "\n" +
  ["tripType", "isBusiness", "matchesTripType"].map(grab).join("\n") +
  ";Object.assign(globalThis,{TRIP_TYPES,tripType,isBusiness,matchesTripType});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const ok = got === want;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + JSON.stringify(want) + "\n        got  " + JSON.stringify(got));
};

// ---- the default ----------------------------------------------------------
// 183 trips predate the flag. Absent has to mean personal or the whole history
// would need backfilling before the app was correct.
t("absent is personal", tripType({}), "personal");
t("null trip is personal", tripType(null), "personal");
t("undefined field is personal", tripType({ trip_type: undefined }), "personal");
t("explicit personal", tripType({ trip_type: "personal" }), "personal");
t("explicit business", tripType({ trip_type: "business" }), "business");
// Anything unrecognised falls to personal rather than inventing a third state.
t("garbage value is personal", tripType({ trip_type: "Business " }), "personal");
t("wrong case is personal", tripType({ trip_type: "BUSINESS" }), "personal");
t("isBusiness only for the exact value", isBusiness({ trip_type: "business" }), true);
t("isBusiness false by default", isBusiness({}), false);

// ---- search ---------------------------------------------------------------
const B = { trip_type: "business" }, P = {};

t("full word matches business", matchesTripType(B, "business"), true);
t("full word matches personal", matchesTripType(P, "personal"), true);
t("business query does not match a personal trip", matchesTripType(P, "business"), false);
t("personal query does not match a business trip", matchesTripType(B, "personal"), false);

// Prefixes at or above the threshold.
t("four characters is enough — busi", matchesTripType(B, "busi"), true);
t("four characters is enough — pers", matchesTripType(P, "pers"), true);
t("six characters — person", matchesTripType(P, "person"), true);

// Below the threshold, nothing matches. This is the whole point: "per" must
// stay available for Perth and Perugia, and "bus" for a bus.
t("three characters does not match — per", matchesTripType(P, "per"), false);
t("three characters does not match — bus", matchesTripType(B, "bus"), false);
t("one character does not match", matchesTripType(P, "p"), false);
t("empty query does not match", matchesTripType(P, ""), false);

// Prefix, not substring: a query has to start the word.
t("mid-word substring does not match", matchesTripType(B, "siness"), false);
t("mid-word substring does not match — rsonal", matchesTripType(P, "rsonal"), false);
t("trailing text does not match", matchesTripType(B, "business trip"), false);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
