// The budget's two sources of money.
//
// A booking carries its own price and is edited on the booking; an expense is
// standalone money that can be filed anywhere and linked to a booking. The
// interesting behaviour is at the seam between them: which category an expense
// lands in when it does not name one, and what happens when the thing it points
// at is no longer there.
//
// Fixtures are invented — no real trip data in this directory.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");
const css = fs.readFileSync("public/styles.css", "utf8");

function grab(name) {
  const i = src.indexOf("  function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
function grabVar(name) {
  const i = src.indexOf("  var " + name + " = ");
  if (i < 0) throw new Error("missing " + name);
  return src.slice(i, src.indexOf(";", i) + 1);
}

// linkableItems reaches for four things that belong to the display layer.
globalThis.dayKey = (utc) => (utc ? String(utc).slice(0, 10) : null);
globalThis.dateLocale = () => "en-US";
globalThis.transIcon = (s) => ({ airplane: "PLANE", car: "CAR" }[s] || "CAR");
// Added when three hand-built copies of the same toLocaleDateString call were
// folded into one helper -- the real function, so a change to how a short date
// is formatted still shows up here rather than being stubbed away.
eval(grab("fmtMD") + ";globalThis.fmtMD = fmtMD;");

eval([grabVar("BUDGET_CATS"), grabVar("KIND_CAT"), grabVar("CREDIT_CAT"),
  grabVar("DINING_CAT"), grabVar("DINING_TYPES"),
  ...["linkableItems", "linkedItem", "priceCurrency", "signedAmount", "linkCategory",
      "budgetLines", "budgetCategories"].map(grab)].join("\n") +
  ";Object.assign(globalThis,{BUDGET_CATS,KIND_CAT,CREDIT_CAT,DINING_CAT,DINING_TYPES," +
  "linkableItems,linkedItem,priceCurrency,signedAmount,linkCategory,budgetLines,budgetCategories});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

const TRIP = {
  transports: [
    { id: 1, company: "Delta Air Lines", transport_number: "DL395", price: 420, currency: "USD" },
    { id: 2, company: "Adobe Rent A Car", price: 0, currency: "USD" },
  ],
  hostings: [
    { id: 10, name: "Hotel Example", price: 900, currency: "USD" },
    { id: 11, name: "Friend's spare room" },
  ],
  activities: [
    { id: 20, name: "Walking tour", price: 60, currency: "USD" },
    { id: 21, name: "Find a coffee place" },
  ],
  expenses: [
    { id: 30, title: "Baggage", price: 75, currency: "USD", linked_kind: "transport", linked_id: 1 },
    { id: 31, title: "Resort fee", price: 45, currency: "USD", category: "Other",
      linked_kind: "hosting", linked_id: 10 },
    { id: 32, title: "Taxi", price: 30, currency: "USD" },
    { id: 33, title: "Ski hire", price: 120, currency: "USD", category: "Gear" },
  ],
};

// ---- what gets a line ------------------------------------------------------
const lines = budgetLines(TRIP);
// Seven, not five. Flight #1 costs 420 AND carries a 75 baggage expense; hotel
// #10 costs 900 AND carries a 45 resort fee. Both pairs are real money and both
// get a line: a linked expense is an EXTRA, not a restatement of the booking.
//
// This count is what stops that being "fixed". An attempt to suppress a
// booking whose id appears in any expense's linked_id dropped it to five here
// and was reverted on the strength of it.
t("every priced thing has a line, nothing else", lines.length, 3 + 4);
// A booking with no price is not a budget line. Half a trip's bookings have no
// price on them and listing them all at zero would bury the ones that do.
t("a zero-price booking is left out",
  lines.some((l) => l.label.indexOf("Adobe") >= 0), false);
t("a priceless hotel is left out",
  lines.some((l) => l.label.indexOf("spare room") >= 0), false);
t("a priceless activity is left out",
  lines.some((l) => l.label.indexOf("coffee") >= 0), false);
// An expense with no amount is still a line — you entered it deliberately, and
// a zero you typed is different from a price nobody filled in.
t("a zero expense still shows",
  budgetLines({ expenses: [{ id: 1, title: "Comped dinner", price: 0 }] }).length, 1);

// ---- which category --------------------------------------------------------
const cat = (title) => lines.filter((l) => l.label === title)[0].cat;
t("a flight is Transport", cat("Delta Air Lines DL395"), "Transport");
t("a hotel is Lodging", cat("Hotel Example"), "Lodging");
t("an activity is Activities", cat("Walking tour"), "Activities");
// The point of linking: a baggage fee filed under nothing follows its flight.
t("an unfiled expense follows what it is linked to", cat("Baggage"), "Transport");
t("an unlinked, unfiled expense is Other", cat("Taxi"), "Other");
// An explicit choice beats the link, in both directions.
t("an explicit category beats the link", cat("Resort fee"), "Other");
t("a category of your own is kept", cat("Ski hire"), "Gear");

// ---- ordering --------------------------------------------------------------
t("built-ins in their own order, then yours alphabetically",
  budgetCategories(lines), ["Lodging", "Transport", "Activities", "Other", "Gear"]);
t("an unused category does not appear",
  budgetCategories(budgetLines({ expenses: [{ id: 1, title: "Taxi", price: 10 }] })), ["Other"]);
t("several of your own sort among themselves",
  budgetCategories(budgetLines({ expenses: [
    { id: 1, title: "a", price: 1, category: "Zoo" },
    { id: 2, title: "b", price: 1, category: "Gifts" }] })), ["Gifts", "Zoo"]);

// ---- a link that no longer resolves ---------------------------------------
// Bookings get deleted. The link is a pair of loose fields in the blob, not a
// foreign key, so nothing cleans it up — it has to fail quietly.
t("a link to a deleted flight resolves to nothing",
  linkedItem({ linked_kind: "transport", linked_id: 999 }, TRIP), null);
t("and the expense falls back to Other",
  budgetLines({ expenses: [{ id: 1, title: "Baggage", price: 75,
    linked_kind: "transport", linked_id: 999 }] })[0].cat, "Other");
t("a half-written link is no link",
  linkedItem({ linked_kind: "transport" }, TRIP), null);
t("id zero is still an id, not an absence",
  linkedItem({ linked_kind: "hosting", linked_id: 0 }, { hostings: [{ id: 0, name: "Zero" }] }).label, "Zero");
// D1 hands ids back as numbers, the select hands them back as strings.
t("a string id matches a numeric one",
  linkedItem({ linked_kind: "transport", linked_id: "1" }, TRIP).label, "Delta Air Lines DL395");
t("an unknown kind resolves to nothing",
  linkedItem({ linked_kind: "document", linked_id: 1 }, TRIP), null);

// ---- what you can link to --------------------------------------------------
const opts = linkableItems(TRIP);
t("everything on the itinerary is linkable, priced or not", opts.length, 6);
t("keys are kind:id", opts[0].key, "transport:1");
t("a nameless flight still has a label",
  linkableItems({ transports: [{ id: 1 }] })[0].label.indexOf("Transport") >= 0, true);
// The icon follows the transport's own type — a hire car in a list of flights
// showed a plane, which is the sort of thing you stop reading past.
t("a hire car is not a plane",
  linkableItems({ transports: [{ id: 1, company: "Adobe", transportation_type: "car" }] })[0].label
    .indexOf("CAR") === 0, true);
// Two nights at the same camp are two records with the same name. Without the
// date there is no way to tell which one you are filing an expense against.
const SAME = linkableItems({ hostings: [
  { id: 1, name: "Nayara Tented Camp", starts_at: "2027-01-24T22:00:00Z" },
  { id: 2, name: "Nayara Tented Camp", starts_at: "2027-01-25T22:00:00Z" }] });
t("same-named bookings are told apart", SAME[0].label === SAME[1].label, false);
t("by their date", SAME[0].label.indexOf("Jan 24") > 0, true);
t("an undated booking gets no stray separator",
  linkableItems({ hostings: [{ id: 1, name: "Somewhere" }] })[0].label, "🏨  Somewhere");

// ---- an empty trip ---------------------------------------------------------
t("nothing at all is no lines", budgetLines({}).length, 0);
t("and no categories", budgetCategories([]), []);
t("and nothing to link to", linkableItems({}).length, 0);


console.log("\nthe row's shape");
// Layout, tested because it has already been wrong once today: the now/next
// card put its time in a fixed third column and squeezed the text to 186px on
// a phone. This row has the same three-column temptation.
//
// Amount and controls share one narrow column so the description gets the
// rest. Measured at 420px: description 270px -> 299px, and a long hotel name
// stops wrapping to two lines.
t("the amount and its controls are one column",
  /var side = el\("div", "bud-side"\);/.test(src), true);
t("with the controls under the amount",
  /side\.appendChild\(acts\);/.test(src), true);
// Stacked vertically the three chips were taller than the two lines of text
// they saved, taking the row from 98px to 123px. Side by side it is 65px.
t("the chips sit side by side, not stacked",
  /\.bud-acts \{ display:flex; flex-direction:row/.test(css), true);
// Scoped, because .linkchip is the same class the itinerary uses for links
// you actually read, where the larger size is right.
t("and are only made smaller here",
  /\.bud-acts \.linkchip \{ padding:2px 7px/.test(css), true);
t("the description takes the remaining width",
  /\.bud-body \{ flex:1; min-width:0; \}/.test(css), true);


console.log("\ncredits come off the total");
// A refund, a voucher, points redeemed, somebody paying back their share.
// The category is what makes it a deduction -- there is no separate flag and
// no reliance on a minus sign being typed.
const CREDITED = {
  hostings: [{ id: 10, name: "Hotel Example", price: 900, currency: "USD" }],
  expenses: [
    { id: 40, title: "Cancelled night refunded", price: 300, currency: "USD", category: "Credit" },
    { id: 41, title: "Dinner", price: 120, currency: "USD" },
  ],
};
const cl = budgetLines(CREDITED);
const amt = (title) => cl.filter((l) => l.label === title)[0].amount;
t("a credit is negative", amt("Cancelled night refunded"), -300);
t("an ordinary expense is not", amt("Dinner"), 120);
t("a booking is not", amt("Hotel Example"), 900);
t("so the trip totals to the difference",
  cl.reduce((a, l) => a + l.amount, 0), 900 + 120 - 300);
t("and the line is flagged for the UI", cl.filter((l) => l.label === "Cancelled night refunded")[0].credit, true);
t("others are not", cl.filter((l) => l.label === "Dinner")[0].credit, false);

// The trap this rule exists for: entering the amount with a minus sign as
// well. Negating whatever was typed would turn that into a CHARGE, silently.
const typedNegative = budgetLines({ expenses: [
  { id: 1, title: "Refund", price: -250, currency: "USD", category: "Credit" }] });
t("a minus sign already typed does not flip it back", typedNegative[0].amount, -250);
t("magnitude is taken first", signedAmount("Credit", -250), signedAmount("Credit", 250));

// Credit is only ever an explicit choice. The category otherwise follows the
// booking an expense is linked to, and nothing should become a deduction by
// accident.
t("it is never derived from a link", signedAmount(undefined, 100), 100);
t("nor from a blank category", signedAmount("", 100), 100);
t("nor from a lookalike", signedAmount("Credits", 100), 100);
t("nor from different casing", signedAmount("credit", 100), 100);
t("zero stays zero", signedAmount("Credit", 0), 0);
t("junk is zero, not NaN", signedAmount("Credit", "abc"), 0);

// The word is read out of the source, so renaming the category cannot leave
// the test agreeing with a value the app no longer uses.
t("the category is one of the built-ins", BUDGET_CATS.indexOf(CREDIT_CAT) >= 0, true);
t("and it sorts last, being the one that subtracts",
  BUDGET_CATS[BUDGET_CATS.length - 1], CREDIT_CAT);
// Grouping still works: a credit gets its own section rather than being
// filed under whatever it was linked to.
t("a credit gets its own category section",
  budgetCategories(cl).indexOf(CREDIT_CAT) >= 0, true);


// ---- the sign reaches every surface, not just the panel -------------------
//
// Found by a fresh audit an hour after Credit shipped: three readers of the
// raw amount bypassed signedAmount. The Word and PDF exports printed a $300
// credit as "$300.00" — a document disagreeing with the very panel it was
// exported from — and Trip check would have called a full refund "counted
// twice", since a credit equal to the booking's price matched its test for
// one charge written down two times.
// Since the export redesign both go further: the category is DERIVED, exactly
// as the panel derives it, so a restaurant-linked dinner reads Dining and a
// Credit reads green and negative in the document too.
t("the Word export prints the signed figure",
  /money\(signedAmount\(cat, amt\)|money\(signed, cur\)/.test(src), true);
// Only the PDF still derives inline; the Word document and the spreadsheet
// both go through expenseSheet, whose rows come from budgetLines -- the
// panel's own derivation, one level up.
t("the PDF derives the category as the panel does",
  (src.match(/x\.category \|\| linkCategory\(linkedItem\(x, data\)\) \|\| "Other"/g) || []).length, 1);
t("the Word document and spreadsheet share the sheet builder",
  (src.match(/var sheet = expenseSheet\(t, data\);/g) || []).length, 2);
t("through the same linkCategory the panel itself uses",
  /var cat = x\.category \|\| linkCategory\(link\) \|\| "Other";/.test(src), true);
t("and the PDF sums signed totals per currency",
  (src.match(/totals\[cur\] = \(totals\[cur\] \|\| 0\) \+ signed;/g) || []).length, 1);
t("and Trip check never calls a refund a duplicate",
  /A credit matching the booking's price is a full refund/.test(src) &&
  /if \(x\.category === CREDIT_CAT\) return;/.test(src), true);


console.log("\ndinner follows the restaurant");
// Restaurant is the single biggest activity type in the database -- 124 of
// 323, more than "general" -- so meals were all landing in the Activities
// catch-all. An uncategorised expense linked to a dining place now files
// itself under Dining, the same way a baggage fee follows its flight.
const MEALS = {
  activities: [
    { id: 50, name: "Mother Wolf", activity_type: "restaurant" },
    { id: 51, name: "Walking tour", activity_type: "tour" },
  ],
  expenses: [
    { id: 60, title: "Dinner at Mother Wolf", price: 240, currency: "USD",
      linked_kind: "activity", linked_id: 50 },
    { id: 61, title: "Tour tickets", price: 90, currency: "USD",
      linked_kind: "activity", linked_id: 51 },
    { id: 62, title: "Tip, filed by hand", price: 40, currency: "USD",
      category: "Other", linked_kind: "activity", linked_id: 50 },
  ],
};
const ml = budgetLines(MEALS);
const catOf = (title) => ml.filter((l) => l.label === title)[0].cat;
t("a restaurant-linked expense is Dining", catOf("Dinner at Mother Wolf"), "Dining");
t("a tour-linked one is still Activities", catOf("Tour tickets"), "Activities");
// An explicit choice always beats the derivation, exactly as it does for
// Transport and Lodging.
t("an explicit category still wins", catOf("Tip, filed by hand"), "Other");
t("and Dining gets its own section", budgetCategories(ml).indexOf(DINING_CAT) >= 0, true);

// The rule reads the LINKED item's type, never the expense's title -- a
// "dinner" typed into an unlinked expense stays wherever it was put.
t("an unlinked dinner does not guess", 
  budgetLines({ expenses: [{ id: 1, title: "Dinner somewhere", price: 80, currency: "USD" }] })[0].cat,
  "Other");
t("restaurant is the anchor of the dining set", DINING_TYPES.indexOf("restaurant") >= 0, true);
t("nightlife is deliberately not dining", DINING_TYPES.indexOf("nightlife") >= 0, false);
t("Credit still sorts last after the insertion",
  BUDGET_CATS[BUDGET_CATS.length - 1], CREDIT_CAT);
// linkCategory handles junk from the blob without throwing.
t("no link derives nothing", linkCategory(null), null);
t("a link with no object does not throw",
  linkCategory({ kind: "activity" }), "Activities");
t("an unknown kind derives nothing", linkCategory({ kind: "expense" }), null);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
