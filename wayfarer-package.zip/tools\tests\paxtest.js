// seatList / paxOf — the seat-to-traveller pairing.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");
function grab(n) {
  const i = src.indexOf("  function " + n + "(");
  if (i < 0) throw new Error("missing " + n);
  let d = 0, s = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; s = true; } else if (src[j] === "}") { d--; if (s && !d) return src.slice(i, j + 1); }
  }
}
globalThis.state = { me: {} };
eval(["travellers", "travellerById", "travellerName", "newTravellerId", "tripTravellers", "seatList", "paxOf"]
  .map(grab).join("\n") + ";Object.assign(globalThis,{travellers,tripTravellers,seatList,paxOf,newTravellerId});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const ok = JSON.stringify(got) === JSON.stringify(want);
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + JSON.stringify(want) + "\n        got  " + JSON.stringify(got));
};

// --- seatList: the real formats found in the 124 seated flights ---
t("comma separated", seatList({ seat_number: "6D, 6A, 6F, 6C, 7D" }), ["6D", "6A", "6F", "6C", "7D"]);
t("leading zeros preserved", seatList({ seat_number: "08C, 08D, 08E" }), ["08C", "08D", "08E"]);
t("single seat", seatList({ seat_number: "4C" }), ["4C"]);
t("slash separated", seatList({ seat_number: "8B / 8C" }), ["8B", "8C"]);
t("the word and", seatList({ seat_number: "11B and 11C" }), ["11B", "11C"]);
t("semicolons", seatList({ seat_number: "16B; 16C" }), ["16B", "16C"]);
t("empty", seatList({ seat_number: "" }), []);
t("absent", seatList({}), []);
t("stray separators do not make blank seats", seatList({ seat_number: "9B, , 9C," }), ["9B", "9C"]);

// --- paxOf ---
const roster = [{ id: "alex", name: "Alex" }, { id: "sam", name: "Sam" }, { id: "jo", name: "Jo" }];
state.me.travellers = roster;
const TRIP = (ids) => ({ id: 1, travellers: ids });

t("counts match -> paired in listed order, flagged as a guess",
  paxOf({ seat_number: "6D, 6A, 6F" }, TRIP(["alex", "sam", "jo"])),
  [{ id: "alex", name: "Alex", seat: "6D", guessed: true },
   { id: "sam", name: "Sam", seat: "6A", guessed: true },
   { id: "jo", name: "Jo", seat: "6F", guessed: true }]);

t("more seats than travellers -> no guess (the Camino case)",
  paxOf({ seat_number: "6D, 6A, 6F, 6C, 7D" }, TRIP(["alex", "sam", "jo"])), []);
t("fewer seats than travellers -> no guess",
  paxOf({ seat_number: "6D, 6A" }, TRIP(["alex", "sam", "jo"])), []);
t("nobody on the trip -> nothing", paxOf({ seat_number: "6D, 6A" }, TRIP([])), []);
t("no seats recorded -> nothing", paxOf({}, TRIP(["alex"])), []);

t("a stored assignment wins over any guess",
  paxOf({ seat_number: "6D, 6A, 6F", pax: [{ id: "jo", seat: "6D" }] }, TRIP(["alex", "sam", "jo"])),
  [{ id: "jo", name: "Jo", seat: "6D", guessed: false }]);
t("stored assignment is never marked as a guess",
  paxOf({ seat_number: "1A", pax: [{ id: "alex", seat: "1A" }] }, TRIP(["alex"]))[0].guessed, false);
t("an empty stored list means deliberately none, not fall back to guessing",
  paxOf({ seat_number: "6D, 6A, 6F", pax: [] }, TRIP(["alex", "sam", "jo"])), []);
t("a stored id no longer on the roster still shows, under its id",
  paxOf({ pax: [{ id: "ghost", seat: "2B" }] }, TRIP(["alex"])),
  [{ id: "ghost", name: "ghost", seat: "2B", guessed: false }]);

// Roster order, not trip-list order, so a row cannot reshuffle between renders.
t("pairing follows roster order regardless of how the trip lists them",
  paxOf({ seat_number: "1A, 2B, 3C" }, TRIP(["jo", "alex", "sam"])).map(x => x.name),
  ["Alex", "Sam", "Jo"]);

// --- newTravellerId ---
t("id derived from the name", newTravellerId("Jo", []), "jo");
t("spaces and punctuation collapse", newTravellerId("Santiago Rosales II", []), "santiago-rosales-ii");
t("a clash gets a suffix", newTravellerId("Jo", [{ id: "jo" }]), "jo-2");
t("two clashes keep counting", newTravellerId("Jo", [{ id: "jo" }, { id: "jo-2" }]), "jo-3");
t("a name with no usable characters still yields an id", newTravellerId("!!!", []), "traveller");

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
