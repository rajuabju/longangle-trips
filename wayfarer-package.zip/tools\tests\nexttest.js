// "Where am I meant to be next", and the day the trip thinks it is.
//
// This is the part of the app you read while standing up, so the ways it can be
// wrong are all the embarrassing kind: telling someone in Lisbon that today is
// yesterday, or offering them a connection two hours out while they are on the
// aeroplane.
//
// Fixtures are invented.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");
const css = fs.readFileSync("public/styles.css", "utf8");

function grab(name) {
  const i = src.indexOf("  function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}

// The real dayKey, so the zone handling under test is the shipped one rather
// than a stub that agrees with whatever I assumed.
eval(["dayKey", "todayKey", "tripInProgress", "nextEntry"].map(grab).join("\n") +
  ";Object.assign(globalThis,{dayKey,todayKey,tripInProgress,nextEntry});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

// Date.now() is frozen for the whole file: a test that reads the wall clock
// passes at 10am and fails on the overnight run, and this one is entirely about
// what time it is.
const realNow = Date.now;
const at = (iso, fn) => { Date.now = () => Date.parse(iso); try { return fn(); } finally { Date.now = realNow; } };

console.log("\ntodayKey — the day the TRIP is having");
// 23:30 UTC on the 18th is already the 19th in Lisbon and still the 18th in
// California. A traveller reads their own itinerary, so it has to be the
// trip's zone that decides.
at("2026-08-18T23:30:00Z", () => {
  t("Lisbon has already turned over", todayKey({ timezone: "Europe/Lisbon" }), "2026-08-19");
  t("Los Angeles has not", todayKey({ timezone: "America/Los_Angeles" }), "2026-08-18");
  t("no zone means the viewer's own zone",
    todayKey({}), todayKey({ timezone: Intl.DateTimeFormat().resolvedOptions().timeZone }));
  t("no trip at all does not throw", todayKey(null), "2026-08-18");
});

// The argless Date constructor bypasses a stubbed Date.now, so freezing time
// has no effect on code that uses it -- three tests above passed against the
// real wall clock until this was written the other way.
t("today is read through Date.now, so a test can freeze it",
  /new Date\(Date\.now\(\)\)\.toISOString\(\)/.test(src), true);

console.log("\ntripInProgress");
const camino = { has_dates: true, starts_at: "2026-08-04", ends_at: "2026-08-19", timezone: "Europe/Lisbon" };
at("2026-08-18T12:00:00Z", () => {
  t("mid-trip", tripInProgress(camino), true);
});
// The last day counts in full. Ending "on the 19th" means the 19th is a day of
// the trip, not a boundary you fall out of at midnight — you are still in the
// hotel, and the flight home is still on the itinerary.
at("2026-08-19T21:00:00Z", () => {
  t("the last day counts, right up to its end", tripInProgress(camino), true);
});
at("2026-08-20T00:30:00Z", () => {
  t("the day after does not", tripInProgress(camino), false);
});
at("2026-08-04T06:00:00Z", () => {
  t("the first day counts from its start", tripInProgress(camino), true);
});
at("2026-08-03T12:00:00Z", () => {
  t("the day before does not", tripInProgress(camino), false);
});
// 23:00Z on the 3rd is already midnight on the 4th in Lisbon, so the trip IS
// on. Worth pinning: it reads like an off-by-one and is the zone doing its job.
at("2026-08-03T23:00:00Z", () => {
  t("but the evening before, Lisbon-side, already counts", tripInProgress(camino), true);
});
// A trip with no dates has no "now" to be inside of. Nine of the ten Pinecrest
// weekends are a name and two dates; some older records are a name alone.
at("2026-08-18T12:00:00Z", () => {
  t("a trip without dates is never in progress",
    tripInProgress({ has_dates: false, starts_at: "2026-08-04", ends_at: "2026-08-19" }), false);
  t("nor one missing an end", tripInProgress({ has_dates: true, starts_at: "2026-08-04" }), false);
  t("nor nothing at all", tripInProgress(null), false);
});
// The zone decides the edges too, not just the middle.
at("2026-08-19T23:30:00Z", () => {
  t("Lisbon has rolled past the last day", tripInProgress(camino), false);
  t("but California has not",
    tripInProgress(Object.assign({}, camino, { timezone: "America/Los_Angeles" })), true);
});

console.log("\nnextEntry");
// Every fixture carries a `kind`, because every real entry does. Without one
// they did not resemble buildEntries' output, and the lodging rule below passed
// straight through them without being exercised.
const flight = { kind: "transport", icon: "✈️", title: "TP 1234 Lisbon → London",
  when: "2026-08-19T11:15:00Z", obj: { arrival_at: "2026-08-19T13:50:00Z" } };
const cab = { kind: "transport", icon: "🚗", title: "Taxi to the airport",
  when: "2026-08-19T08:30:00Z", obj: {} };
const dinner = { kind: "activity", icon: "🍽️", title: "Dinner",
  when: "2026-08-19T19:00:00Z", obj: {} };
const stay = { kind: "hosting", icon: "🏨", title: "Hyatt Regency Lisbon",
  when: "2026-08-17T14:00:00Z", obj: { ends_at: "2026-08-19T10:00:00Z" } };
const day = [stay, cab, flight, dinner];

const nm = (r) => (r ? (r.now ? "NOW " : "NEXT ") + r.entry.title : null);

// ---- a hotel is never the answer ----
//
// A stay is true for days at a stretch, so it takes "happening now" the moment
// you check in and holds it through every meal, tour and flight of the trip --
// crowding out the one thing this card exists to tell you. The hotel is on the
// itinerary and in the day's rows; it does not need the top of the screen too.
t("the hotel does not answer 'what now', the next real thing does",
  nm(nextEntry(day, Date.parse("2026-08-19T06:00:00Z"))), "NEXT Taxi to the airport");
t("a day of nothing but lodging has no answer at all",
  nm(nextEntry([stay], Date.parse("2026-08-18T09:00:00Z"))), null);
t("nor when the stay is still ahead of you",
  nm(nextEntry([stay], Date.parse("2026-08-16T09:00:00Z"))), null);
// The word matters: buildEntries emits "hosting" for the itinerary while the
// position model elsewhere in the same file says "lodging". Filtering on the
// wrong one silently does nothing, which is precisely how these fixtures
// passed before they carried a kind at all.
t("the excluded kind is the one buildEntries actually emits",
  /entries\.push\(\{ kind: "hosting", when: h\.starts_at/.test(src), true);
t("and that is the word the filter uses",
  /if \(!e\.when \|\| e\.kind === "hosting"\) return;/.test(src), true);
// Mid-flight the answer is the flight. An entry you are inside of beats one
// that merely starts sooner than the rest -- offering the dinner while the
// wheels are up is the failure this rule exists to prevent.
t("inside the flight, the flight wins", nm(nextEntry(day, Date.parse("2026-08-19T12:00:00Z"))),
  "NOW TP 1234 Lisbon → London");
t("after landing, the next thing ahead", nm(nextEntry(day, Date.parse("2026-08-19T14:00:00Z"))),
  "NEXT Dinner");
t("between the taxi and the flight", nm(nextEntry(day, Date.parse("2026-08-19T10:30:00Z"))),
  "NEXT TP 1234 Lisbon → London");
// A moment has no duration, so it is over the instant it passes. Treating a
// bare starts_at as "still happening" would pin the card to a dinner you ate.
t("a moment does not linger once passed",
  nm(nextEntry([dinner], Date.parse("2026-08-19T19:00:01Z"))), null);
t("but is next right up to its start",
  nm(nextEntry([dinner], Date.parse("2026-08-19T18:59:59Z"))), "NEXT Dinner");
t("nothing left ahead", nm(nextEntry(day, Date.parse("2026-08-20T09:00:00Z"))), null);
t("an empty day", nm(nextEntry([], Date.parse("2026-08-19T09:00:00Z"))), null);

// Two things running at once: the shorter one is the more urgent, because it is
// the one you are about to have to leave. Called a multi-day pass rather than a
// hotel, because a hotel would not be a candidate at all now -- naming it one
// would make this look like it tested the lodging rule when it does not.
const longPass = { kind: "activity", title: "Three-day museum pass",
  when: "2026-08-17T14:00:00Z", obj: { ends_at: "2026-08-20T10:00:00Z" } };
const tour = { kind: "activity", title: "Walking tour",
  when: "2026-08-19T09:00:00Z", obj: { ends_at: "2026-08-19T11:00:00Z" } };
t("overlapping, the one ending soonest wins",
  nm(nextEntry([longPass, tour], Date.parse("2026-08-19T10:00:00Z"))), "NOW Walking tour");

// Junk must not become the answer. Entries reach here from the same records the
// importer writes, and an unparseable date is a thing that happens.
t("an entry with no time is skipped",
  nm(nextEntry([{ title: "A note", obj: {} }, dinner], Date.parse("2026-08-19T09:00:00Z"))), "NEXT Dinner");
t("an unparseable time is skipped",
  nm(nextEntry([{ title: "Broken", when: "not a date", obj: {} }, dinner],
    Date.parse("2026-08-19T09:00:00Z"))), "NEXT Dinner");
t("an unparseable END does not make it current forever",
  nm(nextEntry([{ title: "Broken end", when: "2026-08-19T08:00:00Z", obj: { ends_at: "???" } }],
    Date.parse("2026-08-19T09:00:00Z"))), null);

console.log("\nthe card's shape");
// Measured at 375px: as a third flex column the time was 67 fixed pixels
// that never wrapped, so the body got 186 of the card's 335. A flight
// title wrapped to two lines and its airports to two more, for a 141px-tall
// card saying one thing. Label and time sharing a line puts the body back to
// 273px, the title on one line, and the card at 107px.
t("the label and the time share a line",
  /var head = el\("div", "nextup-head"\);/.test(src), true);
t("with the time inside that line",
  /head\.appendChild\(el\("span", "nextup-when", up\.entry\.meta\)\)/.test(src), true);
// The old third column is what caused it, so make sure it cannot come back.
t("and not as a column of the card",
  /card\.appendChild\(el\("div", "nextup-when"/.test(src), false);
t("the head lays them out end to end",
  /\.nextup-head \{ display:flex; align-items:baseline; justify-content:space-between/.test(css), true);
// min-width:0 lets a flex child shrink but does not break an unbroken run.
// A 54-character title with no spaces would otherwise push past the viewport.
t("a long unbroken title breaks rather than overflows",
  /\.nextup-title \{ overflow-wrap:anywhere; \}/.test(css), true);

console.log("\nthe tracker on the card");
// Same window as the row chip, so the two never disagree about whether a flight
// is worth watching.
t("the card offers Track on a flight in its window",
  /var trackHref = trackable\(up\.entry\.obj, Date\.now\(\)\) \? fr24Url\(up\.entry\.obj\) : null;/.test(src), true);
// The card itself scrolls to the row. Without this the tap does both, and the
// page jumps out from under the newly opened tab.
t("and tapping it does not also scroll the card",
  /tl\.addEventListener\("click", function \(ev\) \{ ev\.stopPropagation\(\); \}\);/.test(src), true);

console.log("\nwhat the itinerary does with it");
// The card is for a trip you are ON. On a trip taken in 2015 it would be absurd.
t("the card is gated on the trip being in progress", /if \(tripInProgress\(t\)\) \{/.test(src), true);
// openTrip re-renders after every save; scrolling then would throw you back to
// today each time you fixed a typo.
t("a redraw is told apart from an open", /if \(shownTrip !== t\.id\) \{/.test(src), true);
t("and closing the trip forgets it", /shownTrip = null;/.test(src), true);
t("today's section is marked", /sec\.classList\.add\("is-today"\)/.test(src), true);
// Auto-collapsing past days must not swallow today: at 00:01 the day is "past"
// by a UTC string compare while being the day you are living in.
t("today is never auto-collapsed as a past day",
  /startCollapsed = pastDay && k !== todayKey\(t\)/.test(src), true);

console.log("\nthe skeleton");
t("the itinerary starts as a skeleton, not a spinner", /itin\.appendChild\(itinSkeleton\(\)\)/.test(src), true);
// A skeleton that outlives a failed request tells the same lie the old
// `.catch(() => [])` told: that the data is still coming.
t("every load path clears it", /itin\.innerHTML = ""/.test(src), true);
t("renderItinerary clears the container first", /root\.innerHTML = "";/.test(src), true);
// Grey boxes are nothing to announce; the status line is what replaces the
// "Loading itinerary…" that used to be read out.
t("the shapes are hidden from screen readers",
  /skel\.setAttribute\("aria-hidden", "true"\)/.test(src), true);
t("and a live status line is announced instead",
  /say\.setAttribute\("role", "status"\)/.test(src), true);

console.log("\nmotion");
// Vestibular disorders make sweeping motion genuinely unpleasant, and the OS
// setting is how someone says so once rather than per app.
t("reduced motion is respected", /@media \(prefers-reduced-motion: reduce\)/.test(css), true);
// Near-zero rather than none, or an animationend handler waits forever.
t("and stops short of killing the events", /animation-duration:\.01ms/.test(css), true);
t("the shimmer is switched off there too",
  /prefers-reduced-motion[\s\S]*skel-bar::after[\s\S]*display:none/.test(css), true);
// transform and opacity are the compositor's; width/height/top are not, and
// animating those is what makes a phone warm.
const keyframes = (css.match(/@keyframes[^}]*\{[\s\S]*?\}\s*\}/g) || []).join("\n");
t("keyframes animate only transform and opacity",
  /(width|height|top|left|margin|padding):/.test(keyframes), false);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
