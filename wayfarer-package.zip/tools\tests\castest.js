// Two devices editing the same list.
//
// Lists here are stored as one value and written as one value, so the last
// writer won the whole list. Add a task on the phone, add another on the laptop
// from a page loaded five minutes earlier, and the laptop's PATCH carried its
// stale array: the phone's task was gone, and nothing anywhere reported it,
// because from the server's side that is exactly what was asked for.
//
// Two halves are tested here. The server refuses a write whose `if_match` does
// not describe what is stored. The client re-applies an INTENT to fresh data
// rather than resending a finished array, which is the only reason a retry can
// possibly be correct.
//
// Fixtures are invented.
const fs = require("fs");
const api = fs.readFileSync("functions/api/_core.js", "utf8");
const app = fs.readFileSync("public/app.js", "utf8");

function grabFn(src, name, prefix) {
  const i = src.indexOf((prefix || "") + "function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}

// Server side.
eval(["stableJson", "nothingThere", "staleFields"].map((n) => grabFn(api, n)).join(String.fromCharCode(10)) +
  ";Object.assign(globalThis,{stableJson,nothingThere,staleFields});");
// Client side.
eval(["taskKey", "taskIndex", "packKey", "packIndex"].map((n) => grabFn(app, n, "  ")).join("\n") +
  ";Object.assign(globalThis,{taskKey,taskIndex,packKey,packIndex});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

// ---- the server's conflict test --------------------------------------------
const A = { text: "Order currency", done: false, added: "2026-08-01T10:00:00Z" };
const B = { text: "Dog sitter", done: false, added: "2026-08-01T11:00:00Z" };

t("what you expected is what is there", staleFields({ tasks: [A] }, { tasks: [A] }), null);
t("an extra entry is a conflict",
  staleFields({ tasks: [A, B] }, { tasks: [A] }), { tasks: [A, B] });
t("a missing entry is a conflict",
  staleFields({ tasks: [A] }, { tasks: [A, B] }), { tasks: [A] });
t("a changed entry is a conflict",
  staleFields({ tasks: [{ ...A, done: true }] }, { tasks: [A] }), { tasks: [{ ...A, done: true }] });
t("order matters — a reordered list is a different list",
  !!staleFields({ tasks: [B, A] }, { tasks: [A, B] }), true);
t("empty against empty agrees", staleFields({ tasks: [] }, { tasks: [] }), null);
// Absent, null and [] are one state. A trip that has never had a to-do list
// carries no `tasks` key, while a client about to add the first one necessarily
// believes the list is empty. Calling that a disagreement made the FIRST task on
// every trip conflict, retry four times and fail — on all 181 of them.
t("absent against empty agrees", staleFields({}, { tasks: [] }), null);
t("null against empty agrees", staleFields({ tasks: null }, { tasks: [] }), null);
t("empty against absent agrees", staleFields({ tasks: [] }, { tasks: null }), null);
t("absent against something is a conflict", staleFields({}, { tasks: [A] }), { tasks: null });
t("something against absent is a conflict", staleFields({ tasks: [A] }, { tasks: [] }), { tasks: [A] });
// Not over-applied: an empty object is a value, not an absence.
t("an empty object is not an absence", !!staleFields({ x: {} }, { x: [] }), true);

// Only the named fields are compared: a caller guarding `pax` must not conflict
// because the room number moved.
t("only the fields named are compared",
  staleFields({ pax: [], room_number: "402" }, { pax: [] }), null);
t("and several can be named at once",
  staleFields({ a: [1], b: [2] }, { a: [1], b: [9] }), { b: [2] });

// No if_match means the old behaviour, unchanged. Every existing caller relies
// on this — the importer PATCHes constantly and knows nothing about any of it.
t("no if_match, no conflict", staleFields({ tasks: [A] }, undefined), null);
t("null if_match, no conflict", staleFields({ tasks: [A] }, null), null);
t("a non-object if_match is ignored", staleFields({ tasks: [A] }, "tasks"), null);
t("an array if_match is ignored", staleFields({ tasks: [A] }, [1, 2]), null);

// ---- key order must not fake a conflict ------------------------------------
// The client hands back a value it received from here, so key order normally
// survives the round trip — but a false conflict is a retry loop, and sorting
// costs three lines.
t("the same object written in two key orders matches",
  staleFields({ x: [{ a: 1, b: 2 }] }, { x: [{ b: 2, a: 1 }] }), null);
t("nested the same way", stableJson({ b: 1, a: { d: 2, c: 3 } }), stableJson({ a: { c: 3, d: 2 }, b: 1 }));
t("but a different value still differs", stableJson({ a: 1 }) === stableJson({ a: 2 }), false);
t("null and undefined read alike", stableJson(null), stableJson(undefined));
t("a number is not its string", stableJson(1) === stableJson("1"), false);
t("an empty array is not an empty object", stableJson([]) === stableJson({}), false);

// ---- the client re-applies an intent ---------------------------------------
// The whole point. A finished array cannot be retried; "tick THIS one" can.
const apply = (list, mutate) => { const next = mutate(list); return next == null ? list : next; };

// Two devices: the phone adds B while the laptop is adding C from a stale view.
const laptopAdds = (cur) => cur.concat([{ text: "Check in", done: false, added: "2026-08-01T12:00:00Z" }]);
t("re-applying an add against fresh data keeps both",
  apply([A, B], laptopAdds).map((x) => x.text), ["Order currency", "Dog sitter", "Check in"]);

// Ticking is by identity, not by index — the index moved.
const tick = (x, want) => (cur) => {
  const at = taskIndex(cur, x);
  if (at < 0) return null;
  if (!!cur[at].done === want) return null;
  const next = cur.slice();
  next[at] = Object.assign({}, cur[at], { done: want });
  return next;
};
t("ticking finds its task after the list shifted",
  apply([B, A], tick(A, true)).filter((x) => x.done).map((x) => x.text), ["Order currency"]);
t("and does not tick the one that took its old index",
  apply([B, A], tick(A, true))[0].done, false);
t("ticking something already removed elsewhere does nothing",
  apply([B], tick(A, true)), [B]);
t("ticking something the other device already ticked does nothing",
  apply([{ ...A, done: true }], tick(A, true))[0].done, true);
// Absolute, not a flip: you meant "mark it done", so a re-apply must not undo
// what it just did.
t("re-applying a tick twice is still done",
  apply(apply([A], tick(A, true)), tick(A, true))[0].done, true);

// Removing, likewise by identity.
const drop = (x) => (cur) => {
  const at = taskIndex(cur, x);
  if (at < 0) return null;
  return cur.slice(0, at).concat(cur.slice(at + 1));
};
t("removing finds its task after a shift", apply([B, A], drop(A)).map((x) => x.text), ["Dog sitter"]);
t("removing something already gone does nothing", apply([B], drop(A)), [B]);

// ---- identity ---------------------------------------------------------------
t("two tasks with the same text differ by when they were added",
  taskKey({ text: "Pack", added: "1" }) === taskKey({ text: "Pack", added: "2" }), false);
t("an older task with no `added` still has a key", taskKey({ text: "Pack" }), "Pack|");
t("a missing task is not found", taskIndex([A], B), -1);
t("packing items are identified by text and person",
  packKey({ text: "Charger", who: "Alex" }) === packKey({ text: "Charger", who: "Sam" }), false);
t("two identical packing entries are interchangeable, so the first is taken",
  packIndex([{ text: "Socks", who: "" }, { text: "Socks", who: "" }], { text: "Socks", who: "" }), 0);

// ---- the wiring is really there --------------------------------------------
t("patchRow refuses a stale write", /const stale = staleFields\(stored, body && body\.if_match\)/.test(api), true);
t("and strips if_match before storing", /body = withoutIfMatch\(body\)/.test(api), true);
t("the settings table is guarded too", /staleFields\(cur, body\.if_match\)/.test(api), true);
t("and packing lists", /staleFields\(\{ items: safeJsonArr\(row\.items\)/.test(api), true);
t("a conflict is a 409", /conflict: true, current: stale \}, 409\)/.test(api), true);
t("the client retries only on 409", /if \(e\.status !== 409\) throw e;/.test(app), true);
t("and gives up rather than spinning", /CAS_TRIES/.test(app), true);
t("tasks go through the retrying path", /function updateTasks\(t, mutate\)/.test(app), true);
t("packing goes through the retrying path", /function updatePacking\(l, mutate\)/.test(app), true);
t("the dialog lists refuse rather than merge", /function replaceValue\(/.test(app), true);
t("no bare tasks PATCH is left", /JSON\.stringify\(\{ tasks: next \}\)/.test(app), false);
t("no bare packing PATCH is left", /JSON\.stringify\(\{ items: items \}\)/.test(app), false);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
