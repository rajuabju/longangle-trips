// Are the negative assertions real, or do they pass because the pattern never
// matched anything in the first place?
//
// A negative assertion -- t("X is gone", /re/.test(src), false) -- is only
// meaningful if /re/ DID match before the thing was removed. If the pattern was
// mistyped it passes now, passed before, and will pass forever while asserting
// nothing at all. That is the same failure as a fixture with no `kind`.
//
// So: replay each pattern against public/app.js through history. One that never
// matches anywhere is vacuous.
//
// Two things this got wrong, both found in the 2026-08-22 audit:
//
//   THE WINDOW WAS FIXED at 25 commits. Thirteen commits in one day pushed
//   older guards out of it, and three genuine regression guards were reported
//   as vacuous -- they were clean the same morning. A guard against a bug fixed
//   last week is still a guard. The recent window is now only the FAST PATH;
//   anything that misses is searched deeper, one commit at a time, until it is
//   found or history runs out.
//
//   THE FILE LIST WAS HARDCODED, so four suites written that day were never
//   checked at all. It discovers them now, which is the only version of this
//   that stays true.
const { execSync } = require("child_process");
const fs = require("fs");
const path = require("path");

const FAST = 25;      // replayed up front
const DEEP = 400;     // how far a missing pattern is chased

const commits = execSync('git log -n ' + DEEP + ' --format=%H -- public/app.js', { encoding: "utf8" })
  .trim().split("\n").filter(Boolean);

const cache = new Map();
function versionAt(rev) {
  if (cache.has(rev)) return cache.get(rev);
  let src = null;
  try {
    src = execSync("git show " + rev + ":public/app.js",
      { encoding: "utf8", maxBuffer: 64 * 1024 * 1024 });
  } catch (e) { src = null; }
  cache.set(rev, src);
  return src;
}

// The parent of the earliest commit in the fast window is the state before any
// of it, which is where a just-removed pattern still lives.
let base = null;
try {
  base = execSync("git rev-parse " + commits[Math.min(FAST, commits.length) - 1] + "^",
    { encoding: "utf8" }).trim();
} catch (e) { /* the repo may not go back that far */ }

const fastRevs = commits.slice(0, FAST).concat(base ? [base] : []);
const deepRevs = commits.slice(FAST);

// Where a pattern is found, so the report can say when it was last true.
function findMatch(rx) {
  for (const r of fastRevs) {
    const src = versionAt(r);
    if (src && rx.test(src)) return { rev: r.slice(0, 7), deep: false };
  }
  // Only now is it worth paying for older history, and only until it is found.
  for (const r of deepRevs) {
    const src = versionAt(r);
    if (src && rx.test(src)) return { rev: r.slice(0, 7), deep: true };
  }
  return null;
}

const dir = "tools/tests";
// Every suite, discovered. A hardcoded list silently stops covering whatever
// was written after it.
const targets = fs.readdirSync(dir)
  .filter((f) => f.endsWith(".js") && f !== "run.js").sort();
const re = /t\(\s*"([^"]+)"[^\n]*?(\/[^\n]+?\/)\.test\((src|app|core)\)\s*,\s*false\s*\)/gs;

let vacuous = 0, real = 0, deep = 0, checked = 0;
for (const f of targets) {
  const p = path.join(dir, f);
  const s = fs.readFileSync(p, "utf8");
  let m;
  re.lastIndex = 0;
  while ((m = re.exec(s))) {
    const label = m[1], pattern = m[2], against = m[3];
    // Patterns tested against the API file are replayed against app.js history,
    // which proves nothing. Skip rather than pretend.
    if (against === "core") continue;
    checked++;
    let rx;
    try { rx = eval(pattern); } catch (e) { console.log("  ?? " + f + " :: unparseable " + pattern); continue; }
    const hit = findMatch(rx);
    if (hit) {
      real++;
      if (hit.deep) deep++;
      console.log("  ok  %s :: %s  (matched at %s%s)", f, label, hit.rev, hit.deep ? ", older history" : "");
    } else {
      vacuous++;
      console.log("  !!  %s :: %s", f, label);
      console.log("      pattern never matched ANY version in " + commits.length + " commits: " + pattern);
    }
  }
}
console.log("\n  real: " + real + "   vacuous: " + vacuous +
  (deep ? "   (" + deep + " found only in older history)" : ""));
console.log("  (" + checked + " negative assertions across " + targets.length +
  " suites, against up to " + commits.length + " versions of app.js)");
process.exit(vacuous ? 1 : 0);
