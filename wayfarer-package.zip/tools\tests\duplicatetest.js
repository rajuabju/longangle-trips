// U21 -- duplicating a trip says how far it has got, and survives a failure.
//
// It was a POST per item, awaited in sequence, with nothing on screen. A trip
// with eleven items was eleven round trips of silence. Worse, a failure at the
// eighth threw out of the whole thing -- leaving a trip that already had seven
// items in it, sitting invisibly on a dashboard of a hundred and eighty, behind
// an error message about the eighth. The copy existed and the user had no way
// to know.
//
// Both halves are fixed here: it reports progress, and what it managed to make
// is always opened rather than left to be found.
//
// Verified live on a throwaway trip of 11 items (3 transports, 2 hostings,
// 6 activities):
//   the happy path -> labels "Copying 1 of 11…" through "Copying 11 of 11…",
//     then "Finishing…", then the copy opened with all 11 rows
//   with 2 hosting POSTs and 1 activity POST forced to 500 ->
//     "Copied 8 of 11 items. These did not copy: ZZ Hotel 1, ZZ Hotel 2,
//      ZZ Activity 4", carrying role="alert" and the error styling, the
//     partial trip OPENED with its 8 rows, and the sticky toast cleaned up
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

const dup = app.slice(app.indexOf("async function duplicateTrip"),
                      app.indexOf("// ---- currency conversion"));
if (dup.length < 2000) { console.log("  FAIL  duplicateTrip slice is " + dup.length); process.exit(1); }

console.log("\nthe work is gathered before any of it is done");
// Which is what lets the progress say "of 11" rather than counting upward with
// no idea where it ends.
t("one list of jobs", /var jobs = \[\];/.test(dup), true);
t("transports go in it", /jobs\.push\(\{ plural: "transportations", body: b, label:/.test(dup), true);
t("hostings too", /jobs\.push\(\{ plural: "hostings", body: hb, label:/.test(dup), true);
t("and activities", /jobs\.push\(\{ plural: "activities", body: ab, label:/.test(dup), true);
// Named through the same helper as the dialog titles and the delete toast, so
// a failed item is reported in the words the itinerary uses for it.
t("each job carries a human name", /label: recordLabel\("transport", x\) \|\| "a transport"/.test(dup), true);
t("with a fallback for unnamed records", /recordLabel\("hosting", h\) \|\| "a hotel"/.test(dup), true);
// The old shape: three indexed loops each awaiting inside.
t("no indexed loop of awaited posts survives", /for \(var i = 0; i < \(src\.transports \|\| \[\]\)\.length; i\+\+\)/.test(app), false);

console.log("\nit says how far along it is");
t("through the U20 progress toast", /var prog = progressToast\("Copying 1 of " \+ jobs\.length/.test(dup), true);
t("starting at zero", /prog\.set\(0\);/.test(dup), true);
t("advancing by fraction and by words", /prog\.set\(done \/ jobs\.length,/.test(dup), true);
// The last item is not the last thing that happens -- loadAll still has to run.
t("and naming the tail rather than sticking at 11 of 11", /"Finishing/.test(dup), true);
// An empty trip has nothing to report on; a bar for zero items is noise.
t("a trip with no items shows no bar", /if \(jobs\.length\) \{/.test(dup), true);
t("and the sticky toast is always ended", /prog\.done\(null\);/.test(dup), true);

console.log("\nfour at a time, because each item is independent");
// sort_order is not copied, so the itinerary orders itself chronologically and
// the order these land in does not matter. Same worker-pool shape reviewChanges
// already uses.
t("a worker pool", /var worker = async function \(\) \{/.test(dup), true);
t("pulling from a shared cursor", /var job = jobs\[next\+\+\];/.test(dup), true);
t("four of them", /await Promise\.all\(\[worker\(\), worker\(\), worker\(\), worker\(\)\]\);/.test(dup), true);

console.log("\none failure does not cost you the other ten");
t("a failed item is caught, not thrown", /failed\.push\(job\.label\);/.test(dup), true);
// The catch is INSIDE the loop. Outside it, the first failure still ends the run.
t("and the loop carries on", dup.indexOf("failed.push(job.label);") < dup.indexOf("done++;"), true);
t("the count is still advanced for it", /\} catch \(e\) \{[\s\S]{0,400}?\}\s*\n\s*done\+\+;/.test(dup), true);

console.log("\nand what failed is named, not counted");
// "2 items failed" tells you to go hunting. The names tell you what to re-add.
t("up to three by name", /failed\.slice\(0, 3\)\.join\(", "\)/.test(dup), true);
t("with the rest summarised", /\(failed\.length > 3 \? " and " \+ \(failed\.length - 3\) \+ " more" : ""\)/.test(dup), true);
t("as an error, so it holds the screen longer", /\{ error: true \}\);/.test(dup), true);
t("and a clean run just says duplicated", /toast\("Duplicated" \+ shifted\);/.test(dup), true);
t("mentioning the shift when there was one", /var shifted = days \? " \(shifted " \+ days \+ " days\)" : "";/.test(dup), true);

console.log("\nwhatever was made is opened, not left to be found");
// This is the recovery. A half-copied trip on a dashboard of 180 is invisible;
// opening it puts the result in front of the person who has to decide about it.
t("the list is reloaded first", /await loadAll\(\);/.test(dup), true);
t("the copy is looked up by the id just created",
  /var made = \(state\.own \|\| \[\]\)\.filter\(function \(x\) \{ return x\.id === nid; \}\)\[0\];/.test(dup), true);
t("and opened", /if \(made\) openTrip\(made\); else closeDetail\(\);/.test(dup), true);
// The old ending dropped you back on the dashboard with no idea what had
// happened to the copy. Matched on that exact one-liner: the first attempt
// wrapped the toast too and used [^)]*, which cannot cross the ternary's own
// brackets -- so it matched no version in 226 commits and guarded nothing.
t("it no longer just closes and reloads", /closeDetail\(\); loadAll\(\);/.test(app), false);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
