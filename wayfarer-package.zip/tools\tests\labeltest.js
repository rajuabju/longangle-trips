// U14 -- a dialog says which record it has open.
//
// "Edit lodging" is equally true of every hotel on a trip, so it identifies
// none of them. The database has trips carrying six hostings and trips carrying
// eleven activities; on those, the title was the last chance to notice you had
// tapped the wrong row, and it said nothing. The itinerary row already knows
// what to call the record -- this makes the dialog, the row and the delete
// toast agree by routing all three through one function.
//
// Run for real, not matched: the functions are lifted out of app.js and called.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

// Lift the real source of each helper rather than reimplementing it -- a copy
// would drift and the test would go on passing against its own idea of the code.
function lift(name, decl) {
  const start = app.indexOf(decl);
  if (start < 0) throw new Error("not found: " + decl);
  let depth = 0, i = app.indexOf("{", start);
  const from = i;
  for (; i < app.length; i++) {
    if (app[i] === "{") depth++;
    else if (app[i] === "}") { depth--; if (!depth) break; }
  }
  return app.slice(start, i + 1);
}

const src = ["function cap(s)", "function transName(o)", "function recordLabel(kind, o)",
             "function clipName(s, max)", "function formTitle(isNew, kind, noun, o)"]
  .map((d) => lift(d, d)).join("\n");
const F = new Function(src + "\nreturn { cap, transName, recordLabel, clipName, formTitle };")();

console.log("\na flight is called what the itinerary calls it");
t("carrier and number", F.recordLabel("transport", { transportation_type: "airplane", company: "United", transport_number: "UA679" }), "United UA679");
t("the importer's own field names too",
  F.recordLabel("transport", { transportation_type: "airplane", carrier_name: "Delta", flight_number: "DL55" }), "Delta DL55");
t("a nameless flight falls back", F.recordLabel("transport", { transportation_type: "airplane" }), "Flight");
t("a hire car uses its company", F.recordLabel("transport", { transportation_type: "car", company: "Hertz" }), "Hertz");
t("a road trip uses its type", F.recordLabel("transport", { transportation_type: "car" }), "Car");
// The API says "transportation", the client says "transport". Both arrive here.
t("either spelling of the kind", F.recordLabel("transportation", { transportation_type: "airplane", company: "AA", transport_number: "1" }), "AA 1");

console.log("\neverything else is its name");
t("a hotel", F.recordLabel("hosting", { name: "Hotel Bel-Air" }), "Hotel Bel-Air");
t("an activity", F.recordLabel("activity", { name: "Getty Center" }), "Getty Center");
t("an expense", F.recordLabel("expense", { name: "Dinner" }), "Dinner");
t("a document, which titles rather than names", F.recordLabel("document", { title: "Rate confirmation" }), "Rate confirmation");

console.log("\nnothing to say is said as nothing");
// A placeholder would print Edit "" -- worse than the generic noun, because it
// looks like the record is called nothing rather than not called anything.
t("no name is null, not empty string", F.recordLabel("hosting", {}), null);
t("whitespace is not a name", F.recordLabel("hosting", { name: "   " }), null);
t("a missing object does not throw", F.recordLabel("hosting", null), null);
t("nor a missing kind", F.recordLabel(undefined, { name: "Something" }), "Something");

console.log("\nthe title reads the way you would say it");
t("editing names the record", F.formTitle(false, "hosting", "lodging", { name: "Hotel Bel-Air" }), "Edit \u201cHotel Bel-Air\u201d");
t("adding cannot, so it does not try", F.formTitle(true, "hosting", "lodging", {}), "Add lodging");
t("adding ignores any object passed", F.formTitle(true, "hosting", "lodging", { name: "Hotel Bel-Air" }), "Add lodging");
t("an unnamed record keeps the noun", F.formTitle(false, "hosting", "lodging", {}), "Edit lodging");
t("a note is a note, not an activity", F.formTitle(true, "activity", "note", {}), "Add note");
t("a flight reads as its flight", F.formTitle(false, "transport", "transportation", { transportation_type: "airplane", company: "United", transport_number: "UA679" }), "Edit \u201cUnited UA679\u201d");

console.log("\nlong names are cut, not allowed to break the header");
const long = "The Ritz-Carlton Bacara Santa Barbara Resort and Spa, Goleta";
t("clipped at 40 with an ellipsis", F.clipName(long, 40).length, 40);
t("and it is visibly clipped", F.clipName(long, 40).slice(-1), "\u2026");
t("a name that fits is untouched", F.clipName("Hotel Bel-Air", 40), "Hotel Bel-Air");
t("exactly at the limit is untouched", F.clipName("x".repeat(40), 40), "x".repeat(40));
t("the title clips too", F.formTitle(false, "hosting", "lodging", { name: long }).length, 47);

// Measured live on trip 1141871 "South America" -- three hotels and seven
// LATAM flights, five of them sharing a carrier, which is exactly the trip the
// generic title fails on. Tapping Edit gave:
//   hotel row   -> Edit “Palacio Duhau - Park Hyatt Buenos Aires”  (was "Edit lodging")
//   flight row  -> Edit “LATAM Airlines LA4248”                   (was "Edit transportation")
//
// Header at 375x812, the phone case: the real title wraps to two lines and
// neither overflows the panel nor scrolls the body sideways. The same name
// unclipped takes three. So the 40-character cut buys back a line of header on
// the device with the least of it, which is what it is for.
console.log("\nevery dialog that has a subject names it");
t("transportation", /formTitle\(isNew, "transport", "transportation", o\)/.test(app), true);
t("lodging", /formTitle\(isNew, "hosting", "lodging", o\)/.test(app), true);
t("expense", /formTitle\(isNew, "expense", "expense", o\)/.test(app), true);
t("activity and note", /formTitle\(isNew, "activity", isNote \? "note" : "activity", o\)/.test(app), true);
t("the trip editor", /formDialog\("Edit \u201c" \+ clipName\(t\.name \|\| "trip", 40\) \+ "\u201d",/.test(app), true);
t("the calendar feed", /f\.name \? "\u201c" \+ clipName\(f\.name, 40\) \+ "\u201d settings" : "Feed settings"/.test(app), true);
// Found while verifying U16: the Trip Ideas editor still said a bare "Edit",
// which is the same defect in the one dialog U14 had not reached.
t("the trip-idea editor names its idea",
  /"Edit “" \+ clipName\(item\.place, 40\) \+ "”" : "Edit idea"/.test(app), true);
t("and falls back rather than printing empty quotes",
  /item && item\.place \?/.test(app), true);
// The generic pair are gone from the code, comments aside.
const code = app.replace(/^\s*\/\/.*$/gm, "");
t("no bare Edit lodging remains", /"Add" : "Edit"\) \+ " lodging"/.test(code), false);
t("no bare Edit transportation remains", /"Add" : "Edit"\) \+ " transportation"/.test(code), false);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
