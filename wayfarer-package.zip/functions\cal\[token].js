// Live calendar feed — the one Tripsy feature that genuinely needed replacing.
//
// iOS Calendar subscribes by URL and fetches on its own schedule with no
// session, so this path must sit outside Cloudflare Access. It is therefore
// protected the way calendar feeds always are: by an unguessable URL, with
// X-Robots-Tag: noindex and a Cache-Control that keeps intermediaries from
// holding your itinerary.
//
// It exposes read-only .ics. There is no write path here and no way to reach
// any other endpoint from it. What the feed CONTAINS is editable — every knob
// lives in cal_feeds.settings and is edited in the PWA — but a calendar client
// can only ever read.
//
// Two ways to authenticate, and both matter:
//   - A row in cal_feeds, one token per feed, revocable on its own.
//   - The original CAL_TOKEN Pages secret, which is already subscribed on a
//     phone. It maps onto the '@legacy' row so that subscription keeps working
//     and becomes editable, without the secret ever being copied into the
//     database.

const ok = (body, extra = {}) =>
  new Response(body, {
    status: 200,
    headers: {
      "content-type": "text/calendar; charset=utf-8",
      "cache-control": "private, max-age=900",
      "x-robots-tag": "noindex, nofollow",
      ...extra,
    },
  });

// Length-independent compare so a wrong token cannot be narrowed by timing.
function safeEqual(a, b) {
  const x = new TextEncoder().encode(String(a));
  const y = new TextEncoder().encode(String(b));
  let diff = x.length ^ y.length;
  const n = Math.max(x.length, y.length);
  for (let i = 0; i < n; i++) diff |= (x[i] || 0) ^ (y[i] || 0);
  return diff === 0;
}

const esc = (s) =>
  String(s == null ? "" : s)
    .replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,")
    .replace(/\r?\n/g, "\\n");

// RFC 5545 folds at 75 OCTETS, not characters. Counting characters meant every
// line carrying an em dash, an accent or a "·" ran over — 40 of them in the
// live feed — and, worse, a split could in principle land inside a multi-byte
// character and emit invalid UTF-8. Walk code points and measure encoded length.
const TE = new TextEncoder();
function fold(line) {
  if (TE.encode(line).length <= 75) return line;
  const out = [];
  let cur = "", bytes = 0;
  for (const ch of line) {                 // by code point: never splits a character
    const n = TE.encode(ch).length;
    if (bytes + n > 75) { out.push(cur); cur = " " + ch; bytes = 1 + n; }
    else { cur += ch; bytes += n; }
  }
  if (cur) out.push(cur);
  return out.join("\r\n");
}

// Absent must mean absent, not 1970.
//
// new Date(null) is epoch 0 -- a perfectly valid Date -- so isNaN() waves it
// through and this returned "19700101T000000Z". null is exactly what a missing
// field reads as coming out of D1, so every item with a start and no end got
// DTEND at the epoch: a dinner reservation, an Uber, anything booked for a time
// rather than a span. In a US timezone the calendar drew that as 31 December
// 1969. Thirty-two events across the feed.
//
// The `|| s` fallback in timed() was supposed to catch this and could not: a
// non-empty string is truthy, so it never fired. Fixing it there would have
// papered over a function that reports a real time for no input.
//
// Note undefined and "" DO give Invalid Date. Only null is silently a moment.
const stampUtc = (iso) => {
  if (iso == null || iso === "") return null;
  const d = new Date(iso);
  if (isNaN(d)) return null;
  return d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
};
const dateOnly = (ymd) => String(ymd || "").replace(/-/g, "");

// All-day end dates in iCalendar are exclusive, so a trip ending on the 19th
// must say DTEND 20.
//
// DO NOT DELETE THIS AS UNUSED. It has exactly one call site and that call sits
// inside a template literal — `DTEND;VALUE=DATE:${nextDay(t.ends_at)}` — which a
// dead-code sweep hunting for ordinary call sites can miss. It was removed on
// 2026-08-12 for that reason and took the entire calendar feed down: every
// request 500'd, and the only symptom anyone saw was Outlook refusing the
// subscription with "not a valid calendar link".
function nextDay(ymd) {
  const d = new Date(ymd + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + 1);
  return d.toISOString().slice(0, 10).replace(/-/g, "");
}

// Two rules govern the shape of every event, and neither is a preference:
//
//   1. The TRIP is the only all-day entry, and the only thing allowed to occupy
//      more than one day. Everything inside it is either a moment or a single
//      journey. A hotel is not a two-night appointment — it is a check-in and a
//      check-out, and it is emitted as two. Same for a week-long hire car and
//      for airport parking left over a weekend.
//   2. Nothing marks you busy. An itinerary is a record of where you are, not a
//      claim on your working hours, and a traveller's calendar that blocks out
//      whole days makes them unschedulable for the entire trip.
//
// The single exception to rule 1 is a scheduled leg that genuinely flies,
// sails or drives through midnight — a red-eye is one event that happens to
// land tomorrow, and splitting it would be a lie about the journey.
const DEFAULTS = {
  include: { trips: true, transport: true, lodging: true, activities: true },
  backDays: 365,
  alarms: { transport: 180, lodging: 0, activity: 0 },   // minutes before; 0 = none
  busy: { trips: false, transport: false, lodging: false, activity: false },
  emojis: true, rich: true, link: true, categories: true,
};

// A leg carries you: it may cross a midnight. A hire car, a hotel or a parking
// space is HELD, not travelled in, so it is bounded by two moments instead.
const LEG_TYPES = /^(airplane|train|ferry|boat|bus|shuttle|subway|tram|helicopter)$/;

// How long a split marker lasts. Zero-length events are legal but render as an
// invisible sliver in several clients, and some drop them; half an hour reads
// as "this is when you do this" without pretending to know more.
const MARK_MS = 30 * 60000;

function settingsOf(row) {
  let s = {};
  try { s = JSON.parse(row.settings || "{}"); } catch { s = {}; }
  return {
    ...DEFAULTS, ...s,
    include: { ...DEFAULTS.include, ...(s.include || {}) },
    alarms: { ...DEFAULTS.alarms, ...(s.alarms || {}) },
    busy: { ...DEFAULTS.busy, ...(s.busy || {}) },
  };
}

// The local calendar date an instant falls on, in the item's own timezone —
// which is the only frame in which "does this cross a day boundary" means
// anything. A stay checking in at 15:00 and out at 12:00 four days later is
// four days long wherever you read it from; a red-eye is not.
function dayIn(iso, tz) {
  const t = Date.parse(iso);
  if (!Number.isFinite(t)) return null;
  try {
    return new Intl.DateTimeFormat("en-CA", {
      timeZone: tz || "UTC", year: "numeric", month: "2-digit", day: "2-digit",
    }).format(new Date(t));
  } catch { return new Date(t).toISOString().slice(0, 10); }
}
function daysApart(aIso, bIso, tzA, tzB) {
  const a = dayIn(aIso, tzA), b = dayIn(bIso, tzB || tzA);
  if (!a || !b) return 0;
  return Math.round((Date.parse(b + "T00:00:00Z") - Date.parse(a + "T00:00:00Z")) / 86400000);
}

export async function onRequest({ request, params, env }) {
  const db = env.DB;
  if (!db) return new Response("Database unavailable.", { status: 503 });

  const raw = String(params.token || "").replace(/\.ics$/i, "");
  if (!raw) return new Response("Not found", { status: 404 });

  let feed = null;
  try {
    // The legacy secret first, so the phone that is already subscribed keeps
    // working even if the row were somehow missing.
    if (env.CAL_TOKEN && safeEqual(raw, env.CAL_TOKEN)) {
      feed = await db.prepare("SELECT * FROM cal_feeds WHERE token='@legacy' AND deleted_at IS NULL").first();
      if (!feed) feed = { id: 0, name: "Wayfarer", settings: "{}" };
    } else if (/^[a-f0-9]{24,64}$/i.test(raw)) {
      // Only a well-formed token reaches the database at all.
      feed = await db.prepare("SELECT * FROM cal_feeds WHERE token=? AND deleted_at IS NULL").bind(raw).first();
    }
  } catch (e) {
    return new Response("Feed error: " + (e && e.stack ? e.stack : String(e)), {
      status: 500, headers: { "content-type": "text/plain" },
    });
  }

  // Deliberately indistinguishable from a path that does not exist.
  if (!feed) return new Response("Not found", { status: 404 });

  try {
    const body = await buildFeed(request, db, feed);
    // Best-effort: knowing a feed is still being polled is what tells you it is
    // safe to revoke one. Never let it fail the request.
    if (feed.id) {
      try { await db.prepare("UPDATE cal_feeds SET last_used_at=? WHERE id=?").bind(new Date().toISOString(), feed.id).run(); } catch { /* ignore */ }
    }
    return body;
  } catch (e) {
    // Only reachable with a valid token, so the detail goes to you and nobody
    // else. A bare 500 told me nothing and cost two deploys to chase.
    return new Response("Feed error: " + (e && e.stack ? e.stack : String(e)), {
      status: 500, headers: { "content-type": "text/plain" },
    });
  }
}

async function buildFeed(request, db, feed) {
  const cfg = settingsOf(feed);
  const url = new URL(request.url);
  const origin = url.origin;

  // A query string still wins, so a one-off can be pulled without editing the
  // feed — but the saved setting is what every subscribed client gets.
  const qBack = url.searchParams.get("back");
  const back = Math.min(Math.max(Number(qBack != null ? qBack : cfg.backDays) || 0, 0), 5000);
  const from = new Date(Date.now() - back * 86400000).toISOString().slice(0, 10);

  const trips = await db
    .prepare("SELECT id,name,starts_at,ends_at,has_dates,timezone FROM trips WHERE deleted_at IS NULL AND (ends_at >= ? OR ends_at IS NULL) ORDER BY starts_at")
    .bind(from).all();

  // Three queries for the whole feed, grouped in memory. One query per trip per
  // table meant 543 D1 round-trips in a single request, which a Worker will not
  // do — that was the 500.
  const ids = (trips.results || []).map((t) => t.id);
  const byTrip = { tr: new Map(), ho: new Map(), ac: new Map() };
  if (ids.length) {
    const inList = ids.join(",");   // integers straight from the DB, not user input
    // Only PROMOTED columns may be named in a SELECT. Everything else — seat,
    // terminal, gate, notes, room, and the airport descriptions — lives inside
    // the `data` blob and is read out below. Naming one of those directly is a
    // D1_ERROR that takes the whole feed down with a 500, which is exactly how
    // this line broke the first time.
    const [trAll, hoAll, acAll] = await Promise.all([
      db.prepare(`SELECT trip_id,id,name,transportation_type,transport_number,company,departure_at,arrival_at,departure_timezone,arrival_timezone,provider_reservation_code,data FROM transportations WHERE deleted_at IS NULL AND trip_id IN (${inList})`).all(),
      db.prepare(`SELECT trip_id,id,name,starts_at,ends_at,timezone,address,provider_reservation_code,data FROM hostings WHERE deleted_at IS NULL AND trip_id IN (${inList})`).all(),
      db.prepare(`SELECT trip_id,id,name,activity_type,starts_at,ends_at,timezone,address,provider_reservation_code,data FROM activities WHERE deleted_at IS NULL AND trip_id IN (${inList})`).all(),
    ]);
    // An allowlist, not a spread: the blob holds the whole original record, so
    // copying it wholesale would let a stale copy shadow every promoted column.
    // Anything the feed needs must be named here, and a field that is missing
    // shows up as a feature that silently produces nothing rather than an error.
    const FROM_BLOB = ["departure_description", "arrival_description", "departure_terminal",
      "departure_gate", "seat_number", "notes", "room_number"];
    const group = (rows, m) => {
      for (const r of rows.results || []) {
        if (r.data) {
          try {
            const d = JSON.parse(r.data);
            // Never let the blob shadow a promoted column that already has a
            // value — the column is the one the rest of the app writes.
            for (const k of FROM_BLOB) if (r[k] == null && d[k] != null) r[k] = d[k];
          } catch { /* a malformed blob should not sink the whole feed */ }
        }
        if (!m.has(r.trip_id)) m.set(r.trip_id, []);
        m.get(r.trip_id).push(r);
      }
    };
    group(trAll, byTrip.tr); group(hoAll, byTrip.ho); group(acAll, byTrip.ac);
  }

  // One place decides whether a title carries its emoji, so the setting cannot
  // apply to hotels and quietly miss trips.
  const ico = (e) => (cfg.emojis === false ? "" : e + " ");

  const calName = feed.name || "Wayfarer";
  const lines = [
    "BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Wayfarer//EN",
    "CALSCALE:GREGORIAN", "METHOD:PUBLISH",
    fold(`X-WR-CALNAME:${esc(calName)}`),
    "X-WR-CALDESC:Trips and itineraries",
    "X-PUBLISHED-TTL:PT1H", "REFRESH-INTERVAL;VALUE=DURATION:PT1H",
  ];
  const now = stampUtc(new Date().toISOString());
  const nowMs = Date.now();

  // A reminder on a flight you took last year is pure noise, and on a phone it
  // can actually fire while the client back-fills. Alarms go on the future only.
  const alarmFor = (mins, startIso) => {
    if (!mins || mins <= 0) return [];
    const t = Date.parse(startIso);
    if (!Number.isFinite(t) || t < nowMs) return [];
    return ["BEGIN:VALARM", "ACTION:DISPLAY", "DESCRIPTION:Reminder",
      `TRIGGER:-PT${Math.round(mins)}M`, "END:VALARM"];
  };

  const descLines = (parts) => {
    const body = parts.filter(Boolean).join("\\n")
      .replace(/(?:\\n\s*){3,}/g, "\\n\\n")   // imported notes arrive padded with blank lines
      .replace(/(?:\\n\s*)+$/, "");           // and usually a few trailing ones
    return body ? [fold(`DESCRIPTION:${body}`)] : [];
  };

  // Notes come out of confirmation emails and carry their whitespace with them.
  const note = (s) => {
    const t = String(s == null ? "" : s).trim();
    return t ? esc(t.slice(0, 500)) : "";
  };

  for (const t of trips.results || []) {
    // The trip itself as an all-day span, so it reads as a band in month view.
    if (cfg.include.trips && t.has_dates && t.starts_at && t.ends_at) {
      lines.push("BEGIN:VEVENT",
        `UID:trip-${t.id}@wayfarer`,
        `DTSTAMP:${now}`,
        `DTSTART;VALUE=DATE:${dateOnly(t.starts_at)}`,
        `DTEND;VALUE=DATE:${nextDay(t.ends_at)}`,
        fold(`SUMMARY:${ico("✈")}${esc(t.name || "Trip")}`),
        cfg.busy.trips ? "TRANSP:OPAQUE" : "TRANSP:TRANSPARENT");
      if (cfg.categories) lines.push("CATEGORIES:Trip");
      if (cfg.link) lines.push(fold(`URL:${origin}/#trip/${t.id}`));
      lines.push("END:VEVENT");
    }

    const tripUrl = cfg.link ? `${origin}/#trip/${t.id}` : null;

    // One place that emits a timed event, so free/busy, categories, the link
    // back and the alarm cannot drift apart between item types.
    const timed = (uid, summary, startIso, endIso, location, desc, opts) => {
      const s = stampUtc(startIso);
      if (!s) return;
      const e = stampUtc(endIso) || s;
      lines.push("BEGIN:VEVENT",
        `UID:${uid}@wayfarer`,
        `DTSTAMP:${now}`,
        `DTSTART:${s}`, `DTEND:${e}`,
        fold(`SUMMARY:${esc(summary)}`),
        opts.busy ? "TRANSP:OPAQUE" : "TRANSP:TRANSPARENT");
      if (location) lines.push(fold(`LOCATION:${esc(location)}`));
      lines.push(...descLines(desc));
      if (cfg.categories && opts.category) lines.push(`CATEGORIES:${opts.category}`);
      if (tripUrl) lines.push(fold(`URL:${tripUrl}`));
      lines.push(...alarmFor(opts.alarm, startIso));
      lines.push("END:VEVENT");
    };

    // Emit one event if it fits inside a day, or two markers if it does not.
    // `openLabel`/`closeLabel` name the two ends in the language of the thing
    // itself — you check into a hotel, you collect a car, you retrieve a car
    // from a parking space.
    const spanOrSplit = (uid, summary, startIso, endIso, tzStart, tzEnd, location, desc, opts) => {
      if (!startIso) return;
      const crosses = endIso && daysApart(startIso, endIso, tzStart, tzEnd) > 0;
      if (!crosses) {
        timed(uid, summary, startIso, endIso, location, desc, opts);
        return;
      }
      const open = `${opts.openLabel}: ${summary}`;
      const close = `${opts.closeLabel}: ${summary}`;
      // Each marker carries its OWN end. A one-way hire car collected at
      // Liberia and returned at San José should say so on each event, rather
      // than repeating the whole route twice.
      timed(`${uid}-a`, open, startIso, new Date(Date.parse(startIso) + MARK_MS).toISOString(),
        location, desc, opts);
      timed(`${uid}-b`, close, endIso, new Date(Date.parse(endIso) + MARK_MS).toISOString(),
        opts.locationB != null ? opts.locationB : location, desc,
        { ...opts, alarm: 0 });   // one reminder per booking, on the start
    };

    if (cfg.include.transport) {
      for (const x of byTrip.tr.get(t.id) || []) {
        const label = [x.company, x.transport_number].filter(Boolean).join(" ") || x.name || "Transport";
        const route = [x.departure_description, x.arrival_description].filter(Boolean).join(" → ");
        const desc = cfg.rich
          ? [x.provider_reservation_code ? `Confirmation ${esc(x.provider_reservation_code)}` : "",
             x.seat_number ? `Seat ${esc(x.seat_number)}` : "",
             x.departure_terminal ? `Terminal ${esc(x.departure_terminal)}` : "",
             x.departure_gate ? `Gate ${esc(x.departure_gate)}` : "",
             note(x.notes)]
          : [x.provider_reservation_code ? `Confirmation ${esc(x.provider_reservation_code)}` : ""];
        const opts = { busy: cfg.busy.transport, category: "Travel", alarm: cfg.alarms.transport,
          openLabel: "Pick up", closeLabel: "Drop off" };
        const summary = `${label}${route ? " " + route : ""}`;

        // A red-eye is one journey that happens to land tomorrow — splitting it
        // would misdescribe the flight. But a leg claiming to span more than a
        // single midnight is a wrong date, not a long flight (a corrupted
        // duplicate of UA679 once read as thirty days), and must not be allowed
        // to paint a month-long band across the calendar.
        const isLeg = LEG_TYPES.test(x.transportation_type || "");
        const nights = x.arrival_at ? daysApart(x.departure_at, x.arrival_at, x.departure_timezone, x.arrival_timezone) : 0;
        if (isLeg && nights <= 1) {
          timed(`tr-${x.id}`, summary, x.departure_at, x.arrival_at, route, desc, opts);
        } else {
          // Split form drops the route from the title — "Pick up: Adobe Rent A
          // Car" with the office as its location beats repeating
          // "Adobe Rent a Car → Adobe Rent a Car" on both halves.
          spanOrSplit(`tr-${x.id}`, label, x.departure_at, x.arrival_at,
            x.departure_timezone, x.arrival_timezone,
            x.departure_description || route, desc,
            { ...opts, locationB: x.arrival_description || route,
              ...(isLeg ? { openLabel: "Departs", closeLabel: "Arrives" } : {}) });
        }
      }
    }

    if (cfg.include.lodging) {
      for (const x of byTrip.ho.get(t.id) || []) {
        const name = x.name || "Lodging";
        const desc = cfg.rich
          ? [x.provider_reservation_code ? `Confirmation ${esc(x.provider_reservation_code)}` : "",
             x.room_number ? `Room ${esc(x.room_number)}` : "",
             note(x.notes)]
          : [x.provider_reservation_code ? `Confirmation ${esc(x.provider_reservation_code)}` : ""];
        spanOrSplit(`ho-${x.id}`, `${ico("🏨")}${name}`, x.starts_at, x.ends_at, x.timezone, x.timezone,
          x.address, desc, { busy: cfg.busy.lodging, category: "Lodging", alarm: cfg.alarms.lodging,
            openLabel: "Check in", closeLabel: "Check out" });
      }
    }

    if (cfg.include.activities) {
      for (const x of byTrip.ac.get(t.id) || []) {
        const desc = cfg.rich
          ? [x.provider_reservation_code ? `Confirmation ${esc(x.provider_reservation_code)}` : "",
             note(x.notes)]
          : [x.provider_reservation_code ? `Confirmation ${esc(x.provider_reservation_code)}` : ""];
        const parking = x.activity_type === "parking";
        spanOrSplit(`ac-${x.id}`, x.name || "Activity", x.starts_at, x.ends_at, x.timezone, x.timezone,
          x.address, desc, { busy: cfg.busy.activity, category: "Activity", alarm: cfg.alarms.activity,
            openLabel: parking ? "Drop off car" : "Starts",
            closeLabel: parking ? "Collect car" : "Ends" });
      }
    }

    // Cancellation deadlines are deliberately NOT emitted here. They exist on
    // items as `terms.cancel_by` and are shown in the trip's Dossier, which is
    // where they belong: the calendar is a record of where you will be, not a
    // list of decisions still open. Adding them was tried and reverted.
  }

  lines.push("END:VCALENDAR");
  return ok(lines.join("\r\n") + "\r\n");
}
