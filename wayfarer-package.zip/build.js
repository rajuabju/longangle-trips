#!/usr/bin/env node
// Content-hash app.js and styles.css into immutable filenames.
//
// Why this exists: Cloudflare Pages serves these assets with
// Cache-Control: max-age=2678400 (31 days) and ignores a _headers override for
// them — it merges directives rather than replacing them. Combined with ?v=
// cache-busting that is actively harmful: a browser that fetches /app.js?v=N
// during the minute it takes a deploy to reach the edge caches the PREVIOUS
// build's body under the new version URL, and keeps it for a month.
//
// Hashed filenames sidestep the whole problem. The content at
// app.<hash>.js never changes, so caching it forever is correct, and every
// build produces a URL nothing has ever cached. index.html stays no-cache and
// is the only thing that needs to be fresh.
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const PUB = path.join(__dirname, "public");

// ---- versioning: one number, written once ---------------------------------
//
// package.json is the source of truth and the ONLY place a version is edited.
// Everything the app shows is generated from it here, because the alternative
// was tried and failed: APP_VERSION and __WAYFARER_BUILD were both maintained by
// hand, and __WAYFARER_BUILD sat on "v119" through eight releases while
// APP_VERSION climbed from 1.5.0 to 1.8.2. The pill that exists to answer "has
// this phone got the new code" spent all of that time confidently saying no.
//
// Shape is MAJOR.MINOR.PATCH because npm requires three parts; the app shows
// vMAJOR.MINOR -- v120.3. Bump the major for a release, the minor for a change
// within one. The patch digit is unused and stays 0.
(function writeVersion() {
  const pkg = JSON.parse(fs.readFileSync(path.join(__dirname, "package.json"), "utf8")).version;
  const m = /^(\d+)\.(\d+)\.(\d+)$/.exec(pkg);
  if (!m) {
    console.error('build: package.json version "' + pkg + '" is not MAJOR.MINOR.PATCH');
    process.exit(1);
  }
  const shown = "v" + m[1] + "." + m[2];
  const file = path.join(PUB, "app.js");
  let src = fs.readFileSync(file, "utf8");
  let wrote = 0;
  const set = (re, replacement, label) => {
    if (!re.test(src)) {
      console.error("build: " + label + " is missing from public/app.js");
      process.exit(1);
    }
    const before = src;
    src = src.replace(re, replacement);
    if (src !== before) wrote++;
  };
  set(/var APP_VERSION = "[^"]*"/, 'var APP_VERSION = "' + shown + '"', "APP_VERSION");
  set(/window\.__WAYFARER_BUILD = "[^"]*"/,
    'window.__WAYFARER_BUILD = "' + shown + '"', "__WAYFARER_BUILD");
  if (wrote) {
    fs.writeFileSync(file, src);
    console.log("  version " + shown + " (updated " + wrote + " constant" + (wrote > 1 ? "s" : "") + ")");
  }
})();
// ---- minification -----------------------------------------------------------
//
// The sources are heavily commented on purpose -- 42% of app.js and 36% of
// styles.css is explanation, and that is worth keeping. What is not worth
// keeping is SHIPPING it: measured, app.js goes 636,938 -> ~282,000 bytes and
// styles.css 111,780 -> ~64,600. Gzip hides some of the wire cost, but the
// phone still parses every byte on every cold start of the installed PWA, and
// styles.css is the one asset that blocks first paint.
//
// No target is set, deliberately. esbuild's default ("esnext") means "minify
// but do not rewrite syntax" -- the shipped code stays the code that was
// written and tested, only smaller. Setting a target here would silently start
// transpiling, which is a much larger change than this is meant to be.
//
// The hash is taken over the MINIFIED bytes, because those are what the browser
// receives; hashing the source would let two different shipped files share a
// URL.
const esbuild = require("esbuild");

function minify(file, ext) {
  const raw = fs.readFileSync(path.join(PUB, file), "utf8");
  let out;
  try {
    out = esbuild.transformSync(raw, { loader: ext === "css" ? "css" : "js", minify: true }).code;
  } catch (e) {
    console.error("build: could not minify " + file + " -- " + e.message);
    process.exit(1);
  }
  // A minifier that emits something unparseable would otherwise ship silently:
  // every test suite in this repo reads the SOURCE app.js, so nothing else in
  // the pipeline would notice until the app failed to boot in a browser.
  if (ext === "js") {
    try { new Function(out); } catch (e) {
      console.error("build: minified " + file + " does not parse -- " + e.message);
      process.exit(1);
    }
  }
  return out;
}

const hashOf = (text) =>
  crypto.createHash("md5").update(text).digest("hex").slice(0, 10);

// Every hashed asset, as [source, extension]. Adding one here is all it takes:
// the rewrites below are driven off this list, so index.html and sw.js stay in
// step automatically.
// ORDER MATTERS. qr.js is lazy-loaded by app.js, which therefore has to carry
// its hashed filename -- so qr is built first and its name written into app.js
// BEFORE app.js is read, minified and hashed. app stays last for that reason.
const ASSETS = [
  ["qr", "js"],
  ["styles", "css"],
  ["feasibility", "js"],
  ["app", "js"]
];
const STEMS = ASSETS.map(([stem]) => stem).join("|");

// Drop artifacts from previous builds so the directory doesn't accumulate.
fs.readdirSync(PUB)
  .filter((f) => new RegExp(`^(${STEMS})\\.[0-9a-f]{10}\\.(js|css)$`).test(f))
  .forEach((f) => fs.unlinkSync(path.join(PUB, f)));

// app.js cannot reference /qr.<hash>.js from index.html any more, because it is
// no longer loaded there -- so the name is written into app.js the same way the
// version constants are.
function pinQr(name) {
  const file = path.join(PUB, "app.js");
  const src = fs.readFileSync(file, "utf8");
  const re = /var QR_SRC = "[^"]*"/;
  if (!re.test(src)) {
    console.error("build: QR_SRC is missing from public/app.js");
    process.exit(1);
  }
  const next = src.replace(re, 'var QR_SRC = "/' + name + '"');
  if (next !== src) fs.writeFileSync(file, next);
}

let savedRaw = 0, shippedRaw = 0;
const built = ASSETS.map(([stem, ext]) => {
  const src = `${stem}.${ext}`;
  const before = fs.statSync(path.join(PUB, src)).size;
  const code = minify(src, ext);
  const h = hashOf(code);
  const name = `${stem}.${h}.${ext}`;
  fs.writeFileSync(path.join(PUB, name), code);
  if (stem === "qr") pinQr(name);
  savedRaw += before - Buffer.byteLength(code);
  shippedRaw += Buffer.byteLength(code);
  return { stem, ext, hash: h, name, before, after: Buffer.byteLength(code) };
});
// The shell cache name must change when ANY shipped asset does, not just
// app.js. Deriving it from app.js alone was fine while app.js was the only
// thing that ever changed; the moment feasibility.js could change on its own,
// a feasibility-only deploy left the cache name identical and relied on the
// service worker noticing sw.js had shifted by a few bytes. Hash the hashes.
const shellHash = crypto.createHash("md5")
  .update(built.map((b) => b.name).join("|")).digest("hex").slice(0, 10);

// Point index.html and the service worker at the hashed names, replacing
// whatever form is there now (plain, ?v=N, or a previous hash). The service
// worker must precache exactly the URLs the page requests, and its cache name
// must change whenever any of the assets do.
const idxPath = path.join(PUB, "index.html");
const swPath = path.join(PUB, "sw.js");
let idx = fs.readFileSync(idxPath, "utf8");
let sw = fs.readFileSync(swPath, "utf8");

for (const b of built) {
  // Anchored to the attribute, NOT bare. The unanchored form matched the string
  // anywhere in the file, prose included: the comment above the stylesheet link
  // read "on every app.js/styles.css change", and every build rewrote that
  // sentence into "app.js/styles.<hash>.css". A sentence is not a reference.
  const attr = new RegExp(`(src|href)="\\/${b.stem}(?:\\.[0-9a-f]{10})?\\.${b.ext}(?:\\?v=\\d+)?"`, "g");
  const quoted = new RegExp(`"\\/${b.stem}(?:\\.[0-9a-f]{10})?\\.${b.ext}(?:\\?v=\\d+)?"`, "g");
  idx = idx.replace(attr, `$1="/${b.name}"`);
  sw = sw.replace(quoted, `"/${b.name}"`);
}
sw = sw.replace(/var SHELL = "[^"]*";/, `var SHELL = "wayfarer-shell-${shellHash}";`);
fs.writeFileSync(idxPath, idx);
fs.writeFileSync(swPath, sw);

const kb = (n) => (n / 1024).toFixed(1) + "KB";
console.log("built:");
built.forEach((b) => console.log("  " + b.name.padEnd(30) +
  kb(b.before) + " -> " + kb(b.after) +
  "  (-" + Math.round((1 - b.after / b.before) * 100) + "%)"));
console.log("  shell cache: wayfarer-shell-" + shellHash);
console.log("  minified away: " + kb(savedRaw) + " (shipping " + kb(shippedRaw) + ")");

