// What the trips list ships, and what the dashboard costs to start.
//
// Measured on the real 181-trip dataset before this changed: the list response
// was 194,116 bytes, of which `guests` alone was 92,312 (48%) -- a retired
// Tripsy profile blob with S3 photo URLs and a ten-key permissions object, read
// by nothing. After: 91,125 bytes.
//
// Separately, the search index over hotel names and addresses was built by
// fetching every trip's hostings and activities one trip at a time: two
// requests each, up to 362 on a device with an empty localStorage, fired right
// after first paint. It is one request now.
const fs = require("fs");
const core = fs.readFileSync("functions/api/_core.js", "utf8");
const app = fs.readFileSync("public/app.js", "utf8");
const sw = fs.readFileSync("public/sw.js", "utf8");

const grab = (src, name) => {
  const head = "function " + name + "(";
  const i = src.indexOf(head);
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
};

eval(grab(core, "project") + ";globalThis.project = project;");
const DROP = JSON.parse(
  (/const TRIP_LIST_DROP = (\[[^\]]*\])/.exec(core) || [])[1].replace(/'/g, '"'));

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

console.log("\nwhat gets dropped from the trip list");
t("the four dead Tripsy keys", DROP.sort(),
  ["collaborators", "collaborators_count", "guests", "owner"]);
// Being wrong here fails silently -- the field simply stops arriving and some
// screen quietly renders nothing -- so each of these is checked by name.
t("suggestions is NOT dropped", DROP.includes("suggestions"), false);
t("because renderSuggested reads it", /var sg = t\.suggestions/.test(app), true);
t("documents is NOT dropped", DROP.includes("documents"), false);
t("emails is NOT dropped", DROP.includes("emails"), false);
t("the list handler applies it", /for \(const k of TRIP_LIST_DROP\) delete t\[k\]/.test(core), true);
// Only the list. A single trip fetched on its own stays complete.
t("and only in the list handler",
  (core.match(/TRIP_LIST_DROP/g) || []).length, 2);

console.log("\nthe fields parameter the client was already sending");
t("id survives even when not asked for",
  Object.keys(project({ id: 7, name: "x", junk: 1 }, "name")).sort(), ["id", "name"]);
t("it projects to what was asked",
  project({ id: 7, name: "x", junk: 1 }, "id,name"), { id: 7, name: "x" });
t("whitespace is tolerated",
  Object.keys(project({ id: 1, a: 1, b: 2 }, " a , b ")).sort(), ["a", "b", "id"]);
t("no fields means the whole object",
  project({ id: 1, a: 1 }, null), { id: 1, a: 1 });
t("an empty fields means the whole object too",
  project({ id: 1, a: 1 }, ""), { id: 1, a: 1 });
t("an unknown field is simply absent",
  project({ id: 1, a: 1 }, "nope"), { id: 1 });
// This is why it exists: detectChangedTrips has always asked for it.
t("detectChangedTrips asks for id,name", app.indexOf('&fields=id,name') > -1, true);

console.log("\none request for the search index");
t("the endpoint exists", /segs\[0\] === "destinations" && method === "GET"/.test(core), true);
// name and address are promoted columns on both tables, so no blob parsing.
t("it reads hostings by column",
  /SELECT trip_id, name, address FROM hostings WHERE deleted_at IS NULL/.test(core), true);
t("and activities by column",
  /SELECT trip_id, address FROM activities WHERE deleted_at IS NULL/.test(core), true);
const destBlock = core.slice(core.indexOf('segs[0] === "destinations"'),
  core.indexOf("nearest-airport", core.indexOf('segs[0] === "destinations"')));
t("deleted rows are excluded from the index",
  (destBlock.match(/WHERE deleted_at IS NULL/g) || []).length, 2);
t("terms are capped so one itinerary cannot bloat the response",
  /\.slice\(0, 4000\)/.test(core), true);
t("the client calls it", /api\("\/v1\/destinations"\)/.test(app), true);
const indexFn = (() => {
  const i = app.indexOf("  async function indexDestinations() {");
  let d = 0, seen = false;
  for (let j = i; j < app.length; j++) {
    if (app[j] === "{") { d++; seen = true; }
    else if (app[j] === "}") { d--; if (seen && !d) return app.slice(i, j + 1); }
  }
  throw new Error("indexDestinations not found");
})();
t("and indexDestinations no longer walks trips one at a time",
  /apiAll\(/.test(indexFn), false);
// Check Trips and Changes still fetch whole itineraries on purpose -- they
// audit them rather than index place names -- so this is not a global ban.
t("the sweeps that genuinely need itineraries still have them",
  (app.match(/apiAll\("\/v1\/trip\/" \+ t\.id \+ "\/hostings"\)/g) || []).length, 2);
// A failed lookup must not be cached as "this trip has no places".
t("a failure leaves the trip unindexed rather than caching an empty answer",
  /Leave them unindexed rather than caching a wrong empty answer/.test(app), true);

console.log("\nthe cache stops evicting the itinerary");
t("core responses are recognised", /function isCore\(url\)/.test(sw), true);
t("and that means the trip list", /pathname\.indexOf\("\/api\/v1\/trips"\) === 0/.test(sw), true);
t("trim takes the excess from everything else",
  /var droppable = keys\.filter\(function \(k\) \{ return !isCore\(k\.url\); \}\)/.test(sw), true);
// Better slightly over cap than deleting the payload offline mode needs.
t("and never deletes core just to hit the cap",
  /nothing safe to drop/.test(sw), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
