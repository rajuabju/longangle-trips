// Flight lookups: the one feature here that spends money to answer.
//
// Everything else in this app answers from data we own. This asks SerpApi, the
// allowance is 250 searches a MONTH, and that budget is the design constraint
// rather than a footnote. So the tests care about three things in this order:
//
//   1. NOTHING SPENDS A SEARCH IT DOES NOT HAVE TO. A date outside the
//      schedule horizon, a window naming only a year, a destination we cannot
//      name an airport for -- each is answerable without a fetch, and each is
//      checked before one. A feature that quietly drains its own allowance
//      stops working in week two, which is indistinguishable from broken.
//   2. THE HORIZON IS THE SAME NUMBER ON BOTH SIDES. The client hides the
//      button past it; the server refuses past it. If those two drift, one of
//      them is lying, and the failure is invisible.
//   3. A PRICE IS NEVER DRESSED AS A QUOTE. These are one day's fares for a
//      date nobody picked.
//
// Fixtures are invented; the airports are real codes with real coordinates,
// which is what makes the nearest-airport arithmetic meaningful.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");
const core = fs.readFileSync("functions/api/_core.js", "utf8");

function grab(src, name, indent) {
  const head = (indent || "") + "function " + name + "(";
  const i = src.indexOf(head);
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
const chunk = (src, start) =>
  src.slice(src.indexOf(start), src.indexOf(";", src.indexOf(start)) + 1);

eval([
  chunk(app, "  var HOME = {"), chunk(app, "  var HOME_MAX_KM = "),
  chunk(app, "  var FLIGHT_HORIZON_DAYS = "), chunk(app, "  var MONTHS = ["),
  grab(app, "km", "  "), grab(app, "nearestAirport", "  "), grab(app, "targetLabel", "  "),
  grab(app, "sampleDate", "  "), grab(app, "flightWindow", "  "),
  grab(app, "homeAirport", "  "), grab(app, "destAirport", "  "),
  grab(app, "durLabel", "  "), grab(app, "stopsLabel", "  "),
  grab(core, "normalizeFlights", ""),
].join("\n") + ";Object.assign(globalThis,{HOME,HOME_MAX_KM,FLIGHT_HORIZON_DAYS,MONTHS,km," +
  "nearestAirport,targetLabel,sampleDate,flightWindow,homeAirport,destAirport,durLabel," +
  "stopsLabel,normalizeFlights});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

console.log("\nwhich day to price");
t("a specific day is used as given", sampleDate({ target_from: "2027-05-14" }), "2027-05-14");
t("a month becomes its middle", sampleDate({ target_from: "2027-05" }), "2027-05-15");
// A bare year names no month. Picking one would put a specific price on a
// decision that has not been made, which is worse than saying nothing.
t("a bare year gets NO sample date", sampleDate({ target_from: "2027" }), null);
t("nothing set, nothing sampled", sampleDate({}), null);
t("junk is not a date", sampleDate({ target_from: "someday" }), null);

console.log("\nthe schedule horizon — the check that costs nothing");
const NOW = Date.parse("2026-08-22T12:00:00Z");
t("next month is checkable", flightWindow("2026-09-15", NOW), "ok");
t("ten months out is checkable", flightWindow("2027-06-15", NOW), "ok");
// Past ~11 months there is no timetable. An empty result would read as "you
// cannot get there", which is a different and wrong statement.
t("two years out is not", flightWindow("2028-06-15", NOW), "far");
t("a date already gone is past", flightWindow("2026-01-15", NOW), "past");
t("no date, no window", flightWindow(null, NOW), null);
// The boundary itself, from both sides.
const dayAt = (n) => new Date(NOW + n * 86400000).toISOString().slice(0, 10);
t("the day before the horizon is ok", flightWindow(dayAt(FLIGHT_HORIZON_DAYS - 1), NOW), "ok");
t("the day past it is not", flightWindow(dayAt(FLIGHT_HORIZON_DAYS + 2), NOW), "far");

// THE drift test. Two constants, two files, one meaning. If the client offers a
// button the server refuses, nothing crashes -- it just fails for one reason
// while displaying another, forever.
const serverHorizon = Number(/FLIGHT_HORIZON_DAYS = (\d+)/.exec(core)[1]);
t("client and server agree on the horizon", FLIGHT_HORIZON_DAYS, serverHorizon);

console.log("\nwhich airports");
const PORTS = [
  { code: "LAX", latitude: 33.9434, longitude: -118.4084, legs: 120 },
  { code: "OGG", latitude: 20.8986, longitude: -156.4305, legs: 6 },
  { code: "JFK", latitude: 40.6423, longitude: -73.7882, legs: 4 },
];
t("home flies out of LAX, from his own history", homeAirport(PORTS), "LAX");
t("no history, no origin", homeAirport([]), null);
t("a known airport nearby is used", destAirport({ latitude: 20.79, longitude: -156.33 }, PORTS), "OGG");
// Blackberry Farm is in Tennessee. The nearest airport he has EVER used is JFK,
// 700 miles away -- searching LAX>JFK for it would be wrong and would charge
// for the privilege.
t("a distant known airport is NOT assumed",
  destAirport({ latitude: 35.65, longitude: -83.94 }, PORTS), null);
t("a typed code wins over the guess",
  destAirport({ latitude: 35.65, longitude: -83.94, airport: "TYS" }, PORTS), "TYS");
t("and is normalised", destAirport({ airport: "tys" }, PORTS), "TYS");
t("a typed code overrides even a close match",
  destAirport({ latitude: 20.79, longitude: -156.33, airport: "HNL" }, PORTS), "HNL");
t("a malformed code is ignored, not searched",
  destAirport({ airport: "Maui" }, PORTS), null);
t("no coordinates and no code means no search", destAirport({}, PORTS), null);

console.log("\nreading the answer");
t("hours and minutes", durLabel(345), "5h 45m");
t("a whole number of hours", durLabel(300), "5h");
t("under an hour", durLabel(45), "45m");
t("zero is not blank", durLabel(0), "0m");
t("nothing in, nothing out", durLabel(null), "");
t("nonstop is a word, not a zero", stopsLabel(0), "nonstop");
t("one stop is singular", stopsLabel(1), "1 stop");
t("two are not", stopsLabel(2), "2 stops");

console.log("\nfares read as fares");
eval(grab(app, "fare", "  ") + ";globalThis.fare=fare;");
// Verified against the live result: SerpApi returned 202 and the row read
// "$202.00". Cents are right for an expense, which genuinely has them, and
// wrong for a fare, which is quoted in whole dollars everywhere including
// on Google Flights itself.
t("whole dollars, not cents", fare(202), "$202");
t("thousands are grouped", fare(1450), "$1,450");
t("a fraction rounds rather than exposing cents", fare(202.4), "$202");
t("nothing in gives a dash, not $NaN", fare(null), "\u2014");
// money() still exists and still shows cents; this must not have replaced it.
t("expenses keep their cents", /function money\(/.test(app), true);

console.log("\nnormalising what SerpApi returns");
const RAW = {
  best_flights: [{
    flights: [
      { departure_airport: { id: "LAX", name: "Los Angeles Intl", time: "2027-05-15 08:15" },
        arrival_airport: { id: "DFW", name: "Dallas Fort Worth", time: "2027-05-15 13:30" },
        duration: 195, airline: "American", flight_number: "AA 1234",
        airplane: "Boeing 737", travel_class: "Economy" },
      { departure_airport: { id: "DFW", name: "Dallas Fort Worth", time: "2027-05-15 15:40" },
        arrival_airport: { id: "OGG", name: "Kahului", time: "2027-05-15 18:25" },
        duration: 465, airline: "American", flight_number: "AA 567" },
    ],
    layovers: [{ duration: 130, name: "Dallas Fort Worth", id: "DFW", overnight: false }],
    total_duration: 790, price: 487, type: "One way",
    carbon_emissions: { this_flight: 500000 },
  }],
  other_flights: [{
    flights: [{ departure_airport: { id: "LAX", time: "2027-05-15 09:00" },
      arrival_airport: { id: "OGG", time: "2027-05-15 12:05" },
      duration: 365, airline: "Hawaiian", flight_number: "HA 33" }],
    layovers: [], total_duration: 365, price: 612,
  }],
  price_insights: { lowest_price: 487, typical_price_range: [420, 780], price_level: "typical" },
};
const N = normalizeFlights(RAW, "LAX", "OGG", "2027-05-15");
t("both buckets are kept", N.results.length, 2);
t("the price comes through", N.results[0].price, 487);
t("and the total duration", N.results[0].minutes, 790);
// Counted from the legs, not read from a field: three legs is two stops
// whatever anything else in the response claims.
t("stops are counted from the legs", N.results[0].stops, 1);
t("a single leg is nonstop", N.results[1].stops, 0);
t("the flight number survives", N.results[0].legs[0].flight, "AA 1234");
t("so does the airport code", N.results[0].legs[1].to, "OGG");
t("and the layover", N.results[0].layovers[0].code, "DFW");
t("with its length", N.results[0].layovers[0].minutes, 130);
t("the typical range is carried", N.typical, { low: 420, high: 780 });
t("and the route it was asked for", [N.from, N.to, N.date], ["LAX", "OGG", "2027-05-15"]);
// Storing the whole response would put aircraft photos and booking tokens in D1
// forever, for a feature that shows six lines.
t("aircraft type is dropped", /airplane/.test(JSON.stringify(N)), false);
t("carbon estimates are dropped", /carbon/.test(JSON.stringify(N)), false);

console.log("\nnormalising what it returns on a bad day");
t("an empty response is empty, not a crash",
  normalizeFlights({}, "LAX", "OGG", "2027-05-15").results, []);
t("a null response too", normalizeFlights(null, "LAX", "OGG", "2027-05-15").results, []);
t("no price insights, no typical range", normalizeFlights({}, "L", "O", "d").typical, null);
// An itinerary with no legs describes no journey and would render as a blank
// card with a price on it.
t("an itinerary with no legs is dropped",
  normalizeFlights({ best_flights: [{ price: 99, flights: [] }] }, "L", "O", "d").results, []);
t("a missing airport does not throw",
  normalizeFlights({ best_flights: [{ flights: [{ duration: 60 }] }] }, "L", "O", "d")
    .results[0].legs[0].from, null);
const many = { best_flights: new Array(20).fill(0).map(() => ({
  flights: [{ departure_airport: { id: "A" }, arrival_airport: { id: "B" } }], price: 1 })) };
t("the list is capped at six", normalizeFlights(many, "A", "B", "d").results.length, 6);

console.log("\nwhat the code actually does");
// Each of these is a spending rule, and each is invisible until the month runs
// out early.
t("the horizon is checked BEFORE the fetch",
  core.indexOf("reason: \"too_far\"") < core.indexOf("serpapi.com/search.json"), true);
t("the cache is read before the fetch",
  core.indexOf("SELECT payload, fetched_at FROM flight_cache") < core.indexOf("serpapi.com/search.json"), true);
t("a viewer cannot spend the allowance",
  /flightsearch" && method === "GET"\)\s*\{[\s\S]{0,600}?role !== "admin"/.test(core), true);
t("the key is a binding, never a literal", /env\.SERPAPI_KEY/.test(core), true);
// A key pasted into the dashboard textarea keeps its trailing newline, and
// SerpApi rejects it as "Invalid API key" -- which reads as "wrong key" and
// sends you to reissue one that was correct.
t("and is trimmed before use", /String\(env\.SERPAPI_KEY \|\| ""\)\.trim\(\)/.test(core), true);
t("the trimmed value is what gets sent",
  /searchParams\.set\("api_key", apiKey\)/.test(core), true);
t("whitespace alone counts as unconfigured", /if \(!apiKey\)/.test(core), true);
t("and no key is committed", /serpapi[^\n]{0,40}[0-9a-f]{40,}/i.test(core), false);
t("a missing key says so instead of failing oddly",
  /Flight search is not configured/.test(core), true);
// Was one way, which was right when routing was the only question and wrong
// once the price had to mean something: a one-way fare is roughly half of
// what going somewhere costs, and on a long haul not even that.
t("a round trip when a return date is given",
  /searchParams\.set\("type", back \? "1" : "2"\)/.test(core), true);
// Google rejects type=1 with no return_date, so the two move together.
t("and the return date goes with it",
  /if \(back\) q\.searchParams\.set\("return_date", back\)/.test(core), true);
// The list paints many rows; a fetch per row per open would be ~17 searches
// every time the list is opened.
t("the list paints without fetching anything",
  /Nothing is fetched here/.test(app), true);
t("the search runs only on a press",
  /go\.addEventListener\("click", function \(\) \{ run\(false\); \}\)/.test(app), true);
t("refreshing warns that it costs a search",
  /this spends one of the 250 monthly searches/.test(app), true);
// The single most misleading thing available here is a real price for a date
// nobody chose.
t("every result says it is indicative",
  /indicative, not a quote/.test(app), true);
t("and names the dates it priced", /targetLabel\(data\.date, ""\)/.test(app), true);
// A one-way fare is roughly half of what going somewhere costs, so which of
// the two this is has to sit on the line with the money.
t("and says which kind of trip that was",
  /data\.round_trip \? "Round trip " : "One way "/.test(app), true);
// A cached answer that cannot be parsed must refetch, not 500.
// Nothing else ever visits flight_cache, so the write path is the only place
// it can be swept. Without this, expired rows live for the life of the database
// -- and a key-format change strands every existing row at once, as the return
// date joining the key did.
t("the cache prunes its own expired rows",
  /DELETE FROM flight_cache WHERE expires_at <= \?/.test(core), true);
t("a corrupt cache row falls through to a refetch",
  /a corrupt row is not worth failing over/.test(core), true);

console.log("\nwhen the upstream refuses — the message has to survive the edge");
// Found the hard way on the live deployment. Cloudflare replaces a 5xx body
// from the origin with its OWN branded error page, so a 502 carrying SerpApi's
// explanation arrived as {"error_name":"origin_bad_gateway"} and the
// explanation was gone. A spent allowance, a rejected key and an unknown route
// are three different problems with three different fixes, and all three were
// indistinguishable. So an upstream refusal is reported the way too_far already
// is -- a 200 carrying a reason -- and 5xx is kept for OUR faults.
const fsBlock = core.slice(core.indexOf('segs[0] === "flightsearch"'),
  core.indexOf('segs[0] === "linkpeek"'));
t("the block was found", fsBlock.length > 500, true);
t("an upstream refusal carries a reason", /reason: "upstream"/.test(fsBlock), true);
t("an unreachable upstream too", /reason: "timeout"/.test(fsBlock), true);
t("a missing key too", /reason: "unconfigured"/.test(fsBlock), true);
// THE regression. Any 5xx here and the body is discarded at the edge.
t("nothing in this endpoint returns a 5xx", /err\([^;]*?, 5\d\d\)/.test(fsBlock), false);
t("the upstream's own words are passed through", /message: why/.test(fsBlock), true);
t("and logged where a tail can see them",
  /console\.log\("flightsearch upstream /.test(fsBlock), true);
// The search is already paid for by the time it is parsed; a bare 500 would
// hide both the cause and the fact that it cost something.
t("an answer in an unexpected shape says so", /reason: "unreadable"/.test(fsBlock), true);
t("and parsing is guarded", /try \{\s*payload = normalizeFlights/.test(fsBlock), true);
// A 200 can still carry an error: SerpApi reports a spent allowance this way.
t("a 200 with an error field is still a failure",
  /if \(raw && raw\.error\)/.test(fsBlock), true);

console.log("\nand the client tells the silences apart");
// "Nothing came back" for a spent allowance sends you looking at the route;
// for a rejected key it sends you looking at the date. Both are wrong.
t("a missing key does not read as 'no flights'", /why === "unconfigured"/.test(app), true);
t("an upstream message is shown verbatim when there is one",
  /said \|\| "The flight service could not answer\."/.test(app), true);
t("a past date says so", /why === "past"/.test(app), true);
t("and a genuine failure is marked, not whispered",
  /line\.classList\.add\("is-bad"\)/.test(app), true);
t("which has a style", /\.fl-empty\.is-bad/.test(fs.readFileSync("public/styles.css", "utf8")), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
