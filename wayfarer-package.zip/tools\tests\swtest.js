// Service worker: what it refuses to believe.
//
// Cloudflare Pages answers a request for a file it does not have with
// index.html and a 200. There is no 404 and no error. A <script> tag that
// receives HTML fails to parse silently, so the app simply never runs and the
// page sits at its bare shell -- indistinguishable from "the site is down".
//
// On 2026-08-23 trips.example.com served 10,608 bytes of index.html for
// app.9c199b7ac9.js during a deploy. install() then made it durable, because
// addAll() treats any 200 as a success, so the HTML was cached under the
// script's URL. The dashboard rendered a header and nothing else, with an
// empty console, until the bundle was re-fetched by hand.
//
// These tests pin the guard that stops a 200 from being trusted on status
// alone.
const fs = require("fs");
const sw = fs.readFileSync("public/sw.js", "utf8");

function grab(name) {
  const head = "function " + name + "(";
  const i = sw.indexOf(head);
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < sw.length; j++) {
    if (sw[j] === "{") { d++; seen = true; }
    else if (sw[j] === "}") { d--; if (seen && !d) return sw.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}

global.self = { location: { origin: "https://trips.example.com" } };
eval(grab("wrongType") + ";globalThis.wrongType=wrongType;");

const res = (ct) => ({ headers: { get: () => ct } });

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

console.log("\nHTML where code belongs");
// The exact response that broke the app.
t("index.html served as the app bundle is rejected",
  wrongType("/app.9c199b7ac9.js", res("text/html; charset=utf-8")), true);
t("and as a stylesheet",
  wrongType("/styles.0624c899a2.css", res("text/html")), true);
t("a full URL is handled too, not just a path",
  wrongType("https://trips.example.com/app.9c199b7ac9.js", res("text/html")), true);

console.log("\nwhat must still be allowed through");
t("real JavaScript", wrongType("/app.9c199b7ac9.js", res("application/javascript")), false);
t("real CSS", wrongType("/styles.0624c899a2.css", res("text/css")), false);
t("text/javascript, which some edges send",
  wrongType("/app.9c199b7ac9.js", res("text/javascript")), false);
// index.html IS html. Guarding it would break the offline shell entirely.
t("the shell itself is not suspect", wrongType("/index.html", res("text/html")), false);
t("nor a navigation to the root", wrongType("/", res("text/html")), false);
// The API is JSON, and an Access interstitial there is handled by api(), not here.
t("API responses are out of scope", wrongType("/api/v1/trips", res("text/html")), false);
t("images are out of scope", wrongType("/icon-192.png", res("text/html")), false);
// Absence is left alone deliberately: some proxies strip the header, and
// refusing on absence would break more than it fixes.
t("a missing content-type is not treated as failure",
  wrongType("/app.9c199b7ac9.js", { headers: { get: () => null } }), false);
t("a malformed URL does not throw",
  wrongType("::::not a url::::", res("text/html")), false);

console.log("\nevery path that could persist the bad response");
// Storing it is what turned a transient deploy race into a broken install.
t("save() refuses to store a wrong-typed response",
  /if \(wrongType\(req\.url, res\)\) return;/.test(sw), true);
// Serving it is what blanked the page in the first place.
t("networkFirst treats it as a failed request, not a success",
  /if \(wrongType\(req\.url, res\)\) \{ cacheOrRetry\(req, key\)\.then\(finish\); return; \}/.test(sw), true);
// addAll() accepts any 200, which is how the HTML became durable.
t("install no longer uses addAll for the core files",
  /c\.addAll\(CORE\)/.test(sw), false);
t("it checks each core file's type instead",
  /wrongType\(u, res\)\) throw new Error\("core " \+ u \+ " served as HTML"\)/.test(sw), true);
t("and a bad core file fails the install",
  /if \(!res\.ok\) throw new Error\("core " \+ u \+ " HTTP " \+ res\.status\);/.test(sw), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
