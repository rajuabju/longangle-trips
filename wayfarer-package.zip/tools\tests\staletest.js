// Cached data must not look like live data.
//
// The service worker serves a saved itinerary when the network is gone, which
// is the whole reason it exists. What it must not do is serve it silently: a
// gate number from four hours ago rendered identically to one from four
// seconds ago, and the moment that matters is the moment you cannot check.
//
// This is the same rule the loaders already follow — a request that FAILED must
// never look like an absence of data — applied to a request that was answered
// from a cupboard rather than from the network.
//
// Fixtures are invented.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");
const sw = fs.readFileSync("public/sw.js", "utf8");
const html = fs.readFileSync("public/index.html", "utf8");
const css = fs.readFileSync("public/styles.css", "utf8");

function grab(text, name, indent) {
  const i = text.indexOf(indent + "function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < text.length; j++) {
    if (text[j] === "{") { d++; seen = true; }
    else if (text[j] === "}") { d--; if (seen && !d) return text.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

// ---- the worker's half ------------------------------------------------------
console.log("\nthe worker labels what it took from the cache");
// A cached Response has immutable headers, so labelled() has to rebuild it.
// Reading the body to do that would buffer a whole itinerary in the worker;
// passing res.body through keeps it a stream.
t("the label is added by rebuilding, not mutating", /new Response\(res\.body,/.test(sw), true);
t("and says it was a cache hit", /h\.set\("X-SW-Cache", "hit"\)/.test(sw), true);
// The response's own Date header is when the copy was FETCHED. Stamping "now"
// instead would say the data is current at the moment you read it, which is
// precisely the lie being fixed.
t("the timestamp is when the copy was fetched, not when it was read",
  /h\.set\("X-SW-Cached-At", h\.get\("date"\)/.test(sw), true);
// A label is a nicety; the itinerary is not.
t("a failure to label never fails the request", /catch \(e\) \{[\s\S]{0,120}return res;/.test(sw), true);

// Both routes to the cache must label. The timeout path is the one that gets
// missed: the network accepted the connection and then went quiet, which is the
// common hotel-wifi shape and is just as stale as a hard failure.
t("the hard-failure path labels", /if \(hit\) return labelled\(hit\)/.test(sw), true);
t("and so does the timeout path", /if \(hit\) finish\(labelled\(hit\)\)/.test(sw), true);

// ---- the client's half ------------------------------------------------------
console.log("\nthe client reads the label");
const res = (headers) => ({ headers: { get: (k) => (headers[k] === undefined ? null : headers[k]) } });

// noteFreshness writes to a variable in its own closure, so it is lifted into a
// scope that supplies that variable and hands it back. paintOffline is stubbed:
// it only touches the DOM, and there is none here.
const makeHarness = () => eval(
  "(function(){ var lastCacheAt = null; var freshSeq = 0, freshSeen = 0; function paintOffline(){} " +
  grab(src, "noteFreshness", "  ") +
  " return { note: noteFreshness, get: function(){ return lastCacheAt; }," +
  "          seen: function(){ return freshSeen; } }; })()");
const harness = makeHarness();

harness.note(res({ "X-SW-Cache": "hit", "X-SW-Cached-At": "Tue, 19 Aug 2026 09:15:00 GMT" }));
t("a labelled response records when it was saved",
  harness.get() instanceof Date && harness.get().toISOString(), "2026-08-19T09:15:00.000Z");

harness.note(res({}));
t("an unlabelled response clears it", harness.get(), null);

// A hit with no usable date still has to raise the flag: the data IS stale, and
// saying so without a time beats saying nothing.
harness.note(res({ "X-SW-Cache": "hit", "X-SW-Cached-At": "" }));
t("a hit with no timestamp still counts as stale", harness.get() instanceof Date, true);
harness.note(res({}));
harness.note(res({ "X-SW-Cache": "hit", "X-SW-Cached-At": "not a date" }));
t("an unparseable timestamp still counts as stale", harness.get() instanceof Date, true);

// Anything other than a hit is live data.
harness.note(res({}));
harness.note(res({ "X-SW-Cache": "miss" }));
t("an explicit miss is not stale", harness.get(), null);

// Junk must not throw inside a request path.
t("no headers at all does not throw", (() => { try { harness.note({}); return "ok"; } catch (e) { return e.message; } })(), "ok");
t("no response at all does not throw", (() => { try { harness.note(null); return "ok"; } catch (e) { return e.message; } })(), "ok");

console.log("\nwired into the request path");
t("every API response is checked", /noteFreshness\(res, ticket\);/.test(src), true);
// Taken BEFORE the fetch, so the order is the order requests were ISSUED in
// rather than the order they came back in -- which is the entire point.
t("the ticket is taken before the request goes out",
  /var ticket = \+\+freshSeq;\s*\n\s*var res = await fetch\(API_BASE \+ path/.test(src), true);
t("and the counters live outside the function", /var freshSeq = 0, freshSeen = 0;/.test(src), true);

// Reproduced live and proved in both directions (2026-08-24):
//   /checkstate went out first and was made to answer CACHED after 1200ms,
//   while /trips and /categories -- issued later -- answered FRESH straight
//   away. The strip stayed hidden when the late cached answer landed.
//
//   The control matters as much as the test: with EVERY answer cached, so the
//   last to land is also the newest ticket, the same response raises
//   "Offline - showing what was saved on Aug 19 at 2:15 AM". The cached
//   response is therefore strip-worthy, and in the race it was suppressed
//   purely because its ticket was older -- not because it was ignored outright.
//
//   And mutation-tested: deleting the two guard lines fails exactly three
//   assertions here and nothing else in the suite.
// ---- U22: whichever answer is NEWEST wins, not whichever is LAST ------------
//
// noteFreshness runs on every response, and responses do not come back in the
// order they were sent. The app fires several at once -- loadAll, apiAll's
// pages, whichever panel is open -- so a CACHED answer to an early request can
// land after a FRESH answer to a later one. The strip then says "Offline" a
// moment after a successful refresh cleared it; and the other way round, a late
// fresh answer clears a strip that was telling the truth, which is worse: it
// presents stale data as current, at the moment you cannot check.
const HIT_AT = { "X-SW-Cache": "hit", "X-SW-Cached-At": "Tue, 19 Aug 2026 09:15:00 GMT" };

console.log("\na late answer to an early request cannot win");
{
  const h = makeHarness();
  // Request 2 was issued later and answered fresh: no strip.
  h.note(res({}), 2);
  t("the newer fresh answer clears it", h.get(), null);
  // Request 1 was issued FIRST and is only answering now, from the cache.
  h.note(res(HIT_AT), 1);
  t("the older cached answer is ignored", h.get(), null);
  t("and the watermark does not move backwards", h.seen(), 2);
}
{
  const h = makeHarness();
  // The dangerous direction: genuinely offline, and then a fresh-looking answer
  // to an OLDER request arrives and would have cleared the warning.
  h.note(res(HIT_AT), 5);
  t("a cached answer raises the strip", h.get() instanceof Date, true);
  h.note(res({}), 3);
  t("an older fresh answer cannot clear it", h.get() instanceof Date, true);
}
{
  const h = makeHarness();
  // A newer answer always wins, in both directions.
  h.note(res(HIT_AT), 1);
  h.note(res({}), 2);
  t("a newer fresh answer clears a cached one", h.get(), null);
  h.note(res(HIT_AT), 3);
  t("and a newer cached answer raises it again", h.get() instanceof Date, true);
}
{
  const h = makeHarness();
  // Ties pass: the newest ticket is the one that just answered, and no two
  // responses share a ticket anyway.
  h.note(res({}), 4);
  h.note(res(HIT_AT), 4);
  t("an equal ticket is allowed through", h.get() instanceof Date, true);
}
{
  const h = makeHarness();
  // A caller with no ticket is unaffected: the guard is skipped entirely rather
  // than treating "no ticket" as ticket zero and silently dropping the update.
  h.note(res(HIT_AT), 9);
  h.note(res({}));
  t("a ticketless call still applies", h.get(), null);
  t("and does not disturb the watermark", h.seen(), 9);
}
// navigator.onLine reports whether an interface is up, so a captive portal that
// routes nowhere reads as online. The worker's own answer is the honest signal.
//
// A regex assertion here used to claim navigator.onLine was not consulted. It
// never was, in any version, so the pattern matched nothing and proved nothing.
// What actually pins this is above: the flag is set from the X-SW-Cache header
// and cleared when it is absent, tested against real response objects.
t("regaining a connection re-reads rather than just hiding the strip",
  /addEventListener\("online"[\s\S]{0,80}loadAll\(\)/.test(src), true);
t("there is somewhere to show it", /id="offline-strip"/.test(html), true);
t("and it is hidden until there is something to say", /id="offline-strip"[^>]*hidden/.test(html), true);
// The trip detail is a fixed overlay at z-index 20. A strip nested inside the
// dashboard would disappear the moment you opened the itinerary you are trying
// to read with no signal -- the one screen this is for.
t("it lives outside the dashboard section",
  html.indexOf('id="offline-strip"') < html.indexOf('<main id="main">'), true);
t("and stacks above the overlay", /\.offline-strip \{[\s\S]{0,200}z-index:25/.test(css), true);

// ---- the iOS defect ---------------------------------------------------------
console.log("\nsafe areas actually apply");
// Four env(safe-area-inset-*) rules were already written. On iOS they resolve
// to 0 unless the viewport opts in, so all four did nothing — and the app runs
// fullscreen when installed, which is exactly when they matter.
t("the CSS asks for safe-area insets", /env\(safe-area-inset-/.test(css), true);
t("and the viewport lets them resolve", /viewport-fit=cover/.test(html), true);
t("the app still runs fullscreen when installed",
  /apple-mobile-web-app-capable" content="yes/.test(html), true);

console.log("\nthe rest of the polish");
t("the dashboard has a skeleton, not a sentence", /skel-card/.test(html), true);
t("its shapes are hidden from screen readers", /class="card-list" aria-hidden="true"/.test(html), true);
t("and a status line is announced instead", /class="sr-status" role="status"/.test(html), true);
// Focus fell to the browser default outline, which is near-invisible on Navy,
// Forest and Burnt.
t("keyboard focus is visible", /:focus-visible \{[\s\S]{0,80}outline:2px solid var\(--accent\)/.test(css), true);
t("and it degrades where color-mix is missing", /@supports not \(color: color-mix/.test(css), true);
// Covers are deferred because 182 trips in card view is 182 photo requests.
t("card covers load near the viewport", /coverWatcher\.observe\(node\)/.test(src), true);
t("with a fallback where IntersectionObserver is missing",
  /if \(!\("IntersectionObserver" in window\)\)/.test(src), true);
// The day pips only ever lit on click.
t("the day strip follows the scroll", /dayWatcher = new IntersectionObserver/.test(src), true);
t("and only one observer is ever live", /if \(dayWatcher\) \{ dayWatcher\.disconnect\(\); dayWatcher = null; \}/.test(src), true);
// A day key goes into a CSS selector; unescaped it is an injection point and a
// syntax error waiting for the first odd key.
t("day keys are escaped into the selector", /CSS\.escape\(k\)/.test(src), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
