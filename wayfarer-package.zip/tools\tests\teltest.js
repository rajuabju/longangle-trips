// telHref must emit a dialable URI, not a bare number.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");
function grab(n) {
  const i = src.indexOf("  function " + n + "(");
  if (i < 0) throw new Error("missing " + n);
  let d = 0, s = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; s = true; } else if (src[j] === "}") { d--; if (s && !d) return src.slice(i, j + 1); }
  }
}
const oneLine = (name) => {
  const i = src.indexOf("  var " + name);
  return src.slice(i, src.indexOf(";\n", i) + 1);
};
eval(oneLine("PHONE_EXT") + "\n" + oneLine("CC") + "\n" +
  ["leadingCC", "telNumber", "telHref"].map(grab).join("\n") +
  ";Object.assign(globalThis,{telHref,telNumber});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const ok = got === want;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + JSON.stringify(want) + "\n        got  " + JSON.stringify(got));
};

// The regression: a href with no scheme is a relative path, not a phone call.
t("US number carries the tel: scheme", telHref("1-800-252-7522"), "tel:+18002527522");
t("Costa Rica number carries the scheme", telHref("506-2479-1600"), "tel:+50624791600");
t("already-E.164 input", telHref("+1 844 865 2002"), "tel:+18448652002");
t("10-digit US with parens", telHref("(310) 968-3144"), "tel:+13109683144");
t("extension is preserved", telHref("1-800-252-7522 ext. 42"), "tel:+18002527522;ext=42");
t("empty input yields no href at all", telHref(""), "");
t("null input yields no href", telHref(null), "");
t("a value with no digits yields no href", telHref("call the desk"), "");

// Nothing may ever start with a bare + again.
["1-800-252-7522", "506-2479-1600", "+44 20 7946 0000", "(310) 968-3144"].forEach((n) => {
  const h = telHref(n);
  t("href for " + n + " starts with tel:", h.slice(0, 4), "tel:");
});

// telNumber remains the bare form for anything that needs it.
t("telNumber stays scheme-less", telNumber("1-800-252-7522"), "+18002527522");

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
