# Setting up Wayfarer

A self-hosted travel itinerary that runs entirely on your own Cloudflare
account. You own the data; nothing is shared with anyone, including whoever
gave you this package.

**Time to a working install: about an hour.** Most of it is waiting for DNS.

Everything in Part 1 is required. **Everything in Part 2 is optional** — the
app is fully usable without a single API key, because the services it leans on
hardest (maps, geocoding, routing, weather, holidays) are free and need no
account at all.

---

## What you are signing up for

| | Cost | Needed? |
|---|---|---|
| Cloudflare account | Free | **Yes** |
| Cloudflare Pages, D1, R2 | Free tier is ample | **Yes** |
| Cloudflare Zero Trust (Access) | Free up to 50 users | **Yes** — this is the only thing standing between your itinerary and the open internet |
| A domain name | ~$10/year, or use the free `*.pages.dev` | Optional |
| Node.js 20+ | Free | **Yes**, to deploy |
| Google Maps Platform | Free credit, then pay-as-you-go | Optional |
| SerpApi | 250 searches/month free | Optional |
| FlightAware AeroAPI | Paid, ~$0.01/query | Optional |
| Plaid | Free for 10 accounts, needs approval | Optional |
| Claude Code + email connectors | Claude subscription | Optional, advanced |

**R2 note:** enabling R2 asks for a payment card even though the free tier
(10 GB) is far more than this app needs. If you would rather not, skip it —
you lose only file attachments on trips.

---

# Part 1 — the required half

## 1. Install the tools

```bash
node --version      # need 20 or newer
npm install
npm install -g wrangler
wrangler login
```

`wrangler login` opens a browser and authorises the CLI against your
Cloudflare account. **Use OAuth login, not an API token** — token permissions
are fiddly and several commands below need broader scopes than a token
typically carries.

## 2. Create the database

```bash
wrangler d1 create wayfarer-data
```

It prints a `database_id`. **Copy it.** Open `wrangler.toml` and replace
`YOUR_D1_DATABASE_ID` with it — there is one occurrence in the root file and
one in each of `workers/inbox/wrangler.toml` and
`workers/flight-status/wrangler.toml` if you use those later.

Then create the tables:

```bash
wrangler d1 execute wayfarer-data --remote --file=schema.sql
```

You should see a run of `success` lines. `schema.sql` is safe to re-run — every
statement is `IF NOT EXISTS`.

## 3. Create the file store *(skip if you declined R2)*

```bash
wrangler r2 bucket create wayfarer-docs
```

The bucket stays **private**. Documents are served through
`/api/v1/doc` behind your login, never from a public R2 URL, so an attachment
is exactly as protected as the trip it belongs to.

## 4. Create the Pages project and deploy once

```bash
npm run build
wrangler pages deploy public --project-name wayfarer
```

This prints a URL like `https://wayfarer.pages.dev`. **It is unauthenticated
right now** — anyone with the URL can read everything. Step 5 fixes that, and
you should not add real data until it is done.

## 5. Put a lock on it — Cloudflare Access

This is the security model. There is no password in this app; Cloudflare
decides who gets through before a request ever reaches your data.

1. In the Cloudflare dashboard, open **Zero Trust**. First visit asks you to
   pick a **team name** — you get `your-team.cloudflareaccess.com`. Write it
   down.
2. **Settings → Authentication → Login methods.** Add at least one. **One-time
   PIN** needs no configuration and emails a code; Google or GitHub are nicer
   day to day.
3. **Access → Applications → Add an application → Self-hosted.**
   - Application name: `Wayfarer`
   - Session duration: 1 month is comfortable
   - Public hostname: your domain (Part 1.6) or `wayfarer.pages.dev`
4. Add a policy: **Action: Allow**, rule **Emails** → your email address. Add
   anyone else who should see your trips.
5. Open the application's **Overview** tab and copy the **Application Audience
   (AUD) tag** — a long hex string.

Now edit `wrangler.toml`:

```toml
[vars]
ACCESS_TEAM_DOMAIN = "your-team.cloudflareaccess.com"
ACCESS_AUD = "the-long-hex-string-you-just-copied"
```

**Both values are checked on every request.** The AUD is what stops a token
Cloudflare issued for a *different* application on your team being replayed
against this one — signature checking alone would accept all of them.

> **If you ever delete and recreate the Access application it gets a new AUD.**
> Update it here or every request fails closed. That is the correct failure
> direction, but it looks like a total outage, so remember this paragraph.

## 6. Point a domain at it *(optional but recommended)*

`*.pages.dev` works, but Access is easier to reason about on your own name.

1. Add your domain to Cloudflare (dashboard → **Add a site**), and change your
   registrar's nameservers to the two Cloudflare gives you. **DNS propagation
   is the slow part — up to a few hours.**
2. **Workers & Pages → your project → Custom domains → Set up a custom
   domain.** Use something like `trips.yourdomain.com`.
3. Go back to your Access application and make sure its hostname matches.

> **The `*.pages.dev` address stays live and is NOT covered by a custom-domain
> Access policy.** Either add a second Access application for it, or accept
> that it is a public back door and never let it be indexed. Do not assume the
> custom domain protects both.

## 7. Set the two required secrets

```bash
wrangler pages secret put IMPORTER_KEY --project-name wayfarer
wrangler pages secret put CAL_TOKEN --project-name wayfarer
```

Each prompts for a value. Generate long random strings:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

- **`IMPORTER_KEY`** authenticates machine callers at `/api/ingest/*`, which
  bypass Access. Anyone holding it has admin-level write access to your data.
  Treat it like a password.
- **`CAL_TOKEN`** signs the calendar-feed URL. **That URL is a bearer
  credential**: anyone with the link reads your whole itinerary, because
  calendar apps cannot log in. Never commit it, never paste it in a shared
  document.

> **Adding a NEW secret name does not reach an already-running deployment.**
> Changing an existing secret's *value* is instant, but a new name needs a
> redeploy before the code can see it. This costs everyone an hour of
> confusion exactly once.

## 8. Configure the app for you

Four values, all marked `CONFIGURE ME` in the source:

| Where | What |
|---|---|
| `public/app.js` → `HOME` | Your home coordinates. Right-click a point in Google Maps to copy exact lat/lng. |
| `functions/api/_core.js` → `HOME` | **The same coordinates.** Note this one says `lon`, the client says `lng`. A test asserts they agree. |
| `public/app.js` → `PACK_WHO` | Who a packing item can be assigned to. |
| `public/app.js` → `KNOWN_PLACES` | Optional. A cabin or second home you visit repeatedly with no booking. |

`HOME` matters more than it looks: it decides whether a destination is "near
enough to drive", which suppresses the airport field and draws a road instead
of a lone map pin. **Geocode the building, not the city** — a mile of error is
the difference between a useful drive time and a decorative one.

> **The shipped test suite asserts drive distances from the default home**
> (Los Angeles City Hall). After you change `HOME`, three assertions in
> `tools/tests/domtest.js`, `ideatest.js` and `transfertest.js` will fail
> because the fixture cities are no longer the right distance away. Update
> those numbers or delete those assertions — nothing in the app is broken.

## 9. Make yourself an admin

Access decides *who may enter*; a `users` row decides *what they may do*.
Anyone not listed gets read-only.

`schema.sql` already seeded one admin, `you@example.com`, so the table is never
empty on a fresh deploy — an empty table would mean no admins and no way to
appoint one through the app. **Point it at yourself:**

```bash
wrangler d1 execute wayfarer-data --remote \
  --command "UPDATE users SET email='real@address.com', name='Your Name' WHERE email='you@example.com';"
```

Use the **exact address, lowercased**, that you log in to Access with. Do not
`INSERT` a second row — the placeholder is already there, and adding beside it
leaves a stale admin behind.

Add anyone else later from **Settings → People** in the app, or with another
`INSERT`. Roles are `admin` (can change things) and `view` (read-only, and the
default for anyone Access lets in who is not listed here).

## 10. Load the demo data, then deploy

```bash
wrangler d1 execute wayfarer-data --remote --file=demo-seed.sql
npm run build
wrangler pages deploy public --project-name wayfarer
```

Open your site. You should be sent to a Cloudflare login, and after signing in
see four demo trips. Click into **Lisbon** — the itinerary, map, weather and
Budget should all render.

**That is a working install.** When you are ready:

```bash
wrangler d1 execute wayfarer-data --remote \
  --command "DELETE FROM trips WHERE id BETWEEN 9000001 AND 9000099;"
```

## 11. Put it on your phone

Open the site in Safari or Chrome on your phone and **Add to Home Screen**. It
installs as a standalone app with offline caching.

> On iOS the home-screen icon is fetched **without your login cookie**, so an
> icon hosted on the Access-protected domain comes back as a redirect and the
> icon renders blank. The manifest points at the `*.pages.dev` copy for exactly
> this reason. If you change hostnames and your icon disappears, this is why.

---

# Part 2 — optional services

Everything above works with none of these. Add them when you want the feature.

## What already works, free, with no account

You do not sign up for any of these, and there is nothing to configure. Be a
good citizen: they are volunteer-run and this app caches aggressively.

| Service | Used for |
|---|---|
| **Nominatim** (OpenStreetMap) | Turning addresses into coordinates |
| **OSRM** + **openstreetmap.de** | Drive times and routes |
| **Open-Meteo** | Forecast, and 5-year historical averages for trips beyond the ~16-day forecast |
| **Nager.Date** | National public holidays at your destination |
| **Frankfurter / ECB** | Currency conversion in the Budget |
| **Wikimedia Commons** | Trip cover images |
| **OurAirports** | Airport names and coordinates (bundled, not called) |

## Google Maps — nicer maps and better routes

Two **separate** keys, and mixing them up is the usual failure.

1. [Google Cloud Console](https://console.cloud.google.com/) → create a project
2. **APIs & Services → Enable APIs**: enable **Maps JavaScript API** and
   **Routes API**
3. Create two keys under **Credentials**:

| Key | Restriction | Secret name |
|---|---|---|
| Browser key | *HTTP referrers* → your domain | `MAPS_BROWSER_KEY` |
| Server key | *API restrictions* → Routes API only | `MAPS_SERVER_KEY` |

```bash
wrangler pages secret put MAPS_BROWSER_KEY --project-name wayfarer
wrangler pages secret put MAPS_SERVER_KEY --project-name wayfarer
```

The browser key is **sent to the client** — that is what a Maps JavaScript key
is for, and it is protected by the referrer restriction, not by secrecy. The
server key never leaves the Worker. **Do not use one key for both:** a
referrer-restricted key cannot be used server-side, and an unrestricted browser
key is a key anyone can lift from your page and spend your credit on.

Billing must be enabled, and Google gives a monthly free allowance that a
personal itinerary will not exhaust. **Set a budget alert anyway.**

*Without these keys:* maps still render and routing still works, via
OpenStreetMap. Geocoding stays on Nominatim regardless — Google's terms cap
how long you may store coordinates, and this app stores them permanently.

## SerpApi — flight ideas in the planner

Free tier is **250 searches/month**.

1. Sign up at [serpapi.com](https://serpapi.com/), copy the key from your dashboard
2. `wrangler pages secret put SERPAPI_KEY --project-name wayfarer`

*Without it:* the planner's "what would it cost to fly there" lookup is
unavailable. Everything else is unaffected.

## FlightAware AeroAPI — live flight status

Paid, roughly a cent per query, with a monthly cap you set yourself.

1. Register at [flightaware.com/aeroapi](https://flightaware.com/aeroapi/)
2. Deploy the worker:

```bash
cd workers/flight-status
# edit wrangler.toml: database_id, and API_BASE -> https://YOUR-DOMAIN/api/ingest/v1
wrangler secret put AEROAPI_KEY
wrangler secret put IMPORTER_KEY      # the same value as the Pages secret
wrangler deploy
```

It runs every 10 minutes and stops at `AEROAPI_MONTHLY_CAP` queries (default
400) so a stuck loop cannot run up a bill.

*Without it:* flights show scheduled times. A deep link to Flightradar24 is
built from the flight number and needs no key at all.

## Plaid — credit-card spend thresholds

Only worth it if you chase annual-spend rewards. **Plan for delay:** Plaid's
production access needs an application and is reviewed over days, and the free
tier covers **10 accounts total** — one bank login can consume several.

1. Sign up at [plaid.com](https://plaid.com/), request **Production** access
2. Set the shared credentials:

```bash
wrangler pages secret put PLAID_CLIENT_ID --project-name wayfarer
wrangler pages secret put PLAID_SECRET --project-name wayfarer
wrangler pages secret put PLAID_ENV --project-name wayfarer     # "production"
```

3. Create a local `.dev.vars` (gitignored) with the same three values, then
   link a bank:

```bash
node tools/plaid-connect.js start amex     # prints a URL; sign in at your bank
node tools/plaid-connect.js finish amex    # saves a token to .dev.vars
wrangler pages secret put PLAID_AMEX_ACCESS_TOKEN --project-name wayfarer
npm run build && wrangler pages deploy public --project-name wayfarer
```

4. Add rows to `card_items`, `card_accounts` and `card_goals`. The comments in
   `schema.sql` describe each column.

> **`card_items` stores the NAME of the secret, never the token.** A stored
> bank token would be copied into every SQL backup you ever take.

> **Reconcile before you trust a total.** Run
> `node tools/plaid-spend.js <bank>` and compare against your bank's own
> year-to-date figure. The classifier's patterns were written against one
> bank's wording, and a description it does not recognise falls through to
> "refund" — which *subtracts*. A payment misread as a refund understates a
> year badly. The tool prints exactly what it treated as a refund so you can
> check.

## Email import — forward a confirmation, get a trip

Deploy the inbox worker and point Cloudflare Email Routing at it.

```bash
cd workers/inbox
# edit wrangler.toml: database_id and bucket_name
wrangler deploy
```

Then **Cloudflare dashboard → your domain → Email → Email Routing**, enable it,
and route an address such as `trips@yourdomain.com` to the `wayfarer-inbox`
worker. Forwarded mail lands in D1 and R2 for the importer to parse.

> **Enabling Email Routing overwrites your domain's SPF record.** If you send
> mail from that domain through another provider, unlock the record afterwards
> and merge both into ONE SPF entry naming both senders. Two SPF records is the
> same as none.

## The importer — automatic parsing *(advanced)*

**This is the one piece that is not turnkey**, and you should treat it as a
starting point rather than a feature.

It is a [Claude Code](https://claude.com/claude-code) scheduled task: a long
`SKILL.md` describing how to read booking confirmations and POST them to
`/api/ingest/v1`. It is not shipped in this package, because it is written
around one person's mailbox and habits.

You would need:

- A Claude subscription and Claude Code installed
- An **MCP email connector** for your mail — Gmail and Microsoft 365 Outlook
  both work; authorise them in your Claude connector settings
- A scheduled task pointed at a folder holding the skill
- Your `IMPORTER_KEY`, so the task can write via `/api/ingest/v1`

Two things worth knowing before you invest in it:

- **Outlook's connector returns extracted text, never bytes** — you cannot
  upload a PDF attachment through it.
- **Gmail search fails when called in parallel.** Issue searches one at a time.

If you would rather not, everything can be entered by hand — and the app is
designed for that, since costs and many details are typed in regardless.

## The calendar feed

Settings → Calendar gives a URL to subscribe to from Apple Calendar, Google
Calendar or Outlook. It needs `CAL_TOKEN` set (Part 1.7).

**That URL is a password.** Calendar apps cannot log in, so the token in the
link is the only thing protecting it. Anyone you send it to can read your
entire itinerary, forever, until you rotate `CAL_TOKEN`.

---

# Keeping it running

## Updating

```bash
npm run build
wrangler pages deploy public --project-name wayfarer
npm test                    # 71 suites; see the HOME caveat in Part 1.8
```

## Backing up

D1 has **Time Travel** — any point in the last 7 days, whole-database:

```bash
wrangler d1 time-travel info wayfarer-data
wrangler d1 time-travel restore wayfarer-data --bookmark=<id>
```

For anything older, or to restore a single table, export to a file on a
schedule and keep it somewhere safe:

```bash
wrangler d1 export wayfarer-data --remote --output=backup-$(date +%F).sql
```

> `d1 export` is the one command that wants a `CLOUDFLARE_API_TOKEN` set,
> unlike deploys which want OAuth. If it fails with error 10000, that is why.

## When something looks wrong

| Symptom | Cause |
|---|---|
| Every request 401s or redirects forever | `ACCESS_AUD` no longer matches the application. Recreated apps get a new AUD. |
| A new secret has no effect | New secret *names* need a redeploy. Changed *values* do not. |
| Blank page after deploy | Pages serves your `index.html` for a missing asset, so a stale bundle reference returns HTML with a 200. Check the response's content-type, not just its status. |
| Data looks stale after a write | The dashboard caches its payload. Re-check with a cache-busting query string before concluding anything. |
| Changes not showing on your phone | The service worker holds the old bundle. Pull to refresh, or close and reopen the app. |

## Where things live

| Path | What |
|---|---|
| `public/` | The client. Vanilla JS, one file, no framework. |
| `functions/api/` | The API, on Cloudflare Pages Functions. |
| `functions/api/ext/` | Proxies to the free external services, with caching. |
| `schema.sql` | Every table, with the reasoning in comments. |
| `tools/tests/` | 71 suites. Run them before you deploy a change. |
| `workers/` | The two optional workers: email inbox, flight status. |

The source comments are unusually long on purpose: they record *why* a thing is
the way it is, usually because the obvious alternative was tried and was wrong.
Read them before changing something that looks over-complicated.

---

## A word on what you are responsible for

This runs on your account, holds your travel history, and has no vendor behind
it. **Cloudflare Access is the only thing between your itinerary and the
internet** — get Part 1.5 right, verify you are actually challenged for login
from a private browser window, and remember the `*.pages.dev` address is a
separate door.

The calendar feed URL and the `IMPORTER_KEY` are both bearer credentials.
Anyone holding either has your data.
