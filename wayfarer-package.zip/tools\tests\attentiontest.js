// U15 -- the phone's "More" chip says whether anything behind it wants you.
//
// Five features collapse behind one unmarked chip on a phone: History, Check
// Trips, Changes, Calendar, Trip Ideas. Two of them can genuinely want
// something, and behind an unmarked chip the only way to learn that is to go
// and look. On the device where the app is actually used, those two features
// were effectively switched off.
//
// The badge is deliberately a claim about the PAST. Both counts come from
// sweeps that read every item on every upcoming trip -- the traffic P1 and P2
// removed -- so nothing runs one to draw a badge. It shows what the last sweep
// found, the tooltip says "as of when you last looked", and opening the panel
// re-runs the real thing and corrects it.
//
// Run for real against a localStorage stub, because the two rules worth having
// -- expiry, and what a partial sweep may clear -- are behaviour, not shape.
// Verified live at 375x812 (2026-08-24):
//   2 + 1 planted -> chip reads "⋯ More" with a red 3, tooltip "2 to fix in
//     Check Trips · 1 to review in Changes — as of when you last looked",
//     aria-label carrying the same words, badge inside the chip, no h-scroll
//   store emptied  -> no badge, plain tooltip back, chip 116px -> 88px
//   20-day-old 6   -> stored, but no badge; expiry works end to end
//
// The first browser run found the bug the whole static suite had passed: the
// three `var`s lived beside the functions that use them, several thousand lines
// BELOW the toolbar that reads them at load. A var hoists its declaration and
// not its value, so the tooltip rendered as the literal string "undefined" and
// readAttention called getItem(undefined). They now sit with the other keys at
// the top of the file.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");
const css = fs.readFileSync("public/styles.css", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

// Lift the real source rather than reimplementing it; a copy drifts and then
// the test passes against its own idea of the code.
function lift(decl) {
  const start = app.indexOf(decl);
  if (start < 0) throw new Error("not found: " + decl);
  let depth = 0, i = app.indexOf("{", start);
  for (; i < app.length; i++) {
    if (app[i] === "{") depth++;
    else if (app[i] === "}") { depth--; if (!depth) break; }
  }
  return app.slice(start, i + 1);
}

const DAY = 86400000;
const KEY = "wayfarer_attention_v1";

function harness() {
  const store = {};
  const localStorage = {
    getItem: (k) => (k in store ? store[k] : null),
    setItem: (k, v) => { store[k] = String(v); },
  };
  const drew = [];
  const src = [
    'var ATTN_KEY = "' + KEY + '", ATTN_MAX_DAYS = 14;',
    lift("function readAttention()"),
    lift("function noteAttention(which, n, complete)"),
    "function drawMoreBadge() { drew.push(1); }",
  ].join("\n");
  const api = new Function("localStorage", "drew",
    src + "\nreturn { readAttention: readAttention, noteAttention: noteAttention };")(localStorage, drew);
  return { readAttention: api.readAttention, noteAttention: api.noteAttention, store, drew };
}

console.log("\na sweep records what it found");
{
  const h = harness();
  h.noteAttention("check", 3, true);
  t("the count is kept", h.readAttention().check.n, 3);
  t("with a timestamp", typeof h.readAttention().check.at, "number");
  t("and the chip is redrawn", h.drew.length, 1);
  h.noteAttention("changes", 2, true);
  t("the two sweeps do not overwrite each other",
    [h.readAttention().check.n, h.readAttention().changes.n], [3, 2]);
}

console.log("\nfinding nothing clears it -- if the sweep actually finished");
{
  const h = harness();
  h.noteAttention("check", 3, true);
  h.noteAttention("check", 0, true);
  t("a complete sweep of zero clears the badge", h.readAttention().check, undefined);
}
{
  // The one that matters. A sweep that could not read every trip has NOT
  // established that there is nothing, so letting it clear the badge means a
  // single failed request silently marks everything as handled.
  const h = harness();
  h.noteAttention("check", 3, true);
  h.noteAttention("check", 0, false);
  t("a partial sweep of zero does not", h.readAttention().check.n, 3);
  t("and it still redraws, so nothing looks stuck", h.drew.length, 2);
}
{
  // A partial sweep that FOUND something is news, and is believed.
  const h = harness();
  h.noteAttention("check", 1, true);
  h.noteAttention("check", 4, false);
  t("a partial sweep that found more is believed", h.readAttention().check.n, 4);
}
{
  const h = harness();
  h.noteAttention("check", 0, false);
  t("a partial zero on an empty store stays empty", h.readAttention().check, undefined);
}

console.log("\nold counts expire rather than lingering");
{
  const h = harness();
  h.store[KEY] = JSON.stringify({
    check:   { n: 5, at: Date.now() - 13 * DAY },
    changes: { n: 7, at: Date.now() - 15 * DAY },
  });
  const a = h.readAttention();
  t("thirteen days old still counts", a.check.n, 5);
  // A month-old count describes a trip you have already taken.
  t("fifteen days old does not", a.changes, undefined);
}

console.log("\na broken store is no badge, not an error");
{
  const h = harness();
  h.store[KEY] = "{not json";
  t("unparseable reads as empty", h.readAttention(), {});
  h.store[KEY] = JSON.stringify({ check: { n: "lots", at: Date.now() } });
  t("a non-numeric count is ignored", h.readAttention().check, undefined);
  h.store[KEY] = JSON.stringify({ check: { n: 2 } });
  t("one with no timestamp cannot be aged, so it is dropped", h.readAttention().check, undefined);
  h.store[KEY] = JSON.stringify({ check: null });
  t("a null entry does not throw", h.readAttention(), {});
  h.store[KEY] = JSON.stringify({ check: { n: 0, at: Date.now() } });
  t("a stored zero is not a badge", h.readAttention().check, undefined);
}
{
  // Private browsing throws on setItem. A badge is not worth an exception that
  // aborts the sweep drawing it.
  const throwing = { getItem: () => null, setItem: () => { throw new Error("quota"); } };
  const src = ['var ATTN_KEY = "k", ATTN_MAX_DAYS = 14;', lift("function readAttention()"),
               lift("function noteAttention(which, n, complete)"),
               "function drawMoreBadge() {}"].join("\n");
  const f = new Function("localStorage", src + "\nreturn noteAttention;")(throwing);
  let threw = false;
  try { f("check", 3, true); } catch (e) { threw = true; }
  t("a store that refuses to write does not throw", threw, false);
}

console.log("\nonly things to FIX light it");
// A warn is "worth a look". Badging those would light the chip permanently,
// which is indistinguishable from the chip having no badge at all.
t("Check Trips reports its issues, not its warnings",
  /noteAttention\("check", totals\.issue, !unread\.length\);/.test(app), true);
t("Changes reports the rows still to review",
  /noteAttention\("changes", rows\.length, !unread\.length\);/.test(app), true);
// The empty exit is what actually clears the badge once you acknowledge them.
t("and reports zero when there are none",
  /noteAttention\("changes", 0, !unread\.length\);/.test(app), true);

console.log("\nthe chip itself");
t("it is held for the sweeps to update", /moreChip = more;/.test(app), true);
t("and drawn as soon as it exists", /moreChip = more;\s*\n\s*drawMoreBadge\(\);/.test(app), true);
t("nothing waiting means no badge at all",
  /if \(!n\) \{ if \(dot\) dot\.remove\(\); moreChip\.title = MORE_TITLE; return; \}/.test(app), true);
t("past nine it stops counting", /dot\.textContent = n > 9 \? "9\+" : String\(n\);/.test(app), true);
// "More, 3" tells a screen reader a number with no subject.
t("the chip says what the number is about", /moreChip\.setAttribute\("aria-label", "More/.test(app), true);
t("and the tooltip dates the claim", /as of when you last looked/.test(app), true);

console.log("\nthe badge is styled as a count, not a decoration");
t("it uses the danger colour", /\.chip-badge \{[^}]*background:var\(--danger\)/.test(css), true);
// NOT #fff. Measured white on --danger across all nine themes: the six light
// ones clear 5.8:1, but dark, forest and tangerine set --danger to a bright
// coral because there it is TEXT on a dark ground -- as a ground for white it
// gave 2.55, 2.79 and 2.79. Each theme's own --bg is the one colour guaranteed
// to contrast with that theme's foregrounds, so the single rule is light on the
// light themes and near-black on the dark ones. Re-measured, worst is desert at
// 4.75:1 and the best is forest at 7.85. The rule also corrects itself for any
// theme added later, which a hardcoded #fff cannot.
t("with the theme's own background as the text", /background:var\(--danger\); color:var\(--bg\);/.test(css), true);
t("and no hardcoded white to go stale", /\.chip-badge \{[^}]*color:#fff/.test(css), false);
// Measured 21x21 for every single digit and 25x21 for "9+" -- two characters
// are wider, which is what a pill is for. What must not happen is the toolbar
// reflowing: at 375x812 it stayed at three rows and the chip grew four pixels,
// with no horizontal scroll.
t("single digits share one width", /min-width:1\.55em/.test(css), true);
t("digits line up", /font-variant-numeric:tabular-nums/.test(css), true);
// Everything here scales with --fs; a px badge stops matching the chip it sits
// on the moment the system text size moves.
// U24 re-expressed every sized thing in rem via --px, so this now reads
// 11 * var(--px) * var(--fs) -- the app's own preference AND the reader's
// browser or OS text size, multiplied together.
t("it scales with the app text size", /font-size:calc\(11 \* var\(--px\) \* var\(--fs\)\)/.test(css), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
