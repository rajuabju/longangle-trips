#!/usr/bin/env node
// Backfill `terms` from the prose already sitting in each item's `notes`.
//
// Fifteen years of confirmations were imported before `terms` existed, so the
// cancellation deadlines, phone numbers and deposits are all there — as prose,
// unreadable to the dossier. This lifts the parts that can be recognised
// without guessing.
//
// The governing rule is the importer's: an assumed deadline is worse than none,
// because the dossier sorts by it and presents it as fact. So every pattern
// here demands an explicit, unambiguous date, and anything it cannot resolve
// confidently is reported as a skip rather than written as an approximation.
//
// Upcoming trips only. A cancellation deadline on a trip that already happened
// is noise, and past trips are deliberately left alone everywhere else too.
//
//   node tools/backfill-terms.js                 # dry run, prints what it found
//   node tools/backfill-terms.js --apply         # writes
//   node tools/backfill-terms.js --base=http://127.0.0.1:8788
const args = process.argv.slice(2);
const APPLY = args.includes("--apply");
const BASE = (args.find((a) => a.startsWith("--base=")) || "--base=http://127.0.0.1:8788").split("=")[1];

const MONTHS = { jan:0,feb:1,mar:2,apr:3,may:4,jun:5,jul:6,aug:7,sep:8,oct:9,nov:10,dec:11 };

// "Jan-08-2027", "8 January 2027", "January 8, 2027", "2027-01-08".
function parseDate(s) {
  let m = s.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
  if (m) return { y: +m[1], mo: +m[2] - 1, d: +m[3] };
  m = s.match(/\b([A-Za-z]{3,9})[-\s.]+(\d{1,2})(?:st|nd|rd|th)?[,\s-]+(\d{4})\b/);
  if (m && MONTHS[m[1].slice(0, 3).toLowerCase()] !== undefined)
    return { y: +m[3], mo: MONTHS[m[1].slice(0, 3).toLowerCase()], d: +m[2] };
  m = s.match(/\b(\d{1,2})(?:st|nd|rd|th)?[\s-]+([A-Za-z]{3,9})[,\s-]+(\d{4})\b/);
  if (m && MONTHS[m[2].slice(0, 3).toLowerCase()] !== undefined)
    return { y: +m[3], mo: MONTHS[m[2].slice(0, 3).toLowerCase()], d: +m[1] };
  return null;
}
// "11:59 p.m.", "11:59pm", "3:00 PM", "23:59". Defaults to end of day, which is
// what a cancellation deadline means when a confirmation states only a date.
function parseTime(s) {
  let m = s.match(/\b(\d{1,2}):(\d{2})\s*([ap])\.?m\.?/i);
  if (m) {
    let h = +m[1] % 12;
    if (m[3].toLowerCase() === "p") h += 12;
    return { h, mi: +m[2] };
  }
  m = s.match(/\b(\d{1,2}):(\d{2})\b/);
  if (m && +m[1] <= 23) return { h: +m[1], mi: +m[2] };
  return { h: 23, mi: 59 };
}
// Build an ISO instant from a wall-clock date and time in the item's own zone.
// Without this a Costa Rican 11:59pm deadline would be stored as if it were UTC
// and shown six hours early — which for a cancellation deadline is the
// difference between free and one night plus tax.
function isoInstant(tz, dt, tm) {
  const guess = new Date(Date.UTC(dt.y, dt.mo, dt.d, tm.h, tm.mi));
  let offMin = 0;
  try {
    const f = new Intl.DateTimeFormat("en-US", { timeZone: tz || "UTC", timeZoneName: "longOffset" });
    const p = f.formatToParts(guess).find((x) => x.type === "timeZoneName");
    const m = p && p.value.match(/GMT([+-])(\d{1,2}):?(\d{2})?/);
    if (m) offMin = (m[1] === "-" ? -1 : 1) * (+m[2] * 60 + (+m[3] || 0));
  } catch { /* leave at UTC */ }
  return new Date(guess.getTime() - offMin * 60000).toISOString();
}

// Only sentences that actually state a deadline.
//
// The first draft of this matched any sentence containing "cancel" plus any
// date, and three of its four hits were wrong: two took a date out of generic
// boilerplate ("Refundable: Yes Cancellation Penalty Window: ..."), and one read
// "France cancelled AF1125 on 2026-01-15" — a flight the airline cancelled — as
// a deadline to plan around. A wrong deadline is the single worst thing this
// tool can produce, so the rules below are deliberately narrow and will miss
// real deadlines rather than invent any.
const CANCEL_RE = /([^.\n]*\b(?:cancel|cancellation|refund)[^.\n]*)/gi;
// The date must be introduced by a word that makes it a cut-off, and that word
// must sit just before it — not merely somewhere in the same sentence.
const DEADLINE_LEAD = /\b(?:until|by|before|up to|no later than|through)\b[^.\n]{0,24}$/i;
// Past tense describes something that already happened to the booking, not a
// rule about the future.
const HAPPENED = /\b(?:was|were|has been|have been|is|are)\s+cancell?ed\b|\bcancell?ed\s+(?:by|on|due)\b|\b[A-Z][a-z]+\s+cancell?ed\b/;

function findCancel(raw, tz) {
  // Sentences are split on the full stop, so "11:59 p.m." splits itself in two
  // and strands the date in a fragment with no deadline word in front of it.
  // That silently dropped the Waldorf's real 8 Jan deadline. Normalise the
  // abbreviations first; they are the only full stops that are not sentence
  // ends in this material.
  const notes = String(raw)
    .replace(/\b([ap])\.\s*m\./gi, "$1m")
    .replace(/\bno\.\s*/gi, "no ");
  const out = [];
  let m;
  CANCEL_RE.lastIndex = 0;
  while ((m = CANCEL_RE.exec(notes))) {
    const sent = m[1].trim();
    if (HAPPENED.test(sent)) continue;
    const dt = parseDate(sent);
    if (!dt) continue;
    // Where in the sentence did the date start? Everything before it has to end
    // with a deadline word.
    const idx = sent.search(/\b\d{4}-\d{2}-\d{2}\b|\b[A-Za-z]{3,9}[-\s.]+\d{1,2}(?:st|nd|rd|th)?[,\s-]+\d{4}\b|\b\d{1,2}(?:st|nd|rd|th)?[\s-]+[A-Za-z]{3,9}[,\s-]+\d{4}\b/);
    if (idx < 0 || !DEADLINE_LEAD.test(sent.slice(0, idx))) continue;
    const iso = isoInstant(tz, dt, parseTime(sent));
    // A deadline already past is either misparsed or useless. Relative wording
    // ("48 hours before arrival") is never resolved here either — that needs the
    // arrival time and a judgement call, which belongs to the importer working
    // from the live email, not to a regex working from a summary.
    if (new Date(iso) <= new Date()) continue;
    out.push({ sentence: sent.replace(/\s+/g, " ").slice(0, 160), iso });
  }
  return out;
}
// The "+" has to be inside the gap-skipping class, or "WhatsApp +506 ..." loses
// its country code and the resulting tel: link dials nothing.
const PHONE_RE = /(?:tel|phone|call|whatsapp)[^\d+]{0,12}(\+?\d[\d\s().-]{7,17}\d)/i;
// Not merely the first address in the note. Adobe Rent A Car's note ends
// "Booked via Mytanfeet (web@mytanfeet.com)" — a real address, belonging to the
// agent rather than to the rental desk, which under a Contacts heading reading
// "Adobe Rent A Car" is just wrong. So an address counts only where the
// surrounding words present it as somewhere to make contact.
const EMAIL_RE = /(?:e-?mail|contact|reservation|booking|enquir|inquir|concierge|front desk|operator|host|·)[^@\n]{0,40}?\b([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})\b/i;
// A no-reply address in the Contacts list is worse than an empty one: it looks
// like somewhere you could get help.
const JUNK_EMAIL = /^(?:no-?reply|do-?not-?reply|donotreply|notifications?|mailer|bounce)@/i;
const ANY_EMAIL_RE = /\b([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})\b/g;

// An address also counts when its domain is the thing itself — "hyatt.com" on
// an item called "Hyatt Regency Hesperia Madrid". That recovers the hotel
// addresses the cue rule alone misses, while still refusing "mytanfeet.com" on
// a car hire from Adobe, because the name has nothing to do with the domain.
function pickEmail(notes, itemName) {
  const cued = notes.match(EMAIL_RE);
  if (cued && !JUNK_EMAIL.test(cued[1])) return cued[1];
  const words = String(itemName || "").toLowerCase().match(/[a-z]{4,}/g) || [];
  ANY_EMAIL_RE.lastIndex = 0;
  let m;
  while ((m = ANY_EMAIL_RE.exec(notes))) {
    if (JUNK_EMAIL.test(m[1])) continue;
    const domain = m[1].split("@")[1].toLowerCase();
    if (words.some((w) => domain.includes(w))) return m[1];
  }
  return null;
}

async function api(path, opts) {
  const r = await fetch(BASE + "/api/v1" + path, Object.assign({ cache: "no-store" }, opts, {
    headers: Object.assign({ "content-type": "application/json" }, (opts || {}).headers),
  }));
  if (!r.ok) throw new Error(path + " -> " + r.status);
  return r.json();
}

(async () => {
  const today = new Date().toISOString().slice(0, 10);
  const trips = [];
  for (let page = 1; ; page++) {
    const r = await api("/trips?page=" + page);
    trips.push(...(r.results || []));
    if (!r.next) break;
  }
  const upcoming = trips.filter((t) => (t.ends_at || t.starts_at || "") >= today);
  console.log(`${trips.length} trips, ${upcoming.length} upcoming\n`);

  let scanned = 0, withNotes = 0, proposed = 0, skipped = 0;
  const writes = [];

  for (const t of upcoming) {
    const kinds = [["hostings", "hosting"], ["transportations", "transportation"], ["activities", "activity"]];
    for (const [plural, singular] of kinds) {
      const items = (await api(`/trip/${t.id}/${plural}`)).results || [];
      for (const o of items) {
        scanned++;
        const notes = String(o.notes || "");
        if (!notes.trim()) continue;
        withNotes++;
        const tz = o.timezone || o.departure_timezone || t.timezone;
        const terms = {};

        const cancels = findCancel(notes, tz);
        if (cancels.length === 1) {
          terms.cancel_by = cancels[0].iso;
          terms.cancel_policy = cancels[0].sentence;
        } else if (cancels.length > 1) {
          // Two datable cancellation sentences in one note is ambiguous, and
          // picking one would be a coin flip presented as a fact.
          skipped++;
          console.log(`  ~ ${t.name} / ${o.name || singular}: ${cancels.length} candidate deadlines, left alone`);
        }
        const ph = notes.match(PHONE_RE);
        const email = pickEmail(notes, o.name);
        if (ph || email) {
          terms.contact = {};
          if (ph) terms.contact.phone = ph[1].trim();
          if (email) terms.contact.email = email;
        }
        if (!Object.keys(terms).length) continue;
        // Never overwrite terms the importer already wrote from the live email —
        // that is a better source than this prose.
        if (o.terms && Object.keys(o.terms).length) { skipped++; continue; }
        proposed++;
        writes.push({ trip: t.id, kind: singular, id: o.id, label: `${t.name} / ${o.name || singular}`, terms });
      }
    }
  }

  console.log(`\nscanned ${scanned} items, ${withNotes} had notes`);
  console.log(`proposed ${proposed} terms objects, skipped ${skipped}\n`);
  for (const w of writes) {
    const bits = [];
    if (w.terms.cancel_by) bits.push("cancel_by=" + w.terms.cancel_by);
    if (w.terms.contact && w.terms.contact.phone) bits.push("phone=" + w.terms.contact.phone);
    if (w.terms.contact && w.terms.contact.email) bits.push("email=" + w.terms.contact.email);
    console.log(`  ${w.label}\n      ${bits.join("  ")}`);
    if (w.terms.cancel_policy) console.log(`      "${w.terms.cancel_policy}"`);
  }
  if (!APPLY) { console.log("\nDRY RUN — nothing written. Re-run with --apply."); return; }
  let ok = 0;
  for (const w of writes) {
    try { await api(`/trip/${w.trip}/${w.kind}/${w.id}`, { method: "PATCH", body: JSON.stringify({ terms: w.terms }) }); ok++; }
    catch (e) { console.log(`  FAILED ${w.label}: ${e.message}`); }
  }
  console.log(`\nwrote ${ok}/${writes.length}`);
})();
