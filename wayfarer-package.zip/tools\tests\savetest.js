// Pressing Save must always produce something.
//
// Reported 2026-08-23 as "trouble saving edits to trip ideas": the button did
// nothing. No request, no message, nothing in the console.
//
// bucketFields' read() calls coordPair, which THROWS -- by design -- when only
// one of latitude/longitude is filled, when either is not a number, or when
// either is out of range. Both Save handlers called f.read() OUTSIDE their try,
// inside an async listener. The throw rejected that listener and vanished:
// an unhandled rejection in an event handler is reported nowhere a person
// looks. Every other refusal in read() toasts a reason and returns null, so
// this was the one path that failed mute.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");

const grab = (name) => {
  const head = "  function " + name + "(";
  const i = app.indexOf(head);
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < app.length; j++) {
    if (app[j] === "{") { d++; seen = true; }
    else if (app[j] === "}") { d--; if (seen && !d) return app.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
};

const toasts = [];
global.toast = (m) => toasts.push(String(m));
// readForm logs the fault deliberately; that is the point of it, but the
// stack trace is noise in a test run.
console.error = () => {};
eval(grab("ApiError") + grab("coordPair") + grab("readForm") +
  grab("normalizeTarget") + grab("realDate") +
  ";Object.assign(globalThis,{ApiError,coordPair,readForm,normalizeTarget,realDate});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};
const threw = (fn) => { try { fn(); return null; } catch (e) { return e.message; } };

console.log("\ncoordPair throws — that is deliberate");
t("both blank is fine", coordPair("", ""), { latitude: null, longitude: null });
t("a real pair is fine", coordPair("34.05", "-118.25"), { latitude: 34.05, longitude: -118.25 });
// The exact case a person hits by pasting one number and pressing Save.
t("latitude alone throws",
  threw(() => coordPair("34.05", "")), "Give both a latitude and a longitude, or leave both blank.");
t("longitude alone throws",
  threw(() => coordPair("", "-118.25")), "Give both a latitude and a longitude, or leave both blank.");
t("nonsense throws", threw(() => coordPair("north", "west")) !== null, true);
t("out of range throws", threw(() => coordPair("999", "-118.25")) !== null, true);

console.log("\nso the caller has to catch it");
{
  toasts.length = 0;
  const btn = { disabled: true };
  const got = readForm({ read: () => coordPair("34.05", "") }, btn);
  t("it returns null rather than a value", got, null);
  t("it says what is wrong",
    toasts[0], "Give both a latitude and a longitude, or leave both blank.");
  // The message is already a sentence; prefixing it buries the instruction.
  t("and does not bury it behind a prefix", /Couldn't read the form/.test(toasts[0]), false);
  t("the button is usable again", btn.disabled, false);
}
{
  toasts.length = 0;
  const got = readForm({ read: () => { throw new TypeError("x is not a function"); } }, null);
  t("an unexpected fault is labelled as one",
    /Couldn't read the form: x is not a function/.test(toasts[0]), true);
  t("and still returns null", got, null);
}
{
  toasts.length = 0;
  const got = readForm({ read: () => ({ place: "Kona" }) }, null);
  t("an ordinary read passes the value through", got.value, { place: "Kona" });
  t("silently", toasts.length, 0);
}
{
  // read() still returns null for its own refusals, having toasted already.
  const got = readForm({ read: () => null }, null);
  t("a refusal is not mistaken for a fault", got.value, null);
}

console.log("\nneither Save button reads outside its guard");
t("the edit dialog uses the guard",
  /var got = readForm\(f, ok\); if \(!got\) return;/.test(app), true);
t("both call sites do, and the definition is not miscounted",
  (app.match(/= readForm\(f, ok\);/g) || []).length, 2);
// The shape that caused it. If this returns, so does the silent failure.
t("no bare f.read() survives", /var v = f\.read\(\); if \(!v\) return;/.test(app), false);

console.log("\nthe dates a person actually types");
// The box used to take ISO and nothing else, so 10/15/27 -- the way a date is
// written on every US form, and the way this app displays them -- was refused
// outright. Reported while trying to put October 2027 on a trip to Europe.
const norm = (v) => { const r = normalizeTarget(v); return ("value" in r) ? r.value : "REFUSED"; };
t("US order, two-digit year", norm("10/15/27"), "2027-10-15");
t("US order, four-digit year", norm("10/15/2027"), "2027-10-15");
t("single digits are fine", norm("9/5/27"), "2027-09-05");
t("dashes work the same way", norm("10-15-27"), "2027-10-15");
t("a month and a year", norm("10/2027"), "2027-10");
t("a month and a short year", norm("10/27"), "2027-10");
t("a bare year", norm("2027"), "2027");

console.log("\nand the ISO it always took");
t("a year", norm("2027"), "2027");
t("a month", norm("2027-09"), "2027-09");
t("a day", norm("2027-09-14"), "2027-09-14");
t("blank means unset", norm(""), null);
t("so does whitespace", norm("   "), null);

console.log("\nwhat is still refused, and why");
// A two-digit year is 2000+yy with no pivot: these are trips being planned, so
// 27 is 2027 and can never be 1927.
t("the century is never guessed backwards", norm("10/15/99"), "2099-10-15");
t("prose is not a date", norm("October 2027"), "REFUSED");
t("there is no month 13", norm("13/15/27"), "REFUSED");
t("nor a 30th of February", norm("2/30/27"), "REFUSED");
t("in ISO either", norm("2027-02-30"), "REFUSED");
t("nor a 31st of November", norm("11/31/27"), "REFUSED");
// Range checks alone would pass these; only a round trip catches them.
t("but a real leap day is kept", norm("2/29/28"), "2028-02-29");
t("and a fake one is not", norm("2/29/27"), "REFUSED");
t("a bad month says which", normalizeTarget("13/15/27").error, "there is no month 13");
t("a bad day says so", /is not a real date/.test(normalizeTarget("2/30/27").error), true);

console.log("\nwhat gets stored");
// Everything downstream -- the season check, the flight window, the target
// label -- parses ISO. Normalising at the boundary keeps one shape inside.
t("storage is always ISO", /^\d{4}(-\d{2}){0,2}$/.test(norm("10/15/27")), true);
t("the form writes back the normalised value",
  app.indexOf("if (got.value) pair[0].value = got.value;") > -1, true);
t("and the placeholder shows the friendly form",
  /10\/15\/27/.test(app), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
if (fail) process.exit(1);
