// Qualifying card spend, and the two ways of getting it wrong.
//
// The tracker answers one question -- keep steering spend at this card, or
// stop -- and it is only worth anything if the total is right. The total was
// wrong twice before it was right, and both wrong answers looked plausible on
// screen:
//
//   1. Keying off Plaid's personal_finance_category. Plaid files "PAYMENT
//      RECEIVED - THANK YOU" as INCOME_SALARY, so $427,904 of Amex payments
//      were read as refunds and SUBTRACTED, understating the Business Platinum
//      by about $210,000. The tell was a 65% refund rate, which is not a thing
//      that happens on a charge card.
//
//   2. Treating every remaining negative as a refund. That subtracted statement
//      credits -- the Aspire's five Hilton resort credits, $550 -- which are not
//      reversals: the purchase they offset still counts toward the threshold.
//      That was the whole of a $549.04 gap against Amex's own figure.
//
// The rules that closed both now reconcile to 96 cents, the 96 cents being a
// rounded input. This suite pins the rules AND the arithmetic on top of them,
// against fixtures carrying the exact descriptions and categories that fooled
// each earlier version. No real transactions live here -- see run.js.
const fs = require("fs");
const core = fs.readFileSync("functions/api/_core.js", "utf8");
const app = fs.readFileSync("public/app.js", "utf8");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

// Lift the real declaration out of the source rather than copying it here, so
// a rule quietly edited in _core.js fails this suite instead of passing a
// stale duplicate of itself.
function lift(decl, src) {
  const text = src || core;
  const at = text.indexOf(decl);
  if (at < 0) throw new Error("not found: " + decl);
  let depth = 0, i = text.indexOf("{", at);
  for (; i < text.length; i++) {
    if (text[i] === "{") depth++;
    else if (text[i] === "}") { depth--; if (!depth) break; }
  }
  return text.slice(at, i + 1);
}
function liftLine(prefix) {
  const at = core.indexOf(prefix);
  if (at < 0) throw new Error("not found: " + prefix);
  return core.slice(at, core.indexOf("\n", at));
}

const RULES =
  liftLine("const CARD_PAYMENT_RE =") + "\n" +
  liftLine("const CARD_CREDIT_RE =") + "\n" +
  liftLine("const CARD_BALANCE_REFUND_RE =") + "\n" +
  lift("function classifyCardTxn(");

const classify = new Function(RULES + "\nreturn classifyCardTxn;")();

console.log("\nthe descriptions that Plaid's own category gets wrong");
{
  // Verbatim shapes from the real feed. INCOME_SALARY on a card payment is not
  // a typo in this fixture -- it is what Plaid actually returns, and it is the
  // reason the category cannot be the primary signal.
  t("PAYMENT RECEIVED - THANK YOU, filed as INCOME_SALARY",
    classify("PAYMENT RECEIVED - THANK YOU", "INCOME_WAGES", -52000), "payment");
  t("AUTOPAY is a payment however it is categorised",
    classify("AUTOPAY PAYMENT", "GENERAL_MERCHANDISE_OTHER", -1200), "payment");
  t("REMITTANCE RECEIVED is a payment",
    classify("ONLINE REMITTANCE RECEIVED", "", -900), "payment");
}

console.log("\nstatement credits are not refunds");
{
  // The Aspire's resort credits. Negative, filed under INCOME/TRANSFER_IN, and
  // the charge they offset still counts toward the $60,000.
  t("a Hilton credit under INCOME_OTHER is a credit",
    classify("HILTON RESORT CREDIT", "INCOME_OTHER_INCOME", -110), "credit");
  t("TRANSFER_IN with no telling description is still a credit",
    classify("ADJUSTMENT", "TRANSFER_IN_OTHER_TRANSFER_IN", -110), "credit");
  t("Pay with Points is a credit",
    classify("PAY WITH POINTS", "", -3400), "credit");
}

console.log("\nChase words all three of these differently");
{
  // Every pattern was written against Amex, and Chase broke three of them on
  // contact -- caught by the reconciliation report, not by anything static.
  //
  // Chase TRUNCATES its description at "THANK", so a pattern requiring the
  // "YOU" missed $109,000 of card payments; they fell through to the category
  // test, which files them as INCOME_SALARY and INCOME_CONTRACTOR. They landed
  // in "credit" -- also excluded from spend, so the total survived by luck.
  t("AUTOMATIC PAYMENT - THANK, truncated by Chase",
    classify("AUTOMATIC PAYMENT - THANK", "INCOME_SALARY", -38319.44), "payment");
  t("and the same wording filed as contractor income",
    classify("AUTOMATIC PAYMENT - THANK", "INCOME_CONTRACTOR", -451.41), "payment");
  t("Chase's other payment wording", classify("Payment ThankYou Image", "LOAN_DISBURSEMENTS_OTHER_DISBURSEMENT", -12500), "payment");

  // POSITIVE and still not spend: the bank returning an overpayment. The
  // "anything positive is a charge" shortcut counted $501.52 of phantom spend.
  t("a credit balance refund is not a charge despite being positive",
    classify("CREDIT BALANCE REFUND", "LOAN_PAYMENTS_CREDIT_CARD_PAYMENT", 501.52), "payment");

  // A Chase Offers credit. It read as a merchant refund and subtracted $60.
  t("a Chase Offers credit is a credit, not a refund",
    classify("Offer:Hyatt Unbound Colle", "TRAVEL_LODGING", -60), "credit");
  // But the ordinary hotel reversal beside it still is one.
  t("a plain hotel reversal is still a refund",
    classify("HYATT SCOTTSDALE NORTH", "TRAVEL_LODGING", -50), "refund");
}

console.log("\nAmex benefit credits are credits, not merchant refunds");
{
  // Found by the reconciliation report on 2026-08-27, after Chase. Amex prints
  // its benefit credits as ordinary negatives, so four kinds were subtracting
  // as though a shop had refunded something. Ten rows across two years; two of
  // them in 2026, worth $200 on the Business Platinum.
  t("an airline fee reimbursement", classify("AMEX Airline Fee Reimbursement", "BANK_FEES_OTHER_BANK_FEES", -100), "credit");
  t("a flight credit", classify("AMEX Flight Credit", "TRAVEL_FLIGHTS", -50), "credit");
  t("the Global Entry fee credit", classify("TSA Global Entry Fee Credit", "GOVERNMENT_AND_NON_PROFIT_OTHER", -120), "credit");
  t("the Business Platinum's Dell credit", classify("Dell Credit", "GENERAL_MERCHANDISE_ELECTRONICS", -200), "credit");

  // And what was deliberately NOT reclassified, on the same evidence. These
  // are the ones a looser pattern would have swallowed.
  //
  // "AMEX Fine Hotels and AmexTravel.com" came through at $494.33, $253.07 and
  // $236.97 -- not the flat $100 FHR property credit, so they are refunds of
  // hotel bookings and belong in the bucket that subtracts.
  t("a Fine Hotels booking refund is still a refund",
    classify("AMEX Fine Hotels andAmexTravel.com", "TRAVEL_LODGING", -494.33), "refund");
  // Global Blue is VAT reimbursed on goods bought, which genuinely reduces
  // what was spent.
  t("a VAT reimbursement is still a refund",
    classify("GLOBAL BLUE FRANCE SSTOCKHOLM AU", "GENERAL_SERVICES_INSURANCE", -225.31), "refund");
  t("a Nordstrom return is still a refund",
    classify("Nordstrom", "GENERAL_MERCHANDISE_DEPARTMENT_STORES", -893.30), "refund");
  t("a hotel reversal is still a refund",
    classify("WALDORF ASTORIA LOS CABOS SAN LUCAS ME", "TRAVEL_LODGING", -200), "refund");
}

console.log("\na real merchant reversal still subtracts");
{
  // The other half of the same rule: these came back GENERAL_*, from merchants,
  // and they are genuine reversals.
  t("a Walmart return is a refund", classify("WALMART.COM", "GENERAL_MERCHANDISE_ONLINE_MARKETPLACES", -84.16), "refund");
  t("a Google One refund is a refund", classify("GOOGLE ONE", "GENERAL_SERVICES_OTHER", -19.99), "refund");
  t("anything positive is a charge", classify("PAYMENT THANK YOU", "INCOME_WAGES", 250), "charge");
}

console.log("\nthe tool classifier is the app classifier");
{
  // tools/plaid-rules.js exists so the command-line tools run the SAME rules
  // as the app -- and for a day it did not: plaid-spend.js kept a stale
  // pre-Chase copy, which is exactly the drift this section now makes loud.
  // Regex sources must match byte for byte, and behaviour must agree on the
  // fixtures that broke each earlier version.
  const shared = require("../plaid-rules");
  const rx = (line) => new Function(line + "\nreturn RX;")();
  const appPayment = rx(liftLine("const CARD_PAYMENT_RE =").replace("CARD_PAYMENT_RE", "RX"));
  const appCredit = rx(liftLine("const CARD_CREDIT_RE =").replace("CARD_CREDIT_RE", "RX"));
  const appBalance = rx(liftLine("const CARD_BALANCE_REFUND_RE =").replace("CARD_BALANCE_REFUND_RE", "RX"));
  t("the payment pattern matches the app's", shared.PAYMENT.source, appPayment.source);
  t("the credit pattern matches the app's", shared.CREDIT.source, appCredit.source);
  t("both classifiers agree on every canonical case", [
    ["PAYMENT RECEIVED - THANK YOU", "INCOME_WAGES", -52000],
    ["AUTOMATIC PAYMENT - THANK", "INCOME_SALARY", -38319.44],
    ["Payment ThankYou Image", "LOAN_DISBURSEMENTS_OTHER_DISBURSEMENT", -12500],
    ["CREDIT BALANCE REFUND", "LOAN_PAYMENTS_CREDIT_CARD_PAYMENT", 501.52],
    ["Offer:Hyatt Unbound Colle", "TRAVEL_LODGING", -60],
    ["AMEX Airline Fee Reimbursement", "BANK_FEES_OTHER_BANK_FEES", -100],
    ["Dell Credit", "GENERAL_MERCHANDISE_ELECTRONICS", -200],
    ["HILTON RESORT CREDIT", "INCOME_OTHER_INCOME", -110],
    ["WALMART.COM", "GENERAL_MERCHANDISE_ONLINE_MARKETPLACES", -84.16],
    ["HOTEL", "TRAVEL_LODGING", 6000],
  ].map(([n, c, a]) => shared.classify({ name: n, personal_finance_category: { primary: c.split("_")[0], detailed: c }, amount: a })),
  [
    ["PAYMENT RECEIVED - THANK YOU", "INCOME_WAGES", -52000],
    ["AUTOMATIC PAYMENT - THANK", "INCOME_SALARY", -38319.44],
    ["Payment ThankYou Image", "LOAN_DISBURSEMENTS_OTHER_DISBURSEMENT", -12500],
    ["CREDIT BALANCE REFUND", "LOAN_PAYMENTS_CREDIT_CARD_PAYMENT", 501.52],
    ["Offer:Hyatt Unbound Colle", "TRAVEL_LODGING", -60],
    ["AMEX Airline Fee Reimbursement", "BANK_FEES_OTHER_BANK_FEES", -100],
    ["Dell Credit", "GENERAL_MERCHANDISE_ELECTRONICS", -200],
    ["HILTON RESORT CREDIT", "INCOME_OTHER_INCOME", -110],
    ["WALMART.COM", "GENERAL_MERCHANDISE_ONLINE_MARKETPLACES", -84.16],
    ["HOTEL", "TRAVEL_LODGING", 6000],
  ].map(([n, c, a]) => classify(n, c, a)));
  // No fallback here: an unexported pattern must FAIL, not compare the app's
  // regex against itself and pass vacuously.
  t("the balance-refund pattern matches too",
    shared.BALANCE_REFUND && shared.BALANCE_REFUND.source, appBalance.source);
}

console.log("\nqualifying spend, end to end");
{
  // The whole payload function, against a stubbed D1. force:false and a fresh
  // last_sync_at keep it off the network, so this exercises the arithmetic and
  // nothing else.
  const nowIso = () => new Date().toISOString();
  const year = String(new Date().getUTCFullYear());
  const d = (mmdd) => year + "-" + mmdd;

  const txns = [
    { date: d("01-10"), amount: 30000, name: "BIG SUPPLIER", category: "GENERAL_SERVICES_OTHER" },
    { date: d("02-01"), amount: -30000, name: "PAYMENT RECEIVED - THANK YOU", category: "INCOME_WAGES" },
    { date: d("02-15"), amount: 25000, name: "AIRLINE TICKETS", category: "TRAVEL_FLIGHTS" },
    { date: d("03-01"), amount: -500, name: "HILTON RESORT CREDIT", category: "INCOME_OTHER_INCOME" },
    { date: d("03-20"), amount: -1000, name: "WALMART.COM", category: "GENERAL_MERCHANDISE_ONLINE_MARKETPLACES" },
    // Pending: counts toward spend (the behaviour the 96-cent reconciliation
    // validated), is reported separately, and must never DATE a crossing --
    // a milestone should not be pinned to a charge that might still vanish.
    { date: d("03-25"), amount: 500, name: "PENDING RESTAURANT", category: "FOOD_AND_DRINK_RESTAURANT", pending: 1 },
    { date: d("04-05"), amount: 6000, name: "HOTEL", category: "TRAVEL_LODGING" },
    // Last year's, which must not be counted at all.
    { date: (Number(year) - 1) + "-12-30", amount: 99999, name: "OLD CHARGE", category: "TRAVEL_LODGING" },
  ];

  const db = {
    prepare(sql) {
      const rows =
        /card_items/.test(sql) ? [{ id: 1, institution: "Test Bank", access_token: "x", last_sync_at: nowIso() }] :
        /card_accounts/.test(sql) ? [{ id: 2, item_id: 1, plaid_account_id: "acct1", name: "Test Card", mask: "1234" }] :
        /card_goals/.test(sql) ? [{ id: 3, plaid_account_id: "acct1", label: "a reward", target: 60000, paid_next_year: 1 }] :
        txns.filter((x) => x.date >= year + "-01-01" && x.date <= year + "-12-31");
      const res = { results: rows };
      return { all: async () => res, run: async () => ({}), bind: () => ({ all: async () => res, run: async () => ({}) }) };
    },
  };

  const payload = new Function("nowIso", "fetch",
    RULES + "\n" + lift("async function refreshCardAccounts(") + "\n" +
    lift("async function syncCardItem(") + "\n" +
    liftLine("const CARD_SYNC_STALE_MS =") + "\n" +
    // The window helpers, which cardsPayload now calls per goal — see
    // windowtest.js for the March-to-February year they exist for.
    lift("function goalWindow(") + "\n" + lift("function daysInclusive(") + "\n" +
    lift("function stayNights(") + "\n" + lift("function dayAfter(") + "\n" +
    lift("const STAY_BRANDS = ") + "\n" +
    lift("async function nightsFromStays(") + "\n" +
    lift("async function cardsPayload(") + "\nreturn cardsPayload;"
  )(nowIso, () => { throw new Error("a fresh sync must not hit the network"); });

  return payload({}, db, { force: false }).then((out) => {
    const r = out.results[0];
    // 30000 + 25000 + 500 + 6000 = 61500 charged; the $1,000 Walmart return
    // subtracts; the $500 pending row counts and is reported separately.
    t("charges exclude payments and credits", r.charges, 61500);
    t("a merchant refund subtracts", r.refunds, -1000);
    t("qualifying spend is charges plus refunds", r.spend, 60500);
    t("the $30,000 payment is excluded entirely", r.payments, -30000);
    t("the statement credit is recorded but not subtracted", r.credits, -500);
    t("the pending charge is surfaced on its own", r.pending_spend, 500);
    t("last year is not counted", r.txn_count, 7);
    t("the target is met", r.met, true);
    // The crossing is the first POSTED transaction at which the running total
    // reaches the target -- the April hotel. The pending row that ran through
    // the total earlier must not date the milestone.
    t("it crossed on the transaction that took it over", r.crossed_on, d("04-05"));
    t("and it says the reward is paid the following year", r.paid_next_year, true);
    t("nothing failed", out.problems, []);

    // Derived from the same clock the code uses, because an expectation written
    // as a constant is only right on the day it was written.
    const start = Date.UTC(Number(year), 0, 1);
    const total = Math.floor((Date.UTC(Number(year), 11, 31) - start) / 86400000) + 1;
    const elapsed = Math.max(1, Math.floor((Date.now() - start) / 86400000) + 1);
    t("days left is the rest of the calendar year", r.days_left, Math.max(0, total - elapsed));
    t("the pace is spend over days elapsed", Math.round(r.per_day * 100), Math.round((60500 / elapsed) * 100));

    console.log("\na points goal on American's own year");
    {
      // The window is derived from the SAME clock the code uses -- a fixture
      // date written as a constant is only right until next March.
      const gw = new Function(lift("function goalWindow(") + "\n" + lift("function daysInclusive(") + "\nreturn goalWindow;")();
      const win = gw("march", Date.now());
      const dayN = (off) => new Date(Date.parse(win.from + "T00:00:00Z") + off * 86400000).toISOString().slice(0, 10);
      const beforeWin = new Date(Date.parse(win.from + "T00:00:00Z") - 10 * 86400000).toISOString().slice(0, 10);

      const ptTxns = [
        // Before the window: the year's spend must not see it at all.
        { date: beforeWin, amount: 99999, name: "OLD YEAR CHARGE", category: "TRAVEL_LODGING" },
        { date: dayN(10), amount: 12000, name: "EARLY CHARGE", category: "GENERAL_SERVICES_OTHER" },
        { date: dayN(80), amount: 3000, name: "LATE CHARGE", category: "TRAVEL_FLIGHTS" },
      ];
      // Two goals, one card: an anchor read inside the window and one read
      // BEFORE it -- last year's balance, which reset when the year rolled.
      const ptGoals = [
        { id: 9, plaid_account_id: "acct1", label: "fresh", target: 125000, period: "march", unit: "points",
          spend_step: 1, units_per_step: 1, baseline_units: 70000, baseline_at: dayN(60) },
        { id: 10, plaid_account_id: "acct1", label: "stale", target: 125000, period: "march", unit: "points",
          spend_step: 1, units_per_step: 1, baseline_units: 70000, baseline_at: beforeWin },
      ];
      // This stub HONOURS the binds -- the windowing is the thing under test.
      const db2 = {
        prepare(sql) {
          const base = /card_items/.test(sql) ? [{ id: 1, institution: "T", last_sync_at: nowIso() }]
            : /card_accounts/.test(sql) ? [{ id: 2, item_id: 1, plaid_account_id: "acct1", name: "Card", mask: "9" }]
            : /card_goals/.test(sql) ? ptGoals : [];
          return {
            all: async () => ({ results: base }),
            run: async () => ({}),
            bind: (...a) => ({
              all: async () => ({
                results: /card_txns/.test(sql) ? ptTxns.filter((x) => x.date >= a[1] && x.date <= a[2]) : [],
              }),
              run: async () => ({}),
              first: async () => null,
            }),
          };
        },
      };
      return payload({}, db2, { force: false }).then((out2) => {
        const fresh = out2.results.find((x) => x.goal_id === 9);
        const stale = out2.results.find((x) => x.goal_id === 10);
        t("the window is March, not January", fresh.window_from, win.from);
        t("spend before the window is invisible", fresh.txn_count, 2);
        t("a fresh anchor adds only what followed it", fresh.progress, 73000);
        t("and reports what it added", fresh.spend_since_anchor, 3000);
        t("it is not stale", fresh.anchor_stale, false);
        // Last year's 70,000 points no longer exist -- the programme reset
        // them. Adding them overstated progress by last year's entire total.
        t("a stale anchor is dropped, spend-only", stale.progress, 15000);
        t("and says so", stale.anchor_stale, true);
        t("its dead balance is not offered as current", stale.baseline_units, null);
        t("but the read date survives for the warning", stale.baseline_at, beforeWin);
        finish();
      });
    }

    function finish() {
    console.log("\na failed sync says so rather than showing a smaller number");
    {
      // The rule from every loader in this app: an upstream failure must not
      // render as an answer. Here that means the error is written down, the
      // cursor is NOT advanced, and the panel has somewhere to show it.
      const sync = lift("async function syncCardItem(");
      t("the error is persisted against the item", /card_items SET last_error=/.test(sync), true);
      t("and it returns a failure rather than an empty result", /return \{ ok: false, error: msg \}/.test(sync), true);
      // The cursor update is the last statement, after the early return above,
      // so a failed round cannot mark the item as caught up.
      t("a failed round never advances the cursor",
        sync.indexOf("return { ok: false") < sync.indexOf("SET cursor=?"), true);

      const panel = lift("function openCardGoals(", app);
      t("the panel renders each problem",
        panel.indexOf("(data && data.problems) || []).forEach") > 0, true);
      t("with a visible strip, not a console line", /goal-problem/.test(panel), true);
      t("and says the figures beneath it are stale", /last successful check/.test(panel), true);
      t("a request that throws replaces the panel with the error",
        /Could not reach the card data/.test(panel), true);
    }

    console.log("\n" + pass + " passed, " + fail + " failed\n");
    process.exit(fail ? 1 : 0);
    }
  });
}
