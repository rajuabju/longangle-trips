// Moving the map and the drive times to Google, and following a link to a pin.
//
// One rule decides the shape of all of this: Google's terms allow caching
// coordinates from Geocoding, Directions and Routes for at most 30 consecutive
// calendar days. This app stores coordinates on every record PERMANENTLY —
// fifteen years of them — so geocoding cannot move without either deleting the
// lot every month or being in breach. OpenStreetMap's data is ODbL and may be
// kept. So: display and routing moved, geocoding did not, and these tests exist
// mostly to stop that line being crossed later by accident.
const fs = require("fs");
const app = fs.readFileSync("public/app.js", "utf8");
const core = fs.readFileSync("functions/api/_core.js", "utf8");
const ext = fs.readFileSync("functions/api/ext/[[path]].js", "utf8");

function grab(src, name) {
  const head = "function " + name + "(";
  const i = src.indexOf(head);
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}
eval(grab(ext, "decodePolyline") + grab(core, "postalAddress") + grab(core, "geoOf") +
  ";Object.assign(globalThis,{decodePolyline,postalAddress,geoOf});");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  const ok = g === w;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + w + "\n        got  " + g);
};

console.log("\nthe licence line, which is the whole design");
// If this ever flips, coordinates stored on 15 years of records are in breach.
t("geocoding still goes to OpenStreetMap", /nominatim\.openstreetmap\.org/.test(ext), true);
t("and never to Google", /maps\.googleapis\.com\/maps\/api\/geocode/.test(ext), false);
t("routing may use Google, because a route is not stored",
  /routes\.googleapis\.com/.test(ext), true);
t("the 30-day rule is written down where it matters", /30 consecutive days/.test(ext), true);
t("and the reason geocoding stayed is written next to it",
  /only ODbL permits that/.test(ext), true);
// The OSRM fallback is not dead code. Anyone tidying it away should hit the
// reason first, in the file, not have to reconstruct it from a commit message.
t("the OSRM fallback says why it is kept", /OSRM, kept deliberately/.test(ext), true);
// It used to name a trial-expiry date. The account is pay-as-you-go now, so the
// reason is no longer a deadline -- it is the quota cap, which refuses rather
// than bills, and which therefore fires on purpose.
t("and names the condition that makes it necessary",
  /capped[\s\S]{0,40}300\/day/.test(ext), true);
t("no stale expiry date is left in the reasoning",
  /22 November 2026/.test(ext), false);

console.log("\nGoogle's encoded polyline");
// Google's own documented sample. A decoder that is subtly wrong draws a road
// through the sea and nothing throws.
const SAMPLE = "_p~iF~ps|U_ulLnnqC_mqNvxq" + String.fromCharCode(96) + "@";
t("decodes the published example", decodePolyline(SAMPLE),
  [[38.5, -120.2], [40.7, -120.95], [43.252, -126.453]]);
t("an empty string is an empty path", decodePolyline(""), []);
t("returns [lat, lon], matching the OSRM branch", decodePolyline("_p~iF~ps|U")[0][0] > 0, true);

console.log("\nrouting falls back rather than losing the road");
t("Google is tried first",
  ext.indexOf("routes.googleapis.com") < ext.indexOf("router.project-osrm.org"), true);
t("no key means straight to OSRM", /if \(env\.MAPS_SERVER_KEY\)/.test(ext), true);
// A Maps JS key must be referrer-restricted because it is public in the page;
// a Worker fetch sends no referrer, so that key is rejected there every time.
// One key cannot be both, and using one would fail only at runtime.
t("routing uses the SERVER key", /"X-Goog-Api-Key": env\.MAPS_SERVER_KEY/.test(ext), true);
t("and never the browser one", /MAPS_BROWSER_KEY/.test(ext), false);
t("the browser gets the browser key", /maps_key: env\.MAPS_BROWSER_KEY/.test(core), true);
t("and the server key is never published", /maps_key: env\.MAPS_SERVER_KEY/.test(core), false);
t("a failure falls through instead of throwing",
  /fall through to OSRM rather than lose the road line/.test(ext), true);
// A ReferenceError node --check cannot see: env was not destructured at first.
t("env is actually in scope", /const \{ request, params, env \} = context;/.test(ext), true);
// Routes bills by requested fields, so ask for exactly what gets drawn.
t("only the three fields used are requested",
  /routes\.distanceMeters,routes\.duration,routes\.polyline\.encodedPolyline/.test(ext), true);
t("the duration string is parsed, not used raw", /replace\(\/\[\^0-9\.\]\/g, ""\)/.test(ext), true);

console.log("\nthe map falls back too");
t("Leaflet is still there as the fallback", /renderMapLeaflet/.test(app), true);
t("and for the history map", /drawInsightsMapLeaflet/.test(app), true);
// A rejected key, a blocked referrer, an offline phone: each must land on
// Leaflet rather than an exception and a blank rectangle.
t("a failed script load resolves rather than rejects",
  /sc\.addEventListener\("error", function \(\) \{ resolve\(null\); \}\)/.test(app), true);
t("a null result draws Leaflet instead",
  /if \(!g\) return withLeaflet\(function \(\) \{ renderMapLeaflet/.test(app), true);
t("the key is fetched, never hardcoded", /state\.me && state\.me\.maps_key/.test(app), true);
t("no key is committed", /AIza[0-9A-Za-z_-]{30,}/.test(app + core + ext), false);
// Settings are user-writable, so a key named maps_key in there must not be able
// to point the map at somebody else's billing account.
t("settings cannot override the key",
  core.indexOf("role: role, maps_key:") > core.indexOf("...s,"), true);

console.log("\nthe driving route survived the move");
// drawDriving was only ever called from the Leaflet path. Left alone, setting
// the key would have silently dropped the road line and the "3h 40m drive" note
// from every road trip, with nothing failing.
// Matched on the callback argument, so the DEFINITION line does not count as a
// third call and quietly satisfy this.
t("the Google path draws it too",
  (app.match(/drawDriving\(dest, dark, function/g) || []).length, 2);
t("and drawDriving knows which map it is on",
  /if \(googleMap && window\.google && window\.google\.maps\)/.test(app), true);
t("it bails when both maps are gone", /if \(!leafletMap && !googleMap\) return null;/.test(app), true);
t("opening a new trip drops the old Google map",
  /googleMap = null; googleFitPts = null;/.test(app), true);

console.log("\nsetup stays to one API key");
// AdvancedMarkerElement needs a Map ID configured in the Cloud console. Classic
// Marker does not, and the point of this design is that a key is the only step.
t("classic markers, so no Map ID is needed", /new g\.Marker\(/.test(app), true);
t("dark styling is inline, not a cloud style", /var GMAP_DARK = \[/.test(app), true);
t("and the tradeoff is written down", /needs a Map ID configured/.test(app), true);

console.log("\nGoogle refusing is not the same as Google being unreachable");
// THE bug this suite exists to prevent, found in the 2026-08-23 audit.
//
// The loader only listened for the script failing to DOWNLOAD. When billing
// lapses, a key is rejected, or a referrer is not allowed, the script
// downloads perfectly and window.google.maps exists -- so every check said
// Google was fine while the map rendered as a grey watermarked box, and the
// Leaflet fallback never fired. gm_authFailure is the only signal Google
// gives for it.
//
// Not a dated concern: the quota cap (300/day, deliberately below the free
// allowance) refuses requests rather than billing for them, so a refusal is an
// expected condition the app must survive, not an emergency.
t("the auth-failure hook is installed", /window\.gm_authFailure = function/.test(app), true);
t("it marks Google unusable", /googleDead = true;/.test(app), true);
t("the loader refuses to try again afterwards",
  /if \(!mapsKey \|\| googleDead\) return Promise\.resolve\(null\);/.test(app), true);
t("and the load handler re-checks it, in case the refusal raced the load",
  /resolve\(googleDead \? null : \(window\.google && window\.google\.maps\)\)/.test(app), true);
// A map already on screen when the refusal lands is a broken map. Marking
// future draws is not enough; the visible one has to be rebuilt.
// Named slots, not a list: only two maps can ever be visible, and a list grew
// by one closure per trip opened -- each pinning a DOM node and a trip's data
// alive for a callback that fires at most once, if ever.
t("maps already drawn are rebuilt without Google",
  /var mapRedraws = \{ trip: null, history: null \};/.test(app), true);
t("and the slots are bounded, not a growing list",
  /mapRedraws\.push/.test(app), false);
t("the trip map registers how to rebuild itself",
  /mapRedraws\.trip = function \(\) \{ mapEl\.innerHTML = ""; renderMap/.test(app), true);
t("so does the history map",
  /mapRedraws\.history = function \(\) \{ node\.innerHTML = ""; drawInsightsMap/.test(app), true);
t("one bad redraw does not stop the other",
  /One bad map must not stop the other/.test(app), true);
// Both entry points must consult the flag, or a refusal only half-applies.
t("the trip map checks it", /if \(mapsKey && !googleDead\) {/.test(app), true);
t("both surfaces check it",
  (app.match(/mapsKey && !googleDead/g) || []).length, 2);

console.log("\nthe Travellers bar scrolls rather than wrapping on a phone");
const css = fs.readFileSync('public/styles.css', 'utf8');
// Six travellers plus Manage wrapped to three lines and pushed the itinerary
// down the page.
t("it stops wrapping on a phone", /\.pax-bar {[^}]*flex-wrap:nowrap/.test(css), true);
t("and scrolls sideways instead", /\.pax-bar {[^}]*overflow-x:auto/.test(css), true);
// Without this the chips compress to fit instead of overflowing, and every
// name becomes an ellipsis -- the failure this was meant to fix.
t("the chips keep their width", /\.pax-bar > \* { flex:0 0 auto; }/.test(css), true);
// 700px is what isPhone() uses; two different thresholds would disagree
// about what a phone is.
t("at the same breakpoint the rest of the app uses",
  /@media \(max-width:700px\)[^@]*\.pax-bar/.test(css), true);

console.log("\nLeaflet loads only when it is needed");
const html = fs.readFileSync('public/index.html', 'utf8');
// 144KB of JavaScript and 14KB of CSS on every page view, for a path that
// never runs while Google is working.
t("no eager Leaflet in the markup", /unpkg\.com\/leaflet/.test(html), false);
t("but the reason is written there", /Leaflet is NOT loaded here/.test(html), true);
t("app.js injects it instead", /function loadLeaflet\(/.test(app), true);
// Lazy loading must not quietly become UNVERIFIED loading -- the markup
// carried subresource-integrity hashes and the injected tags must too.
t("the script keeps its integrity hash",
  /sha256-20nQCchB9co0qIjJZRGuk2\/Z9VM\+kNiyxNV1lvTlZBo=/.test(app), true);
t("and the stylesheet keeps its own",
  /sha256-p4NxAoJBhIIN\+hmNHrzRCf9tD\/miZyoHS5obTRR9BMY=/.test(app), true);
t("both are set on the injected elements",
  /sc\.integrity = LEAFLET_JS_SRI/.test(app) && /css\.integrity = LEAFLET_CSS_SRI/.test(app), true);
t("a failed load resolves false rather than rejecting",
  /sc\.addEventListener\("error", function \(\) { resolve\(false\); }\)/.test(app), true);
t("it is fetched once, not per map", /if \(leafletPromise\) return leafletPromise/.test(app), true);
// Every Leaflet entry point has to wait for it now.
t("all four fallback paths go through withLeaflet",
  (app.match(/withLeaflet\(function/g) || []).length, 4);

// THE regression this introduced. The Map section used to be gated on
// window.L, which was true at page load while Leaflet was eager -- and is
// now ALWAYS false there. Left alone it hid the Map section on every single
// trip, and nothing would have failed.
t("the Map section is gated on coordinates, not on Leaflet being loaded",
  /if \(!geoPoints\(data\)\.length\) mapSec\.hidden = true;/.test(app), true);
t("and never on window.L again",
  /if \(!\(window\.L && geoPoints/.test(app), false);

console.log("\nfollowing a link to an address");
t("a full postal address keeps the street",
  postalAddress({ streetAddress: "1471 W Millers Cove Rd", addressLocality: "Walland",
    addressRegion: "TN", postalCode: "37886", addressCountry: "US" }),
  "1471 W Millers Cove Rd, Walland, TN, 37886, US");
t("a plain string passes through", postalAddress("One Casino Drive, Paradise Island"),
  "One Casino Drive, Paradise Island");
t("an array takes the first usable one",
  postalAddress([{ streetAddress: "1 Antler Hill Rd", addressLocality: "Asheville" }]),
  "1 Antler Hill Rd, Asheville");
// Some sites put the town in both locality and region.
t("a repeated town is not printed twice",
  postalAddress({ addressLocality: "Ravello", addressRegion: "Ravello", addressCountry: "Italy" }),
  "Ravello, Italy");
t("empty slots do not leave stray commas",
  postalAddress({ streetAddress: "", addressLocality: "Solvang", addressCountry: "US" }),
  "Solvang, US");
t("nothing in, nothing out", postalAddress(null), "");

// blackberryfarm.com really does answer "Home", and an idea called Home is
// worse than one named after the site.
t("a generic page title is not used as a place name",
  /\^\(home\|homepage\|welcome/.test(core), true);
t("the site name is preferred over it", /name = usable \|\| site \|\| host/.test(core), true);

console.log("\ncoordinates published by the property itself");
t("read straight off the page",
  geoOf({ geo: { "@type": "GeoCoordinates", latitude: 35.6512, longitude: -83.9385 } }),
  { latitude: 35.6512, longitude: -83.9385 });
t("strings are numbers here", geoOf({ geo: { latitude: "35.65", longitude: "-83.93" } }),
  { latitude: 35.65, longitude: -83.93 });
t("an array of one still works", geoOf({ geo: [{ latitude: 1.5, longitude: 2.5 }] }),
  { latitude: 1.5, longitude: 2.5 });
// 0,0 is in the Gulf of Guinea and is what an empty template serialises to.
t("null island is not a location", geoOf({ geo: { latitude: 0, longitude: 0 } }), null);
t("out-of-range values are refused", geoOf({ geo: { latitude: 991, longitude: 2 } }), null);
t("no geo block, no coordinates", geoOf({ name: "Somewhere" }), null);
t("nothing at all", geoOf(null), null);

console.log("\nand what the client does with them");
t("the form is prefilled from the page", /address: info\.address \|\| ""/.test(app), true);
t("coordinates included", /latitude: info\.latitude != null \? info\.latitude : null/.test(app), true);
// A pin read off the page is exact; a pin inferred from an address is not. The
// difference is worth saying before it is saved.
t("it says when the pin came from the page itself", /info\.geo_source === "page"/.test(app), true);
t("and the server reports which it was", /geo_source: geo \? "page" : /.test(core), true);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
