// The text that goes out by Message, WhatsApp or mail.
//
// It arrived as one unbroken paragraph. The cause was leading whitespace: items
// were indented two spaces and their detail six, and runs of spaces collapse in
// most of these targets, so every line ran into the next. This suite pins the
// two things that fixed it — no indentation anywhere, and one line per item —
// plus what must NOT be in the message: addresses and confirmation codes.
//
// The fixtures are invented. Real confirmation codes and addresses do not
// belong in the repository, and a test for "the code is absent" works just as
// well with a made-up one.
const fs = require("fs");
const src = fs.readFileSync("public/app.js", "utf8");

function grab(name) {
  const i = src.indexOf("  function " + name + "(");
  if (i < 0) throw new Error("missing " + name);
  let d = 0, seen = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === "{") { d++; seen = true; }
    else if (src[j] === "}") { d--; if (seen && !d) return src.slice(i, j + 1); }
  }
  throw new Error("unterminated " + name);
}

// Stub only what itineraryText reaches for. orderedEntries and buildEntries pull
// in display settings and icon tables that have nothing to do with formatting.
const ENTRIES = {
  scheduled: [
    { kind: "transport", when: "2026-08-04T13:00:00Z", tz: "UTC",
      title: "Delta Air Lines DL395", meta: "Dep 1:00 PM · Arr 8:25 PM",
      sub: "Los Angeles (LAX)  →  Atlanta (ATL)",
      obj: { provider_reservation_code: "ZZZ999" } },
    { kind: "hosting", when: "2026-08-04T22:00:00Z", tz: "UTC",
      title: "Hotel Example · Check-in", meta: "10:00 PM",
      sub: "1 Example Street, Atlanta, GA 30301",
      obj: { provider_reservation_code: "AAA111" } },
    { kind: "activity", when: "2026-08-05T09:30:00Z", tz: "UTC",
      title: "Walking tour", meta: "All day",
      sub: "2 Sample Avenue, Atlanta", obj: {} },
  ],
  unscheduled: [{ kind: "activity", title: "Find a coffee place", obj: {} }],
};
globalThis.orderedEntries = () => ENTRIES;
globalThis.dayKey = (w) => String(w).slice(0, 10);
globalThis.dayLabel = (k) => ({ "2026-08-04": "Tue, Aug 4, 2026", "2026-08-05": "Wed, Aug 5, 2026" }[k] || k);
globalThis.fmtTime = () => "9:30 AM";
globalThis.fmtRange = () => "Aug 4 – 5, 2026";
globalThis.spanDays = () => 2;
globalThis.tripTravellers = () => [{ name: "Alex" }, { name: "Sam" }];

eval(grab("itineraryText") + ";globalThis.itineraryText = itineraryText;");

let pass = 0, fail = 0;
const t = (label, got, want) => {
  const ok = got === want;
  ok ? pass++ : fail++;
  console.log("  " + (ok ? "ok  " : "FAIL") + "  " + label);
  if (!ok) console.log("        want " + JSON.stringify(want) + "\n        got  " + JSON.stringify(got));
};

const text = itineraryText({ name: "Test Trip", has_dates: true }, {});
const lines = text.split("\n");

// ---- the regression -------------------------------------------------------
t("no line begins with a space", lines.some(l => /^\s/.test(l)), false);
t("no line contains a run of spaces", lines.some(l => /  /.test(l)), false);
t("more than one line", lines.length > 5, true);

// ---- structure ------------------------------------------------------------
t("opens with the trip name", lines[0], "Test Trip");
t("then the dates", lines[1], "Aug 4 – 5, 2026 · 2 days");
t("then who is going", lines[2], "Travelling: Alex, Sam");
t("a blank line before the itinerary", lines[3], "");
t("day headings are upper case", lines[4], "TUE, AUG 4, 2026");
t("days are separated by a blank line", text.indexOf("\n\nWED, AUG 5, 2026") > 0, true);
t("unscheduled work is labelled", text.indexOf("\n\nNOT SCHEDULED\n") > 0, true);
t("no run of three newlines", /\n{3,}/.test(text), false);

// ---- one line per item ----------------------------------------------------
t("the flight is one line", lines[5], "Dep 1:00 PM · Arr 8:25 PM — Delta Air Lines DL395 (Los Angeles (LAX) → Atlanta (ATL))");
t("check-in is one line", lines[6], "10:00 PM — Hotel Example · Check-in");

// ---- what must not travel -------------------------------------------------
// A confirmation code in a group chat is a booking reference in a place nobody
// can revoke. Both fixtures carry one; neither may appear.
t("no confirmation code", /ZZZ999|AAA111/.test(text), false);
t("the word Conf never appears", /\bConf\b/.test(text), false);
t("no hotel street address", text.indexOf("1 Example Street") >= 0, false);
t("no activity street address", text.indexOf("2 Sample Avenue") >= 0, false);
// The airport pair is how you tell one flight from another, so it stays.
t("the flight route survives", text.indexOf("(LAX) → Atlanta (ATL)") >= 0, true);

// ---- the route only appears when it says something ------------------------
// A hire car's two ends are the same depot, and the depot is the company, so
// the raw field read "Adobe Rent A Car · Pick-up (Adobe Rent a Car → Adobe Rent
// a Car)". Real data produced that; the fixtures above never would have.
const CAR = {
  scheduled: [
    { kind: "transport", when: "2026-08-04T19:30:00Z", tz: "UTC",
      title: "Adobe Rent A Car · Pick-up", meta: "Pick-up 7:30 PM",
      sub: "Adobe Rent a Car  →  Adobe Rent a Car", obj: {} },
    { kind: "transport", when: "2026-08-05T21:30:00Z", tz: "UTC",
      title: "Adobe Rent A Car · Drop-off", meta: "Drop-off 9:30 PM",
      sub: "Adobe Rent a Car", obj: {} },
    { kind: "transport", when: "2026-08-05T22:00:00Z", tz: "UTC",
      title: "Iberia IB6250", meta: "Dep 10:00 PM",
      sub: "Madrid (MAD)  →  Lisbon (LIS)", obj: {} },
  ],
  unscheduled: [],
};
globalThis.orderedEntries = () => CAR;
const carText = itineraryText({ name: "Car Trip", has_dates: true }, {});
t("a repeated depot is not printed", /\(Adobe/.test(carText), false);
t("a depot the title already gave is not repeated", carText.indexOf("Pick-up (") >= 0, false);
t("neither is the drop-off end", carText.indexOf("Drop-off (") >= 0, false);
t("a genuine route still prints", carText.indexOf("(Madrid (MAD) → Lisbon (LIS))") >= 0, true);

console.log("\n  " + pass + " passed, " + fail + " failed");
process.exit(fail ? 1 : 0);
